﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main

    'Is presumed that the device settings are commons for all users.
    'Users without administration rights can't change these settings,
    'with the only exclusions of tray icon and sharing capability.

    Dim devsettingsfolder As String = My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData '& "\"
    Dim usersettingsfolder As String = My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData '& "\"

    Private Sub LoadDeviceSettings(ByVal device As Device)
        'avoid to search and load an existing setting file
        If installdevice = StoringDevice.Removable Then Exit Sub
        Dim filename As String = device.Model & "_" & device.SerialNumber
        'replace all non valid characters for file names
        filename = filename.Replace("\", "").Replace("/", "").Replace(":", "").Replace("?", "").Replace("""", "") _
            .Replace("<", "").Replace(">", "").Replace("|", "")

        Dim i As Short = devsettingsfolder.LastIndexOf("\")
        Dim folder As String = devsettingsfolder.Substring(0, i + 1)

        If IO.File.Exists(folder & filename) Then
            Dim settings As String = IO.File.ReadAllText(folder & filename, System.Text.Encoding.Default)

            If settings.Length > 0 Then
                ParseOptions(settings)
            End If

            device.Options = settings
        End If
    End Sub

    Private Sub SaveDeviceSettings()
        If lvwDevices.Items.Count = 0 Then Exit Sub
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        Dim filename As String = dev.Model & "_" & dev.SerialNumber
        'replace all non valid characters for file names
        filename = filename.Replace("\", "").Replace("/", "").Replace(":", "").Replace("?", "").Replace("""", "") _
            .Replace("<", "").Replace(">", "").Replace("|", "")

        Dim tolerance As String = ""
        If chkTolerance.Checked Then
            Select Case cboTolerance.SelectedIndex
                Case 0 'normal
                    tolerance = "-T normal "
                Case 1 'conservative
                    tolerance = "-T conservative "
                Case 2 'very permissive
                    tolerance = "-T verypermissive "
            End Select
        End If

        Dim attrformat As String = ""
        If chkAttributes.Checked Then
            With lvwAttrFormat
                If .Items.Count > 0 Then
                    For i As Integer = 0 To .Items.Count - 1
                        attrformat = attrformat & "-v " & .Items(i).Text & "," & _
                        .Items(i).SubItems(1).Text & "," & .Items(i).SubItems(2).Text & " "
                    Next
                End If
            End With
        End If

        Dim fdebug As String = ""
        Dim swap As String = ""
        If chkFirmware.Checked Then
            Select Case cboFirmware.SelectedIndex
                Case 0
                    fdebug = "-F none "
                Case 1
                    fdebug = "-F samsung "
                Case 2
                    fdebug = "-F samsung2 "
                Case 3
                    fdebug = "-F samsung3 "
            End Select
            If chkFixSwap.Checked Then swap = "-F swapid "
        End If

        Dim attrautosave As String = ""
        If picAttrAutosave.Tag = "on" Then attrautosave = "-S on "

        Dim content As String = tolerance & attrformat & fdebug & swap & attrautosave

        Dim s As Short = devsettingsfolder.LastIndexOf("\")
        Dim folder As String = devsettingsfolder.Substring(0, s + 1)

        dev.Options = tolerance & attrformat & fdebug & swap & attrautosave
        If dev.Options.Length > 0 Then
            FileIO.FileSystem.WriteAllText(folder & filename, content, False)
        Else
            If IO.File.Exists(folder & filename) Then
                IO.File.Delete(folder & filename)
            End If
        End If

    End Sub

    Private Sub LoadMonitoringSettings(ByVal device As Device)
        'avoid to search and load an existing setting file
        If installdevice = StoringDevice.Removable Then Exit Sub

        Dim filename As String = device.Model & "_" & device.SerialNumber
        'replace all non valid characters for file names
        filename = filename.Replace("\", "").Replace("/", "").Replace(":", "").Replace("?", "").Replace("""", "") _
            .Replace("<", "").Replace(">", "").Replace("|", "")

        Dim i As Short = usersettingsfolder.LastIndexOf("\")
        Dim folder As String = usersettingsfolder.Substring(0, i + 1)

        If IO.File.Exists(folder & filename) Then
            Dim settings() As String = IO.File.ReadAllLines(folder & filename, System.Text.Encoding.Default)

            'tray icon
            If settings(0) = "0" Then
                device.ShowTrayIcon = False
                picTrayIcon.Image = My.Resources.switch_off
            Else
                device.ShowTrayIcon = True
                picTrayIcon.Image = My.Resources.switch_on
            End If

            'sharing option
            If IO.Directory.Exists(m_sharingfolder) Then
                If settings(1) = "0" Then
                    device.IsShared = False
                    picShareOutput.Image = My.Resources.switch_off
                Else
                    device.IsShared = True
                    picShareOutput.Image = My.Resources.switch_on
                End If
            Else
                device.IsShared = False
                picShareOutput.Image = My.Resources.switch_na
            End If
        End If
    End Sub

    Private Sub SaveMonitoringSettings()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        Dim filename As String = dev.Model & "_" & dev.SerialNumber
        'replace all non valid characters for file names
        filename = filename.Replace("\", "").Replace("/", "").Replace(":", "").Replace("?", "").Replace("""", "") _
            .Replace("<", "").Replace(">", "").Replace("|", "")

        Dim trayicon As String = "0"
        If dev.ShowTrayIcon Then trayicon = "1"

        Dim share As String = "0"
        If dev.IsShared Then share = "1"

        Dim content As String = trayicon & vbCrLf & share

        Dim i As Short = usersettingsfolder.LastIndexOf("\")
        Dim folder As String = usersettingsfolder.Substring(0, i + 1)

        FileIO.FileSystem.WriteAllText(folder & filename, content, False)
    End Sub

    Private Sub ParseOptions(ByVal options As String)
        isloading_devsettings = True 'this prevent a not required saving for device settings

        picAttrAutosave.Image = My.Resources.switch_off
        picAttrAutosave.Tag = ""
        chkTolerance.Checked = False
        chkAttributes.Checked = False
        chkFirmware.Checked = False
        lvwAttrFormat.Items.Clear()

        If options = Nothing Then Exit Sub

        Dim commands() As String = options.Split("-", 255, StringSplitOptions.RemoveEmptyEntries)

        chkTolerance.Enabled = True
        chkAttributes.Enabled = True
        chkFirmware.Enabled = True
        picAttrAutosave.Enabled = True

        For i As Integer = 0 To commands.Length - 1
            Dim Param() As Char = commands(i).Trim.ToCharArray

            Select Case Param(0)
                Case "T"
                    chkTolerance.Checked = True
                    If commands(i).Contains("normal") Then cboTolerance.SelectedIndex = 0
                    If commands(i).Contains("conservative") Then cboTolerance.SelectedIndex = 1
                    If commands(i).Contains("verypermissive") Then cboTolerance.SelectedIndex = 2
                Case "v"
                    chkAttributes.Checked = True
                    Dim Attribute() As String = commands(i).Substring(1).Trim.Split(",")
                    If Attribute.Length = 2 Then
                        With lvwAttrFormat
                            .Items.Add(Attribute(0))
                            .Items(.Items.Count - 1).SubItems.Add(Attribute(1))
                        End With
                    Else
                        With lvwAttrFormat
                            .Items.Add(Attribute(0))
                            .Items(.Items.Count - 1).SubItems.Add(Attribute(1))
                            .Items(.Items.Count - 1).SubItems.Add(Attribute(2))
                        End With
                    End If
                Case "F"
                    chkFirmware.Checked = True
                    If commands(i).Contains("none") Then cboFirmware.SelectedIndex = 0
                    If commands(i).Contains("samsung") Then cboFirmware.SelectedIndex = 1
                    If commands(i).Contains("samsung2") Then cboFirmware.SelectedIndex = 2
                    If commands(i).Contains("samsung3") Then cboFirmware.SelectedIndex = 3
                    If commands(i).Contains("swapid") Then chkFixSwap.Checked = True
                Case "S"
                    If commands(i).Contains("on") Then
                        picAttrAutosave.Image = My.Resources.switch_on
                        picAttrAutosave.Tag = "on"
                    Else
                        picAttrAutosave.Image = My.Resources.switch_off
                        picAttrAutosave.Tag = ""
                    End If

            End Select
        Next

        isloading_devsettings = False
    End Sub
End Class
