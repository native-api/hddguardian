﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main

    Private Class TrayIcon
        Private WithEvents ti As New NotifyIcon
        Dim m_visible As Boolean
        Dim m_title, m_content As String
        Dim m_icon As System.Drawing.Icon

        Private Sub ti_MouseDown(ByVal sedender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ti.MouseDown
            Select Case e.Button
                Case Windows.Forms.MouseButtons.Left
                    'restore main screen
                    Main.WindowState = FormWindowState.Normal
                    Main.ShowInTaskbar = True
                    Main.Visible = True
                    Main.Activate()
                    Main.niTrayIcon.Visible = My.Settings.AlwaysShowTrayIcon
                Case Windows.Forms.MouseButtons.Middle
                    'if is pressed the middle button refresh all devices
                    Main.UpdateAll()
                Case Windows.Forms.MouseButtons.Right
                    'show device tooltip
                    Me.ti.ShowBalloonTip(3000)
            End Select
        End Sub

        Public Property Visible As Boolean
            Get
                Return m_visible
            End Get
            Set(ByVal value As Boolean)
                m_visible = value
                Me.ti.Visible = value
            End Set
        End Property

        Public Property Title As String
            Get
                Return m_title
            End Get
            Set(ByVal value As String)
                m_title = value
                Me.ti.BalloonTipTitle = value
                Me.ti.Text = value
            End Set
        End Property

        Public Property Content As String
            Get
                Return m_content
            End Get
            Set(ByVal value As String)
                m_content = value
                Me.ti.BalloonTipText = value
            End Set
        End Property

        Public Property Icon As System.Drawing.Icon
            Get
                Return m_icon
            End Get
            Set(ByVal value As System.Drawing.Icon)
                m_icon = value
                Me.ti.Icon = value
            End Set
        End Property

    End Class

    Dim m_devtrayicon() As TrayIcon

    Private Function GetTrayIcon(ByVal temperature As String, ByVal health As Status) As Icon
        Dim trayicons As Bitmap = My.Resources.devices_tray_icons

        Select Case health
            Case Status.Failed
                If IsNumeric(temperature) Then
                    If temperature > 99 Then temperature = 99
                    Dim rect As New Rectangle(temperature * 16, 16, 16, 16)
                    Dim geticon As IntPtr = trayicons.Clone(rect, trayicons.PixelFormat).GetHicon
                    Return Icon.FromHandle(geticon)
                Else
                    Dim rect As New Rectangle(100 * 16, 16, 16, 16)
                    Dim geticon As IntPtr = trayicons.Clone(rect, trayicons.PixelFormat).GetHicon
                    Return Icon.FromHandle(geticon)
                End If
            Case Status.Passed
                If IsNumeric(temperature) Then
                    If temperature > 99 Then temperature = 99
                    Dim rect As New Rectangle(temperature * 16, 0, 16, 16)
                    Dim geticon As IntPtr = trayicons.Clone(rect, trayicons.PixelFormat).GetHicon
                    Return Icon.FromHandle(geticon)
                Else
                    Dim rect As New Rectangle(100 * 16, 0, 16, 16)
                    Dim geticon As IntPtr = trayicons.Clone(rect, trayicons.PixelFormat).GetHicon
                    Return Icon.FromHandle(geticon)
                End If
            Case Status.Unkonwn
                If IsNumeric(temperature) Then
                    'if device health is unknown, normally no SMART attributes are available...
                Else
                    Dim rect As New Rectangle(101 * 16, 0, 16, 16)
                    Dim geticon As IntPtr = trayicons.Clone(rect, trayicons.PixelFormat).GetHicon
                    Return Icon.FromHandle(geticon)
                End If
        End Select
        Return Nothing
    End Function

    Private Sub DestroyTrayIcons()
        If IsNothing(m_devtrayicon) Then Exit Sub
        For i As Short = 0 To m_devtrayicon.Count - 1
            m_devtrayicon(i).Visible = False
        Next
    End Sub

    Private Sub SetTrayIcons()
        Dim ph As Integer = 0

        For Each dev As Device In devicelist
            If (dev.Type = DeviceType.Physical Or dev.Type = DeviceType.Removable) Then ph += 1
        Next

        ReDim m_devtrayicon(ph - 1)
        For i As Short = 0 To m_devtrayicon.Count - 1
            m_devtrayicon(i) = New TrayIcon
        Next

        UpdateTrayIcons()
    End Sub

    Private Sub UpdateTrayIcons()
        Dim icn As Short = 0

        For i As Short = 0 To devicelist.Count - 1
            Dim dev As Device = devicelist(i)
            Dim temp As String
            If (dev.Type = DeviceType.Physical Or dev.Type = DeviceType.Removable) And dev.ShowTrayIcon = True Then
                With m_devtrayicon(icn)
                    .Visible = True
                    .Icon = GetTrayIcon(dev.Temperature, dev.Health)
                    .Title = dev.Model

                    If IsNumeric(dev.Temperature) Then
                        temp = dev.Temperature & "°C"
                    Else
                        temp = dev.Temperature
                    End If

                    Select Case dev.Health
                        Case Status.Failed
                            .Content = m_temperature & ": " & temp & vbCrLf & _
                                m_overallhealth & ": " & h_overallfailed
                        Case Status.Passed
                            .Content = m_temperature & ": " & temp & vbCrLf & _
                                m_overallhealth & ": " & h_overallpassed
                        Case Status.Unkonwn
                            .Content = m_temperature & ": " & temp & vbCrLf & _
                                m_overallhealth & ": " & h_unknown
                    End Select
                    icn += 1
                End With
            End If
        Next
    End Sub

End Class
