﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HealthPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim flwTemperature As System.Windows.Forms.FlowLayoutPanel
        Dim flwWarnings As System.Windows.Forms.FlowLayoutPanel
        Dim pnlWarning As System.Windows.Forms.Panel
        Me.pbTemp = New System.Windows.Forms.PictureBox()
        Me.lblTempValue = New System.Windows.Forms.Label()
        Me.lblWarningValue = New System.Windows.Forms.Label()
        Me.lnkWeb1 = New System.Windows.Forms.LinkLabel()
        Me.lnkWeb2 = New System.Windows.Forms.LinkLabel()
        Me.lnkWeb3 = New System.Windows.Forms.LinkLabel()
        Me.pbWarning = New System.Windows.Forms.PictureBox()
        Me.lblLastUpdateValue = New System.Windows.Forms.Label()
        Me.tlpMain = New System.Windows.Forms.TableLayoutPanel()
        Me.lblTemperature = New System.Windows.Forms.Label()
        Me.lblLastTest = New System.Windows.Forms.Label()
        Me.flwLastTest = New System.Windows.Forms.FlowLayoutPanel()
        Me.pbLastTest = New System.Windows.Forms.PictureBox()
        Me.lblLastTestValue = New System.Windows.Forms.Label()
        Me.flwOverallHealth = New System.Windows.Forms.FlowLayoutPanel()
        Me.pbOverallHealth = New System.Windows.Forms.PictureBox()
        Me.lblOverallHealthValue = New System.Windows.Forms.Label()
        Me.lblBadSectorsValue = New System.Windows.Forms.Label()
        Me.lblOverallHealth = New System.Windows.Forms.Label()
        Me.lblLastUpdate = New System.Windows.Forms.Label()
        Me.lblWarning = New System.Windows.Forms.Label()
        flwTemperature = New System.Windows.Forms.FlowLayoutPanel()
        flwWarnings = New System.Windows.Forms.FlowLayoutPanel()
        pnlWarning = New System.Windows.Forms.Panel()
        flwTemperature.SuspendLayout()
        CType(Me.pbTemp, System.ComponentModel.ISupportInitialize).BeginInit()
        flwWarnings.SuspendLayout()
        pnlWarning.SuspendLayout()
        CType(Me.pbWarning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tlpMain.SuspendLayout()
        Me.flwLastTest.SuspendLayout()
        CType(Me.pbLastTest, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.flwOverallHealth.SuspendLayout()
        CType(Me.pbOverallHealth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'flwTemperature
        '
        flwTemperature.AutoSize = True
        flwTemperature.Controls.Add(Me.pbTemp)
        flwTemperature.Controls.Add(Me.lblTempValue)
        flwTemperature.Dock = System.Windows.Forms.DockStyle.Top
        flwTemperature.Location = New System.Drawing.Point(88, 0)
        flwTemperature.Margin = New System.Windows.Forms.Padding(0)
        flwTemperature.Name = "flwTemperature"
        flwTemperature.Size = New System.Drawing.Size(324, 20)
        flwTemperature.TabIndex = 34
        '
        'pbTemp
        '
        Me.pbTemp.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pbTemp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pbTemp.Location = New System.Drawing.Point(2, 2)
        Me.pbTemp.Margin = New System.Windows.Forms.Padding(2)
        Me.pbTemp.Name = "pbTemp"
        Me.pbTemp.Size = New System.Drawing.Size(16, 16)
        Me.pbTemp.TabIndex = 2
        Me.pbTemp.TabStop = False
        '
        'lblTempValue
        '
        Me.lblTempValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblTempValue.AutoSize = True
        Me.lblTempValue.Location = New System.Drawing.Point(23, 3)
        Me.lblTempValue.Name = "lblTempValue"
        Me.lblTempValue.Size = New System.Drawing.Size(69, 13)
        Me.lblTempValue.TabIndex = 1
        Me.lblTempValue.Text = "lblTempValue"
        '
        'flwWarnings
        '
        flwWarnings.AutoSize = True
        flwWarnings.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        flwWarnings.Controls.Add(Me.lblWarningValue)
        flwWarnings.Controls.Add(Me.lnkWeb1)
        flwWarnings.Controls.Add(Me.lnkWeb2)
        flwWarnings.Controls.Add(Me.lnkWeb3)
        flwWarnings.Dock = System.Windows.Forms.DockStyle.Top
        flwWarnings.Location = New System.Drawing.Point(0, 0)
        flwWarnings.Margin = New System.Windows.Forms.Padding(0)
        flwWarnings.Name = "flwWarnings"
        flwWarnings.Padding = New System.Windows.Forms.Padding(20, 0, 0, 0)
        flwWarnings.Size = New System.Drawing.Size(324, 64)
        flwWarnings.TabIndex = 37
        '
        'lblWarningValue
        '
        Me.lblWarningValue.AutoSize = True
        flwWarnings.SetFlowBreak(Me.lblWarningValue, True)
        Me.lblWarningValue.Location = New System.Drawing.Point(23, 0)
        Me.lblWarningValue.Name = "lblWarningValue"
        Me.lblWarningValue.Padding = New System.Windows.Forms.Padding(0, 3, 0, 3)
        Me.lblWarningValue.Size = New System.Drawing.Size(83, 19)
        Me.lblWarningValue.TabIndex = 14
        Me.lblWarningValue.Text = "lblWarningValue"
        '
        'lnkWeb1
        '
        Me.lnkWeb1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkWeb1.AutoSize = True
        flwWarnings.SetFlowBreak(Me.lnkWeb1, True)
        Me.lnkWeb1.Location = New System.Drawing.Point(23, 19)
        Me.lnkWeb1.Name = "lnkWeb1"
        Me.lnkWeb1.Padding = New System.Windows.Forms.Padding(0, 0, 0, 3)
        Me.lnkWeb1.Size = New System.Drawing.Size(48, 16)
        Me.lnkWeb1.TabIndex = 15
        Me.lnkWeb1.TabStop = True
        Me.lnkWeb1.Text = "lnkWeb1"
        '
        'lnkWeb2
        '
        Me.lnkWeb2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkWeb2.AutoSize = True
        flwWarnings.SetFlowBreak(Me.lnkWeb2, True)
        Me.lnkWeb2.Location = New System.Drawing.Point(23, 35)
        Me.lnkWeb2.Name = "lnkWeb2"
        Me.lnkWeb2.Padding = New System.Windows.Forms.Padding(0, 0, 0, 3)
        Me.lnkWeb2.Size = New System.Drawing.Size(48, 16)
        Me.lnkWeb2.TabIndex = 16
        Me.lnkWeb2.TabStop = True
        Me.lnkWeb2.Text = "lnkWeb2"
        '
        'lnkWeb3
        '
        Me.lnkWeb3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkWeb3.AutoSize = True
        flwWarnings.SetFlowBreak(Me.lnkWeb3, True)
        Me.lnkWeb3.Location = New System.Drawing.Point(23, 51)
        Me.lnkWeb3.Name = "lnkWeb3"
        Me.lnkWeb3.Size = New System.Drawing.Size(48, 13)
        Me.lnkWeb3.TabIndex = 17
        Me.lnkWeb3.TabStop = True
        Me.lnkWeb3.Text = "lnkWeb3"
        '
        'pnlWarning
        '
        pnlWarning.AutoSize = True
        pnlWarning.Controls.Add(Me.pbWarning)
        pnlWarning.Controls.Add(flwWarnings)
        pnlWarning.Dock = System.Windows.Forms.DockStyle.Top
        pnlWarning.Location = New System.Drawing.Point(88, 109)
        pnlWarning.Margin = New System.Windows.Forms.Padding(0)
        pnlWarning.Name = "pnlWarning"
        pnlWarning.Size = New System.Drawing.Size(324, 64)
        pnlWarning.TabIndex = 42
        '
        'pbWarning
        '
        Me.pbWarning.Location = New System.Drawing.Point(2, 2)
        Me.pbWarning.Margin = New System.Windows.Forms.Padding(2)
        Me.pbWarning.Name = "pbWarning"
        Me.pbWarning.Size = New System.Drawing.Size(16, 16)
        Me.pbWarning.TabIndex = 13
        Me.pbWarning.TabStop = False
        '
        'lblLastUpdateValue
        '
        Me.lblLastUpdateValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblLastUpdateValue.AutoSize = True
        Me.lblLastUpdateValue.Location = New System.Drawing.Point(91, 83)
        Me.lblLastUpdateValue.Name = "lblLastUpdateValue"
        Me.lblLastUpdateValue.Padding = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.lblLastUpdateValue.Size = New System.Drawing.Size(98, 16)
        Me.lblLastUpdateValue.TabIndex = 0
        Me.lblLastUpdateValue.Text = "lblLastUpdateValue"
        Me.lblLastUpdateValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tlpMain
        '
        Me.tlpMain.AutoSize = True
        Me.tlpMain.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpMain.ColumnCount = 2
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpMain.Controls.Add(Me.lblTemperature, 0, 0)
        Me.tlpMain.Controls.Add(flwTemperature, 1, 0)
        Me.tlpMain.Controls.Add(Me.lblLastTest, 0, 1)
        Me.tlpMain.Controls.Add(Me.flwLastTest, 1, 1)
        Me.tlpMain.Controls.Add(Me.flwOverallHealth, 1, 2)
        Me.tlpMain.Controls.Add(Me.lblOverallHealth, 0, 2)
        Me.tlpMain.Controls.Add(Me.lblLastUpdate, 0, 4)
        Me.tlpMain.Controls.Add(Me.lblLastUpdateValue, 1, 4)
        Me.tlpMain.Controls.Add(Me.lblWarning, 0, 6)
        Me.tlpMain.Controls.Add(pnlWarning, 1, 6)
        Me.tlpMain.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpMain.Location = New System.Drawing.Point(0, 0)
        Me.tlpMain.Margin = New System.Windows.Forms.Padding(0)
        Me.tlpMain.Name = "tlpMain"
        Me.tlpMain.RowCount = 7
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.Size = New System.Drawing.Size(412, 173)
        Me.tlpMain.TabIndex = 0
        '
        'lblTemperature
        '
        Me.lblTemperature.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblTemperature.AutoSize = True
        Me.lblTemperature.Location = New System.Drawing.Point(6, 3)
        Me.lblTemperature.Name = "lblTemperature"
        Me.lblTemperature.Size = New System.Drawing.Size(79, 13)
        Me.lblTemperature.TabIndex = 0
        Me.lblTemperature.Text = "lblTemperature"
        '
        'lblLastTest
        '
        Me.lblLastTest.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblLastTest.AutoSize = True
        Me.lblLastTest.Location = New System.Drawing.Point(27, 23)
        Me.lblLastTest.Name = "lblLastTest"
        Me.lblLastTest.Size = New System.Drawing.Size(58, 13)
        Me.lblLastTest.TabIndex = 6
        Me.lblLastTest.Text = "lblLastTest"
        '
        'flwLastTest
        '
        Me.flwLastTest.AutoSize = True
        Me.flwLastTest.Controls.Add(Me.pbLastTest)
        Me.flwLastTest.Controls.Add(Me.lblLastTestValue)
        Me.flwLastTest.Dock = System.Windows.Forms.DockStyle.Top
        Me.flwLastTest.Location = New System.Drawing.Point(88, 20)
        Me.flwLastTest.Margin = New System.Windows.Forms.Padding(0)
        Me.flwLastTest.Name = "flwLastTest"
        Me.flwLastTest.Size = New System.Drawing.Size(324, 20)
        Me.flwLastTest.TabIndex = 35
        '
        'pbLastTest
        '
        Me.pbLastTest.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pbLastTest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pbLastTest.Location = New System.Drawing.Point(2, 2)
        Me.pbLastTest.Margin = New System.Windows.Forms.Padding(2)
        Me.pbLastTest.Name = "pbLastTest"
        Me.pbLastTest.Size = New System.Drawing.Size(16, 16)
        Me.pbLastTest.TabIndex = 7
        Me.pbLastTest.TabStop = False
        '
        'lblLastTestValue
        '
        Me.lblLastTestValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblLastTestValue.AutoSize = True
        Me.flwLastTest.SetFlowBreak(Me.lblLastTestValue, True)
        Me.lblLastTestValue.Location = New System.Drawing.Point(23, 3)
        Me.lblLastTestValue.Name = "lblLastTestValue"
        Me.lblLastTestValue.Size = New System.Drawing.Size(84, 13)
        Me.lblLastTestValue.TabIndex = 8
        Me.lblLastTestValue.Text = "lblLastTestValue"
        '
        'flwOverallHealth
        '
        Me.flwOverallHealth.AutoSize = True
        Me.flwOverallHealth.Controls.Add(Me.pbOverallHealth)
        Me.flwOverallHealth.Controls.Add(Me.lblOverallHealthValue)
        Me.flwOverallHealth.Controls.Add(Me.lblBadSectorsValue)
        Me.flwOverallHealth.Dock = System.Windows.Forms.DockStyle.Top
        Me.flwOverallHealth.Location = New System.Drawing.Point(88, 40)
        Me.flwOverallHealth.Margin = New System.Windows.Forms.Padding(0)
        Me.flwOverallHealth.Name = "flwOverallHealth"
        Me.flwOverallHealth.Size = New System.Drawing.Size(324, 33)
        Me.flwOverallHealth.TabIndex = 36
        '
        'pbOverallHealth
        '
        Me.pbOverallHealth.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pbOverallHealth.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pbOverallHealth.Location = New System.Drawing.Point(2, 2)
        Me.pbOverallHealth.Margin = New System.Windows.Forms.Padding(2)
        Me.pbOverallHealth.Name = "pbOverallHealth"
        Me.pbOverallHealth.Size = New System.Drawing.Size(16, 16)
        Me.pbOverallHealth.TabIndex = 10
        Me.pbOverallHealth.TabStop = False
        '
        'lblOverallHealthValue
        '
        Me.lblOverallHealthValue.AutoSize = True
        Me.flwOverallHealth.SetFlowBreak(Me.lblOverallHealthValue, True)
        Me.lblOverallHealthValue.Location = New System.Drawing.Point(23, 0)
        Me.lblOverallHealthValue.Name = "lblOverallHealthValue"
        Me.lblOverallHealthValue.Padding = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.lblOverallHealthValue.Size = New System.Drawing.Size(108, 16)
        Me.lblOverallHealthValue.TabIndex = 11
        Me.lblOverallHealthValue.Text = "lblOverallHealthValue"
        '
        'lblBadSectorsValue
        '
        Me.lblBadSectorsValue.AutoSize = True
        Me.lblBadSectorsValue.Location = New System.Drawing.Point(3, 20)
        Me.lblBadSectorsValue.Name = "lblBadSectorsValue"
        Me.lblBadSectorsValue.Padding = New System.Windows.Forms.Padding(20, 0, 0, 0)
        Me.lblBadSectorsValue.Size = New System.Drawing.Size(117, 13)
        Me.lblBadSectorsValue.TabIndex = 5
        Me.lblBadSectorsValue.Text = "lblBadSectorsValue"
        '
        'lblOverallHealth
        '
        Me.lblOverallHealth.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblOverallHealth.AutoSize = True
        Me.lblOverallHealth.Location = New System.Drawing.Point(3, 43)
        Me.lblOverallHealth.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblOverallHealth.Name = "lblOverallHealth"
        Me.lblOverallHealth.Size = New System.Drawing.Size(82, 13)
        Me.lblOverallHealth.TabIndex = 9
        Me.lblOverallHealth.Text = "lblOverallHealth"
        '
        'lblLastUpdate
        '
        Me.lblLastUpdate.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblLastUpdate.AutoSize = True
        Me.lblLastUpdate.Location = New System.Drawing.Point(13, 83)
        Me.lblLastUpdate.Name = "lblLastUpdate"
        Me.lblLastUpdate.Padding = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.lblLastUpdate.Size = New System.Drawing.Size(72, 16)
        Me.lblLastUpdate.TabIndex = 30
        Me.lblLastUpdate.Text = "lblLastUpdate"
        Me.lblLastUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWarning
        '
        Me.lblWarning.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblWarning.AutoSize = True
        Me.lblWarning.Location = New System.Drawing.Point(28, 109)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.Padding = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.lblWarning.Size = New System.Drawing.Size(57, 16)
        Me.lblWarning.TabIndex = 12
        Me.lblWarning.Text = "lblWarning"
        '
        'HealthPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Controls.Add(Me.tlpMain)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MinimumSize = New System.Drawing.Size(300, 0)
        Me.Name = "HealthPanel"
        Me.Size = New System.Drawing.Size(412, 184)
        flwTemperature.ResumeLayout(False)
        flwTemperature.PerformLayout()
        CType(Me.pbTemp, System.ComponentModel.ISupportInitialize).EndInit()
        flwWarnings.ResumeLayout(False)
        flwWarnings.PerformLayout()
        pnlWarning.ResumeLayout(False)
        pnlWarning.PerformLayout()
        CType(Me.pbWarning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tlpMain.ResumeLayout(False)
        Me.tlpMain.PerformLayout()
        Me.flwLastTest.ResumeLayout(False)
        Me.flwLastTest.PerformLayout()
        CType(Me.pbLastTest, System.ComponentModel.ISupportInitialize).EndInit()
        Me.flwOverallHealth.ResumeLayout(False)
        Me.flwOverallHealth.PerformLayout()
        CType(Me.pbOverallHealth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Protected WithEvents lblTemperature As System.Windows.Forms.Label
    Protected WithEvents lblTempValue As System.Windows.Forms.Label
    Protected WithEvents pbTemp As System.Windows.Forms.PictureBox
    Protected WithEvents lblBadSectorsValue As System.Windows.Forms.Label
    Protected WithEvents lblLastTest As System.Windows.Forms.Label
    Protected WithEvents pbLastTest As System.Windows.Forms.PictureBox
    Protected WithEvents lblOverallHealth As System.Windows.Forms.Label
    Protected WithEvents pbOverallHealth As System.Windows.Forms.PictureBox
    Protected WithEvents lblOverallHealthValue As System.Windows.Forms.Label
    Protected WithEvents lblLastTestValue As System.Windows.Forms.Label
    Protected WithEvents lblWarning As System.Windows.Forms.Label
    Protected WithEvents pbWarning As System.Windows.Forms.PictureBox
    Protected WithEvents lblWarningValue As System.Windows.Forms.Label
    Protected WithEvents lnkWeb1 As System.Windows.Forms.LinkLabel
    Protected WithEvents lnkWeb2 As System.Windows.Forms.LinkLabel
    Protected WithEvents lnkWeb3 As System.Windows.Forms.LinkLabel
    Private WithEvents tlpMain As System.Windows.Forms.TableLayoutPanel
    Protected WithEvents lblLastUpdate As System.Windows.Forms.Label
    Protected WithEvents lblLastUpdateValue As System.Windows.Forms.Label
    Protected WithEvents flwLastTest As System.Windows.Forms.FlowLayoutPanel
    Protected WithEvents flwOverallHealth As System.Windows.Forms.FlowLayoutPanel

End Class
