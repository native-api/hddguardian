﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Drawing

Partial Class ValuesPanel

    Dim col As Color = Color.Black

    'letters A, E, H, L, O, R, S, T, U, V, W are the only used

    Private Sub A(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "A" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y)
            .DrawLine(letter, x, y - 2, x + 4, y - 2)
        End With
    End Sub

    Private Sub E(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "E" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
            .DrawLine(letter, x, y - 2, x + 2, y - 2)
        End With
    End Sub

    Private Sub H(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "H" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x + 4, y, x + 4, y - 4)
            .DrawLine(letter, x, y - 2, x + 4, y - 2)
        End With
    End Sub

    Private Sub L(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "L" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
        End With
    End Sub

    Private Sub O(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "O" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y)
            .DrawLine(letter, x, y, x + 4, y)
        End With
    End Sub

    Private Sub R(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "R" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y - 2)
            .DrawLine(letter, x + 4, y - 2, x, y - 2)
            .DrawLine(letter, x + 2, y - 2, x + 4, y)
        End With
    End Sub

    Private Sub S(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "S" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x, y - 4, x, y - 2)
            .DrawLine(letter, x, y - 2, x + 4, y - 2)
            .DrawLine(letter, x + 4, y - 2, x + 4, y)
            .DrawLine(letter, x + 4, y, x, y)
        End With
    End Sub

    Private Sub T(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "T" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 2, y, x + 2, y - 4)
        End With
    End Sub

    Private Sub U(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "U" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
            .DrawLine(letter, x + 4, y, x + 4, y - 4)
        End With
    End Sub

    Private Sub V(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "V" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y - 4, x, y - 2)
            .DrawLine(letter, x, y - 2, x + 2, y)
            .DrawLine(letter, x + 2, y, x + 4, y - 2)
            .DrawLine(letter, x + 4, y - 2, x + 4, y - 4)
        End With
    End Sub

    Private Sub W(ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(col, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "W" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
            .DrawLine(letter, x + 4, y, x + 4, y - 4)
            .DrawLine(letter, x + 2, y, x + 2, y - 4)
        End With
    End Sub
End Class
