﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Drawing

Partial Class ValuesPanel

    Enum Styles
        Blue = 0
        Red = 1
        Grey = 2
    End Enum

    Private Sub ProgressBar(ByVal x As Integer, ByVal y As Integer, ByVal style As Styles, ByVal value As Integer)
        Dim border1 As New Pen(Color.FromArgb(207, 207, 207), 1)
        Dim border2 As New Pen(Color.FromArgb(232, 232, 232), 1)
        Dim border3 As New Pen(Color.FromArgb(219, 219, 219), 1)
        Dim innerborder As New Pen(Color.FromArgb(161, 161, 161), 1)
        Dim filler As Brush = New SolidBrush((Color.FromArgb(211, 211, 211)))

        Dim g As Graphics = Me.CreateGraphics

        y = y - 7

        'draw progressbar background/container
        With g
            'background
            .FillRectangle(filler, x, y, 255, 7)
            'outher border
            .DrawRectangle(border3, x, y, 255, 7)
            .DrawLine(border1, x, y + 5, x, y)
            .DrawLine(border1, x, y, x + 254, y)
            .DrawLine(border2, x + 255, y + 1, x + 255, y + 7)
            .DrawLine(border2, x + 255, y + 7, x, y + 7)
            'inner border
            .DrawRectangle(innerborder, x + 1, y + 1, 253, 5)
        End With


        Dim border As New Pen(Color.FromArgb(83, 104, 126))
        Dim filler1 As Brush = New SolidBrush(Color.FromArgb(139, 178, 220))
        Dim filler2 As Brush = New SolidBrush(Color.FromArgb(114, 159, 207))
        Select Case style
            Case Styles.Blue

            Case Styles.Red
                border.Color = Color.FromArgb(150, 49, 49)
                filler1 = New SolidBrush(Color.FromArgb(212, 128, 128))
                filler2 = New SolidBrush(Color.FromArgb(203, 98, 98))
            Case Styles.Grey
                border.Color = Color.FromArgb(91, 91, 91)
                filler1 = New SolidBrush(Color.FromArgb(154, 154, 154))
                filler2 = New SolidBrush(Color.FromArgb(136, 136, 136))
        End Select

        'draw progressbar
        With g
            .DrawRectangle(border, x + 1, y + 1, value, 5)
            .FillRectangle(filler1, x + 2, y + 2, value - 1, 4)
            .FillRectangle(filler2, x + 3, y + 3, value - 2, 3)
        End With
    End Sub

End Class
