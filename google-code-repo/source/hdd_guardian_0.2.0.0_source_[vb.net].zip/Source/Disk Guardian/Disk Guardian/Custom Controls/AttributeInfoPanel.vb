﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Drawing
Imports System.ComponentModel

Public Class AttributeInfoPanel

    Dim m_type, m_updated As String

    Public Sub SetCaptions(Optional ByVal type As String = "Type", Optional ByVal updated As String = "Updated")
        m_type = type & ": "
        m_updated = updated & ": "
    End Sub

    Public Sub SetInfo(ByVal title As String, ByVal meaning As String, ByVal type As String, ByVal updated As String)
        lblTitle.Text = title
        lblMeaning.Text = meaning
        If type.Length > 0 Then lblType.Visible = True Else lblType.Visible = False
        If updated.Length > 0 Then lblUpdated.Visible = True Else lblUpdated.Visible = False
        lblType.Text = m_type & type
        lblUpdated.Text = m_updated & updated
    End Sub

    Public Sub New()

        ' Chiamata richiesta dalla finestra di progettazione.
        InitializeComponent()

        ' Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent().
        lblTitle.Text = ""
        lblMeaning.Text = ""
        lblType.Text = ""
        lblUpdated.Text = ""
    End Sub

#Region "Hidden properties"

    <System.ComponentModel.Browsable(False), _
    System.ComponentModel.EditorBrowsable(EditorBrowsableState.Never)> _
    Public Overrides Property BackgroundImage As System.Drawing.Image
        Get
            Return MyBase.BackgroundImage
        End Get
        Set(ByVal value As System.Drawing.Image)
            MyBase.BackgroundImage = value
        End Set
    End Property

    <System.ComponentModel.Browsable(False), _
    System.ComponentModel.EditorBrowsable(EditorBrowsableState.Never)> _
    Public Overrides Property BackgroundImageLayout As System.Windows.Forms.ImageLayout
        Get
            Return MyBase.BackgroundImageLayout
        End Get
        Set(ByVal value As System.Windows.Forms.ImageLayout)
            MyBase.BackgroundImageLayout = value
        End Set
    End Property
    
#End Region
End Class
