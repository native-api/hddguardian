﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.ComponentModel
Imports System.ComponentModel.Design

Public Class DeviceInfoPanel

    Public Sub New()

        ' Chiamata richiesta dalla finestra di progettazione.
        InitializeComponent()

        ' Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent().
        For Each Label In tlpGrid.Controls
            Label.Text = ""
        Next
    End Sub

    Public Sub SetCaptions(ByVal modelfamily As String, ByVal devicemodel As String, ByVal serialnumber As String, _
                           ByVal wwn As String, ByVal firmware As String, ByVal usercapacity As String, ByVal sectorsize As String, _
                           ByVal indatabase As String, ByVal ataversion As String, ByVal atastandard As String, _
                           ByVal lastcheck As String, ByVal smartavailable As String, ByVal smartenabled As String)
        lblFamily.Text = modelfamily & ":"
        lblModel.Text = devicemodel & ":"
        lblSerial.Text = serialnumber & ":"
        lblWwn.Text = wwn & ":"
        lblFirmware.Text = firmware & ":"
        lblSize.Text = usercapacity & ":"
        lblSectorSize.Text = sectorsize & ":"
        lblDatabase.Text = indatabase & ":"
        lblAtaVersion.Text = ataversion & ":"
        lblAtaStandard.Text = atastandard & ":"
        lblLastCheck.Text = lastcheck & ":"
        lblSmartAvailable.Text = smartavailable & ":"
        lblSmartEnabled.Text = smartenabled & ":"
    End Sub

    Public Sub ModelFamily(ByVal value As String)
        lblFamilyValue.Text = Value
    End Sub

    Public Sub DeviceModel(ByVal value As String)
        lblModelValue.Text = Value
    End Sub

    Public Sub SerialNumber(ByVal value As String)
        lblSerialValue.Text = Value
    End Sub

    Public Sub WorldWideName(ByVal value As String)
        lblWwnValue.Text = Value
    End Sub

    Public Sub FirmwareVersion(ByVal value As String)
        lblFirmwareValue.Text = Value
    End Sub

    Public Sub UserCapacity(ByVal value As String)
        lblSizeValue.Text = Value
    End Sub

    Public Sub SectorSize(ByVal value As String)
        lblSectorSizeValue.Text = Value
    End Sub

    Public Sub InDatabase(ByVal value As String)
        lblDatabaseValue.Text = Value
    End Sub

    Public Sub AtaVersion(ByVal value As String)
        lblAtaVersionValue.Text = Value
    End Sub

    Public Sub AtaStandard(ByVal value As String)
        lblAtaStandardValue.Text = Value
    End Sub

    Public Sub LastCheck(ByVal value As String)
        lblLastCheckValue.Text = Value
    End Sub

    Public Sub SmartAvailable(ByVal value As String)
        lblSmartAvailableValue.Text = Value
    End Sub

    Public Sub SmartEnabled(ByVal value As String)
        lblSmartEnabledValue.Text = Value
    End Sub
End Class
