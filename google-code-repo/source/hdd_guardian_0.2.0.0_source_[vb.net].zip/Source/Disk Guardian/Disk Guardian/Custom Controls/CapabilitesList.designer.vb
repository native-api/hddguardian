﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CapabilitesList
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpList = New System.Windows.Forms.TableLayoutPanel()
        Me.lblCap1 = New System.Windows.Forms.Label()
        Me.lblValue1 = New System.Windows.Forms.Label()
        Me.lblMeaning1 = New System.Windows.Forms.Label()
        Me.lblCap2 = New System.Windows.Forms.Label()
        Me.lblValue2 = New System.Windows.Forms.Label()
        Me.lblMeaning2 = New System.Windows.Forms.Label()
        Me.lblCap3 = New System.Windows.Forms.Label()
        Me.lblValue3 = New System.Windows.Forms.Label()
        Me.lblMeaning3 = New System.Windows.Forms.Label()
        Me.lblCap4 = New System.Windows.Forms.Label()
        Me.lblValue4 = New System.Windows.Forms.Label()
        Me.lblMeaning4 = New System.Windows.Forms.Label()
        Me.lblCap5 = New System.Windows.Forms.Label()
        Me.lblValue5 = New System.Windows.Forms.Label()
        Me.lblMeaning5 = New System.Windows.Forms.Label()
        Me.lblCap6 = New System.Windows.Forms.Label()
        Me.lblValue6 = New System.Windows.Forms.Label()
        Me.lblMeaning6 = New System.Windows.Forms.Label()
        Me.lblCap7 = New System.Windows.Forms.Label()
        Me.lblValue7 = New System.Windows.Forms.Label()
        Me.lblMeaning7 = New System.Windows.Forms.Label()
        Me.lblCap8 = New System.Windows.Forms.Label()
        Me.lblCap9 = New System.Windows.Forms.Label()
        Me.lblCap10 = New System.Windows.Forms.Label()
        Me.lblValue8 = New System.Windows.Forms.Label()
        Me.lblValue9 = New System.Windows.Forms.Label()
        Me.lblValue10 = New System.Windows.Forms.Label()
        Me.lblMeaning8 = New System.Windows.Forms.Label()
        Me.lblMeaning9 = New System.Windows.Forms.Label()
        Me.lblMeaning10 = New System.Windows.Forms.Label()
        Me.tlpList.SuspendLayout()
        Me.SuspendLayout()
        '
        'tlpList
        '
        Me.tlpList.AutoScroll = True
        Me.tlpList.AutoSize = True
        Me.tlpList.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpList.ColumnCount = 3
        Me.tlpList.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpList.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpList.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpList.Controls.Add(Me.lblCap1, 0, 0)
        Me.tlpList.Controls.Add(Me.lblValue1, 1, 0)
        Me.tlpList.Controls.Add(Me.lblMeaning1, 2, 0)
        Me.tlpList.Controls.Add(Me.lblCap2, 0, 1)
        Me.tlpList.Controls.Add(Me.lblValue2, 1, 1)
        Me.tlpList.Controls.Add(Me.lblMeaning2, 2, 1)
        Me.tlpList.Controls.Add(Me.lblCap3, 0, 2)
        Me.tlpList.Controls.Add(Me.lblValue3, 1, 2)
        Me.tlpList.Controls.Add(Me.lblMeaning3, 2, 2)
        Me.tlpList.Controls.Add(Me.lblCap4, 0, 3)
        Me.tlpList.Controls.Add(Me.lblValue4, 1, 3)
        Me.tlpList.Controls.Add(Me.lblMeaning4, 2, 3)
        Me.tlpList.Controls.Add(Me.lblCap5, 0, 4)
        Me.tlpList.Controls.Add(Me.lblValue5, 1, 4)
        Me.tlpList.Controls.Add(Me.lblMeaning5, 2, 4)
        Me.tlpList.Controls.Add(Me.lblCap6, 0, 5)
        Me.tlpList.Controls.Add(Me.lblValue6, 1, 5)
        Me.tlpList.Controls.Add(Me.lblMeaning6, 2, 5)
        Me.tlpList.Controls.Add(Me.lblCap7, 0, 6)
        Me.tlpList.Controls.Add(Me.lblValue7, 1, 6)
        Me.tlpList.Controls.Add(Me.lblMeaning7, 2, 6)
        Me.tlpList.Controls.Add(Me.lblCap8, 0, 7)
        Me.tlpList.Controls.Add(Me.lblCap9, 0, 8)
        Me.tlpList.Controls.Add(Me.lblCap10, 0, 9)
        Me.tlpList.Controls.Add(Me.lblValue8, 1, 7)
        Me.tlpList.Controls.Add(Me.lblValue9, 1, 8)
        Me.tlpList.Controls.Add(Me.lblValue10, 1, 9)
        Me.tlpList.Controls.Add(Me.lblMeaning8, 2, 7)
        Me.tlpList.Controls.Add(Me.lblMeaning9, 2, 8)
        Me.tlpList.Controls.Add(Me.lblMeaning10, 2, 9)
        Me.tlpList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpList.Location = New System.Drawing.Point(0, 0)
        Me.tlpList.MinimumSize = New System.Drawing.Size(500, 0)
        Me.tlpList.Name = "tlpList"
        Me.tlpList.RowCount = 10
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpList.Size = New System.Drawing.Size(515, 250)
        Me.tlpList.TabIndex = 0
        '
        'lblCap1
        '
        Me.lblCap1.AutoSize = True
        Me.lblCap1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCap1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap1.Location = New System.Drawing.Point(0, 0)
        Me.lblCap1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap1.Name = "lblCap1"
        Me.lblCap1.Size = New System.Drawing.Size(171, 13)
        Me.lblCap1.TabIndex = 0
        Me.lblCap1.Text = "lblCap1"
        '
        'lblValue1
        '
        Me.lblValue1.AutoSize = True
        Me.lblValue1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblValue1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue1.Location = New System.Drawing.Point(171, 0)
        Me.lblValue1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue1.Name = "lblValue1"
        Me.lblValue1.Size = New System.Drawing.Size(171, 13)
        Me.lblValue1.TabIndex = 1
        Me.lblValue1.Text = "lblValue1"
        Me.lblValue1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeaning1
        '
        Me.lblMeaning1.AutoSize = True
        Me.lblMeaning1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblMeaning1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning1.Location = New System.Drawing.Point(342, 0)
        Me.lblMeaning1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning1.Name = "lblMeaning1"
        Me.lblMeaning1.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning1.TabIndex = 2
        Me.lblMeaning1.Text = "lblMeaning1"
        '
        'lblCap2
        '
        Me.lblCap2.AutoSize = True
        Me.lblCap2.BackColor = System.Drawing.Color.White
        Me.lblCap2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap2.Location = New System.Drawing.Point(0, 13)
        Me.lblCap2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap2.Name = "lblCap2"
        Me.lblCap2.Size = New System.Drawing.Size(171, 13)
        Me.lblCap2.TabIndex = 3
        Me.lblCap2.Text = "lblCap2"
        '
        'lblValue2
        '
        Me.lblValue2.AutoSize = True
        Me.lblValue2.BackColor = System.Drawing.Color.White
        Me.lblValue2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue2.Location = New System.Drawing.Point(171, 13)
        Me.lblValue2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue2.Name = "lblValue2"
        Me.lblValue2.Size = New System.Drawing.Size(171, 13)
        Me.lblValue2.TabIndex = 4
        Me.lblValue2.Text = "lblValue2"
        Me.lblValue2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeaning2
        '
        Me.lblMeaning2.AutoSize = True
        Me.lblMeaning2.BackColor = System.Drawing.Color.White
        Me.lblMeaning2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning2.Location = New System.Drawing.Point(342, 13)
        Me.lblMeaning2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning2.Name = "lblMeaning2"
        Me.lblMeaning2.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning2.TabIndex = 5
        Me.lblMeaning2.Text = "lblMeaning2"
        '
        'lblCap3
        '
        Me.lblCap3.AutoSize = True
        Me.lblCap3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCap3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap3.Location = New System.Drawing.Point(0, 26)
        Me.lblCap3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap3.Name = "lblCap3"
        Me.lblCap3.Size = New System.Drawing.Size(171, 13)
        Me.lblCap3.TabIndex = 6
        Me.lblCap3.Text = "lblCap3"
        '
        'lblValue3
        '
        Me.lblValue3.AutoSize = True
        Me.lblValue3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblValue3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue3.Location = New System.Drawing.Point(171, 26)
        Me.lblValue3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue3.Name = "lblValue3"
        Me.lblValue3.Size = New System.Drawing.Size(171, 13)
        Me.lblValue3.TabIndex = 7
        Me.lblValue3.Text = "lblValue3"
        Me.lblValue3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeaning3
        '
        Me.lblMeaning3.AutoSize = True
        Me.lblMeaning3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblMeaning3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning3.Location = New System.Drawing.Point(342, 26)
        Me.lblMeaning3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning3.Name = "lblMeaning3"
        Me.lblMeaning3.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning3.TabIndex = 8
        Me.lblMeaning3.Text = "lblMeaning3"
        '
        'lblCap4
        '
        Me.lblCap4.AutoSize = True
        Me.lblCap4.BackColor = System.Drawing.Color.White
        Me.lblCap4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap4.Location = New System.Drawing.Point(0, 39)
        Me.lblCap4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap4.Name = "lblCap4"
        Me.lblCap4.Size = New System.Drawing.Size(171, 13)
        Me.lblCap4.TabIndex = 9
        Me.lblCap4.Text = "lblCap4"
        '
        'lblValue4
        '
        Me.lblValue4.AutoSize = True
        Me.lblValue4.BackColor = System.Drawing.Color.White
        Me.lblValue4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue4.Location = New System.Drawing.Point(171, 39)
        Me.lblValue4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue4.Name = "lblValue4"
        Me.lblValue4.Size = New System.Drawing.Size(171, 13)
        Me.lblValue4.TabIndex = 10
        Me.lblValue4.Text = "lblValue4"
        Me.lblValue4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeaning4
        '
        Me.lblMeaning4.AutoSize = True
        Me.lblMeaning4.BackColor = System.Drawing.Color.White
        Me.lblMeaning4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning4.Location = New System.Drawing.Point(342, 39)
        Me.lblMeaning4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning4.Name = "lblMeaning4"
        Me.lblMeaning4.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning4.TabIndex = 11
        Me.lblMeaning4.Text = "lblMeaning4"
        '
        'lblCap5
        '
        Me.lblCap5.AutoSize = True
        Me.lblCap5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCap5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap5.Location = New System.Drawing.Point(0, 52)
        Me.lblCap5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap5.Name = "lblCap5"
        Me.lblCap5.Size = New System.Drawing.Size(171, 13)
        Me.lblCap5.TabIndex = 12
        Me.lblCap5.Text = "lblCap5"
        '
        'lblValue5
        '
        Me.lblValue5.AutoSize = True
        Me.lblValue5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblValue5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue5.Location = New System.Drawing.Point(171, 52)
        Me.lblValue5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue5.Name = "lblValue5"
        Me.lblValue5.Size = New System.Drawing.Size(171, 13)
        Me.lblValue5.TabIndex = 13
        Me.lblValue5.Text = "lblValue5"
        Me.lblValue5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeaning5
        '
        Me.lblMeaning5.AutoSize = True
        Me.lblMeaning5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblMeaning5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning5.Location = New System.Drawing.Point(342, 52)
        Me.lblMeaning5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning5.Name = "lblMeaning5"
        Me.lblMeaning5.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning5.TabIndex = 14
        Me.lblMeaning5.Text = "lblMeaning5"
        '
        'lblCap6
        '
        Me.lblCap6.AutoSize = True
        Me.lblCap6.BackColor = System.Drawing.Color.White
        Me.lblCap6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap6.Location = New System.Drawing.Point(0, 65)
        Me.lblCap6.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap6.Name = "lblCap6"
        Me.lblCap6.Size = New System.Drawing.Size(171, 13)
        Me.lblCap6.TabIndex = 15
        Me.lblCap6.Text = "lblCap6"
        '
        'lblValue6
        '
        Me.lblValue6.AutoSize = True
        Me.lblValue6.BackColor = System.Drawing.Color.White
        Me.lblValue6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue6.Location = New System.Drawing.Point(171, 65)
        Me.lblValue6.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue6.Name = "lblValue6"
        Me.lblValue6.Size = New System.Drawing.Size(171, 13)
        Me.lblValue6.TabIndex = 16
        Me.lblValue6.Text = "lblValue6"
        Me.lblValue6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeaning6
        '
        Me.lblMeaning6.AutoSize = True
        Me.lblMeaning6.BackColor = System.Drawing.Color.White
        Me.lblMeaning6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning6.Location = New System.Drawing.Point(342, 65)
        Me.lblMeaning6.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning6.Name = "lblMeaning6"
        Me.lblMeaning6.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning6.TabIndex = 17
        Me.lblMeaning6.Text = "lblMeaning6"
        '
        'lblCap7
        '
        Me.lblCap7.AutoSize = True
        Me.lblCap7.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCap7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap7.Location = New System.Drawing.Point(0, 78)
        Me.lblCap7.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap7.Name = "lblCap7"
        Me.lblCap7.Size = New System.Drawing.Size(171, 13)
        Me.lblCap7.TabIndex = 18
        Me.lblCap7.Text = "lblCap7"
        '
        'lblValue7
        '
        Me.lblValue7.AutoSize = True
        Me.lblValue7.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblValue7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue7.Location = New System.Drawing.Point(171, 78)
        Me.lblValue7.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue7.Name = "lblValue7"
        Me.lblValue7.Size = New System.Drawing.Size(171, 13)
        Me.lblValue7.TabIndex = 19
        Me.lblValue7.Text = "lblValue7"
        Me.lblValue7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeaning7
        '
        Me.lblMeaning7.AutoSize = True
        Me.lblMeaning7.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblMeaning7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning7.Location = New System.Drawing.Point(342, 78)
        Me.lblMeaning7.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning7.Name = "lblMeaning7"
        Me.lblMeaning7.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning7.TabIndex = 20
        Me.lblMeaning7.Text = "lblMeaning7"
        '
        'lblCap8
        '
        Me.lblCap8.AutoSize = True
        Me.lblCap8.BackColor = System.Drawing.Color.White
        Me.lblCap8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap8.Location = New System.Drawing.Point(0, 91)
        Me.lblCap8.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap8.Name = "lblCap8"
        Me.lblCap8.Size = New System.Drawing.Size(171, 13)
        Me.lblCap8.TabIndex = 21
        Me.lblCap8.Text = "lblCap8"
        '
        'lblCap9
        '
        Me.lblCap9.AutoSize = True
        Me.lblCap9.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCap9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap9.Location = New System.Drawing.Point(0, 104)
        Me.lblCap9.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap9.Name = "lblCap9"
        Me.lblCap9.Size = New System.Drawing.Size(171, 13)
        Me.lblCap9.TabIndex = 22
        Me.lblCap9.Text = "lblCap9"
        '
        'lblCap10
        '
        Me.lblCap10.AutoSize = True
        Me.lblCap10.BackColor = System.Drawing.Color.White
        Me.lblCap10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCap10.Location = New System.Drawing.Point(0, 117)
        Me.lblCap10.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCap10.Name = "lblCap10"
        Me.lblCap10.Size = New System.Drawing.Size(171, 133)
        Me.lblCap10.TabIndex = 23
        Me.lblCap10.Text = "lblCap10"
        '
        'lblValue8
        '
        Me.lblValue8.AutoSize = True
        Me.lblValue8.BackColor = System.Drawing.Color.White
        Me.lblValue8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue8.Location = New System.Drawing.Point(171, 91)
        Me.lblValue8.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue8.Name = "lblValue8"
        Me.lblValue8.Size = New System.Drawing.Size(171, 13)
        Me.lblValue8.TabIndex = 24
        Me.lblValue8.Text = "lblValue8"
        Me.lblValue8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblValue9
        '
        Me.lblValue9.AutoSize = True
        Me.lblValue9.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblValue9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue9.Location = New System.Drawing.Point(171, 104)
        Me.lblValue9.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue9.Name = "lblValue9"
        Me.lblValue9.Size = New System.Drawing.Size(171, 13)
        Me.lblValue9.TabIndex = 25
        Me.lblValue9.Text = "lblValue9"
        Me.lblValue9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblValue10
        '
        Me.lblValue10.AutoSize = True
        Me.lblValue10.BackColor = System.Drawing.Color.White
        Me.lblValue10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblValue10.Location = New System.Drawing.Point(171, 117)
        Me.lblValue10.Margin = New System.Windows.Forms.Padding(0)
        Me.lblValue10.Name = "lblValue10"
        Me.lblValue10.Size = New System.Drawing.Size(171, 133)
        Me.lblValue10.TabIndex = 26
        Me.lblValue10.Text = "lblValue10"
        Me.lblValue10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeaning8
        '
        Me.lblMeaning8.AutoSize = True
        Me.lblMeaning8.BackColor = System.Drawing.Color.White
        Me.lblMeaning8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning8.Location = New System.Drawing.Point(342, 91)
        Me.lblMeaning8.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning8.Name = "lblMeaning8"
        Me.lblMeaning8.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning8.TabIndex = 27
        Me.lblMeaning8.Text = "lblMeaning8"
        '
        'lblMeaning9
        '
        Me.lblMeaning9.AutoSize = True
        Me.lblMeaning9.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblMeaning9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning9.Location = New System.Drawing.Point(342, 104)
        Me.lblMeaning9.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning9.Name = "lblMeaning9"
        Me.lblMeaning9.Size = New System.Drawing.Size(173, 13)
        Me.lblMeaning9.TabIndex = 28
        Me.lblMeaning9.Text = "lblMeaning9"
        '
        'lblMeaning10
        '
        Me.lblMeaning10.AutoSize = True
        Me.lblMeaning10.BackColor = System.Drawing.Color.White
        Me.lblMeaning10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblMeaning10.Location = New System.Drawing.Point(342, 117)
        Me.lblMeaning10.Margin = New System.Windows.Forms.Padding(0)
        Me.lblMeaning10.Name = "lblMeaning10"
        Me.lblMeaning10.Size = New System.Drawing.Size(173, 133)
        Me.lblMeaning10.TabIndex = 29
        Me.lblMeaning10.Text = "lblMeaning10"
        '
        'CapabilitesList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.tlpList)
        Me.Name = "CapabilitesList"
        Me.Size = New System.Drawing.Size(515, 250)
        Me.tlpList.ResumeLayout(False)
        Me.tlpList.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Protected WithEvents tlpList As System.Windows.Forms.TableLayoutPanel
    Private WithEvents lblCap1 As System.Windows.Forms.Label
    Private WithEvents lblValue1 As System.Windows.Forms.Label
    Private WithEvents lblMeaning1 As System.Windows.Forms.Label
    Private WithEvents lblCap2 As System.Windows.Forms.Label
    Private WithEvents lblValue2 As System.Windows.Forms.Label
    Private WithEvents lblMeaning2 As System.Windows.Forms.Label
    Private WithEvents lblCap3 As System.Windows.Forms.Label
    Private WithEvents lblValue3 As System.Windows.Forms.Label
    Private WithEvents lblMeaning3 As System.Windows.Forms.Label
    Private WithEvents lblCap4 As System.Windows.Forms.Label
    Private WithEvents lblValue4 As System.Windows.Forms.Label
    Private WithEvents lblMeaning4 As System.Windows.Forms.Label
    Private WithEvents lblCap5 As System.Windows.Forms.Label
    Private WithEvents lblValue5 As System.Windows.Forms.Label
    Private WithEvents lblMeaning5 As System.Windows.Forms.Label
    Private WithEvents lblCap6 As System.Windows.Forms.Label
    Private WithEvents lblValue6 As System.Windows.Forms.Label
    Private WithEvents lblMeaning6 As System.Windows.Forms.Label
    Private WithEvents lblCap7 As System.Windows.Forms.Label
    Private WithEvents lblValue7 As System.Windows.Forms.Label
    Private WithEvents lblMeaning7 As System.Windows.Forms.Label
    Private WithEvents lblCap8 As System.Windows.Forms.Label
    Private WithEvents lblCap9 As System.Windows.Forms.Label
    Private WithEvents lblCap10 As System.Windows.Forms.Label
    Private WithEvents lblValue8 As System.Windows.Forms.Label
    Private WithEvents lblValue9 As System.Windows.Forms.Label
    Private WithEvents lblValue10 As System.Windows.Forms.Label
    Private WithEvents lblMeaning8 As System.Windows.Forms.Label
    Private WithEvents lblMeaning9 As System.Windows.Forms.Label
    Private WithEvents lblMeaning10 As System.Windows.Forms.Label

End Class
