﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Drawing

Public Class FlagsPanel

    Private Enum State
        isOn = 1
        isOff = 0
    End Enum

    Dim flag_on As Color = Color.Black
    Dim flag_off As Color = Color.FromArgb(204, 204, 204)

    Private Sub DrawTitle()
        Dim panel As Brush = New SolidBrush(Color.DarkBlue)
        Dim title As New Pen(Color.White, 1)
        Dim g As Graphics = Me.CreateGraphics

        'create panel
        g.FillRectangle(panel, 0, 0, 9, 32)
        'create "FLAGS" label
        With g
            'F
            .DrawLine(title, 2, 30, 6, 30)
            .DrawLine(title, 2, 30, 2, 26)
            .DrawLine(title, 4, 30, 4, 28)
            'L
            .DrawLine(title, 2, 24, 6, 24)
            .DrawLine(title, 6, 24, 6, 20)
            'A
            .DrawLine(title, 6, 18, 2, 18)
            .DrawLine(title, 2, 18, 2, 14)
            .DrawLine(title, 2, 14, 6, 14)
            .DrawLine(title, 4, 18, 4, 14)
            'G
            .DrawLine(title, 2, 8, 2, 12)
            .DrawLine(title, 2, 12, 6, 12)
            .DrawLine(title, 6, 12, 6, 8)
            .DrawLine(title, 6, 8, 4, 8)
            .DrawLine(title, 4, 8, 4, 10)
            'S
            .DrawLine(title, 2, 2, 2, 6)
            .DrawLine(title, 2, 6, 4, 6)
            .DrawLine(title, 4, 6, 4, 2)
            .DrawLine(title, 4, 2, 6, 2)
            .DrawLine(title, 6, 2, 6, 6)
        End With

    End Sub

    Private Sub DrawPrefailureFlag(Optional ByVal value As State = State.isOff)
        Dim col As Color = flag_on
        If value = State.isOff Then col = flag_off
        Dim y As Integer = 6

        'create "PREFAILURE WARNING" label
        P(col, 11, y)
        R(col, 17, y)
        E(col, 23, y)
        F(col, 29, y)
        A(col, 35, y)
        I(col, 41, y)
        L(col, 43, y)
        U(col, 49, y)
        R(col, 55, y)
        E(col, 61, y)
        ' (+12)
        W(col, 73, y)
        A(col, 79, y)
        R(col, 85, y)
        N(col, 91, y)
        I(col, 97, y)
        N(col, 99, y)
        G(col, 105, y)
    End Sub

    Private Sub DrawUpdatedOnlineFlag(Optional ByVal value As State = State.isOff)
        Dim col As Color = flag_on
        If value = State.isOff Then col = flag_off
        Dim y As Integer = 18

        'create "UPDATED ONLINE" label
        U(col, 11, y)
        P(col, 17, y)
        D(col, 23, y)
        A(col, 29, y)
        T(col, 35, y)
        E(col, 41, y)
        D(col, 47, y)
        ' (+12)
        O(col, 59, y)
        N(col, 65, y)
        L(col, 71, y)
        I(col, 77, y)
        N(col, 79, y)
        E(col, 85, y)
    End Sub

    Private Sub DrawSpeedPerformanceFlag(Optional ByVal value As State = State.isOff)
        Dim col As Color = flag_on
        If value = State.isOff Then col = flag_off
        Dim y As Integer = 30

        'create "SPEED/PERFORMANCE" label
        S(col, 11, y)
        P(col, 17, y)
        E(col, 23, y)
        E(col, 29, y)
        D(col, 35, y)
        Slash(col, 41, y)
        P(col, 47, y)
        E(col, 53, y)
        R(col, 59, y)
        F(col, 65, y)
        O(col, 71, y)
        R(col, 77, y)
        M(col, 83, y)
        A(col, 89, y)
        N(col, 95, y)
        C(col, 101, y)
        E(col, 107, y)
    End Sub

    Private Sub DrawErrorRateFlag(Optional ByVal value As State = State.isOff)
        Dim col As Color = flag_on
        If value = State.isOff Then col = flag_off
        Dim y As Integer = 6

        'create "ERROR RATE" label
        E(col, 126, y)
        R(col, 132, y)
        R(col, 138, y)
        O(col, 144, y)
        R(col, 150, y)
        ' (+12)
        R(col, 162, y)
        A(col, 168, y)
        T(col, 174, y)
        E(col, 180, y)
    End Sub

    Private Sub DrawEventCountFlag(Optional ByVal value As State = State.isOff)
        Dim col As Color = flag_on
        If value = State.isOff Then col = flag_off
        Dim y As Integer = 18

        'create "EVENT COUNT" label
        E(col, 126, y)
        V(col, 132, y)
        E(col, 138, y)
        N(col, 144, y)
        T(col, 150, y)
        ' (+12)
        C(col, 162, y)
        O(col, 168, y)
        U(col, 174, y)
        N(col, 180, y)
        T(col, 186, y)
    End Sub

    Private Sub DrawSelfPreservingFlag(Optional ByVal value As State = State.isOff)
        Dim col As Color = flag_on
        If value = State.isOff Then col = flag_off
        Dim y As Integer = 30

        'create "SELF-PRESERVING" label
        S(col, 126, y)
        E(col, 132, y)
        L(col, 138, y)
        F(col, 144, y)
        Line(col, 150, y)
        P(col, 156, y)
        R(col, 162, y)
        E(col, 168, y)
        S(col, 174, y)
        E(col, 180, y)
        R(col, 186, y)
        V(col, 192, y)
        I(col, 198, y)
        N(col, 200, y)
        G(col, 206, y)
    End Sub

    Public Sub Reset()
        DrawPrefailureFlag()
        DrawUpdatedOnlineFlag()
        DrawSpeedPerformanceFlag()
        DrawErrorRateFlag()
        DrawEventCountFlag()
        DrawSelfPreservingFlag()
    End Sub

    Private Sub FlagsPanel_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        DrawTitle()
        Reset()
    End Sub

    Public Sub GetFlags(ByVal value As AttributeFlags)
        Reset()
        With value
            If .HasFlag(AttributeFlags.ErrorRate) Then DrawErrorRateFlag(State.isOn)
            If .HasFlag(AttributeFlags.EventCount) Then DrawEventCountFlag(State.isOn)
            If .HasFlag(AttributeFlags.Performance) Then DrawSpeedPerformanceFlag(State.isOn)
            If .HasFlag(AttributeFlags.SelfPreserving) Then DrawSelfPreservingFlag(State.isOn)
            If .HasFlag(AttributeFlags.Prefailure) Then DrawPrefailureFlag(State.isOn)
            If .HasFlag(AttributeFlags.UpdatedOnline) Then DrawUpdatedOnlineFlag(State.isOn)
        End With
    End Sub
End Class
