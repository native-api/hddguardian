﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.ComponentModel
Imports System.ComponentModel.Design

Public Class DevicePanel

#Region "Custom properties"

    ''' <summary>
    ''' Get/set device model
    ''' </summary>
    <DefaultValue("")> _
    Public Property Model As String
        Get
            Return lblModel.Text
        End Get
        Set(ByVal value As String)
            lblModel.Text = value
        End Set
    End Property

    ''' <summary>
    ''' Get/set device path (like "/dev/sda")
    ''' </summary>
    <DefaultValue("")> _
    Public Property Path As String
        Get
            Return lblLocation.Text
        End Get
        Set(ByVal value As String)
            lblLocation.Text = value
        End Set
    End Property

    ''' <summary>
    ''' Get/set device total size
    ''' </summary>
    <DefaultValue("")> _
    Public Property TotalSize As String
        Get
            Return lblSize.Text
        End Get
        Set(ByVal value As String)
            lblSize.Text = value
        End Set
    End Property

    ''' <summary>
    ''' Get/set device firmware version
    ''' </summary>
    <DefaultValue("")> _
    Public Property Firmware As String
        Get
            Return lblFirmware.Text
        End Get
        Set(ByVal value As String)
            lblFirmware.Text = value
        End Set
    End Property

    ''' <summary>
    ''' Get/set device serial number
    ''' </summary>
    <DefaultValue("")> _
    Public Property Serial As String
        Get
            Return lblSerial.Text
        End Get
        Set(ByVal value As String)
            lblSerial.Text = value
        End Set
    End Property

    ''' <summary>
    ''' Get/set manufacturer web link
    ''' </summary>
    <DefaultValue("")> _
    Public Property Web As String
        Get
            Return lnkWeb.Text
        End Get
        Set(ByVal value As String)
            lnkWeb.Text = value
        End Set
    End Property

#End Region

    Public Sub New()

        ' Chiamata richiesta dalla finestra di progettazione.
        InitializeComponent()

        ' Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent().
        lblFirmware.Text = ""
        lblLocation.Text = ""
        lblModel.Text = ""
        lblSerial.Text = ""
        lblSize.Text = ""
        lnkWeb.Text = ""
    End Sub

    Private Sub lnkWeb_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkWeb.LinkClicked
        Try
            'go to web site of manufacturer
            System.Diagnostics.Process.Start(lnkWeb.Text)
        Catch
        End Try
    End Sub

#Region "Toolbox hidden properties"

    <System.ComponentModel.Browsable(False)> _
    Public Overloads ReadOnly Property BackgroundImage() As Boolean
        Get
            Return Nothing
        End Get
    End Property

    <System.ComponentModel.Browsable(False)> _
    Public Overloads Property BackColor() As System.Drawing.Color
        Get
            Return MyBase.BackColor
        End Get
        Set(ByVal value As System.Drawing.Color)
            MyBase.BackColor = value
        End Set
    End Property

    <System.ComponentModel.Browsable(False)> _
    Public Overloads Property ForeColor() As System.Drawing.Color
        Get
            Return MyBase.ForeColor
        End Get
        Set(ByVal value As System.Drawing.Color)
            MyBase.ForeColor = value
        End Set
    End Property

    <System.ComponentModel.Browsable(False)> _
    Public Overloads Property Padding() As System.Windows.Forms.Padding
        Get
            Return MyBase.Padding
        End Get
        Set(ByVal value As System.Windows.Forms.Padding)
            MyBase.Padding = value
        End Set
    End Property

    <System.ComponentModel.Browsable(False)> _
    Public Overloads Property BackgroundImageLayout() As System.Windows.Forms.ImageLayout
        Get
            Return MyBase.BackgroundImageLayout
        End Get
        Set(ByVal value As System.Windows.Forms.ImageLayout)
            MyBase.BackgroundImageLayout = value
        End Set
    End Property

    <System.ComponentModel.Browsable(False)> _
    Public Overloads Property BorderStyle As System.Windows.Forms.BorderStyle
        Get
            Return MyBase.BorderStyle
        End Get
        Set(ByVal value As System.Windows.Forms.BorderStyle)
            MyBase.BorderStyle = value
        End Set
    End Property

#End Region

#Region "Overrided visible properties"

    Public Overloads Property Font As Font
        Get
            Return MyBase.Font
        End Get
        Set(ByVal value As Font)
            MyBase.Font = value
            lblModel.Font = New Font(MyBase.Font.FontFamily, 9, System.Drawing.FontStyle.Bold)
        End Set
    End Property

#End Region

End Class
