﻿'Translation Tool is the HDD Guardian translation utility
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2011  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Xml

Public Class Main
    Structure CultureCodes
        Dim Code, Description As String
    End Structure

    Class CultureCollection
        Inherits List(Of CultureCodes)
    End Class

    Dim cultures As New CultureCollection

    Private Sub Main_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
            MsgBox("HDD Guardian Translation Tool require administration rights.", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error")
            End
        End If

        Dim c() As String = My.Resources.cultures.Split(vbCrLf)
        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        m_xmldoc.LoadXml(My.Resources.cultures)
        m_nodelist = m_xmldoc.SelectNodes("/cultures/item")

        For Each m_node In m_nodelist
            Dim cult As String = m_node.Attributes.GetNamedItem("culture").Value
            Dim zone As String = m_node.Attributes.GetNamedItem("zone").Value
            cboCulture.Items.Add(cult)
            Dim item As New CultureCodes
            item.Code = cult
            item.Description = zone
            cultures.Add(item)
        Next

        'cboCulture.Sorted = True
        cboCulture.SelectedIndex = 0
        lblSelLanguage.Text = cultures(cboCulture.SelectedIndex).Description
        txtLanguage.Enabled = False
        txtLanguage.ResetText()
        txtTranslator.Enabled = False
        txtTranslator.ResetText()
        numVersion.Enabled = False
        numVersion.ResetText()

        m_xmldoc.LoadXml(My.Resources.english)
        m_nodelist = m_xmldoc.SelectNodes("/interface/string")

        For Each m_node In m_nodelist
            Dim id As String = m_node.Attributes.GetNamedItem("id").Value
            Dim text As String = m_node.Attributes.GetNamedItem("text").Value
            With lvwTranslation
                .Items.Add(text)
                .Items(.Items.Count - 1).Tag = id
                .Items(.Items.Count - 1).SubItems.Add("")
            End With
        Next
        chDefaultCulture.Width = lvwTranslation.ClientRectangle.Width / 2
        chNewCulture.Width = lvwTranslation.ClientRectangle.Width / 2
        lvwTranslation.Items(0).Selected = True


        m_xmldoc.LoadXml(My.Resources.attributes)
        m_nodelist = m_xmldoc.SelectNodes("/table/attribute")

        For Each m_node In m_nodelist
            Dim smartctlname As String = m_node.Attributes.GetNamedItem("smartctl").Value
            If smartctlname.Length > 0 Then
                With lvwAttributes
                    .Items.Add(m_node.ChildNodes.Item(0).InnerText)
                    .Items(.Items.Count - 1).Tag = smartctlname
                    .Items(.Items.Count - 1).SubItems.Add(m_node.ChildNodes.Item(1).InnerText.Replace(vbCrLf, "").Trim)
                    .Items(.Items.Count - 1).SubItems.Add("")
                End With
            End If
        Next
        chItemName.AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
        chDefaultAttr.Width = (lvwAttributes.ClientRectangle.Width - chItemName.Width) / 2
        chNewAttr.Width = (lvwAttributes.ClientRectangle.Width - chItemName.Width) / 2
        lvwAttributes.Items(0).Selected = True
    End Sub

    Private Sub lvwTranslation_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvwTranslation.ItemSelectionChanged
        If e.IsSelected _
            Then txtDefault.Text = lvwTranslation.SelectedItems(0).Text.Replace("\", vbCrLf)

        If e.Item.SubItems(1).Text.Length > 0 Then
            txtNew.Text = e.Item.SubItems(1).Text.Replace("\", vbCrLf)
        Else
            txtNew.Text = ""
        End If
    End Sub

    Private Sub txtNew_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtNew.KeyPress
        If e.KeyChar = """" Then e.KeyChar = "'"
    End Sub

    Private Sub txtNew_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNew.TextChanged
        Try
            Dim i As Short = lvwTranslation.SelectedItems(0).Index

            lvwTranslation.Items(i).SubItems(1).Text = txtNew.Text.Replace(vbCrLf, "\")
        Catch
        End Try
    End Sub

    Private Sub lvwAttributes_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvwAttributes.ItemSelectionChanged
        If e.IsSelected Then txtDefaultAttr.Text = e.Item.SubItems(1).Text

        If e.Item.SubItems(2).Text.Length > 0 Then
            txtNewAttr.Text = e.Item.SubItems(2).Text
            lblPreview.Text = e.Item.SubItems(2).Text
        Else
            txtNewAttr.Text = ""
            lblPreview.Text = ""
        End If
    End Sub

    Private Sub txtNewAttr_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNewAttr.TextChanged
        Try
            Dim i As Short = lvwAttributes.SelectedItems(0).Index

            lvwAttributes.Items(i).SubItems(2).Text = txtNewAttr.Text.Replace(vbCrLf, " ")
            lblPreview.Text = txtNewAttr.Text.Replace(vbCrLf, " ")
        Catch
        End Try
    End Sub

    Private Sub lvwTranslation_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwTranslation.SelectedIndexChanged
        Dim output As XmlWriterSettings = New XmlWriterSettings()
        output.Indent = True

        Dim folder As String = My.Application.Info.DirectoryPath & "\" & cboCulture.SelectedItem.ToString & "\"
        If Not IO.Directory.Exists(folder) Then Exit Sub

        Using write As XmlWriter = XmlWriter.Create(folder & "interface.xml", output)
            ' Begin writing.
            write.WriteStartDocument()
            write.WriteStartElement("interface") 'root element
            write.WriteStartElement("info") 'the info element
            write.WriteAttributeString("language", txtLanguage.Text)
            write.WriteAttributeString("translator", txtTranslator.Text)
            write.WriteAttributeString("version", numVersion.Value)
            write.WriteEndElement()
            'the translation strings
            For i As Short = 0 To lvwTranslation.Items.Count - 1
                write.WriteStartElement("string")
                write.WriteAttributeString("id", lvwTranslation.Items(i).Tag)
                write.WriteAttributeString("text", lvwTranslation.Items(i).SubItems(1).Text)
                write.WriteEndElement()
            Next
            'end of root element & write the document
            write.WriteEndElement()
            write.WriteEndDocument()
        End Using
    End Sub

    Private Sub cboCulture_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCulture.SelectedIndexChanged
        lblSelLanguage.Text = cultures(cboCulture.SelectedIndex).Description

        Dim folder As String = My.Application.Info.DirectoryPath & "\" & cboCulture.SelectedItem.ToString & "\"
        If IO.Directory.Exists(folder) Then
            Dim m_xmldoc As New XmlDocument
            Dim m_nodelist As XmlNodeList
            Dim m_node As XmlNode

            m_xmldoc.Load(folder & "interface.xml")

            m_nodelist = m_xmldoc.SelectNodes("/interface/info")
            For Each m_node In m_nodelist
                txtLanguage.Text = m_node.Attributes.GetNamedItem("language").Value
                txtTranslator.Text = m_node.Attributes.GetNamedItem("translator").Value
                numVersion.Value = m_node.Attributes.GetNamedItem("version").Value
            Next

            m_nodelist = m_xmldoc.SelectNodes("/interface/string")

            For Each m_node In m_nodelist
                Dim id As String = m_node.Attributes.GetNamedItem("id").Value
                Dim text As String = m_node.Attributes.GetNamedItem("text").Value

                With lvwTranslation
                    For i As Short = 0 To .Items.Count - 1
                        If .Items(i).Tag = id Then .Items(i).SubItems(1).Text = text
                    Next
                End With
            Next

            m_xmldoc.Load(folder & "attributes.xml")
            m_nodelist = m_xmldoc.SelectNodes("/table/attribute")

            For Each m_node In m_nodelist
                Dim smartctlname As String = m_node.Attributes.GetNamedItem("smartctl").Value
                If smartctlname.Length > 0 Then
                    Dim text As String = m_node.ChildNodes.Item(1).InnerText.Replace(vbCrLf, "").Trim
                    With lvwAttributes
                        For i As Short = 0 To .Items.Count - 1
                            If .Items(i).Tag = smartctlname Then .Items(i).SubItems(2).Text = text
                        Next
                    End With
                End If
            Next
            On Error Resume Next
            lvwTranslation.Items(0).Selected = True
            lvwAttributes.Items(0).Selected = True
            txtNew.Text = lvwTranslation.Items(0).SubItems(1).Text
            txtNewAttr.Text = lvwAttributes.Items(0).SubItems(2).Text
            txtLanguage.Enabled = True
            txtTranslator.Enabled = True
            numVersion.Enabled = True

            btnCreate.Enabled = False
            btnSave.Enabled = True
            tabTranslation.Enabled = True
        Else
            txtLanguage.Enabled = False
            txtLanguage.ResetText()
            txtTranslator.Enabled = False
            txtTranslator.ResetText()
            numVersion.Enabled = False
            numVersion.Value = 0

            For i As Short = 0 To lvwAttributes.Items.Count - 1
                lvwAttributes.Items(i).SubItems(2).Text = ""
            Next

            For i As Short = 0 To lvwTranslation.Items.Count - 1
                lvwTranslation.Items(i).SubItems(1).Text = ""
            Next

            btnCreate.Enabled = True
            btnSave.Enabled = False
            tabTranslation.Enabled = False
        End If
    End Sub

    Private Sub btnCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreate.Click
        Dim folder As String = My.Application.Info.DirectoryPath & "\" & cboCulture.SelectedItem.ToString & "\"

        If Not IO.Directory.Exists(folder) Then
            IO.Directory.CreateDirectory(folder)

            Dim output As XmlWriterSettings = New XmlWriterSettings()
            output.Indent = True

            If Not IO.Directory.Exists(folder) Then Exit Sub

            Using write As XmlWriter = XmlWriter.Create(folder & "interface.xml", output)
                ' Begin writing.
                write.WriteStartDocument()
                write.WriteStartElement("interface") 'root element
                write.WriteStartElement("info") 'the info element
                write.WriteAttributeString("language", txtLanguage.Text)
                write.WriteAttributeString("translator", txtTranslator.Text)
                write.WriteAttributeString("version", numVersion.Value)
                write.WriteEndElement()
                write.WriteStartElement("string") 'one empty translation string
                write.WriteAttributeString("id", "")
                write.WriteAttributeString("text", "")
                write.WriteEndElement()
                'end of root element & write the document
                write.WriteEndElement()
                write.WriteEndDocument()
            End Using

            Using write As XmlWriter = XmlWriter.Create(folder & "attributes.xml", output)
                ' Begin writing.
                write.WriteStartDocument() 'start document
                write.WriteStartElement("table") 'root element
                write.WriteStartElement("attribute") 'start attribute
                write.WriteAttributeString("smartctl", "") 'attribute... attribute!
                write.WriteStartElement("name") 'attribute name
                write.WriteEndElement() 'end attribute name
                write.WriteStartElement("description") 'attribute description
                write.WriteEndElement() 'end attribute description
                write.WriteEndElement() 'end attribute
                write.WriteEndElement() 'end root
                write.WriteEndDocument() 'end document
            End Using

            tabTranslation.Enabled = True
            btnSave.Enabled = True
            btnCreate.Enabled = False

            txtLanguage.Enabled = True
            txtTranslator.Enabled = True
            numVersion.Enabled = True
        End If
    End Sub

    Private Sub txtLanguage_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLanguage.TextChanged
        If txtLanguage.Text.Length = 0 Or txtTranslator.Text.Length = 0 Then
            btnCreate.Enabled = False
        Else
            btnCreate.Enabled = True
        End If
    End Sub

    Private Sub txtTranslator_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtTranslator.TextChanged
        If txtLanguage.Text.Length = 0 Or txtTranslator.Text.Length = 0 Then
            btnCreate.Enabled = False
        Else
            btnCreate.Enabled = True
        End If
    End Sub

    Private Sub lvwAttributes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwAttributes.SelectedIndexChanged
        Dim output As XmlWriterSettings = New XmlWriterSettings()
        output.Indent = True

        Dim folder As String = My.Application.Info.DirectoryPath & "\" & cboCulture.SelectedItem.ToString & "\"
        If Not IO.Directory.Exists(folder) Then Exit Sub

        Using write As XmlWriter = XmlWriter.Create(folder & "attributes.xml", output)
            ' Begin writing.
            write.WriteStartDocument()
            write.WriteStartElement("table") 'root element
            'the attributes meanings strings
            For i As Short = 0 To lvwAttributes.Items.Count - 1
                If lvwAttributes.Items(i).SubItems(2).Text.Length > 0 Then
                    write.WriteStartElement("attribute") 'start attribute
                    write.WriteAttributeString("smartctl", lvwAttributes.Items(i).Tag.ToString)
                    write.WriteStartElement("name") 'start attribute name
                    write.WriteString(lvwAttributes.Items(i).Text)
                    write.WriteEndElement()
                    write.WriteStartElement("description") 'start attribute meaning
                    write.WriteString(lvwAttributes.Items(i).SubItems(2).Text)
                    write.WriteEndElement()
                    write.WriteEndElement()
                End If
            Next
            'end of root element & write the document
            write.WriteEndElement()
            write.WriteEndDocument()
        End Using
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        With lvwTranslation
            Dim i As Short = .SelectedItems(0).Index + 1
            If i > .Items.Count - 1 Then i = 0
            .Items(i).Selected = True
            .Items(i).EnsureVisible()
        End With
    End Sub

    Private Sub btnNextAttr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextAttr.Click
        With lvwAttributes
            Dim i As Short = .SelectedItems(0).Index + 1
            If i > .Items.Count - 1 Then i = 0
            .Items(i).Selected = True
            .Items(i).EnsureVisible()
        End With
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim output As XmlWriterSettings = New XmlWriterSettings()
        output.Indent = True

        Dim folder As String = My.Application.Info.DirectoryPath & "\" & cboCulture.SelectedItem.ToString & "\"
        If Not IO.Directory.Exists(folder) Then Exit Sub

        Using write As XmlWriter = XmlWriter.Create(folder & "attributes.xml", output)
            ' Begin writing.
            write.WriteStartDocument()
            write.WriteStartElement("table") 'root element
            'the attributes meanings strings
            For i As Short = 0 To lvwAttributes.Items.Count - 1
                If lvwAttributes.Items(i).SubItems(2).Text.Length > 0 Then
                    write.WriteStartElement("attribute") 'start attribute
                    write.WriteAttributeString("smartctl", lvwAttributes.Items(i).Tag.ToString)
                    write.WriteStartElement("name") 'start attribute name
                    write.WriteString(lvwAttributes.Items(i).Text)
                    write.WriteEndElement()
                    write.WriteStartElement("description") 'start attribute meaning
                    write.WriteString(lvwAttributes.Items(i).SubItems(2).Text)
                    write.WriteEndElement()
                    write.WriteEndElement()
                End If
            Next
            'end of root element & write the document
            write.WriteEndElement()
            write.WriteEndDocument()
        End Using

        Using write As XmlWriter = XmlWriter.Create(folder & "interface.xml", output)
            ' Begin writing.
            write.WriteStartDocument()
            write.WriteStartElement("interface") 'root element
            write.WriteStartElement("info") 'the info element
            write.WriteAttributeString("language", txtLanguage.Text)
            write.WriteAttributeString("translator", txtTranslator.Text)
            write.WriteAttributeString("version", numVersion.Value)
            write.WriteEndElement()
            'the translation strings
            For i As Short = 0 To lvwTranslation.Items.Count - 1
                write.WriteStartElement("string")
                write.WriteAttributeString("id", lvwTranslation.Items(i).Tag)
                write.WriteAttributeString("text", lvwTranslation.Items(i).SubItems(1).Text)
                write.WriteEndElement()
            Next
            'end of root element & write the document
            write.WriteEndElement()
            write.WriteEndDocument()
        End Using
    End Sub
End Class
