﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim picTranTool As System.Windows.Forms.PictureBox
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.pnlProject = New System.Windows.Forms.Panel()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.lblSelLanguage = New System.Windows.Forms.Label()
        Me.cboCulture = New System.Windows.Forms.ComboBox()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.txtLanguage = New System.Windows.Forms.TextBox()
        Me.txtTranslator = New System.Windows.Forms.TextBox()
        Me.lblCulture = New System.Windows.Forms.Label()
        Me.numVersion = New System.Windows.Forms.NumericUpDown()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.lblTranslator = New System.Windows.Forms.Label()
        Me.lblLanguage = New System.Windows.Forms.Label()
        Me.tabTranslation = New System.Windows.Forms.TabControl()
        Me.tpInterface = New System.Windows.Forms.TabPage()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.txtNew = New System.Windows.Forms.TextBox()
        Me.lblNew = New System.Windows.Forms.Label()
        Me.txtDefault = New System.Windows.Forms.TextBox()
        Me.lblDefault = New System.Windows.Forms.Label()
        Me.lvwTranslation = New System.Windows.Forms.ListView()
        Me.chDefaultCulture = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chNewCulture = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.tpAttributes = New System.Windows.Forms.TabPage()
        Me.grpPreview = New System.Windows.Forms.GroupBox()
        Me.lblPreview = New System.Windows.Forms.Label()
        Me.btnNextAttr = New System.Windows.Forms.Button()
        Me.txtNewAttr = New System.Windows.Forms.TextBox()
        Me.lblNewAttr = New System.Windows.Forms.Label()
        Me.txtDefaultAttr = New System.Windows.Forms.TextBox()
        Me.lblDefaultAttr = New System.Windows.Forms.Label()
        Me.lvwAttributes = New System.Windows.Forms.ListView()
        Me.chItemName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chDefaultAttr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chNewAttr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        picTranTool = New System.Windows.Forms.PictureBox()
        CType(picTranTool, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlProject.SuspendLayout()
        CType(Me.numVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabTranslation.SuspendLayout()
        Me.tpInterface.SuspendLayout()
        Me.tpAttributes.SuspendLayout()
        Me.grpPreview.SuspendLayout()
        Me.SuspendLayout()
        '
        'picTranTool
        '
        picTranTool.Image = Global.TranslationTool.My.Resources.Resources.icn_48
        picTranTool.Location = New System.Drawing.Point(624, 8)
        picTranTool.Name = "picTranTool"
        picTranTool.Size = New System.Drawing.Size(48, 48)
        picTranTool.TabIndex = 13
        picTranTool.TabStop = False
        '
        'pnlProject
        '
        Me.pnlProject.Controls.Add(Me.btnSave)
        Me.pnlProject.Controls.Add(Me.lblSelLanguage)
        Me.pnlProject.Controls.Add(Me.cboCulture)
        Me.pnlProject.Controls.Add(Me.lblVersion)
        Me.pnlProject.Controls.Add(Me.txtLanguage)
        Me.pnlProject.Controls.Add(Me.txtTranslator)
        Me.pnlProject.Controls.Add(Me.lblCulture)
        Me.pnlProject.Controls.Add(Me.numVersion)
        Me.pnlProject.Controls.Add(picTranTool)
        Me.pnlProject.Controls.Add(Me.btnCreate)
        Me.pnlProject.Controls.Add(Me.lblTranslator)
        Me.pnlProject.Controls.Add(Me.lblLanguage)
        Me.pnlProject.Location = New System.Drawing.Point(0, 0)
        Me.pnlProject.Name = "pnlProject"
        Me.pnlProject.Size = New System.Drawing.Size(680, 112)
        Me.pnlProject.TabIndex = 0
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(576, 80)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(96, 24)
        Me.btnSave.TabIndex = 15
        Me.btnSave.Text = "Save project"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'lblSelLanguage
        '
        Me.lblSelLanguage.AutoEllipsis = True
        Me.lblSelLanguage.Location = New System.Drawing.Point(224, 8)
        Me.lblSelLanguage.Name = "lblSelLanguage"
        Me.lblSelLanguage.Size = New System.Drawing.Size(392, 21)
        Me.lblSelLanguage.TabIndex = 14
        Me.lblSelLanguage.Text = "Label1"
        Me.lblSelLanguage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboCulture
        '
        Me.cboCulture.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboCulture.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.cboCulture.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCulture.Location = New System.Drawing.Point(128, 8)
        Me.cboCulture.Name = "cboCulture"
        Me.cboCulture.Size = New System.Drawing.Size(88, 21)
        Me.cboCulture.TabIndex = 0
        '
        'lblVersion
        '
        Me.lblVersion.Location = New System.Drawing.Point(0, 80)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(120, 21)
        Me.lblVersion.TabIndex = 8
        Me.lblVersion.Text = "Version:"
        Me.lblVersion.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtLanguage
        '
        Me.txtLanguage.Location = New System.Drawing.Point(128, 32)
        Me.txtLanguage.Name = "txtLanguage"
        Me.txtLanguage.Size = New System.Drawing.Size(312, 21)
        Me.txtLanguage.TabIndex = 1
        '
        'txtTranslator
        '
        Me.txtTranslator.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtTranslator.Location = New System.Drawing.Point(128, 56)
        Me.txtTranslator.Name = "txtTranslator"
        Me.txtTranslator.Size = New System.Drawing.Size(312, 21)
        Me.txtTranslator.TabIndex = 2
        '
        'lblCulture
        '
        Me.lblCulture.Location = New System.Drawing.Point(0, 8)
        Me.lblCulture.Name = "lblCulture"
        Me.lblCulture.Size = New System.Drawing.Size(120, 21)
        Me.lblCulture.TabIndex = 3
        Me.lblCulture.Text = "Language culture code:"
        Me.lblCulture.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'numVersion
        '
        Me.numVersion.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.numVersion.DecimalPlaces = 1
        Me.numVersion.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.numVersion.Location = New System.Drawing.Point(128, 80)
        Me.numVersion.Name = "numVersion"
        Me.numVersion.Size = New System.Drawing.Size(48, 21)
        Me.numVersion.TabIndex = 3
        Me.numVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numVersion.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(472, 80)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(96, 24)
        Me.btnCreate.TabIndex = 4
        Me.btnCreate.Text = "Create project"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'lblTranslator
        '
        Me.lblTranslator.Location = New System.Drawing.Point(0, 56)
        Me.lblTranslator.Name = "lblTranslator"
        Me.lblTranslator.Size = New System.Drawing.Size(120, 21)
        Me.lblTranslator.TabIndex = 6
        Me.lblTranslator.Text = "Translator:"
        Me.lblTranslator.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblLanguage
        '
        Me.lblLanguage.Location = New System.Drawing.Point(0, 32)
        Me.lblLanguage.Name = "lblLanguage"
        Me.lblLanguage.Size = New System.Drawing.Size(120, 21)
        Me.lblLanguage.TabIndex = 10
        Me.lblLanguage.Text = "Language:"
        Me.lblLanguage.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tabTranslation
        '
        Me.tabTranslation.Controls.Add(Me.tpInterface)
        Me.tabTranslation.Controls.Add(Me.tpAttributes)
        Me.tabTranslation.Location = New System.Drawing.Point(0, 112)
        Me.tabTranslation.Name = "tabTranslation"
        Me.tabTranslation.SelectedIndex = 0
        Me.tabTranslation.Size = New System.Drawing.Size(680, 384)
        Me.tabTranslation.TabIndex = 1
        '
        'tpInterface
        '
        Me.tpInterface.Controls.Add(Me.btnNext)
        Me.tpInterface.Controls.Add(Me.txtNew)
        Me.tpInterface.Controls.Add(Me.lblNew)
        Me.tpInterface.Controls.Add(Me.txtDefault)
        Me.tpInterface.Controls.Add(Me.lblDefault)
        Me.tpInterface.Controls.Add(Me.lvwTranslation)
        Me.tpInterface.Location = New System.Drawing.Point(4, 22)
        Me.tpInterface.Name = "tpInterface"
        Me.tpInterface.Padding = New System.Windows.Forms.Padding(3)
        Me.tpInterface.Size = New System.Drawing.Size(672, 358)
        Me.tpInterface.TabIndex = 0
        Me.tpInterface.Text = "Program interface"
        Me.tpInterface.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(568, 328)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(96, 24)
        Me.btnNext.TabIndex = 3
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'txtNew
        '
        Me.txtNew.Location = New System.Drawing.Point(0, 240)
        Me.txtNew.Multiline = True
        Me.txtNew.Name = "txtNew"
        Me.txtNew.Size = New System.Drawing.Size(672, 80)
        Me.txtNew.TabIndex = 2
        '
        'lblNew
        '
        Me.lblNew.AutoSize = True
        Me.lblNew.Location = New System.Drawing.Point(0, 224)
        Me.lblNew.Name = "lblNew"
        Me.lblNew.Size = New System.Drawing.Size(55, 13)
        Me.lblNew.TabIndex = 4
        Me.lblNew.Text = "New text:"
        '
        'txtDefault
        '
        Me.txtDefault.BackColor = System.Drawing.SystemColors.Window
        Me.txtDefault.Location = New System.Drawing.Point(0, 144)
        Me.txtDefault.Multiline = True
        Me.txtDefault.Name = "txtDefault"
        Me.txtDefault.ReadOnly = True
        Me.txtDefault.Size = New System.Drawing.Size(672, 72)
        Me.txtDefault.TabIndex = 1
        '
        'lblDefault
        '
        Me.lblDefault.AutoSize = True
        Me.lblDefault.Location = New System.Drawing.Point(0, 128)
        Me.lblDefault.Name = "lblDefault"
        Me.lblDefault.Size = New System.Drawing.Size(69, 13)
        Me.lblDefault.TabIndex = 2
        Me.lblDefault.Text = "Default text:"
        '
        'lvwTranslation
        '
        Me.lvwTranslation.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chDefaultCulture, Me.chNewCulture})
        Me.lvwTranslation.FullRowSelect = True
        Me.lvwTranslation.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwTranslation.HideSelection = False
        Me.lvwTranslation.Location = New System.Drawing.Point(0, 0)
        Me.lvwTranslation.MultiSelect = False
        Me.lvwTranslation.Name = "lvwTranslation"
        Me.lvwTranslation.Size = New System.Drawing.Size(672, 120)
        Me.lvwTranslation.TabIndex = 0
        Me.lvwTranslation.UseCompatibleStateImageBehavior = False
        Me.lvwTranslation.View = System.Windows.Forms.View.Details
        '
        'chDefaultCulture
        '
        Me.chDefaultCulture.Text = "Default"
        '
        'chNewCulture
        '
        Me.chNewCulture.Text = "New culture"
        '
        'tpAttributes
        '
        Me.tpAttributes.Controls.Add(Me.grpPreview)
        Me.tpAttributes.Controls.Add(Me.btnNextAttr)
        Me.tpAttributes.Controls.Add(Me.txtNewAttr)
        Me.tpAttributes.Controls.Add(Me.lblNewAttr)
        Me.tpAttributes.Controls.Add(Me.txtDefaultAttr)
        Me.tpAttributes.Controls.Add(Me.lblDefaultAttr)
        Me.tpAttributes.Controls.Add(Me.lvwAttributes)
        Me.tpAttributes.Location = New System.Drawing.Point(4, 22)
        Me.tpAttributes.Name = "tpAttributes"
        Me.tpAttributes.Padding = New System.Windows.Forms.Padding(3)
        Me.tpAttributes.Size = New System.Drawing.Size(672, 358)
        Me.tpAttributes.TabIndex = 1
        Me.tpAttributes.Text = "Attributes meanings"
        Me.tpAttributes.UseVisualStyleBackColor = True
        '
        'grpPreview
        '
        Me.grpPreview.Controls.Add(Me.lblPreview)
        Me.grpPreview.Location = New System.Drawing.Point(456, 128)
        Me.grpPreview.Name = "grpPreview"
        Me.grpPreview.Size = New System.Drawing.Size(208, 192)
        Me.grpPreview.TabIndex = 10
        Me.grpPreview.TabStop = False
        Me.grpPreview.Text = "Preview box"
        '
        'lblPreview
        '
        Me.lblPreview.AutoSize = True
        Me.lblPreview.Location = New System.Drawing.Point(8, 16)
        Me.lblPreview.Margin = New System.Windows.Forms.Padding(3)
        Me.lblPreview.MaximumSize = New System.Drawing.Size(194, 164)
        Me.lblPreview.MinimumSize = New System.Drawing.Size(194, 164)
        Me.lblPreview.Name = "lblPreview"
        Me.lblPreview.Size = New System.Drawing.Size(194, 164)
        Me.lblPreview.TabIndex = 0
        Me.lblPreview.Text = "lblPreview"
        '
        'btnNextAttr
        '
        Me.btnNextAttr.Location = New System.Drawing.Point(568, 328)
        Me.btnNextAttr.Name = "btnNextAttr"
        Me.btnNextAttr.Size = New System.Drawing.Size(96, 24)
        Me.btnNextAttr.TabIndex = 3
        Me.btnNextAttr.Text = "Next"
        Me.btnNextAttr.UseVisualStyleBackColor = True
        '
        'txtNewAttr
        '
        Me.txtNewAttr.Location = New System.Drawing.Point(0, 240)
        Me.txtNewAttr.Multiline = True
        Me.txtNewAttr.Name = "txtNewAttr"
        Me.txtNewAttr.Size = New System.Drawing.Size(448, 80)
        Me.txtNewAttr.TabIndex = 2
        '
        'lblNewAttr
        '
        Me.lblNewAttr.AutoSize = True
        Me.lblNewAttr.Location = New System.Drawing.Point(0, 224)
        Me.lblNewAttr.Name = "lblNewAttr"
        Me.lblNewAttr.Size = New System.Drawing.Size(55, 13)
        Me.lblNewAttr.TabIndex = 9
        Me.lblNewAttr.Text = "New text:"
        '
        'txtDefaultAttr
        '
        Me.txtDefaultAttr.BackColor = System.Drawing.SystemColors.Window
        Me.txtDefaultAttr.Location = New System.Drawing.Point(0, 144)
        Me.txtDefaultAttr.Multiline = True
        Me.txtDefaultAttr.Name = "txtDefaultAttr"
        Me.txtDefaultAttr.ReadOnly = True
        Me.txtDefaultAttr.Size = New System.Drawing.Size(448, 72)
        Me.txtDefaultAttr.TabIndex = 1
        '
        'lblDefaultAttr
        '
        Me.lblDefaultAttr.AutoSize = True
        Me.lblDefaultAttr.Location = New System.Drawing.Point(0, 128)
        Me.lblDefaultAttr.Name = "lblDefaultAttr"
        Me.lblDefaultAttr.Size = New System.Drawing.Size(69, 13)
        Me.lblDefaultAttr.TabIndex = 7
        Me.lblDefaultAttr.Text = "Default text:"
        '
        'lvwAttributes
        '
        Me.lvwAttributes.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chItemName, Me.chDefaultAttr, Me.chNewAttr})
        Me.lvwAttributes.FullRowSelect = True
        Me.lvwAttributes.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwAttributes.HideSelection = False
        Me.lvwAttributes.Location = New System.Drawing.Point(0, 0)
        Me.lvwAttributes.MultiSelect = False
        Me.lvwAttributes.Name = "lvwAttributes"
        Me.lvwAttributes.Size = New System.Drawing.Size(672, 120)
        Me.lvwAttributes.TabIndex = 0
        Me.lvwAttributes.UseCompatibleStateImageBehavior = False
        Me.lvwAttributes.View = System.Windows.Forms.View.Details
        '
        'chItemName
        '
        Me.chItemName.Text = "Attribute name"
        '
        'chDefaultAttr
        '
        Me.chDefaultAttr.Text = "Default"
        '
        'chNewAttr
        '
        Me.chNewAttr.Text = "New culture"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(678, 496)
        Me.Controls.Add(Me.tabTranslation)
        Me.Controls.Add(Me.pnlProject)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HDD Guardian Translation Tool"
        CType(picTranTool, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlProject.ResumeLayout(False)
        Me.pnlProject.PerformLayout()
        CType(Me.numVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabTranslation.ResumeLayout(False)
        Me.tpInterface.ResumeLayout(False)
        Me.tpInterface.PerformLayout()
        Me.tpAttributes.ResumeLayout(False)
        Me.tpAttributes.PerformLayout()
        Me.grpPreview.ResumeLayout(False)
        Me.grpPreview.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlProject As System.Windows.Forms.Panel
    Friend WithEvents lblCulture As System.Windows.Forms.Label
    Friend WithEvents cboCulture As System.Windows.Forms.ComboBox
    Friend WithEvents numVersion As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents txtTranslator As System.Windows.Forms.TextBox
    Friend WithEvents lblTranslator As System.Windows.Forms.Label
    Friend WithEvents tabTranslation As System.Windows.Forms.TabControl
    Friend WithEvents tpInterface As System.Windows.Forms.TabPage
    Friend WithEvents txtNew As System.Windows.Forms.TextBox
    Friend WithEvents lblNew As System.Windows.Forms.Label
    Friend WithEvents txtDefault As System.Windows.Forms.TextBox
    Friend WithEvents lblDefault As System.Windows.Forms.Label
    Friend WithEvents lvwTranslation As System.Windows.Forms.ListView
    Friend WithEvents chDefaultCulture As System.Windows.Forms.ColumnHeader
    Friend WithEvents chNewCulture As System.Windows.Forms.ColumnHeader
    Friend WithEvents tpAttributes As System.Windows.Forms.TabPage
    Friend WithEvents txtNewAttr As System.Windows.Forms.TextBox
    Friend WithEvents lblNewAttr As System.Windows.Forms.Label
    Friend WithEvents txtDefaultAttr As System.Windows.Forms.TextBox
    Friend WithEvents lblDefaultAttr As System.Windows.Forms.Label
    Friend WithEvents lvwAttributes As System.Windows.Forms.ListView
    Friend WithEvents chDefaultAttr As System.Windows.Forms.ColumnHeader
    Friend WithEvents chNewAttr As System.Windows.Forms.ColumnHeader
    Friend WithEvents chItemName As System.Windows.Forms.ColumnHeader
    Friend WithEvents btnCreate As System.Windows.Forms.Button
    Friend WithEvents txtLanguage As System.Windows.Forms.TextBox
    Friend WithEvents lblLanguage As System.Windows.Forms.Label
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnNextAttr As System.Windows.Forms.Button
    Friend WithEvents grpPreview As System.Windows.Forms.GroupBox
    Friend WithEvents lblPreview As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents lblSelLanguage As System.Windows.Forms.Label

End Class
