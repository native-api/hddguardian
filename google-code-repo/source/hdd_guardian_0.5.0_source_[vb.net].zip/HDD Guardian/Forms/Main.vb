﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.IO
Imports System.Runtime.InteropServices

Public Class Main

    Enum StoringDevice
        Fixed = 0
        Removable = 1
    End Enum

    Dim installdevice As StoringDevice = StoringDevice.Fixed
    Dim tab_size As Size = New Size(568, 321)
    Dim tab_loc As Point = New Point(184, 88)
    Dim isloading As Boolean = True
    Dim isadmin As Boolean = True

#Region "UTX Theme call"
    Private Random As Random
    <DllImport("uxtheme.dll", CharSet:=CharSet.Unicode)> _
    Public Shared Function SetWindowTheme(ByVal hWnd As IntPtr, ByVal appName As String, ByVal partList As String) As Integer

    End Function

    Public Sub New()

        ' Chiamata richiesta dalla finestra di progettazione.
        InitializeComponent()

        ' Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent().

        SetWindowTheme(tvwComputer.Handle, "explorer", Nothing)
        SetWindowTheme(lvwAttrFormat.Handle, "explorer", Nothing)
        SetWindowTheme(lvwDevices.Handle, "explorer", Nothing)
        SetWindowTheme(lvwLog.Handle, "explorer", Nothing)
        SetWindowTheme(lvwSelective.Handle, "explorer", Nothing)
        SetWindowTheme(lvwSelfTest.Handle, "explorer", Nothing)
        SetWindowTheme(lvwSmart.Handle, "explorer", Nothing)
        SetWindowTheme(lvwChart.Handle, "explorer", Nothing)
        SetWindowTheme(lvwScsiTests.Handle, "explorer", Nothing)
        SetWindowTheme(tvwScsiErrors.Handle, "explorer", Nothing)
        SetWindowTheme(lvwProgLog.Handle, "explorer", Nothing)
    End Sub
#End Region

#Region "Main form"

    Private Sub Main_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        If tvwComputer.Nodes.Count > 0 Then tvwComputer.Nodes(0).Expand()
        SetWindowTheme(lvwDevices.Handle, "explorer", Nothing)
    End Sub

    Private Sub frmMain_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate
        On Error Resume Next

        If My.Settings.MinimizeOnTray Then
            If Me.WindowState = FormWindowState.Minimized Then
                Me.ShowInTaskbar = False
                Me.Visible = False
                niTrayIcon.Visible = True
            Else
                Me.ShowInTaskbar = True
                Me.Visible = True
                If Not IsNothing(niTrayIcon) Then niTrayIcon.Visible = My.Settings.AlwaysShowTrayIcon
            End If
        End If

        Memory.FlushMemory()
    End Sub

    Private Sub frmMain_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        For Each d In devlist
            d.DisposeTrayIcon()
        Next
        niTrayIcon.Visible = False
        StopMonitorDeviceConnection()
        Me.Dispose()
        End
    End Sub

    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim confirm As MsgBoxResult

        If My.Settings.CloseOnTray Then
            If Me.WindowState = FormWindowState.Normal Then
                e.Cancel = True
                Me.WindowState = FormWindowState.Minimized
                Me.ShowInTaskbar = False
                Me.Visible = False
                niTrayIcon.Visible = True
            End If
        End If

        If My.Settings.ConfirmOnExit And e.CloseReason = CloseReason.UserClosing Then
            confirm = MsgBox(m_exitmsg, MsgBoxStyle.OkCancel + MsgBoxStyle.Exclamation, m_exit)
            If confirm = MsgBoxResult.Cancel Then e.Cancel = True
        End If
    End Sub

    Dim on_debug As Boolean = False
    Dim savedebug As Boolean = False

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'translate interface
        InterfaceTranslation()

        'conversion of old config files
        ConvertDevSettingsFiles()
        'ConvertLogFiles()

        'command line options
        If My.Application.CommandLineArgs.Contains("-debug") Then
            on_debug = True
            DebugWindow.Show()
        End If
        If My.Application.CommandLineArgs.Contains("-savedebug") Then savedebug = True

        isloading = True

        isadmin = My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator)

        AnalyzeWMI()

        'check if smartctl.exe is in the hdd guardian folder:
        'if not, the program will be closed.
        If Not IO.File.Exists(My.Application.Info.DirectoryPath & "\smartctl.exe") Then
            MsgBox(m_nosmartctl, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, m_error)
            Me.Dispose()
            End
        End If

        LoadTrayIcons()

        'hide update panel at main window bottom
        pnlUpdate.Visible = False

        'disable from devices and tray icon context menu the function to scan for external
        'devices if user are not an administrator
        mnuSearchUsb.Enabled = isadmin
        'mnuRescanRemovable.Enabled = isadmin

        LoadSettings()

        'set main window title
        With My.Application.Info
            Me.Text = .Title.ToString & " " & .Version.Major.ToString & "." & .Version.Minor.ToString & "." & .Version.Build.ToString
            If My.Resources.prerelease > 0 Then
                Me.Text += " | beta " & My.Resources.prerelease
            End If
            niTrayIcon.Text = Me.Text
        End With

        PrintDebug(Me.Text)

        'set .NET Framework version label (now, you see the version you're runnig!)
        With System.Environment.Version
            lblFramework.Text = ".NET Framework version " & .ToString
        End With

        'uncheck and hide device options
        chkAttributes.Checked = False
        pnlAttributes.Visible = False
        chkFirmware.Checked = False
        tlpFirmware.Visible = False
        chkTolerance.Checked = False
        flwTolerance.Visible = False
        chkPowerMode.Checked = False
        flwPowerMode.Visible = False

        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabPerformance.Enabled = False
        tabAbout.Enabled = False
        rbScsiErrors.Checked = True
        tabScsi.Enabled = False

        If devtype.DriveType <> DriveType.Fixed Then
            'if hddguardian is stored into a non fixed
            '(removable media, cd-rom, network, etc.) drive, user
            'can't modify the basics settings, can't show devices icons
            'in tray area, can't share the output, can't add or remove
            'virtual devices, and can't modify the behaviour of smartctl
            '(normally if a program is stored into a removable device is
            'used for purposes of a quick check)
            installdevice = StoringDevice.Removable
            mnuRemoveVirtualDev.Enabled = False
            mnuAddVirtualDev.Enabled = False
            chkAttributes.Enabled = False
            chkFirmware.Enabled = False
            chkTolerance.Enabled = False
            chkPowerMode.Enabled = False
        Else

        End If

        LoadAttribInfos()
        LoadManufacturers()
        LoadOs()
        LoadIcons()

        Search()
        CollectDevices()
        PopulateDeviceList()
        VitalsCheck()
        OverallHealthCheck()

        mnuMain.PerformClick()

        'About section:
        'load license
        lblLicense.Text = My.Resources.License
        'set version and copyright
        With My.Application.Info
            lblVersion.Text = .Version.Major.ToString & "." & .Version.Minor.ToString & "." & .Version.Build.ToString
            If My.Resources.prerelease > 0 Then
                lblVersion.Text += " | beta " & My.Resources.prerelease
            End If
            lblCopyright.Text = .Copyright
        End With

        If My.Settings.StartMinimized Then
            Me.WindowState = FormWindowState.Minimized
            If My.Settings.MinimizeOnTray Then
                Me.ShowInTaskbar = False
                Me.Visible = False
                niTrayIcon.Visible = True
            End If
        End If

        'start monitoring for incoming/outcoming devices
        'only if user have administration rights, because smartctl
        'fail to open usb ports if user have a limited account
        If My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
            Me.Text += " | " & ApplicationServices.BuiltInRole.Administrator.ToString
            If My.Settings.MonitorUsb Then StartMonitorDeviceConnection()
        Else
            chkMonitorUsb.Checked = False
            chkMonitorUsb.Enabled = False
        End If

        'populate all panels for the first device in list
        If devlist(0).Type <> DeviceType.SCSI Then
            PopulateAll()
        Else
            ScsiPanels()
        End If
        rbSplit.Checked = True

        Memory.FlushMemory()
        isloading = False
        SetWindowTheme(lvwDevices.Handle, "explorer", Nothing)
    End Sub
#End Region

#Region "Flush memory timer"
    Private Sub tmrFlushMem_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrFlushMem.Tick
        Memory.FlushMemory()
    End Sub
#End Region

#Region "Rating Stars"
    Private Sub picStars_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picStars.Click
        'If gbAdvanced.Enabled Then
        'gbAdvanced_Click(gbAdvanced, System.EventArgs.Empty)
        'gbAdvanced.Checked = True
        tabAdvanced.SelectedTab = tpReliability
        mnuAdvanced_Click(mnuAdvanced, System.EventArgs.Empty)

        'End If
    End Sub
#End Region

#Region "Sections navigation context menu"
    Private Sub pbMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbMenu.Click
        Dim p As New Point(pbMenu.Width, pbMenu.Height)

        cmSections.Show(pbMenu, p, LeftRightAlignment.Left)
    End Sub

    Private Sub mnuMain_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMain.Click
        Dim d As Device = devlist(lvwDevices.SelectedItems(0).Index)
        If d.IsScsi Then
            With tabScsi
                .Size = tab_size
                .Location = tab_loc
                .Enabled = True
                .BringToFront()
                .Focus()
                mnuHelp.Tag = "http://code.google.com/p/hddguardian/wiki/scsi"
            End With
            tabMain.Enabled = False
        Else
            With tabMain
                .Size = tab_size
                .Location = tab_loc
                .Enabled = True
                .BringToFront()
                .Focus()
                mnuHelp.Tag = .SelectedTab.Tag
            End With
            tabScsi.Enabled = False
        End If

        lblCurrentSection.Text = mnuMain.Text

        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False
        tabPerformance.Enabled = False
        tabMonitoring.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub mnuPerformance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPerformance.Click
        With tabPerformance
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            mnuHelp.Tag = "http://code.google.com/p/hddguardian/wiki/performance"
        End With
        lblCurrentSection.Text = mnuPerformance.Text

        tabMain.Enabled = False
        tabScsi.Enabled = False
        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False
        tabMonitoring.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub mnuMonitoring_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMonitoring.Click
        With tabMonitoring
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            mnuHelp.Tag = "http://code.google.com/p/hddguardian/wiki/monitoring_section"
        End With
        lblCurrentSection.Text = mnuMonitoring.Text

        tabMain.Enabled = False
        tabScsi.Enabled = False
        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False
        tabPerformance.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub mnuAdvanced_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdvanced.Click
        With tabAdvanced
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            mnuHelp.Tag = .SelectedTab.Tag
        End With
        lblCurrentSection.Text = mnuAdvanced.Text

        tabMain.Enabled = False
        tabScsi.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False
        tabPerformance.Enabled = False
        tabMonitoring.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub mnuSmartctl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSmartctl.Click
        With tabSmartctl
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            mnuHelp.Tag = .SelectedTab.Tag
        End With
        lblCurrentSection.Text = mnuSmartctl.Text

        tabMain.Enabled = False
        tabScsi.Enabled = False
        tabAdvanced.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False
        tabPerformance.Enabled = False
        tabMonitoring.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub mnuSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSettings.Click
        With tabSettings
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            mnuHelp.Tag = .SelectedTab.Tag
        End With
        lblCurrentSection.Text = mnuSettings.Text

        tabMain.Enabled = False
        tabScsi.Enabled = False
        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabAbout.Enabled = False
        tabPerformance.Enabled = False
        tabMonitoring.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub mnuAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAbout.Click
        With tabAbout
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            mnuHelp.Tag = "http://code.google.com/p/hddguardian/wiki/Project_purpose"
        End With
        lblCurrentSection.Text = mnuAbout.Text

        tabMain.Enabled = False
        tabScsi.Enabled = False
        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabPerformance.Enabled = False
        tabMonitoring.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub mnuHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelp.Click
        Try
            System.Diagnostics.Process.Start(sender.Tag)
        Catch
            PrintDebug("Help error: Internet connection not available", True)
        End Try
    End Sub

    Private Sub mnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        Dim confirm As MsgBoxResult
        If My.Settings.ConfirmOnExit Then
            confirm = MsgBox(m_exitmsg, MsgBoxStyle.OkCancel + MsgBoxStyle.Exclamation, m_exit)
            If confirm = MsgBoxResult.Cancel Then Exit Sub
        End If

        StopMonitorDeviceConnection()

        For Each d In devlist
            d.DisposeTrayIcon()
        Next

        niTrayIcon.Visible = False
        Me.Dispose()
        End
    End Sub
#End Region

#Region "Devices list"
    Dim current As Short
    Dim loadnow As Boolean = True

    Private Sub lvwDevices_Invalidated(ByVal sender As Object, ByVal e As System.Windows.Forms.InvalidateEventArgs) Handles lvwDevices.Invalidated
        SetWindowTheme(lvwDevices.Handle, "explorer", Nothing)
    End Sub

    Private Sub lvwDevices_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvwDevices.MouseDown
        Try
            Dim lvItem As ListViewItem
            current = lvwDevices.SelectedItems(0).Index

            lvItem = lvwDevices.GetItemAt(e.X, e.Y)
            If e.Button = MouseButtons.Right And Not IsNothing(lvItem) Then
                Dim dev As Device = devlist(lvItem.Index)
                mnuRefreshSel.Enabled = True
                If dev.Type = DeviceType.ATA Or dev.Type = DeviceType.USB Or dev.Type = DeviceType.SCSI Then
                    mnuRemoveVirtualDev.Enabled = False
                Else
                    mnuRemoveVirtualDev.Enabled = True
                End If
                cmDevices.Show(CType(sender, ListView), New Point(e.X, e.Y))
            ElseIf e.Button = MouseButtons.Right And IsNothing(lvItem) Then
                mnuRemoveVirtualDev.Enabled = False
                mnuRefreshSel.Enabled = False
                cmDevices.Show(CType(sender, ListView), New Point(e.X, e.Y))
            End If
        Catch ex As Exception
            PrintDebug("Error on devices list: " & ex.Message)
        End Try

    End Sub

    Private Sub lvwDevices_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvwDevices.MouseUp
        Dim lvItem As ListViewItem

        lvItem = lvwDevices.GetItemAt(e.X, e.Y)
        If IsNothing(lvItem) Then
            loadnow = False
            lvwDevices.Items(current).Selected = True
            loadnow = True
        End If
    End Sub

    Private Sub lvwDevices_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvwDevices.ItemSelectionChanged
        If isloading Then Exit Sub
        If e.IsSelected And loadnow And Not Me.ResizeRedraw Then

            Dim dev As Device = devlist(e.ItemIndex)

            If dev.IsScsi Then
                ScsiPanels()
                mnuPerformance.Enabled = False
                mnuAdvanced.Enabled = False
                If tabPerformance.Enabled Or tabAdvanced.Enabled Or tabMain.Enabled Then mnuMain.PerformClick()
            Else
                If tabScsi.Enabled Then mnuMain.PerformClick()
                PopulateAll()
                pnlSystem.Parent = tpSystem
                mnuPerformance.Enabled = True
                mnuAdvanced.Enabled = True
            End If
            DisplayLogEvents()
            FillChartEvents()

            If dev.Type = DeviceType.Virtual Then
                chkEnableTray.Enabled = False
                chkDisplayLife.Enabled = False
                chkEnableShare.Enabled = False
                chkEnableTray.Checked = False
                chkDisplayLife.Checked = False
                chkEnableShare.Checked = False
            Else
                LoadTrayIconSetup()
            End If

            If dev.SmartEnabled = Support.Enabled Then
                If Not dev.IsScsi Then mnuAdvanced.Enabled = True
            Else
                If tabAdvanced.Enabled Then mnuMain.PerformClick()
                mnuAdvanced.Enabled = False
            End If

            If dev.TestIsRunnig Then
                pnlProgress.Visible = True
                flwTest.Enabled = False
                btnRun.Enabled = False
                tmrTest.Start()
            Else
                pnlProgress.Visible = False
                flwTest.Enabled = True
                btnRun.Enabled = True
                tmrTest.Stop()
            End If
        End If
    End Sub
#End Region

#Region "Devices list context menu"

    Private Sub mnuRemoveVirtual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuRemoveVirtualDev.Click
        Dim virtualfolder As String = My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData _
                                      .Substring(0, My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData.LastIndexOf("\")) _
                                      & "\Virtual devices\"
        Dim i As Short = lvwDevices.SelectedItems(0).Index

        With lvwDevices
            .Items(i).Remove()
            .Groups(2).Header = .Groups(2).Tag & " - " & .Groups(2).Items.Count
            .Items(0).Selected = True
            .Columns(2).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
            .Columns(1).Width = .ClientSize.Width - .Columns(2).Width - .Columns(0).Width
            SetWindowTheme(.Handle, "explorer", Nothing)
        End With
        File.Delete(virtualfolder & devlist(i).Model.Replace("/", "") & "_" & devlist(i).SerialNumber.Replace("/", "") & ".vd")
        devlist.RemoveAt(i)
    End Sub

    Private Sub mnuAddVirtual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAddVirtualDev.Click
        AddVirtual.ShowDialog(Me)
        UpdateCurrent()

        Memory.FlushMemory()
    End Sub

    Private Sub mnuUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuRefreshSel.Click
        UpdateCurrent()

        Memory.FlushMemory()
    End Sub

    Private Sub mnuUpdateAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuRefreshAll.Click
        CheckForUpdates()
        UpdateAll(DeviceType.ATA)
        UpdateAll(DeviceType.SCSI)
        UpdateAll(DeviceType.USB)
        UpdateAll(DeviceType.Virtual)

        Memory.FlushMemory()
    End Sub

    Private Sub mnuRescanExternal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuSearchUsb.Click
        UsbDevicesComparison()
        'eSataDevicesComparison()

        Memory.FlushMemory()
    End Sub

#End Region

#Region "Tray icon"
    Private Sub niTrayIcon_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles niTrayIcon.MouseDown
        niTrayIcon.ContextMenu = cmTrayIcon

        Select Case e.Button
            Case Windows.Forms.MouseButtons.Left
                'restore main screen
                Me.WindowState = FormWindowState.Normal
                Me.ShowInTaskbar = True
                Me.Visible = True
                Me.Activate()
                niTrayIcon.Visible = My.Settings.AlwaysShowTrayIcon
            Case Windows.Forms.MouseButtons.Middle
                'if is pressed the middle button refresh all devices
                UpdateAll(DeviceType.ATA)
                UpdateAll(DeviceType.USB)
                UpdateAll(DeviceType.Virtual)
            Case Windows.Forms.MouseButtons.Right
                'none. Automatically display trayicon context menu
        End Select
    End Sub
#End Region

#Region "Timers"
    Private Sub RefreshNonRemovalbe(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefresh.Tick
        PrintDebug("Checking for updated devices values")
        CheckForUpdates()
        PrintDebug("Updating internal devices")
        UpdateAll(DeviceType.ATA)
        UpdateAll(DeviceType.SCSI)
    End Sub

    Private Sub RefreshRemovable(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefreshExt.Tick
        UpdateAll(DeviceType.USB)
    End Sub

    Private Sub RefreshVirtual(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefreshVirtual.Tick
        UpdateAll(DeviceType.Virtual)
    End Sub
#End Region

#Region "Tray icon context menu"
    Private Sub DevRefresh(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CheckForUpdates()
        UpdateAll(DeviceType.ATA)
        UpdateAll(DeviceType.SCSI)
        UpdateAll(DeviceType.USB)
        UpdateAll(DeviceType.Virtual)

        Memory.FlushMemory()
    End Sub

    Private Sub mnuRestore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuRestoreTray.Click
        If Me.WindowState = FormWindowState.Minimized Then
            Me.Size = New Size(757, 460)
            Me.WindowState = FormWindowState.Normal
            Me.ShowInTaskbar = True
            Me.Visible = True
            Me.Activate()
            niTrayIcon.Visible = My.Settings.AlwaysShowTrayIcon
        End If
    End Sub

    Private Sub ExitProgram(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuExitTray.Click
        Dim confirm As MsgBoxResult
        If My.Settings.ConfirmOnExit Then
            confirm = MsgBox(m_exitmsg, MsgBoxStyle.OkCancel + MsgBoxStyle.Exclamation, m_exit)
            If confirm = MsgBoxResult.Cancel Then Exit Sub
        End If

        For Each d In devlist
            d.DisposeTrayIcon()
        Next

        niTrayIcon.Visible = False
        Me.Dispose()
        End
    End Sub
#End Region

#Region "Summary"
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        UpdateCurrent()
    End Sub

    Private Sub btnDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetails.Click
        'gbAdvanced_Click(gbAdvanced, System.EventArgs.Empty)
        'gbAdvanced.Checked = True
        tabAdvanced.SelectedTab = tpAttributes
        mnuAdvanced.PerformClick()

    End Sub

    Private Sub btnRunTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRunTest.Click
        'gbAdvanced_Click(gbAdvanced, System.EventArgs.Empty)
        'gbAdvanced.Checked = True
        tabAdvanced.SelectedTab = tpRunTest
        mnuAdvanced.PerformClick()

    End Sub
#End Region

#Region "Scsi summary"
    Private Sub btnScsiUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnScsiUpdate.Click
        UpdateCurrent()
    End Sub

    Private Sub btnScsiDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnScsiDetails.Click
        tabScsi.SelectedTab = tpScsiDetails
    End Sub

    Private Sub btnScsiRunTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnScsiRunTest.Click
        tabScsi.SelectedTab = tpScsiRunTest
    End Sub
#End Region

#Region "Device info"
    Private Sub lnkUpdateSmartctl_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkUpdateSmartctl.LinkClicked
        If System.IO.File.Exists(My.Application.Info.DirectoryPath & "\update-smart-drivedb.exe") Then
            Shell(My.Application.Info.DirectoryPath & "\update-smart-drivedb.exe", AppWinStyle.NormalFocus, False)
        End If
    End Sub
#End Region

#Region "Enable/disable features"
    Dim isloading_features As Boolean = False

    Private Sub chkEnableSmart_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles chkEnableSmart.MouseDown
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Or isloading_features Then Exit Sub

        Select Case dev.SmartEnabled ' chkEnableSmart.Checked
            Case Support.Disabled   'True
                dev.SetSmartStatus(SmartFeature.Enable)
                dev.Update()
                Select Case dev.SmartEnabled
                    Case Support.Enabled
                        MsgBox(m_smartenabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                        chkEnableSmart.Checked = True
                        chkEnableOffline.Enabled = True
                        chkEnableAutosave.Enabled = True
                    Case Support.Ambiguous
                        MsgBox(m_smartambiguous.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, m_message)
                        chkEnableSmart.Checked = False
                    Case Support.Disabled
                        MsgBox(m_smartnotsupported.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, m_message)
                        chkEnableSmart.Checked = False
                End Select
            Case Support.Enabled  ' False
                Dim qst As MsgBoxResult = MsgBox(m_qdisablesmart.Replace("%", dev.Model), MsgBoxStyle.YesNo + MsgBoxStyle.Question, m_question)
                If qst = MsgBoxResult.Yes Then
                    dev.SetSmartStatus(SmartFeature.Disable)
                    dev.Update()
                    MsgBox(m_smartdisabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                    chkEnableSmart.Checked = False
                    chkEnableOffline.Checked = False
                    chkEnableOffline.Enabled = False
                    chkEnableAutosave.Checked = False
                    chkEnableAutosave.Enabled = False
                End If
        End Select

        PopulateCapabilities()
    End Sub

    Private Sub chkEnableOffline_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles chkEnableOffline.MouseDown
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Or isloading_features Then Exit Sub

        Select Case dev.OfflineCollectionStatus ' chkEnableOffline.Checked
            Case Support.Enabled  ' True
                Dim qst As MsgBoxResult = MsgBox(m_qdisableoffldata.Replace("%", dev.Model), MsgBoxStyle.YesNo + MsgBoxStyle.Question, m_question)
                If qst = MsgBoxResult.Yes Then
                    dev.SetOfflineCollectionStatus(SmartFeature.Disable)
                    dev.Update()
                    If dev.OfflineCollectionStatus = Support.Disabled Then
                        MsgBox(m_offldatadisabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                        chkEnableOffline.Checked = False
                    ElseIf dev.OfflineCollectionStatus = Support.Enabled Then
                        MsgBox(m_unabletodisable.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                        chkEnableOffline.Checked = True
                    End If
                End If
            Case Support.Disabled ' False
                dev.SetOfflineCollectionStatus(SmartFeature.Enable)
                dev.Update()
                txtReport.Text = dev.Output
                Select Case dev.OfflineCollectionStatus
                    Case Support.Enabled
                        MsgBox(m_offldataenabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                        chkEnableOffline.Checked = True
                    Case Support.Disabled
                        MsgBox(m_offldatanotsupported.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, m_message)
                        chkEnableOffline.Checked = False
                End Select
        End Select

        UpdateCurrent()
    End Sub

    Private Sub chkEnableAutosave_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnableAutosave.CheckedChanged
        If isloading_devsettings Or lvwDevices.Items.Count = 0 Then Exit Sub

        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Then Exit Sub

        If installdevice = StoringDevice.Fixed Then
            SaveDeviceSettings()

        Else
            'SaveDeviceSettings()
        End If
    End Sub

#End Region

#Region "System"
    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        UpdateHardware()
    End Sub

    Private Sub tvwComputer_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvwComputer.AfterSelect
        ShowDetails()
    End Sub
#End Region

#Region "Log events"
    'log events are all stored into "LogEvents.vb"
#End Region

#Region "AAM"
    Private Sub trkAam_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkAam.Scroll, trkAam.ValueChanged
        lnkSetAam.Visible = True
        lnkUndoAam.Visible = True
        lblAamValue.Text = lblAamValue.Tag & ": " & trkAam.Value
    End Sub

    Private Sub lnkSetAam_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkSetAam.LinkClicked
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        lnkUndoAam.Visible = False
        pnlApply.Parent = tpAAM
        pnlApply.Visible = True
        picApply.Refresh()
        lblApply.Refresh()

        If trkAam.Value = 0 Then
            dev.AamValue = "off"
        Else
            dev.AamValue = trkAam.Value
        End If

        pnlApply.Visible = False

        txtReport.Text = dev.Output
    End Sub

    Private Sub lnkSetRecommended_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkSetRecommended.LinkClicked
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        lnkUndoAam.Visible = False
        pnlApply.Parent = tpAAM
        pnlApply.Visible = True
        picApply.Refresh()
        lblApply.Refresh()

        lblAamValue.Text = lblAamValue.Tag & ": " & dev.RecommendedAAM
        trkAam.Value = dev.RecommendedAAM
        dev.AamValue = dev.RecommendedAAM

        pnlApply.Visible = False

        txtReport.Text = dev.Output
    End Sub

    Private Sub lnkUndoAam_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkUndoAam.LinkClicked
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)
        trkAam.Value = dev.AamValue
        lnkUndoAam.Visible = False
    End Sub
#End Region

#Region "APM"
    Private Sub trkApm_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkApm.Scroll, trkApm.ValueChanged
        lnkSetApm.Visible = True
        lnkUndoApm.Visible = True
        lblApmValue.Text = lblApmValue.Tag & ": " & trkApm.Value
    End Sub

    Private Sub lnkSetApm_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkSetApm.LinkClicked
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        lnkUndoApm.Visible = False
        pnlApply.Parent = tpAPM
        pnlApply.Visible = True
        picApply.Refresh()
        lblApply.Refresh()

        If trkApm.Value = 0 Then
            dev.ApmValue = "off"
        Else
            dev.ApmValue = trkApm.Value
        End If

        pnlApply.Visible = False

        txtReport.Text = dev.Output
    End Sub

    Private Sub lnkUndoApm_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkUndoApm.LinkClicked
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)
        trkApm.Value = dev.ApmValue
        lnkUndoApm.Visible = False
    End Sub
#End Region

#Region "Standby"
    Private Sub trkStandby_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkStandby.Scroll, trkStandby.ValueChanged
        lnkUndoStandby.Visible = True
        Select Case trkStandby.Value
            Case 0
                lblStandbyValue.Text = lblStandbyValue.Tag & ": 0 (" & m_off & ")"
            Case 1 To 240
                Dim time As Short = trkStandby.Value * 5
                Dim minutes, seconds As Short
                If time > 60 Then
                    minutes = time \ 60
                    seconds = (time / 60 - minutes) * 60
                Else
                    minutes = 0
                    seconds = time
                End If
                Dim min As String = String.Format("{0:D2}", minutes)
                Dim sec As String = String.Format("{0:D2}", seconds)
                lblStandbyValue.Text = lblStandbyValue.Tag & ": " & trkStandby.Value & " (" & min & "'" & sec & """)"
            Case 241 To 251
                Dim time As Short = trkStandby.Value * 30
                Dim minutes, hours As Short
                If time > 60 Then
                    hours = time \ 60
                    minutes = (time / 60 - hours) * 60
                Else
                    hours = 0
                    minutes = time
                End If
                Dim min As String = String.Format("{0:D2}", minutes)
                Dim h As String = String.Format("{0:D2}", hours)
                lblStandbyValue.Text = lblStandbyValue.Tag & ": " & trkStandby.Value & " (" & h & "h " & min & "')"
            Case 252
                lblStandbyValue.Text = lblStandbyValue.Tag & ": " & trkStandby.Value & " (21'00"")"
            Case 253
                lblStandbyValue.Text = lblStandbyValue.Tag & ": " & trkStandby.Value & " (" & m_vendortime & ")"
            Case 254
                lblStandbyValue.Text = lblStandbyValue.Tag & ": " & trkStandby.Value & " (" & m_reserved & ")"
            Case 255
                lblStandbyValue.Text = lblStandbyValue.Tag & ": " & trkStandby.Value & " (21'15"")"
        End Select
    End Sub

    Private Sub lnkSetStandby_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkSetStandby.LinkClicked
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        lnkUndoStandby.Visible = True
        pnlApply.Parent = tpStandby
        pnlApply.Visible = True
        picApply.Refresh()
        lblApply.Refresh()

        dev.Standby = trkStandby.Value

        pnlApply.Visible = False
    End Sub

    Private Sub lnkUndoStandby_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkUndoStandby.LinkClicked
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)
        trkStandby.Value = dev.Standby
        lnkUndoStandby.Visible = False
    End Sub
#End Region

#Region "Other performance features"
    Private Sub chkCache_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCache.CheckedChanged
        If Not isloading_performace Then
            Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

            pnlApply.Parent = tpOtherFeatures
            pnlApply.Visible = True
            picApply.Refresh()
            lblApply.Refresh()

            Select Case chkCache.Checked
                Case False
                    dev.Cache = Feature.Disable
                Case True
                    dev.Cache = Feature.Enable
            End Select

            pnlApply.Visible = False

            txtReport.Text = dev.Output
        End If
    End Sub

    Private Sub chkLookAhead_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkLookAhead.CheckedChanged
        If Not isloading_performace Then
            Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

            pnlApply.Parent = tpOtherFeatures
            pnlApply.Visible = True
            picApply.Refresh()
            lblApply.Refresh()

            Select Case chkLookAhead.Checked
                Case False
                    dev.LookAhead = Feature.Disable
                Case True
                    dev.LookAhead = Feature.Enable
            End Select

            pnlApply.Visible = False

            txtReport.Text = dev.Output
        End If
    End Sub
#End Region

#Region "SMART attributes"

    Private Sub CatchAttributeInfo(ByVal itemname As String, ByVal type As String, ByVal update As String)
        Dim haveinfo As Boolean = False
        Dim family As String = devlist(lvwDevices.SelectedItems(0).Index).Family

        'SSD devices
        If family.StartsWith("Crucial/Micron") Then
            With apAttributes
                For i As Short = 0 To m_MicronMeanings.Count - 1
                    If m_MicronMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_MicronMeanings(i).Name, _
                                 m_MicronMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("SandForce") Then
            With apAttributes
                For i As Short = 0 To m_SandForceMeanings.Count - 1
                    If m_SandForceMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_SandForceMeanings(i).Name, _
                                 m_SandForceMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next

            End With
        ElseIf family.StartsWith("Indilinx") Then
            With apAttributes
                For i As Short = 0 To m_IndilinxMeanings.Count - 1
                    If m_IndilinxMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_IndilinxMeanings(i).Name, _
                                 m_IndilinxMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("Intel") Or family.StartsWith("Kingston") Then 'some Intel SSDs are branded Kingston
            With apAttributes
                For i As Short = 0 To m_IntelMeanings.Count - 1
                    If m_IntelMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_IntelMeanings(i).Name, _
                                 m_IntelMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("JMicron") Then
            With apAttributes
                For i As Short = 0 To m_JMicronMeanings.Count - 1
                    If m_JMicronMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_JMicronMeanings(i).Name, _
                                 m_JMicronMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("Samsung based SSDs") Then
            With apAttributes
                For i As Short = 0 To m_SamsungMeanings.Count - 1
                    If m_SamsungMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_SamsungMeanings(i).Name, _
                                 m_SamsungMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("SMART") Then
            With apAttributes
                For i As Short = 0 To m_SmartMeanings.Count - 1
                    If m_SmartMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_SmartMeanings(i).Name, _
                                 m_SmartMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("SanDisk") Then
            With apAttributes
                For i As Short = 0 To m_SanDiskMeanings.Count - 1
                    If m_SanDiskMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_SanDiskMeanings(i).Name, _
                                 m_SanDiskMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("Adtron") Then
            With apAttributes
                For i As Short = 0 To m_AdtronMeanings.Count - 1
                    If m_AdtronMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_AdtronMeanings(i).Name, _
                                 m_AdtronMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        Else 'HDD
            With apAttributes
                For i As Short = 0 To m_attributesmeanings.Count - 1
                    If m_attributesmeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_attributesmeanings(i).Name, _
                                 m_attributesmeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        End If

        With apAttributes
            If haveinfo = False Then
                For i As Short = 0 To m_attributesmeanings.Count - 1
                    If m_attributesmeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_attributesmeanings(i).Name, _
                                 m_attributesmeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End If
            If haveinfo = False Then
                .SetInfo(m_attributesmeanings(0).Name, _
                         m_attributesmeanings(0).Description, _
                         type, update)
            End If
        End With
    End Sub

    Private Sub lvwSmart_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwSmart.Enter
        Dim itemname As String = ""
        Dim type As String = ""
        Dim update As String = ""
        Dim flags As AttributeFlags


        If lvwSmart.SelectedItems.Count > 0 Then
            With lvwSmart.SelectedItems(0)
                FlagsPanel1.GetFlags(.SubItems(0).Tag)
                ValuesPanel1.SetProgressBarsValues(Val(.SubItems(5).Text), Val(.SubItems(3).Text), Val(.SubItems(4).Text))
                itemname = .SubItems(2).Text
                flags = .SubItems(0).Tag
                If flags.HasFlag(AttributeFlags.UpdatedOnline) Then update = m_always Else update = m_offline
                If flags.HasFlag(AttributeFlags.Prefailure) Then type = m_prefail Else type = m_oldage
            End With

            CatchAttributeInfo(itemname, type, update)
        End If
    End Sub

    Private Sub lvwSmart_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwSmart.Leave
        apAttributes.SetInfo(m_tip, m_tiptext, "", "")
        FlagsPanel1.Reset()
        ValuesPanel1.SetProgressBarsValues(0, 0, 0)
    End Sub
    Private Sub lvwSmart_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwSmart.SelectedIndexChanged
        Dim itemname As String = ""
        Dim type As String = ""
        Dim update As String = ""
        Dim flags As AttributeFlags
        Dim haveinfo As Boolean = False

        If lvwSmart.SelectedItems.Count > 0 Then
            With lvwSmart.SelectedItems(0)
                FlagsPanel1.GetFlags(.SubItems(0).Tag)
                ValuesPanel1.SetProgressBarsValues(Val(.SubItems(5).Text), Val(.SubItems(3).Text), Val(.SubItems(4).Text))
                itemname = .SubItems(2).Text
                flags = .SubItems(0).Tag
                If flags.HasFlag(AttributeFlags.UpdatedOnline) Then update = m_always Else update = m_offline
                If flags.HasFlag(AttributeFlags.Prefailure) Then type = m_prefail Else type = m_oldage
            End With

            CatchAttributeInfo(itemname, type, update)
        End If
    End Sub

    Private Sub lnkShowInfo_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkShowInfo.LinkClicked
        If lvwSmart.Height = 112 Then
            apAttributes.Visible = False
            lvwSmart.Height = 224
        Else
            apAttributes.Visible = True
            lvwSmart.Height = 112
        End If
    End Sub
#End Region

#Region "Smart error log"
    Private Sub Error_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
            Handles optError1.CheckedChanged, optError2.CheckedChanged, optError3.CheckedChanged, _
            optError4.CheckedChanged, optError5.CheckedChanged
        Try
            Dim err As Short = Val(sender.Name.ToString.Substring(8, 1))
            DisplayATAError(err)
        Catch ex As Exception
            PrintDebug("Error displaying ATA errors: " & ex.ToString, True)
        End Try
    End Sub
#End Region

#Region "Run test"
    Private Sub cboTest_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTest.SelectedIndexChanged
        lblTestInfo.Text = m_tests(cboTest.SelectedIndex).Info
        pnlProgress.Visible = False
        btnRun.Visible = True

        If lvwDevices.SelectedItems.Count > 0 Then
            Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)
            Select Case cboTest.SelectedIndex
                Case 0
                    lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.OfflineData
                Case 1
                    lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ShortTest
                Case 2
                    lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ExtendedTest
                Case 3
                    lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ConveyanceTest
            End Select
        End If

        If lblDuration.Text.Contains("N/A") Then btnRun.Visible = False
    End Sub

    Private Sub btnRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRun.Click, btnScsiRun.Click
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        If dev.IsScsi Then
            dev.RunTest(TestType.ScsiLongTest)

            btnScsiRun.Enabled = False
            prbScsiTestProgress.Value = 0
            prbScsiTestProgress.Maximum = dev.TestTiming.Duration
            lblScsiProgress.Text = "0%"
            lblScsiExtimatedEnd.Text = lblScsiExtimatedEnd.Tag & dev.TestTiming.Conclusion
            btnScsiStop.Enabled = True
            pnlScsiTestRun.Visible = True
            tmrTest.Start()
        Else

            Select Case cboTest.SelectedIndex
                Case 0 'offline data collection
                    dev.RunTest(TestType.Offline)
                Case 1 'short test
                    dev.RunTest(TestType.ShortTest)
                Case 2 'extended test
                    dev.RunTest(TestType.LongTest)
                Case 3 'conveyance test
                    dev.RunTest(TestType.Conveyance)
            End Select

            flwTest.Enabled = False
            btnRun.Enabled = False
            prbTestProgress.Value = 0
            prbTestProgress.Maximum = dev.TestTiming.Duration
            lblProgress.Text = "0%"
            lblExtimatedEnd.Text = lblExtimatedEnd.Tag & dev.TestTiming.Conclusion
            btnStop.Enabled = True
            pnlProgress.Visible = True
            tmrTest.Start()
        End If


    End Sub

    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click, btnScsiStop.Click
        Dim response As MsgBoxResult = MsgBox(m_abortmsg, MsgBoxStyle.Question + MsgBoxStyle.YesNo, m_aborttitle)
        If response = MsgBoxResult.Yes Then
            Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)
            dev.RunTest(TestType.Abort)
        End If
    End Sub

    Private Sub tmrTest_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrTest.Tick
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        If dev.IsScsi Then
            If dev.TestIsRunnig Then
                Dim span As TimeSpan = Now - dev.TestTiming.Start
                If span.TotalSeconds <= dev.TestTiming.Duration Then
                    prbScsiTestProgress.Maximum = dev.TestTiming.Duration
                    prbScsiTestProgress.Value = span.TotalSeconds
                    lblScsiProgress.Text = span.TotalSeconds * 100 \ dev.TestTiming.Duration & "%"
                Else
                    UpdateAll(DeviceType.SCSI)
                    pnlScsiTestRun.Visible = False
                    prbScsiTestProgress.Value = 0
                    btnScsiRun.Enabled = True
                    dev.TestIsRunnig = False
                    tmrTest.Stop()
                End If
            End If
        Else
            If dev.TestIsRunnig Then
                Dim span As TimeSpan = Now - dev.TestTiming.Start
                If span.TotalSeconds <= dev.TestTiming.Duration Then
                    prbTestProgress.Maximum = dev.TestTiming.Duration
                    prbTestProgress.Value = span.TotalSeconds
                    lblProgress.Text = span.TotalSeconds * 100 \ dev.TestTiming.Duration & "%"
                Else
                    UpdateAll(DeviceType.ATA)
                    UpdateAll(DeviceType.USB)
                    pnlProgress.Visible = False
                    prbTestProgress.Value = 0
                    flwTest.Enabled = True
                    btnRun.Enabled = True
                    dev.TestIsRunnig = False
                    tmrTest.Stop()
                End If
            End If
        End If
    End Sub
#End Region

#Region "Database"
    'no more available from version 0.3.0
    'Private Sub cboDatabase_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDatabase.SelectedIndexChanged
    '    ShowDbEntryDetails()
    'End Sub
#End Region

#Region "Device output"
    Private Sub btnSaveOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveOutput.Click
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)
        Dim savedialog As New SaveFileDialog
        Dim res As DialogResult

        savedialog.DefaultExt = "txt"
        savedialog.AddExtension = True
        savedialog.Filter = "*.txt|*.txt"
        savedialog.FileName = dev.Model & "_" & dev.SerialNumber
        res = savedialog.ShowDialog(Me)
        If res = DialogResult.OK Then
            File.WriteAllText(savedialog.FileName, txtReport.Text)
        End If
    End Sub
#End Region

#Region "Smartctl settings"
    Dim isloading_devsettings As Boolean = False

#Region "Tolerance"
    Private Sub chkTolerance_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTolerance.CheckedChanged
        flwTolerance.Visible = chkTolerance.Checked
        If chkTolerance.Checked Then rbNormal.Checked = True
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

    Private Sub ChangeTolerance(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbNormal.CheckedChanged, rbConservative.CheckedChanged, rbVeryPermissive.CheckedChanged
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

#End Region

#Region "Attributes remap"
    Private Sub chkAttributes_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAttributes.CheckedChanged
        pnlAttributes.Visible = chkAttributes.Checked
        btnRemove.Enabled = False
        If Not pnlAttributes.Enabled Then
            cboAttributes.SelectedIndex = 0
            cboID.SelectedIndex = 0
            cboFormat.SelectedIndex = 0
            txtName.Text = ""
            btnAdd.Enabled = False
            lvwAttrFormat.Items.Clear()
        End If
        If chkAttributes.Checked = False Then
            SaveDeviceSettings()
        End If
    End Sub

    Private Sub cboAttributes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboAttributes.SelectedIndexChanged
        Dim cboBox As ComboBox = sender

        picAttributes.Visible = True
        If cboAttributes.SelectedIndex > 0 Then
            ttMain.SetToolTip(picAttributes, m_attributes(cboAttributes.SelectedIndex))
        End If

        Select Case cboBox.SelectedIndex
            Case 0
                cboID.SelectedIndex = 0
                cboFormat.SelectedIndex = 0
                txtName.Text = ""
                picAttributes.Visible = False
            Case 1
                cboID.SelectedIndex = 10
                cboFormat.SelectedIndex = 10
                txtName.Text = "Power_On_Minutes"
            Case 2
                cboID.SelectedIndex = 10
                cboFormat.SelectedIndex = 11
                txtName.Text = "Power_On_Seconds"
            Case 3
                cboID.SelectedIndex = 10
                cboFormat.SelectedIndex = 12
                txtName.Text = "Power_On_Half_Minutes"
            Case 4
                cboID.SelectedIndex = 10
                cboFormat.SelectedIndex = 13
                txtName.Text = "Temperature_Celsius"
            Case 5
                cboID.SelectedIndex = 193
                cboFormat.SelectedIndex = 6
                txtName.Text = "Emerg_Retract_Cycle_Ct"
            Case 6
                cboID.SelectedIndex = 194
                cboFormat.SelectedIndex = 5
                txtName.Text = "Load-Unload_Cycle_Count"
            Case 7
                cboID.SelectedIndex = 195
                cboFormat.SelectedIndex = 14
                txtName.Text = "Temperature_Celsius_x10"
            Case 8
                cboID.SelectedIndex = 195
                cboFormat.SelectedIndex = 6
                txtName.Text = "Unknown_Attribute"
            Case 9
                cboID.SelectedIndex = 198
                cboFormat.SelectedIndex = 6
                txtName.Text = "Total_Pending_Sectors"
            Case 10
                cboID.SelectedIndex = 199
                cboFormat.SelectedIndex = 6
                txtName.Text = "Total_Offl_Uncorrectabl"
            Case 11
                cboID.SelectedIndex = 199
                cboFormat.SelectedIndex = 6
                txtName.Text = "Offline_Scan_UNC_SectCt"
            Case 12
                cboID.SelectedIndex = 201
                cboFormat.SelectedIndex = 6
                txtName.Text = "Write_Error_Count"
            Case 13
                cboID.SelectedIndex = 202
                cboFormat.SelectedIndex = 6
                txtName.Text = "Detected_TA_Count"
            Case 14
                cboID.SelectedIndex = 221
                cboFormat.SelectedIndex = 6
                txtName.Text = "Temperature_Celsius"
        End Select
        If cboID.SelectedIndex > 0 Then cboID.Enabled = False Else cboID.Enabled = True
        If cboFormat.SelectedIndex > 0 Then cboFormat.Enabled = False Else cboFormat.Enabled = True
        If txtName.Text.Length > 0 Then txtName.Enabled = False Else txtName.Enabled = True

        btnAdd.Enabled = ValidateEntries()
    End Sub

    Private Sub cboFormat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFormat.SelectedIndexChanged
        If cboFormat.SelectedIndex = 0 Then
            picAttrFormat.Visible = False
        Else
            picAttrFormat.Visible = True
            ttMain.SetToolTip(picAttrFormat, m_formats(cboFormat.SelectedIndex))
        End If
    End Sub

    Private Sub cboID_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboID.SelectedIndexChanged
        Dim cboBox As ComboBox = sender

        Select Case cboBox.SelectedItem.ToString
            Case ""
                cboFormat.SelectedIndex = 0
            Case "3"
                cboFormat.SelectedIndex = 3
            Case "5"
                cboFormat.SelectedIndex = 4
            Case "190"
                cboFormat.SelectedIndex = 13
            Case "194"
                cboFormat.SelectedIndex = 13
            Case "196"
                cboFormat.SelectedIndex = 4
            Case Else
                cboFormat.SelectedIndex = 6
        End Select
        btnAdd.Enabled = ValidateEntries()
    End Sub

    Private Sub txtName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtName.KeyPress
        Select Case e.KeyChar.ToString
            Case "-", "a" To "z", "A" To "Z", "0" To "9", "_", ControlChars.Back.ToString
                'accept ONLY letters, numbers, undescores, lines and backspaces (for editing) digits;
                'arrow keys and cancel key is also accepted by textbox.
            Case Else
                'discard all the others digits.
                e.KeyChar = ""
        End Select
    End Sub

    Private Function ValidateEntries() As Boolean
        If cboFormat.SelectedIndex = 0 Or cboID.SelectedIndex = 0 Then Return False Else Return True
    End Function

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        With lvwAttrFormat
            .Items.Add(cboID.Text)
            .Items(.Items.Count - 1).SubItems.Add(cboFormat.Text)
            .Items(.Items.Count - 1).SubItems.Add(txtName.Text)
        End With
        btnRemove.Enabled = False
        SaveDeviceSettings()
    End Sub

    Private Sub lvwAttrFormat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwAttrFormat.SelectedIndexChanged
        If lvwAttrFormat.SelectedItems.Count > 0 Then btnRemove.Enabled = True
    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        lvwAttrFormat.SelectedItems(0).Remove()
        btnRemove.Enabled = False
        SaveDeviceSettings()
    End Sub
#End Region

#Region "Firmware debug"
    Private Sub chkFirmware_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFirmware.CheckedChanged
        tlpFirmware.Visible = chkFirmware.Checked
        If Not tlpFirmware.Enabled Then
            cboFirmware.SelectedIndex = 0
            chkFixSwap.Checked = False
        End If
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

    Private Sub cboFirmware_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFirmware.SelectedIndexChanged
        ttMain.SetToolTip(picFirmware, m_firmware(cboFirmware.SelectedIndex + 1))
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

    Private Sub chkNoLogDir_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNoLogDir.CheckedChanged
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

    Private Sub chkXErrorLba_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkXErrorLba.CheckedChanged
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

    Private Sub chkFixSwap_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFixSwap.CheckedChanged
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub
#End Region

#Region "Power mode"
    Private Sub chkPowerMode_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkPowerMode.CheckedChanged
        flwPowerMode.Visible = chkPowerMode.Checked
        If chkPowerMode.Checked Then rbNever.Checked = True
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

    Private Sub ChangePowerMode(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbNever.CheckedChanged, rbSleep.CheckedChanged, rbStandby.CheckedChanged, rbIdle.CheckedChanged
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

#End Region
#End Region

#Region "General settings tab"
    Dim isloading_settings As Boolean = True

#Region "Look n' feel"
    Private Sub chkStartupLink_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkStartupLink.CheckedChanged
        If chkStartupLink.Checked Then
            If Not ShortcutExists() Then CreateShortcut()
        Else
            DeleteShortcut()
        End If
    End Sub

    Private Sub look_n_feel(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        chkRunMinimized.CheckedChanged, chkMinimizeInTray.CheckedChanged, chkCloseOnTray.CheckedChanged, _
        chkAlwaysShowTray.CheckedChanged, chkConfirmExit.CheckedChanged
        If Not isloading_settings Then SaveSettings()
        niTrayIcon.Visible = chkAlwaysShowTray.Checked
    End Sub

    Private Sub chkUpdates_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkUpdates.CheckedChanged
        If Not isloading_settings Then
            SaveSettings()
            If chkUpdates.Checked = False Then
                pnlUpdate.Visible = False
            Else
                CheckForUpdates()
            End If
        End If
    End Sub

    Private Sub chkFahrenheit_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkFahrenheit.CheckedChanged
        If Not isloading_settings Then
            SaveSettings()

            For Each d In devlist
                d.Update()
            Next

            With lvwDevices
                For i As Short = 0 To .Items.Count - 1
                    If IsNumeric(devlist(i).Temperature) Then
                        If My.Settings.TempFahrenheit = True Then
                            .Items(i).SubItems(2).Text = (Math.Round(devlist(i).Temperature * 1.8 + 32) & "°F")
                        Else
                            .Items(i).SubItems(2).Text = (devlist(i).Temperature & "°C")
                        End If
                    End If
                Next
                .Columns(2).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                .Columns(1).Width = .ClientSize.Width - .Columns(2).Width
            End With

            SetHealthPanel()
        End If
    End Sub

    Private Sub chkMonitorUsb_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkMonitorUsb.CheckedChanged
        If Not isloading_settings Then
            SaveSettings()
            If chkMonitorUsb.Checked = False Then
                StopMonitorDeviceConnection()
            Else
                StartMonitorDeviceConnection()
            End If
        End If
    End Sub
#End Region

#Region "Update"
    Private Sub numUpdate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles numUpdate.ValueChanged
        If Not isloading_settings Then SaveSettings()
        tmrRefresh.Interval = numUpdate.Value * 60 * 1000
        tmrRefresh.Enabled = True
    End Sub

    Private Sub numUpdateExt_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles numUpdateExt.ValueChanged
        If Not isloading_settings Then SaveSettings()
        tmrRefreshExt.Interval = numUpdateExt.Value * 60 * 1000
        tmrRefreshExt.Enabled = True
    End Sub

    Private Sub numUpdateVirtual_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles numUpdateVirtual.ValueChanged
        If Not isloading_settings Then SaveSettings()
        tmrRefreshVirtual.Interval = numUpdateVirtual.Value * 60 * 1000
        tmrRefreshVirtual.Enabled = True
    End Sub
#End Region

#Region "Monitoring"
    Private Sub lnkInvertSel_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkInvertSel.Click
        'this is a trick: setting to true the variable 'isloading_settings',
        'prevent a multiple writing of the settings file!
        isloading_settings = True

        chkReallEvCt.Checked = Not chkReallEvCt.Checked
        chkReallSectCt.Checked = Not chkReallSectCt.Checked
        chkSoftReadErr.Checked = Not chkSoftReadErr.Checked
        chkSpinRetryCt.Checked = Not chkSpinRetryCt.Checked
        chkTemp.Checked = Not chkTemp.Checked
        chkCurPenSect.Checked = Not chkCurPenSect.Checked
        chkOfflUnc.Checked = Not chkOfflUnc.Checked
        chkDiskShift.Checked = Not chkDiskShift.Checked

        SaveSettings()
        isloading_settings = False
    End Sub

    Private Sub lnkInvertSelSSD_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkInvertSelSSD.Click
        'this is a trick: setting to true the variable 'isloading_settings',
        'prevent a multiple writing of the settings file!
        isloading_settings = True

        chkIndilinx.Checked = Not chkIndilinx.Checked
        chkIntel.Checked = Not chkIntel.Checked
        chkMicron.Checked = Not chkMicron.Checked
        chkSamsung.Checked = Not chkSamsung.Checked
        chkSandForce.Checked = Not chkSandForce.Checked

        SaveSettings()
        isloading_settings = False
    End Sub

    Private Sub monitoring(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        chkReallEvCt.CheckedChanged, chkReallSectCt.CheckedChanged, chkSoftReadErr.CheckedChanged, _
        chkSpinRetryCt.CheckedChanged, chkTemp.CheckedChanged, chkCurPenSect.CheckedChanged, _
        chkOfflUnc.CheckedChanged, chkDiskShift.CheckedChanged, chkIndilinx.CheckedChanged, _
        chkIntel.CheckedChanged, chkMicron.CheckedChanged, chkSamsung.CheckedChanged, chkSandForce.CheckedChanged

        If Not isloading_settings Then SaveSettings()
    End Sub
#End Region

#Region "Warnings"
    Private Sub warnings(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        chkFailure.CheckedChanged, chkTempThresh.CheckedChanged, chkParamChng.CheckedChanged

        If Not isloading_settings Then SaveSettings()
    End Sub
#End Region

#Region "Sharing"
    Private Sub btnBrwsFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrwsFolder.Click
        With dlgFolder
            .Description = lblSelFolder.Text
            Dim result As DialogResult = .ShowDialog(Me)
            If result = DialogResult.OK Then
                lblFolder.Text = .SelectedPath
                lblFolder.Visible = True
                Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

                isloading_features = True
                chkEnableShare.Checked = dev.IsShared
                chkEnableShare.Enabled = True
                isloading_features = False

                SaveSettings()
            End If
        End With
    End Sub

    Private Sub chkXml_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkXml.CheckedChanged
        btnXml.Enabled = chkXml.Checked
        If Not isloading_settings Then SaveSettings()
    End Sub

    Private Sub btnXml_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXml.Click
        With dlgFolder
            .Description = lblXml.Text
            Dim result As DialogResult = .ShowDialog(Me)
            If result = DialogResult.OK Then
                lblXmlPath.Text = .SelectedPath
                lblXmlPath.Visible = True
                SaveSettings()
            End If
        End With
    End Sub
#End Region

#Region "Reliability"
    Private Sub chkRating_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRating.CheckedChanged
        chkTuneUp.Enabled = chkRating.Checked
        If Not isloading_settings Then SaveSettings()

        If chkRating.Checked Then
            If Not isloading_settings Then SetRating()
        Else
            picStars.Image = Nothing
        End If
    End Sub

    Private Sub chkTuneUp_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTuneUp.CheckedChanged
        tlpTuneUp.Enabled = chkTuneUp.Checked
        If Not isloading_settings Then SaveSettings()
    End Sub

    Private Sub TunersValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        numErrors.ValueChanged, numCurPend.ValueChanged, numOfflUnc.ValueChanged
        SetRating()
        SetReliabilityDetails()
        If Not isloading_settings Then SaveSettings()
    End Sub

    Private Sub Reset(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkResetErrors.LinkClicked, lnkResetCurPend.LinkClicked, lnkResetOfflUnc.LinkClicked
        Select Case sender.Name
            Case lnkResetErrors.Name
                numErrors.Value = numErrors.Tag
            Case lnkResetCurPend.Name
                numCurPend.Value = numCurPend.Tag
            Case lnkResetOfflUnc.Name
                numOfflUnc.Value = numOfflUnc.Tag
        End Select
    End Sub

#End Region
#End Region

#Region "Links"
    Private Sub TagLinks(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
         lnkGpl.Click, lnkCcBy.Click, lnkGnome.Click, lnkGplGnome.Click, picVersion.Click, _
         lnkHddGuardian.Click, lnkGroup.Click, lnkEmail.Click, lnkUpdate.Click, lnkPlus.Click, _
         lnkBrandsOfTheWorld.Click, lnkFamFamFam.Click, lnkKamiyamane.Click, lnkPremiumPixels.Click, _
         lnkSmartMonTools.Click, lnkWesternDigital.Click, lnkGnomeGit.Click, lnkCoolerMaster.Click
        Try
            System.Diagnostics.Process.Start(sender.Tag)
        Catch ex As Exception
            PrintDebug("External link error: " & ex.ToString, True)
        End Try
    End Sub
#End Region

#Region "Online help"
    Private Sub tabSettings_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabSettings.SelectedIndexChanged
        mnuHelp.Tag = tabSettings.SelectedTab.Tag
    End Sub

    Private Sub tabAdvanced_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabAdvanced.SelectedIndexChanged
        mnuHelp.Tag = tabAdvanced.SelectedTab.Tag
    End Sub

    Private Sub tabSmartctl_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabSmartctl.SelectedIndexChanged
        mnuHelp.Tag = tabSmartctl.SelectedTab.Tag
    End Sub

    Private Sub tabMain_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabMain.SelectedIndexChanged
        mnuHelp.Tag = tabMain.SelectedTab.Tag
    End Sub

    Private Sub tabPerformance_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabPerformance.SelectedIndexChanged
        mnuHelp.Tag = tabPerformance.SelectedTab.Tag
    End Sub
#End Region

#Region "Monitoring features"

    Dim isloading_monitoring As Boolean = False

    Private Sub LoadTrayIconSetup()
        isloading_monitoring = True

        Dim i As Short = lvwDevices.SelectedItems(0).Index

        chkEnableTray.Enabled = True
        chkEnableTray.Checked = False
        chkDisplayLife.Enabled = False
        chkDisplayLife.Checked = False

        chkEnableTray.Checked = devlist(i).DisplayTrayIcon

        If IO.Directory.Exists(My.Settings.SharingFolder) Then
            chkEnableShare.Enabled = True
            chkEnableShare.Checked = devlist(i).IsShared
        Else
            chkEnableShare.Enabled = False
            chkEnableShare.Checked = False
        End If

        If devlist(i).IsSsd And chkEnableTray.Checked Then
            chkDisplayLife.Enabled = True
            chkDisplayLife.Checked = devlist(i).DisplayLife
        End If

        isloading_monitoring = False
    End Sub

    Private Sub chkEnableTray_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnableTray.CheckedChanged
        If isloading_monitoring Then Exit Sub

        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        dev.DisplayTrayIcon = chkEnableTray.Checked

        If dev.IsSsd And chkEnableTray.Checked Then
            chkDisplayLife.Enabled = True
        Else
            chkDisplayLife.Enabled = False
        End If
    End Sub

    Private Sub chkDisplayLife_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDisplayLife.CheckedChanged
        If isloading_monitoring Then Exit Sub

        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        dev.DisplayLife = chkDisplayLife.Checked

        dev.Update()
    End Sub

    Private Sub chkEnableShare_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnableShare.CheckedChanged
        If isloading_monitoring Then Exit Sub

        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        dev.IsShared = chkEnableShare.Checked
    End Sub

    Private Sub lnkSetFolder_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkSetFolder.LinkClicked
        tabSettings.SelectedTab = tpShare
        mnuSettings_Click(mnuSettings, System.EventArgs.Empty)
    End Sub
#End Region

#Region "Log chart"
    Private Sub cboChartEvents_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboChartEvents.SelectedIndexChanged
        FillList()
        SetGraph()
    End Sub

    Private Sub btnReloadEvents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReloadEvents.Click
        FillChartEvents()
    End Sub

    Private Sub rbList_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbList.CheckedChanged
        With lvwChart
            .Visible = True
            .Top = 32
            .Height = 256
        End With
        With chrChart
            .Visible = False
        End With
    End Sub

    Private Sub rbChart_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbChart.CheckedChanged
        With lvwChart
            .Visible = False
        End With
        With chrChart
            .Visible = True
            .Top = 32
            .Height = 256
        End With
    End Sub

    Private Sub rbSplit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbSplit.CheckedChanged
        With lvwChart
            .Visible = True
            .Top = 32
            .Height = 128
        End With
        With chrChart
            .Visible = True
            .Top = 168
            .Height = 128
        End With
    End Sub

    Private Sub lvwChart_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvwChart.ItemSelectionChanged
        If lvwChart.SelectedItems.Count > 1 Then
            With chrChart
                .Series(0).Points.Clear()
                .Series(0).MarkerSize = 0

                Dim p As New DataVisualization.Charting.DataPoint
                p.YValues(0) = Convert.ToDouble(lvwChart.SelectedItems(0).SubItems(1).Text.Replace("°C", ""))

                .Series(0).Points.Add(p)

                For i As Short = 0 To lvwChart.SelectedItems.Count - 1
                    Dim pt As New DataVisualization.Charting.DataPoint
                    pt.YValues(0) = Convert.ToDouble(lvwChart.SelectedItems(i).SubItems(2).Text.Replace("°C", ""))

                    .Series(0).Points.Add(pt)
                Next
            End With
        Else
            SetGraph()
        End If
    End Sub

#End Region

#Region "Keyboard shortcuts"
    Private Sub ShortcutKeys(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim d As Device = devlist(lvwDevices.SelectedItems(0).Index)

        Select Case e.KeyValue
            Case Keys.F5
                mnuMain.PerformClick()
            Case Keys.F6
                If Not d.IsScsi Then mnuPerformance.PerformClick()
            Case Keys.F7
                mnuMonitoring.PerformClick()
            Case Keys.F8
                If Not d.IsScsi Then mnuAdvanced.PerformClick()
            Case Keys.F9
                mnuSmartctl.PerformClick()
            Case Keys.F1
                mnuHelp.PerformClick()
        End Select

        If e.Alt And e.KeyValue = Keys.F4 Then mnuExit.PerformClick()
    End Sub
#End Region

#Region "SCSI disk features, errors and tests"
    Private Sub rbScsiErrors_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbScsiErrors.CheckedChanged
        If rbScsiErrors.Checked Then
            pnlScsiTests.Visible = False
            pnlScsiTests.Enabled = False
            pnlScsiTests.SendToBack()

            pnlScsiErrors.Location = New System.Drawing.Point(0, 32)
            pnlScsiErrors.Size = New System.Drawing.Size(560, 260)
            tvwScsiErrors.Dock = DockStyle.Fill
            pnlScsiErrors.Visible = True
            pnlScsiErrors.Enabled = True
            pnlScsiErrors.BringToFront()
        End If
    End Sub

    Private Sub rbScsiTest_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbScsiTest.CheckedChanged
        If rbScsiTest.Checked Then
            pnlScsiErrors.Visible = False
            pnlScsiErrors.Enabled = False
            pnlScsiErrors.SendToBack()

            pnlScsiTests.Location = New System.Drawing.Point(0, 32)
            pnlScsiTests.Size = New System.Drawing.Size(560, 260)
            lvwScsiTests.Dock = DockStyle.Fill
            lvwScsiTests.Refresh()
            pnlScsiTests.Visible = True
            pnlScsiTests.Enabled = True
            pnlScsiTests.BringToFront()
        End If
    End Sub

    Private Sub chkScsiSmart_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles chkScsiSmart.MouseDown
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Or isloading_features Then Exit Sub

        Select Case dev.SmartEnabled
            Case Support.Disabled
                dev.SetSmartStatus(SmartFeature.Enable)
                dev.Update()
                Select Case dev.SmartEnabled
                    Case Support.Enabled
                        MsgBox(m_smartenabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                        chkScsiSmart.Checked = True
                        chkScsiSmart.Enabled = True
                    Case Support.Ambiguous
                        MsgBox(m_smartambiguous.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, m_message)
                        chkScsiSmart.Checked = False
                    Case Support.Disabled
                        MsgBox(m_smartnotsupported.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, m_message)
                        chkScsiSmart.Checked = False
                End Select
            Case Support.Enabled
                Dim qst As MsgBoxResult = MsgBox(m_qdisablesmart.Replace("%", dev.Model), MsgBoxStyle.YesNo + MsgBoxStyle.Question, m_question)
                If qst = MsgBoxResult.Yes Then
                    dev.SetSmartStatus(SmartFeature.Disable)
                    dev.Update()
                    MsgBox(m_smartdisabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                    chkScsiSmart.Checked = False
                    chkScsiGltsd.Checked = False
                    chkScsiGltsd.Enabled = False
                    chkScsiWCache.Checked = False
                    chkScsiWCache.Enabled = False
                    chkScsiRCache.Checked = False
                    chkScsiRCache.Enabled = False
                End If
        End Select

        ScsiPanels()
    End Sub


    Private Sub chkScsiGltsd_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkScsiGltsd.CheckedChanged
        If Not isloading_performace Then
            Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

            pnlApply.Parent = tpScsiFeatures
            pnlApply.Visible = True
            picApply.Refresh()
            lblApply.Refresh()

            Select Case chkScsiGltsd.Checked
                Case False
                    dev.ScsiGltsd = Feature.Disable
                Case True
                    dev.ScsiGltsd = Feature.Enable
            End Select

            pnlApply.Visible = False

            ScsiPanels()
        End If
    End Sub

    Private Sub chkScsiWCache_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkScsiWCache.CheckedChanged
        If Not isloading_performace Then
            Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

            pnlApply.Parent = tpScsiFeatures
            pnlApply.Visible = True
            picApply.Refresh()
            lblApply.Refresh()

            Select Case chkScsiWCache.Checked
                Case False
                    dev.ScsiWriteCache = Feature.Disable
                Case True
                    dev.ScsiWriteCache = Feature.Enable
            End Select

            pnlApply.Visible = False

            ScsiPanels()
        End If
    End Sub

    Private Sub chkScsiRCache_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkScsiRCache.CheckedChanged
        If Not isloading_performace Then
            Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

            pnlApply.Parent = tpScsiFeatures
            pnlApply.Visible = True
            picApply.Refresh()
            lblApply.Refresh()

            Select Case chkScsiRCache.Checked
                Case False
                    dev.ScsiReadCache = Feature.Disable
                Case True
                    dev.ScsiReadCache = Feature.Enable
            End Select

            pnlApply.Visible = False

            ScsiPanels()
        End If
    End Sub
#End Region

End Class
