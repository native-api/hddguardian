﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddVirtual
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim tlpVirtual As System.Windows.Forms.TableLayoutPanel
        Dim flwBrowseFile As System.Windows.Forms.FlowLayoutPanel
        Me.lblFile = New System.Windows.Forms.Label()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.lblLocation = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.dlgVirtual = New System.Windows.Forms.OpenFileDialog()
        tlpVirtual = New System.Windows.Forms.TableLayoutPanel()
        flwBrowseFile = New System.Windows.Forms.FlowLayoutPanel()
        tlpVirtual.SuspendLayout()
        flwBrowseFile.SuspendLayout()
        Me.SuspendLayout()
        '
        'tlpVirtual
        '
        tlpVirtual.BackColor = System.Drawing.Color.Transparent
        tlpVirtual.ColumnCount = 2
        tlpVirtual.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        tlpVirtual.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpVirtual.Controls.Add(flwBrowseFile, 1, 1)
        tlpVirtual.Controls.Add(Me.lblDescription, 0, 0)
        tlpVirtual.Controls.Add(Me.txtDescription, 1, 0)
        tlpVirtual.Controls.Add(Me.lblLocation, 0, 1)
        tlpVirtual.Location = New System.Drawing.Point(0, 0)
        tlpVirtual.Name = "tlpVirtual"
        tlpVirtual.RowCount = 3
        tlpVirtual.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpVirtual.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpVirtual.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpVirtual.Size = New System.Drawing.Size(368, 64)
        tlpVirtual.TabIndex = 6
        '
        'flwBrowseFile
        '
        flwBrowseFile.AutoSize = True
        flwBrowseFile.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        flwBrowseFile.Controls.Add(Me.lblFile)
        flwBrowseFile.Controls.Add(Me.btnBrowse)
        flwBrowseFile.Dock = System.Windows.Forms.DockStyle.Top
        flwBrowseFile.Location = New System.Drawing.Point(120, 27)
        flwBrowseFile.Margin = New System.Windows.Forms.Padding(0)
        flwBrowseFile.Name = "flwBrowseFile"
        flwBrowseFile.Size = New System.Drawing.Size(248, 29)
        flwBrowseFile.TabIndex = 7
        '
        'lblFile
        '
        Me.lblFile.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblFile.AutoEllipsis = True
        Me.lblFile.AutoSize = True
        Me.lblFile.ForeColor = System.Drawing.Color.Silver
        Me.lblFile.Location = New System.Drawing.Point(3, 8)
        Me.lblFile.MaximumSize = New System.Drawing.Size(203, 0)
        Me.lblFile.MinimumSize = New System.Drawing.Size(203, 0)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.Size = New System.Drawing.Size(203, 13)
        Me.lblFile.TabIndex = 5
        Me.lblFile.Text = "lblFile"
        '
        'btnBrowse
        '
        Me.btnBrowse.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnBrowse.Location = New System.Drawing.Point(212, 3)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(29, 23)
        Me.btnBrowse.TabIndex = 3
        Me.btnBrowse.Text = "..."
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'lblDescription
        '
        Me.lblDescription.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblDescription.AutoSize = True
        Me.lblDescription.ForeColor = System.Drawing.Color.White
        Me.lblDescription.Location = New System.Drawing.Point(3, 7)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(70, 13)
        Me.lblDescription.TabIndex = 0
        Me.lblDescription.Text = "lblDescription"
        '
        'txtDescription
        '
        Me.txtDescription.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Location = New System.Drawing.Point(123, 3)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(240, 21)
        Me.txtDescription.TabIndex = 4
        '
        'lblLocation
        '
        Me.lblLocation.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblLocation.AutoSize = True
        Me.lblLocation.ForeColor = System.Drawing.Color.White
        Me.lblLocation.Location = New System.Drawing.Point(3, 35)
        Me.lblLocation.Name = "lblLocation"
        Me.lblLocation.Size = New System.Drawing.Size(57, 13)
        Me.lblLocation.TabIndex = 2
        Me.lblLocation.Text = "lblLocation"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(208, 64)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 7
        Me.btnAdd.Text = "btnAdd"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(288, 64)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 8
        Me.btnCancel.Text = "btnCancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'dlgVirtual
        '
        Me.dlgVirtual.FileName = "OpenFileDialog1"
        '
        'AddVirtual
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.hdd_guardian.My.Resources.Resources.pattern_metalgrid
        Me.ClientSize = New System.Drawing.Size(370, 92)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(tlpVirtual)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AddVirtual"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "AddVirtual"
        tlpVirtual.ResumeLayout(False)
        tlpVirtual.PerformLayout()
        flwBrowseFile.ResumeLayout(False)
        flwBrowseFile.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents lblLocation As System.Windows.Forms.Label
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents lblFile As System.Windows.Forms.Label
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents dlgVirtual As System.Windows.Forms.OpenFileDialog
End Class
