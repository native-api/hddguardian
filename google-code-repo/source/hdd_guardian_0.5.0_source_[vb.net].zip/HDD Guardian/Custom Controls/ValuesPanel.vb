﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Drawing

Public Class ValuesPanel

    Private Sub DrawTitle()
        Dim panel As Brush = New SolidBrush(Color.DarkBlue)
        Dim title As New Pen(Color.White, 1)
        Dim g As Graphics = Me.CreateGraphics

        'create panel
        g.FillRectangle(panel, 0, 0, 9, 32)
        'create "FLAGS" label
        With g
            'G
            .DrawLine(title, 2, 30, 6, 30)
            .DrawLine(title, 6, 30, 6, 26)
            .DrawLine(title, 6, 26, 4, 26)
            .DrawLine(title, 4, 26, 4, 28)
            .DrawLine(title, 2, 30, 2, 26)
            'R
            .DrawLine(title, 2, 24, 6, 24)
            .DrawLine(title, 2, 24, 2, 20)
            .DrawLine(title, 2, 20, 4, 20)
            .DrawLine(title, 4, 20, 4, 24)
            .DrawLine(title, 4, 22, 6, 20)
            'A
            .DrawLine(title, 6, 18, 2, 18)
            .DrawLine(title, 2, 18, 2, 14)
            .DrawLine(title, 2, 14, 6, 14)
            .DrawLine(title, 4, 18, 4, 14)
            'P
            .DrawLine(title, 6, 12, 2, 12)
            .DrawLine(title, 2, 12, 2, 8)
            .DrawLine(title, 2, 8, 4, 8)
            .DrawLine(title, 4, 8, 4, 12)
            'H
            .DrawLine(title, 6, 6, 2, 6)
            .DrawLine(title, 2, 2, 6, 2)
            .DrawLine(title, 4, 6, 4, 2)
        End With
    End Sub

    Private Sub DrawLabels()
        Dim x() As Integer = {11, 17, 23, 29, 35, 41}
        Dim y() As Integer = {6, 18, 30}

        'draw "THRESH" label
        T(x(0), y(0))
        H(x(1), y(0))
        R(x(2), y(0))
        E(x(3), y(0))
        S(x(4), y(0))
        H(x(5), y(0))

        'draw "VALUE" label
        V(x(0), y(1))
        A(x(1), y(1))
        L(x(2), y(1))
        U(x(3), y(1))
        E(x(4), y(1))

        'draw "WORST" label
        W(x(0), y(2))
        O(x(1), y(2))
        R(x(2), y(2))
        S(x(3), y(2))
        T(x(4), y(2))
    End Sub

    Private Sub ValuesPanel_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        DrawTitle()
        DrawLabels()
        ProgressBar(48, 7, Styles.Red, 0)
        ProgressBar(48, 19, Styles.Blue, 0)
        ProgressBar(48, 31, Styles.Grey, 0)
    End Sub

    Public Sub SetProgressBarsValues(ByVal Threshold As Integer, ByVal Value As Integer, ByVal Worst As Integer)
        ProgressBar(48, 7, Styles.Red, Threshold)
        ProgressBar(48, 19, Styles.Blue, Value)
        ProgressBar(48, 31, Styles.Grey, Worst)
    End Sub
End Class
