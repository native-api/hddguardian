﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Xml

Class LogToConvert
    Inherits List(Of OldLog)
End Class

Public Structure OldLog
    Dim Device, Day, Time, Attribute, OldValue, NewValue, Variations As String
End Structure

Partial Class Main

    Private Sub ConvertDevSettingsFiles()
        'this routine convert old devices settings file into new format, in xml
        'first, convert monitoring settings:
        Dim l As Short = curruserfolder.LastIndexOf("\")
        Dim folder As String = curruserfolder.Substring(0, l + 1)
        Dim tray As Boolean = False
        Dim share As Boolean = False

        For Each f In IO.Directory.GetFiles(folder)
            Dim file As New IO.FileInfo(f)
            If file.Extension.Length = 0 Then
                Dim device() As String = file.Name.Split("_")
                Dim settings() As String = IO.File.ReadAllLines(folder & file.Name, System.Text.Encoding.Default)

                If settings(0) = "0" Then tray = False Else tray = True
                If settings(1) = "0" Then share = False Else share = True

                FileIO.FileSystem.RenameFile(folder & file.Name, file.Name & ".old")

                Dim output As XmlWriterSettings = New XmlWriterSettings()
                output.Indent = True
                Using write As XmlWriter = XmlWriter.Create(folder & "\" & file.Name & ".xml", output)
                    write.WriteStartDocument()
                    write.WriteStartElement("monitoring")
                    write.WriteStartElement("settings")
                    write.WriteAttributeString("trayicon", tray)
                    write.WriteAttributeString("displaylife", vbFalse)
                    write.WriteAttributeString("share", share)
                    write.WriteEndElement()
                    write.WriteEndElement()
                    write.WriteEndDocument()
                End Using
            End If
        Next


        'second, convert smartctl device settings:
        l = allusersfolder.LastIndexOf("\")
        Dim folderall As String = allusersfolder.Substring(0, l + 1)

        For Each f In IO.Directory.GetFiles(folderall)
            Dim file As New IO.FileInfo(f)
            If file.Extension.Length = 0 Then
                Dim device() As String = file.Name.Split("_")
                Dim settings As String = IO.File.ReadAllText(file.ToString, System.Text.Encoding.Default)
                Dim options As String = ""
                Dim standby As String = ""

                If settings.Length > 0 Then
                    If settings.Contains("|") Then
                        Dim splitsettings() As String = settings.Split("|")
                        If splitsettings(0).Length > 0 Then
                            ParseOptions(splitsettings(0))
                        End If
                        options = splitsettings(0)
                        standby = splitsettings(1)
                    Else
                        ParseOptions(settings)
                        options = settings
                    End If
                End If

                FileIO.FileSystem.RenameFile(folderall & file.Name, file.Name & ".old")

                Dim s_output As XmlWriterSettings = New XmlWriterSettings()
                s_output.Indent = True
                Using write As XmlWriter = XmlWriter.Create(folderall & "\" & file.Name & ".xml", s_output)
                    write.WriteStartDocument()
                    write.WriteStartElement("smartctl")
                    write.WriteStartElement("settings")
                    write.WriteAttributeString("options", options)
                    write.WriteAttributeString("standby", standby)
                    write.WriteEndElement()
                    write.WriteEndElement()
                    write.WriteEndDocument()
                End Using

            End If
        Next

    End Sub

    Dim olddevlog As New LogToConvert

    Private Sub ConvertLogFiles()
        If Not IO.Directory.Exists(logpath) Or IO.File.Exists(logpath & "oldlogs.xml") Then Exit Sub
        'first, load all logs:
        For Each filefullpath In IO.Directory.GetFiles(logpath)
            Dim file As New IO.FileInfo(filefullpath)
            If file.Extension = ".log" Then
                Dim log() As String = IO.File.ReadAllLines(file.FullName)

                For i As Short = 0 To log.Count - 1
                    Dim line() As String = log(i).Split(vbTab)

                    Dim ol As OldLog

                    With ol
                        .Day = file.Name.Replace(file.Extension, "")
                        .Device = line(1)
                        .Time = line(0)
                        .Attribute = line(2)
                        .OldValue = line(3)
                        .NewValue = line(4)
                        .Variations = line(5)
                    End With

                    olddevlog.Add(ol)
                Next

                My.Computer.FileSystem.RenameFile(logpath & file.Name, file.Name.ToString.Replace(".log", ".oldlog"))
            End If
        Next
        'then, put all old log entries into a single file
        Dim drives(0) As String

        If IsNothing(olddevlog) Then Exit Sub
        If olddevlog.Count = 0 Then Exit Sub

        Dim output As XmlWriterSettings = New XmlWriterSettings()
        output.Indent = True
            Using write As XmlWriter = XmlWriter.Create(logpath & "oldlogs.xml", output)
            write.WriteStartDocument()
            write.WriteStartElement("log")
            For i As Short = 0 To olddevlog.Count - 1
                write.WriteStartElement("logitem")
                write.WriteAttributeString("device", olddevlog(i).Device)
                write.WriteAttributeString("year", olddevlog(i).Day.Substring(0, 4))
                write.WriteAttributeString("month", olddevlog(i).Day.Substring(4, 2))
                write.WriteAttributeString("day", olddevlog(i).Day.Substring(6, 2))
                write.WriteAttributeString("hour", olddevlog(i).Time)
                write.WriteAttributeString("event", olddevlog(i).Attribute)
                write.WriteAttributeString("from", olddevlog(i).OldValue)
                write.WriteAttributeString("to", olddevlog(i).NewValue)
                write.WriteAttributeString("variation", olddevlog(i).Variations)
                write.WriteEndElement()
            Next
            write.WriteEndElement()
            write.WriteEndDocument()
        End Using

    End Sub
End Class
