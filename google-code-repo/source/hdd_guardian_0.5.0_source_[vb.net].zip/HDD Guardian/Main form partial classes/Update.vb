﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main
    Sub CheckForUpdates()
        'this sub check for HDD Guardian new versions...

        If My.Settings.CheckUpdates = True Then
            Try
                Dim version As String
                Dim sr As IO.StreamReader
                Dim wc As New Net.WebClient()

                sr = New IO.StreamReader(wc.OpenRead("http://hddguardian.googlecode.com/svn/version.txt"))

                version = sr.ReadToEnd

                Dim last() As String = version.Split(".")
                Dim curr() As String = My.Application.Info.Version.ToString.Split(".")
                Dim diff As Short = (last(0) * 1000 + last(1) * 100 + last(2) * 10) - _
                                    (curr(0) * 1000 + curr(1) * 100 + curr(2) * 10)
                If diff <= 0 Then
                    pnlUpdate.Visible = False
                Else
                    pnlUpdate.Visible = True
                    lnkUpdate.Text = m_updateavailable.Replace("%", version)
                End If
            Catch
            End Try
        End If
    End Sub

End Class
