﻿'HDD Guardian is a GUI for smartcl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System
Imports System.Management
Imports System.ComponentModel

Partial Class Main

    Dim WithEvents media_connect As New ManagementEventWatcher
    Dim WithEvents media_disconnect As New ManagementEventWatcher

    Sub UsbDevicesComparison()
        Dim smartctl As New Console
        Dim usb() As String = Nothing

        'querying smartctl for usb devices
        Dim usbscan() As String = smartctl.SendCmd("--scan -d usb")
        For i As Integer = 0 To usbscan.Count - 2 'the last item is an empty line
            If InStr(usbscan(i), "/dev/sd") < InStr(usbscan(i), "#") And InStr(usbscan(i), "/dev/sd") >= 0 Then
                ReDim Preserve usb(i)
                Dim usbdev As String() = usbscan(i).Split("#")
                usb(i) = usbdev(0).Trim
            End If
        Next

        If Not IsNothing(usb) Then
            With lvwDevices
                'count usb already connected
                Dim connected As Short = 0
                For c As Short = 0 To devlist.Count - 1
                    If devlist(c).Type = DeviceType.USB Then
                        connected += 1
                    End If
                Next

                Select Case connected
                    Case Is > usb.Count
                        'a device is removed
                        For i As Short = 0 To devlist.Count - 1
                            If devlist(i).Type = DeviceType.USB Then
                                Dim toRemove As Boolean = True
                                For c As Short = 0 To usb.Length - 1
                                    If usb(c).Contains(devlist(i).Location) Then toRemove = False
                                    Exit For
                                Next
                                If toRemove Then
                                    devlist(i).DisposeTrayIcon()
                                    devlist.RemoveAt(i)
                                    .Items(i).Remove()
                                    .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                                    SetWindowTheme(.Handle, "explorer", Nothing)
                                End If
                            End If
                        Next

                        UpdateHardware()

                    Case Is < usb.Count
                        'a device is connected
                        For i As Short = 0 To usb.Length - 1
                            Dim toAdd As Boolean = True
                            For c As Short = 0 To devlist.Count - 1
                                If devlist(c).Type = DeviceType.USB Then
                                    If devlist(c).Location.Contains(usb(i)) Then toAdd = False
                                    Exit For
                                End If
                            Next
                            If toAdd Then
                                Dim newusb As New Device(usb(i), DeviceType.USB, False)
                                If newusb.IsDetected Then
                                    devlist.Add(New Device(usb(i), DeviceType.USB, True))
                                    Dim dev As Device = devlist(devlist.Count - 1)

                                    Dim lvi As New ListViewItem("", .Groups(1))
                                    .Items.Add(lvi)
                                    Dim a As Short = .Items.Count - 1
                                    .Items(a).UseItemStyleForSubItems = False

                                    .Items(a).SubItems.Add(dev.Model)
                                    Select Case dev.Health
                                        Case Status.Unkonwn
                                            .Items(a).SubItems(1).ForeColor = Color.DarkGray
                                        Case Status.Failed
                                            .Items(a).SubItems(1).ForeColor = Color.Red
                                            '.Items(a).ImageIndex = 0
                                        Case Status.Passed
                                            .Items(a).SubItems(1).ForeColor = Color.Blue
                                    End Select

                                    If IsNumeric(dev.Temperature) Then
                                        .Items(a).SubItems.Add(dev.Temperature & "°C")
                                        Select Case Val(dev.Temperature)
                                            Case 0 To 49
                                                .Items(a).SubItems(2).ForeColor = Color.Blue
                                            Case 50 To 54
                                                .Items(a).SubItems(2).ForeColor = Color.DarkOrange
                                            Case Is >= 55
                                                .Items(a).SubItems(2).ForeColor = Color.Red
                                        End Select
                                    Else
                                        .Items(a).SubItems.Add(dev.Temperature)
                                        .Items(a).SubItems(2).ForeColor = Color.DarkGray
                                    End If
                                    .Columns(2).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                                    .Columns(1).Width = .ClientSize.Width - .Columns(2).Width
                                    .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                                    SetWindowTheme(.Handle, "explorer", Nothing)
                                End If
                            End If
                        Next
                        'update all removable device vitals...
                        UpdateAll(DeviceType.USB)

                        UpdateHardware()
                    Case Is = usb.Count
                        'do nothing: a new device is connected but is not recognized by smartctl
                        'this appen in case of an usb key is added to system devices
                End Select
            End With
        Else
            'count usb already in list
            Dim connected As Short = 0
            For c As Short = 0 To devlist.Count - 1
                If devlist(c).Type = DeviceType.USB Then connected += 1
            Next

            If connected > 0 Then
                'remove all usb devices...
                lvwDevices.Items(0).Selected = True
                For i As Short = 0 To devlist.Count - 1
                    If i > devlist.Count - 1 Then Exit For
                    If devlist(i).Type = DeviceType.USB Then
                        devlist(i).DisposeTrayIcon()
                        devlist.RemoveAt(i)
                        With lvwDevices
                            .Items(i).Remove()
                            .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                            SetWindowTheme(.Handle, "explorer", Nothing)
                        End With
                    End If
                Next

                UpdateHardware()
            End If
        End If
    End Sub

    '**** eSata are seen as internal devices ****
    Sub eSataDevicesComparison()
        Dim smartctl As New Console
        Dim esata() As String = Nothing

        'querying smartctl for ata devices: eSATA are visualized with ATA (fixed) devices!
        Dim esatascan() As String = smartctl.SendCmd("--scan -d ata")
        For i As Integer = 0 To esatascan.Count - 2 'the last item is an empty line
            If InStr(esatascan(i), "/dev/sd") < InStr(esatascan(i), "#") And InStr(esatascan(i), "/dev/sd") >= 0 Then
                ReDim Preserve esata(i)
                Dim esatadev As String() = esatascan(i).Split("#")
                esata(i) = esatadev(0).Trim
            End If
        Next

        With lvwDevices
            'count usb already connected
            Dim connected As Short = 0
            For c As Short = 0 To devlist.Count - 1
                If devlist(c).Type = DeviceType.ATA Then connected += 1
            Next

            Select Case connected
                Case Is > esata.Count
                    'a device is removed
                    For i As Short = 0 To devlist.Count - 1
                        If devlist(i).Type = DeviceType.ATA Then
                            Dim toRemove As Boolean = True
                            For c As Short = 0 To esata.Length - 1
                                If esata(c).Contains(devlist(i).Location) Then toRemove = False
                                Exit For
                            Next
                            If toRemove Then
                                devlist(i).DisposeTrayIcon()
                                devlist.RemoveAt(i)
                                'oldvitals.RemoveAt(i)
                                'newvitals.RemoveAt(i)
                                .Items(i).Remove()
                                .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                                SetWindowTheme(.Handle, "explorer", Nothing)
                            End If
                        End If
                    Next
                    'update tray icons
                    'DestroyTrayIcons()
                    'SetTrayIcons()

                    UpdateHardware()
                Case Is < esata.Count
                    'a device is connected
                    For i As Short = 0 To esata.Length - 1
                        Dim toAdd As Boolean = True
                        For c As Short = 0 To devlist.Count - 1
                            If devlist(c).Type = DeviceType.ATA Then
                                If devlist(c).Location.Contains(esata(i)) Then toAdd = False
                                Exit For
                            End If
                        Next
                        If toAdd Then
                            Dim newesata As New Device(esata(i), DeviceType.ATA, False)
                            If newesata.IsDetected Then
                                devlist.Add(newesata)
                                Dim dev As Device = devlist(devlist.Count - 1)

                                Dim lvi As New ListViewItem(dev.Model, 1, .Groups(1))
                                .Items.Add(lvi)
                                Dim a As Short = .Items.Count - 1
                                .Items(a).UseItemStyleForSubItems = False

                                Select Case dev.Health
                                    Case Status.Unkonwn
                                        .Items(a).ForeColor = Color.DarkGray
                                    Case Status.Failed
                                        .Items(a).ForeColor = Color.Red
                                        .Items(a).ImageIndex = 0
                                    Case Status.Passed
                                        .Items(a).ForeColor = Color.Blue
                                End Select

                                If IsNumeric(dev.Temperature) Then
                                    .Items(a).SubItems.Add(dev.Temperature & "°C")
                                    Select Case Val(dev.Temperature)
                                        Case 0 To 49
                                            .Items(a).SubItems(1).ForeColor = Color.Blue
                                        Case 50 To 54
                                            .Items(a).SubItems(1).ForeColor = Color.DarkOrange
                                        Case Is >= 55
                                            .Items(a).SubItems(1).ForeColor = Color.Red
                                    End Select
                                Else
                                    .Items(a).SubItems.Add(dev.Temperature)
                                    .Items(a).SubItems(1).ForeColor = Color.DarkGray
                                End If
                                .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                                .Columns(0).Width = .ClientSize.Width - .Columns(1).Width
                                .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                                SetWindowTheme(.Handle, "explorer", Nothing)
                            End If
                        End If
                    Next
                    'update all removable device vitals...
                    UpdateAll(DeviceType.ATA)
                    UpdateHardware()
                Case Is = esata.Count
                    'do nothing: a new device is connected but is not recognized by smartctl
                    'this appen in case of an usb key is added to system devices
            End Select
        End With

        'restart monitoring devices changes...
    End Sub
    '********************************************
    'the eSata code is no longer available since
    'mode informations on how eSata works are needed



    Private Sub StartMonitorDeviceConnection()
        Try
            media_connect = New ManagementEventWatcher
            media_connect.Query = New WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 1 WHERE TargetInstance ISA 'Win32_DiskDrive'")
            media_connect.Start()

            media_disconnect = New ManagementEventWatcher
            media_disconnect.Query = New WqlEventQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 1 WHERE TargetInstance ISA 'Win32_DiskDrive'")
            media_disconnect.Start()

            PrintDebug("External devices connect/disconnect routine successfully started", False, True)
        Catch ex As Exception
            PrintDebug("Error with external connect/disconnect routine: " & ex.ToString, True)
        End Try
    End Sub

    Private Delegate Sub UsbComparison()

    Private Sub DeviceConnect(ByVal sender As Object, ByVal e As System.Management.EventArrivedEventArgs) Handles media_connect.EventArrived, media_disconnect.EventArrived
        Dim UsbDelegate As UsbComparison
        UsbDelegate = AddressOf UsbDevicesComparison

        Me.Invoke(UsbDelegate)
    End Sub

    Private Sub StopMonitorDeviceConnection()
        media_connect.Stop()
        media_disconnect.Stop()
        PrintDebug("External devices connect/disconnect routine successfully stopped", False, True)
    End Sub

End Class
