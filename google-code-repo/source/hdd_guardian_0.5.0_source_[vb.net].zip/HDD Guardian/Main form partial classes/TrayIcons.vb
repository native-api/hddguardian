﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main

    'from version 0.5.0 tray icons are coded into each device, with exclusions of images

    Public Class Icons
        Inherits List(Of Icon)
    End Class

    Public celsius_good As New Icons
    Public celsius_bad As New Icons
    Public fahrenheit_good As New Icons
    Public fahrenheit_bad As New Icons
    Public ssd_good As New Icons
    Public ssd_bad As New Icons
    Public unknown As Icon


    Public Sub LoadTrayIcons()
        Dim celsius As Bitmap = My.Resources.devices_tray_icons

        For i As Short = 0 To 100
            Dim rect As New Rectangle(i * 16, 16, 16, 16)
            Dim geticon As IntPtr = celsius.Clone(rect, celsius.PixelFormat).GetHicon
            celsius_bad.Add(Icon.FromHandle(geticon))
        Next

        For i As Short = 0 To 100
            Dim rect As New Rectangle(i * 16, 0, 16, 16)
            Dim geticon As IntPtr = celsius.Clone(rect, celsius.PixelFormat).GetHicon
            celsius_good.Add(Icon.FromHandle(geticon))
        Next

        Dim rect_u As New Rectangle(101 * 16, 0, 16, 16)
        Dim geticon_u As IntPtr = celsius.Clone(rect_u, celsius.PixelFormat).GetHicon
        unknown = Icon.FromHandle(geticon_u)

        celsius.Dispose()

        Dim fahrenheit As Bitmap = My.Resources.devices_tray_icons_F

        For i As Short = 0 To 100
            Dim rect As New Rectangle(i * 16, 16, 16, 16)
            Dim geticon As IntPtr = fahrenheit.Clone(rect, fahrenheit.PixelFormat).GetHicon
            fahrenheit_bad.Add(Icon.FromHandle(geticon))
        Next

        For i As Short = 0 To 100
            Dim rect As New Rectangle(i * 16, 0, 16, 16)
            Dim geticon As IntPtr = fahrenheit.Clone(rect, fahrenheit.PixelFormat).GetHicon
            fahrenheit_good.Add(Icon.FromHandle(geticon))
        Next

        fahrenheit.Dispose()

        Dim ssd As Bitmap = My.Resources.ssd_tray_icons

        For i As Short = 0 To 101
            Dim rect As New Rectangle(i * 16, 16, 16, 16)
            Dim geticon As IntPtr = ssd.Clone(rect, ssd.PixelFormat).GetHicon
            ssd_bad.Add(Icon.FromHandle(geticon))
        Next

        For i As Short = 0 To 101
            Dim rect As New Rectangle(i * 16, 0, 16, 16)
            Dim geticon As IntPtr = ssd.Clone(rect, ssd.PixelFormat).GetHicon
            ssd_good.Add(Icon.FromHandle(geticon))
        Next

        ssd.Dispose()
    End Sub

End Class
