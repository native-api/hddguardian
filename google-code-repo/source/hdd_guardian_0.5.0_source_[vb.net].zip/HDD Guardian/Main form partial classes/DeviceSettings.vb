﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Xml

Partial Class Main

    'Is presumed that the device settings are commons for all users.
    'Users without administration rights can't change these settings,
    'with the only exclusions of tray icon and sharing capability.

    Dim allusersfolder As String = My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData '& "\"
    Dim curruserfolder As String = My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData '& "\"

    Private Sub LoadDeviceSettings(ByVal device As Device)
        If Not IsNothing(device.Options) Then
            If device.Options.Length > 0 Then
                ParseOptions(device.Options)
            End If
        End If
    End Sub

    Private Sub SaveDeviceSettings()
        If isloading_devsettings Then Exit Sub

        If lvwDevices.Items.Count = 0 Then Exit Sub
        Dim dev As Device = devlist(lvwDevices.SelectedItems(0).Index)

        Dim tolerance As String = ""
        If chkTolerance.Checked Then
            If rbNormal.Checked Then tolerance = "-T normal "
            If rbConservative.Checked Then tolerance = "-T conservative "
            If rbVeryPermissive.Checked Then tolerance = "-T verypermissive "
        End If

        Dim attrformat As String = ""
        If chkAttributes.Checked Then
            With lvwAttrFormat
                If .Items.Count > 0 Then
                    For i As Integer = 0 To .Items.Count - 1
                        attrformat = attrformat & "-v " & .Items(i).Text & "," & _
                        .Items(i).SubItems(1).Text & "," & .Items(i).SubItems(2).Text & " "
                    Next
                End If
            End With
        End If

        Dim fdebug As String = ""
        Dim swap As String = ""
        Dim nologdir As String = ""
        Dim xerror As String = ""
        If chkFirmware.Checked Then
            Select Case cboFirmware.SelectedIndex
                Case 0
                    fdebug = "-F none "
                Case 1
                    fdebug = "-F samsung "
                Case 2
                    fdebug = "-F samsung2 "
                Case 3
                    fdebug = "-F samsung3 "
            End Select
            If chkFixSwap.Checked Then swap = "-F swapid "
            If chkNoLogDir.Checked Then nologdir = "-F nologdir "
            If chkXErrorLba.Checked Then xerror = "-F xerrorlba "
        End If

        Dim attrautosave As String = ""
        If chkEnableAutosave.Checked = True Then attrautosave = "-S on "

        Dim powermode As String = ""
        If chkPowerMode.Checked Then
            If rbNever.Checked Then powermode = "-n never "
            If rbSleep.Checked Then powermode = "-n sleep "
            If rbStandby.Checked Then powermode = "-n standby "
            If rbIdle.Checked Then powermode = "-n idle "
        End If

        Dim content As String = tolerance & attrformat & fdebug & swap & nologdir & xerror & attrautosave & powermode

        dev.Options = content

        Dim standby As String = ""
        If trkStandby.Value > 0 Then dev.Standby = trkStandby.Value

    End Sub


    Private Sub ParseOptions(ByVal options As String)
        isloading_devsettings = True 'this prevent a not required saving for device settings

        chkEnableAutosave.Checked = False
        chkTolerance.Checked = False
        chkAttributes.Checked = False
        chkFirmware.Checked = False
        chkPowerMode.Checked = False
        lvwAttrFormat.Items.Clear()

        If IsNothing(options) Then
            isloading_devsettings = False
            Exit Sub
        End If

        Dim commands() As String = options.Split("-", 255, StringSplitOptions.RemoveEmptyEntries)

        chkTolerance.Enabled = True
        chkAttributes.Enabled = True
        chkFirmware.Enabled = True
        chkPowerMode.Enabled = True


        For i As Integer = 0 To commands.Length - 1
            Dim Param() As Char = commands(i).Trim.ToCharArray
            If Param.Length > 0 Then
                Select Case Param(0)
                    Case "T"
                        chkTolerance.Checked = True
                        If commands(i).Contains("normal") Then rbNormal.Checked = True
                        If commands(i).Contains("conservative") Then rbConservative.Checked = True
                        If commands(i).Contains("verypermissive") Then rbVeryPermissive.Checked = True
                    Case "v"
                        chkAttributes.Checked = True
                        Dim Attribute() As String = commands(i).Substring(1).Trim.Split(",")
                        If Attribute.Length = 2 Then
                            With lvwAttrFormat
                                .Items.Add(Attribute(0))
                                .Items(.Items.Count - 1).SubItems.Add(Attribute(1))
                            End With
                        Else
                            With lvwAttrFormat
                                .Items.Add(Attribute(0))
                                .Items(.Items.Count - 1).SubItems.Add(Attribute(1))
                                .Items(.Items.Count - 1).SubItems.Add(Attribute(2))
                            End With
                        End If
                    Case "F"
                        chkFirmware.Checked = True
                        If commands(i).Contains("none") Then cboFirmware.SelectedIndex = 0
                        If commands(i).Contains("samsung") Then cboFirmware.SelectedIndex = 1
                        If commands(i).Contains("samsung2") Then cboFirmware.SelectedIndex = 2
                        If commands(i).Contains("samsung3") Then cboFirmware.SelectedIndex = 3
                        If commands(i).Contains("swapid") Then chkFixSwap.Checked = True
                        If commands(i).Contains("nologdir") Then chkNoLogDir.Checked = True
                        If commands(i).Contains("xerrorlba") Then chkXErrorLba.Checked = True
                    Case "S"
                        If commands(i).Contains("on") Then
                            chkEnableAutosave.Enabled = True
                            chkEnableAutosave.Checked = True
                        Else
                            chkEnableAutosave.Enabled = True
                            chkEnableAutosave.Checked = False
                        End If
                    Case "n"
                        chkPowerMode.Checked = True
                        If commands(i).Contains("never") Then rbNever.Checked = True
                        If commands(i).Contains("sleep") Then rbSleep.Checked = True
                        If commands(i).Contains("standby") Then rbStandby.Checked = True
                        If commands(i).Contains("idle") Then rbIdle.Checked = True
                End Select
            End If
        Next

        isloading_devsettings = False
    End Sub
End Class
