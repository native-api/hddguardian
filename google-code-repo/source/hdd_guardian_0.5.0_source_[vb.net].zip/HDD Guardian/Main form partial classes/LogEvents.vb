﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Xml

Public Structure OldLogItem
    Dim Device, Year, Month, Day, Hour, EventName, OldValue, NewValue, Variation As String
End Structure

Class OldLogItems
    Inherits List(Of OldLogItem)
End Class

Partial Class Main

    Dim logpath As String = My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData. _
        Substring(0, My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData.LastIndexOf("\")) & "\logs\"

    Dim oldlog As New OldLogItems

#Region "Log viewer section"

    Private Sub DisplayLogEvents()
        lvwLog.Items.Clear()

        If Not IsNothing(devlist(lvwDevices.SelectedItems(0).Index).Log) Then
            If devlist(lvwDevices.SelectedItems(0).Index).Log.Count > 0 Then

                Dim y As String = dteLog.Value.Year
                Dim m As String = dteLog.Value.Month
                Dim d As String = dteLog.Value.Day

                With devlist(lvwDevices.SelectedItems(0).Index)
                    For i As Integer = 0 To .Log.Count - 1
                        If .Log(i).Year = y And .Log(i).Month = m And .Log(i).Day = d Then
                            Dim celsius As String = ""
                            Dim ev As String = .Log(i).EventName
                            If ev = "Temperature" Then celsius = "°C"
                            Dim t() As String = .Log(i).Hour.ToString.Split(":")
                            Dim h As String = String.Format("{0:D2}", Convert.ToInt16(t(0)))
                            Dim min As String = String.Format("{0:D2}", Convert.ToInt16(t(1)))
                            Dim sec As String = String.Format("{0:D2}", Convert.ToInt16(t(2)))
                            Dim old As String = .Log(i).OldValue
                            Dim last As String = .Log(i).NewValue
                            Dim var As String = .Log(i).Variation

                            With lvwLog
                                .SmallImageList = imlLog
                                .Items.Add(ev)
                                .Items(.Items.Count - 1).SubItems.Add(h & ":" & min & ":" & sec)
                                .Items(.Items.Count - 1).SubItems.Add(old & celsius)
                                .Items(.Items.Count - 1).SubItems.Add(last & celsius)
                                .Items(.Items.Count - 1).SubItems.Add(var & celsius)

                                If ev.ToLower = "remaining life (%)" _
                                    Or ev.ToLower = "remaining life percentage" _
                                    Or ev.ToLower = "media wearout indicator" _
                                    Or ev.ToLower = "wear leveling count" _
                                    Or ev.ToLower = "ssd life left" Then
                                    If Convert.ToDouble(Val(var)) < 0 Then
                                        .Items(.Items.Count - 1).ForeColor = Color.Red
                                        .Items(.Items.Count - 1).ImageKey = "warning"
                                    Else
                                        .Items(.Items.Count - 1).ForeColor = Color.Blue
                                        .Items(.Items.Count - 1).ImageKey = "ok"
                                    End If
                                Else
                                    If Convert.ToDouble(Val(var)) > 0 Then
                                        .Items(.Items.Count - 1).ForeColor = Color.Red
                                        .Items(.Items.Count - 1).ImageKey = "warning"
                                    Else
                                        .Items(.Items.Count - 1).ForeColor = Color.Blue
                                        .Items(.Items.Count - 1).ImageKey = "ok"
                                    End If
                                End If
                            End With
                        End If
                    Next
                End With

                With lvwLog
                    .Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    .Columns(1).Width = .ClientSize.Width - .Columns(0).Width - 180

                    .HeaderStyle = ColumnHeaderStyle.Nonclickable
                    .Enabled = True
                    .Visible = True
                    btnSaveLog.Visible = True
                    SetWindowTheme(.Handle, "explorer", Nothing)
                    lblNoLog.Visible = False
                End With

                If lvwLog.Items.Count = 0 Then
                    lvwLog.Visible = False
                    lblNoLog.Text = m_nologforthisday
                    lblNoLog.Top = 32
                    lblNoLog.Visible = True
                Else
                    lblNoLog.Visible = False
                    lvwLog.Top = 32
                    lvwLog.Height = 256
                    lvwLog.Visible = True
                End If

                tlpLogViewer.Visible = True
                btnCopy.Enabled = False
            Else
                tlpLogViewer.Visible = False
                lvwLog.Visible = False
                lblNoLog.Text = m_nologfordevice
                lblNoLog.Top = 0
                lblNoLog.Visible = True
            End If
        End If

    End Sub

    Private Sub btnReload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReload.Click
        DisplayLogEvents()
    End Sub

    Private Sub btnToday_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnToday.Click
        dteLog.Value = Today
    End Sub

    Private Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click
        dteLog.Value = dteLog.Value.AddDays(-1)
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        dteLog.Value = dteLog.Value.AddDays(1)
    End Sub

    Private Sub dteLog_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dteLog.ValueChanged
        DisplayLogEvents()
    End Sub

    Private Sub lvwLog_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwLog.SelectedIndexChanged
        If lvwLog.SelectedItems.Count > 0 Then
            btnCopy.Enabled = True
        Else
            btnCopy.Enabled = False
        End If
    End Sub

    Private Sub btnCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopy.Click
        If lvwLog.SelectedItems.Count > 0 Then
            With lvwLog.Items(lvwLog.SelectedItems(0).Index)
                Dim y As String = dteLog.Value.Year
                Dim m As String = dteLog.Value.Month
                Dim d As String = dteLog.Value.Day
                Dim newdate As String = String.Format("{0:D4}", Convert.ToInt16(y)) & " " & String.Format("{0:D2}", Convert.ToInt16(m)) & " " & String.Format("{0:D2}", Convert.ToInt16((d)))
                Dim datetocopy As String = ""

                Dim dt As DateTime
                If DateTime.TryParseExact(newdate, "yyyy MM dd", Nothing, Nothing, dt) Then
                    datetocopy = FormatDateTime(dt, DateFormat.ShortDate)
                End If

                Dim i As Short = lvwDevices.SelectedItems(0).Index

                Clipboard.SetText(devlist(i).Model & "," & devlist(i).SerialNumber & "," & datetocopy & "," & .Text & "," & .SubItems(1).Text & _
                                  "," & .SubItems(2).Text & "," & .SubItems(3).Text & "," & .SubItems(4).Text)
            End With
        End If
    End Sub

    Private Sub btnSaveLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveLog.Click
        Dim txtlog As String
        Dim d As Short = lvwDevices.SelectedItems(0).Index

        txtlog = "*** DEVICE INFORMATIONS ***" & vbCrLf
        txtlog += "Model family    : " & devlist(d).Family & vbCrLf
        txtlog += "Device model    : " & devlist(d).Model & vbCrLf
        txtlog += "Serial number   : " & devlist(d).SerialNumber & vbCrLf
        txtlog += "Firmware version: " & devlist(d).FirmwareVersion & vbCrLf
        txtlog += vbCrLf
        txtlog += "*** DEVICE HEALTH ***" & vbCrLf
        txtlog += "Overall health  : " & devlist(d).Health.ToString & vbCrLf
        txtlog += "Bad sectors     : " & devlist(d).BadSectorsCount & vbCrLf
        txtlog += "ATA errors      : " & devlist(d).TotalErrors & vbCrLf
        txtlog += "Reliability     : " & New String("*"c, devlist(d).ReliabilityRating.Overall) & vbCrLf
        txtlog += vbCrLf
        txtlog += "*** DEVICE EVENTS LOG ***" & vbCrLf
        txtlog += String.Format("{0,-13}{1,-11}{2,-25}{3,11}{4,11}{5,11}", "Date", "Time", "Event", "Old Value", "New Value", "Variation") & vbCrLf
        txtlog += New String("-"c, 82) & vbCrLf
        For i As Short = 0 To devlist(d).Log.Count - 1
            With devlist(d).Log(i)
                Dim newdate As String = String.Format("{0:D4}", Convert.ToInt16(.Year)) & " " & String.Format("{0:D2}", Convert.ToInt16(.Month)) & " " & String.Format("{0:D2}", Convert.ToInt16(.Day))
                Dim datetocopy As String = ""

                Dim dt As DateTime
                If DateTime.TryParseExact(newdate, "yyyy MM dd", Nothing, Nothing, dt) Then
                    datetocopy = FormatDateTime(dt, DateFormat.ShortDate)
                End If

                Dim t() As String = .Hour.Split(":")
                Dim tc As String = String.Format("{0:D2}", Convert.ToInt16(t(0))) & ":" & String.Format("{0:D2}", Convert.ToInt16(t(1))) & ":" & String.Format("{0:D2}", Convert.ToInt16(t(2)))

                txtlog += String.Format("{0,-13}{1,-11}{2,-25}{3,11}{4,11}{5,11}", datetocopy, tc, .EventName, .OldValue, .NewValue, .Variation) & vbCrLf
            End With
        Next

        Dim sf As New SaveFileDialog
        Dim res As DialogResult
        sf.AddExtension = True
        sf.DefaultExt = "txt"
        sf.Filter = "*.txt|*.txt"
        sf.FileName = devlist(d).Model & "_" & devlist(d).SerialNumber
        res = sf.ShowDialog(Me)
        If res = DialogResult.OK Then
            IO.File.WriteAllText(sf.FileName, txtlog)
        End If

    End Sub

#End Region

End Class
