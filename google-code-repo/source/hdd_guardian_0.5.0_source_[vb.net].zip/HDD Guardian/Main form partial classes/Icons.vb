﻿Imports System.IO

'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main
    Dim pic_admin, pic_noadmin, pic_hourglass, pic_info As Image
    Dim pic_tempok, pic_tempmid, pic_temphigh As Image
    Dim pic_na As Image
    Dim pic_ok, pic_warning, pic_alarm As Image

    Private Sub LoadIcons()
        On Error Resume Next

        Dim iconsfolder As String = My.Application.Info.DirectoryPath & "\graphics\icons\"
        pic_hourglass = Image.FromFile(iconsfolder & "hourglass.png")
        pic_info = Image.FromFile(iconsfolder & "status-information.png")
        pic_admin = Image.FromFile(iconsfolder & "admin.png")
        pic_noadmin = Image.FromFile(iconsfolder & "noadmin.png")
        pic_tempok = Image.FromFile(iconsfolder & "temperature-low.png")
        pic_tempmid = Image.FromFile(iconsfolder & "temperature.png")
        pic_temphigh = Image.FromFile(iconsfolder & "temperature-high.png")
        pic_na = Image.FromFile(iconsfolder & "na.png")
        pic_ok = Image.FromFile(iconsfolder & "status-information.png")
        pic_warning = Image.FromFile(iconsfolder & "status-exclamation.png")
        pic_alarm = Image.FromFile(iconsfolder & "status-exclamation red.png")

        Dim picquestion As Image = Image.FromFile(iconsfolder & "question.png")

        '******************
        '*** main panel ***
        '******************
        picVersion.Image = Image.FromFile(iconsfolder & "new.png")
        hpSummary.SetIconsFolder(iconsfolder)
        picAdminSmart.Image = pic_admin
        picAdminOffline.Image = pic_admin
        picAdminAutosave.Image = pic_admin

        '*************************
        '*** performance panel ***
        '*************************
        tipAam.SetIcons(Image.FromFile(iconsfolder & "aam.png"))
        tipApm.SetIcons(Image.FromFile(iconsfolder & "apm.png"))
        tipStandby.SetIcons(Image.FromFile(iconsfolder & "standby.png"))
        picCache.Image = Image.FromFile(iconsfolder & "cache.png")
        picLookAhead.Image = Image.FromFile(iconsfolder & "look-ahead.png")
        picApply.Image = Image.FromFile(iconsfolder & "status-information.png")

        '************************
        '*** monitoring panel ***
        '************************
        tipDevicesHealth.SetIcons(pic_info)
        btnPrev.Image = Image.FromFile(iconsfolder & "calendar-previous.png")
        btnNext.Image = Image.FromFile(iconsfolder & "calendar-next.png")
        btnToday.Image = Image.FromFile(iconsfolder & "calendar-today.png")
        btnReload.Image = Image.FromFile(iconsfolder & "update.png")
        btnCopy.Image = Image.FromFile(iconsfolder & "copy.png")
        btnSaveLog.Image = Image.FromFile(iconsfolder & "export.png")
        btnReloadEvents.Image = Image.FromFile(iconsfolder & "update.png")
        rbChart.Image = Image.FromFile(iconsfolder & "chart.png")
        rbList.Image = Image.FromFile(iconsfolder & "list.png")
        rbSplit.Image = Image.FromFile(iconsfolder & "split.png")

        '**********************
        '*** advanced panel ***
        '**********************
        With imlAttr.Images
            .Clear()
            '.Add("pre-fail", Image.FromFile(iconsfolder & "attr-pre-fail.png"))
            '.Add("old age", Image.FromFile(iconsfolder & "attr-old age.png"))
            .Add("never", My.Resources.failed_never)
            .Add("inthepast", My.Resources.failed_inthepast)
            .Add("now", My.Resources.failed_now)
            .Add("warning", My.Resources.failed_warning)
        End With
        picAdminError.Image = pic_admin
        picAdminSelective.Image = pic_admin
        picAdminSelfTest.Image = pic_admin
        tipTest.SetIcons(pic_info, pic_admin)
        picTestInfo.Image = pic_info

        '**********************
        '*** smartctl panel ***
        '**********************
        tipTolerance.SetIcons(pic_info, pic_admin)
        tipAttributes.SetIcons(pic_info, pic_admin)
        picAttributes.Image = picquestion
        picAttrFormat.Image = picquestion
        tipFirmware.SetIcons(pic_info, pic_admin)
        picFirmware.Image = picquestion
        picSwap.Image = picquestion
        picNoLogDir.Image = picquestion
        picXErrorLba.Image = picquestion
        tipPowerMode.SetIcons(pic_info, pic_admin)

        '**********************
        '*** settings panel ***
        '**********************
        picWindow.Image = Image.FromFile(iconsfolder & "settings-appearance.png")
        picUpdate.Image = Image.FromFile(iconsfolder & "update.png")
        picWarning.Image = Image.FromFile(iconsfolder & "settings-bell.png")
        picShare.Image = Image.FromFile(iconsfolder & "settings-share.png")
        picMonitoring.Image = Image.FromFile(iconsfolder & "monitoring.png")
        picXml.Image = Image.FromFile(iconsfolder & "xml.png")
        picRating.Image = Image.FromFile(iconsfolder & "star.png")

        '**************************
        '*** device list images ***
        '**************************
        imlDevice.Images.Clear()
        imlDevice.Images.Add("error", My.Resources.drive_error)
        imlDevice.Images.Add("ok", My.Resources.drive_ok)
        imlDevice.Images.Add("pie", My.Resources.pie)
        imlDevice.Images.Add("folder", My.Resources.drive_folder)
        imlDevice.Images.Add("windrive", My.Resources.drive_win)
        imlDevice.Images.Add("pc", Image.FromFile(iconsfolder & "monitor.png"))

        '********************************
        '*** contacts into about page ***
        '********************************
        picHome.Image = Image.FromFile(iconsfolder & "home.png")
        picGroup.Image = Image.FromFile(iconsfolder & "group.png")
        picEmail.Image = Image.FromFile(iconsfolder & "mail.png")
        picPlus.Image = Image.FromFile(iconsfolder & "plus.png")

        '******************
        '*** SCSI pages ***
        '******************
        picScsiSmart.Image = pic_admin
        picScsiGlstd.Image = pic_admin
        picScsiRCache.Image = pic_admin
        picScsiWCache.Image = pic_admin
        tipScsi.SetIcons(pic_info, pic_admin)
    End Sub

End Class
