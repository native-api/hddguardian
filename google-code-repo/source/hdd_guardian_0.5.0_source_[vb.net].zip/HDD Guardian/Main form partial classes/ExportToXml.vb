﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

'This if the partial class of main form that perform the interface translation.
'Interface translation is based upon the culture code installed for the current user;
'it check if the current culture have a translation searching their folder, otherwise
'load the default english translation.
'By example, if the current culture is the spanish used in Argentina, it check if the
'folder "es-AR" exist; if this folder doesn't exist, if go for the generic spanish folder
'named "es"; again, if this folder doesn't exist, it uses the built-in basic english translation.

Imports System.Xml

Partial Class Main

    Private Sub ExportToXml()
        PrintDebug("Generate XML report")

        Dim output As XmlWriterSettings = New XmlWriterSettings()
        output.Indent = True

        Dim folder As String = My.Settings.XmlFolder
        If Not IO.Directory.Exists(folder) Then Exit Sub

        If isloading = False Then
            Using write As XmlWriter = XmlWriter.Create(folder & "\hddguardian.xml", output)
                'begin writing.
                write.WriteStartDocument()
                write.WriteStartElement("devices") 'root element
                'devices infos
                For i As Short = 0 To devlist.Count - 1
                    write.WriteStartElement("device")
                    write.WriteAttributeString("type", devlist(i).Type.ToString)
                    write.WriteAttributeString("model", devlist(i).Model)
                    write.WriteAttributeString("temperature", devlist(i).Temperature)
                    If IsNumeric(devlist(i).Temperature) Then
                        write.WriteAttributeString("fahrenheit", Math.Round(devlist(i).Temperature * 1.8 + 32))
                    Else
                        write.WriteAttributeString("fahrenheit", devlist(i).Temperature)
                    End If
                    write.WriteAttributeString("overallhealth", devlist(i).Health.ToString)
                    write.WriteEndElement()
                Next
                'end of root element & write the document
                write.WriteEndElement()
                write.WriteEndDocument()
            End Using
        End If

        PrintDebug("XML report finished")
    End Sub

End Class
