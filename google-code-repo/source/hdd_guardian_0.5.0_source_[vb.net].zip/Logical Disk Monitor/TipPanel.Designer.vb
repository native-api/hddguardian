﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TipPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picIcon = New System.Windows.Forms.PictureBox()
        Me.lblTip = New System.Windows.Forms.Label()
        Me.picAdmin = New System.Windows.Forms.PictureBox()
        CType(Me.picIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAdmin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picIcon
        '
        Me.picIcon.Location = New System.Drawing.Point(5, 5)
        Me.picIcon.Name = "picIcon"
        Me.picIcon.Size = New System.Drawing.Size(16, 16)
        Me.picIcon.TabIndex = 0
        Me.picIcon.TabStop = False
        '
        'lblTip
        '
        Me.lblTip.AutoSize = True
        Me.lblTip.ForeColor = System.Drawing.Color.DimGray
        Me.lblTip.Location = New System.Drawing.Point(25, 4)
        Me.lblTip.Name = "lblTip"
        Me.lblTip.Size = New System.Drawing.Size(32, 13)
        Me.lblTip.TabIndex = 1
        Me.lblTip.Text = "lblTip"
        '
        'picAdmin
        '
        Me.picAdmin.Location = New System.Drawing.Point(5, 24)
        Me.picAdmin.Name = "picAdmin"
        Me.picAdmin.Size = New System.Drawing.Size(16, 16)
        Me.picAdmin.TabIndex = 2
        Me.picAdmin.TabStop = False
        '
        'TipPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ldm.My.Resources.Resources.ttbackground
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Controls.Add(Me.picAdmin)
        Me.Controls.Add(Me.lblTip)
        Me.Controls.Add(Me.picIcon)
        Me.DoubleBuffered = True
        Me.Name = "TipPanel"
        Me.Size = New System.Drawing.Size(488, 128)
        CType(Me.picIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAdmin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents picIcon As System.Windows.Forms.PictureBox
    Private WithEvents lblTip As System.Windows.Forms.Label
    Friend WithEvents picAdmin As System.Windows.Forms.PictureBox

End Class
