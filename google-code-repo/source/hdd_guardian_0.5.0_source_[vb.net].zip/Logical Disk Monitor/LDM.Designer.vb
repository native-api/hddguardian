﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LDM
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim pnlTop As System.Windows.Forms.Panel
        Dim tlpOptions As System.Windows.Forms.TableLayoutPanel
        Dim pnlLdm As System.Windows.Forms.Panel
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LDM))
        Me.pbLdm = New System.Windows.Forms.PictureBox()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.chkLogonStart = New System.Windows.Forms.CheckBox()
        Me.chkCloseOnTray = New System.Windows.Forms.CheckBox()
        Me.chkStartMinimized = New System.Windows.Forms.CheckBox()
        Me.tpTip = New TipPanel()
        Me.grpOptions = New System.Windows.Forms.GroupBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lnkLicense = New System.Windows.Forms.LinkLabel()
        Me.btnReload = New System.Windows.Forms.Button()
        Me.lvwPartitions = New System.Windows.Forms.ListView()
        Me.chLetter = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chLabel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chRead = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chWrite = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.tlpLdm = New System.Windows.Forms.TableLayoutPanel()
        Me.sbLdm = New System.Windows.Forms.StatusBar()
        Me.niTrayIcon = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.tmrFlushMem = New System.Windows.Forms.Timer(Me.components)
        Me.chkMonitorUsb = New System.Windows.Forms.CheckBox()
        pnlTop = New System.Windows.Forms.Panel()
        tlpOptions = New System.Windows.Forms.TableLayoutPanel()
        pnlLdm = New System.Windows.Forms.Panel()
        pnlTop.SuspendLayout()
        CType(Me.pbLdm, System.ComponentModel.ISupportInitialize).BeginInit()
        tlpOptions.SuspendLayout()
        pnlLdm.SuspendLayout()
        Me.grpOptions.SuspendLayout()
        Me.tlpLdm.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTop
        '
        pnlTop.BackColor = System.Drawing.Color.Black
        pnlTop.BackgroundImage = Global.ldm.My.Resources.Resources.activitymonitor
        pnlTop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        pnlTop.Controls.Add(Me.pbLdm)
        pnlTop.Controls.Add(Me.lblVersion)
        pnlTop.Dock = System.Windows.Forms.DockStyle.Top
        pnlTop.Location = New System.Drawing.Point(0, 0)
        pnlTop.Margin = New System.Windows.Forms.Padding(0)
        pnlTop.Name = "pnlTop"
        pnlTop.Size = New System.Drawing.Size(736, 64)
        pnlTop.TabIndex = 0
        '
        'pbLdm
        '
        Me.pbLdm.Image = Global.ldm.My.Resources.Resources.ldm_48
        Me.pbLdm.Location = New System.Drawing.Point(8, 8)
        Me.pbLdm.Name = "pbLdm"
        Me.pbLdm.Size = New System.Drawing.Size(48, 48)
        Me.pbLdm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbLdm.TabIndex = 0
        Me.pbLdm.TabStop = False
        '
        'lblVersion
        '
        Me.lblVersion.BackColor = System.Drawing.Color.Transparent
        Me.lblVersion.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lblVersion.ForeColor = System.Drawing.Color.White
        Me.lblVersion.Location = New System.Drawing.Point(0, 48)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(736, 16)
        Me.lblVersion.TabIndex = 1
        Me.lblVersion.Text = "lblVersion"
        Me.lblVersion.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'tlpOptions
        '
        tlpOptions.AutoSize = True
        tlpOptions.ColumnCount = 4
        tlpOptions.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        tlpOptions.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        tlpOptions.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        tlpOptions.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        tlpOptions.Controls.Add(Me.chkLogonStart, 0, 0)
        tlpOptions.Controls.Add(Me.chkCloseOnTray, 2, 0)
        tlpOptions.Controls.Add(Me.chkStartMinimized, 1, 0)
        tlpOptions.Controls.Add(Me.chkMonitorUsb, 3, 0)
        tlpOptions.Dock = System.Windows.Forms.DockStyle.Top
        tlpOptions.Location = New System.Drawing.Point(0, 14)
        tlpOptions.Name = "tlpOptions"
        tlpOptions.RowCount = 1
        tlpOptions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpOptions.Size = New System.Drawing.Size(736, 23)
        tlpOptions.TabIndex = 3
        '
        'chkLogonStart
        '
        Me.chkLogonStart.AutoSize = True
        Me.chkLogonStart.Location = New System.Drawing.Point(3, 3)
        Me.chkLogonStart.Name = "chkLogonStart"
        Me.chkLogonStart.Size = New System.Drawing.Size(95, 17)
        Me.chkLogonStart.TabIndex = 0
        Me.chkLogonStart.Text = "chkLogonStart"
        Me.chkLogonStart.UseVisualStyleBackColor = True
        '
        'chkCloseOnTray
        '
        Me.chkCloseOnTray.AutoSize = True
        Me.chkCloseOnTray.Location = New System.Drawing.Point(371, 3)
        Me.chkCloseOnTray.Name = "chkCloseOnTray"
        Me.chkCloseOnTray.Size = New System.Drawing.Size(104, 17)
        Me.chkCloseOnTray.TabIndex = 2
        Me.chkCloseOnTray.Text = "chkCloseOnTray"
        Me.chkCloseOnTray.UseVisualStyleBackColor = True
        '
        'chkStartMinimized
        '
        Me.chkStartMinimized.AutoSize = True
        Me.chkStartMinimized.Location = New System.Drawing.Point(187, 3)
        Me.chkStartMinimized.Name = "chkStartMinimized"
        Me.chkStartMinimized.Size = New System.Drawing.Size(111, 17)
        Me.chkStartMinimized.TabIndex = 1
        Me.chkStartMinimized.Text = "chkStartMinimized"
        Me.chkStartMinimized.UseVisualStyleBackColor = True
        '
        'pnlLdm
        '
        pnlLdm.BackColor = System.Drawing.SystemColors.Window
        pnlLdm.Controls.Add(Me.tpTip)
        pnlLdm.Controls.Add(Me.grpOptions)
        pnlLdm.Controls.Add(Me.btnExit)
        pnlLdm.Controls.Add(Me.lnkLicense)
        pnlLdm.Controls.Add(Me.btnReload)
        pnlLdm.Controls.Add(Me.lvwPartitions)
        pnlLdm.Dock = System.Windows.Forms.DockStyle.Fill
        pnlLdm.Location = New System.Drawing.Point(0, 64)
        pnlLdm.Margin = New System.Windows.Forms.Padding(0, 0, 0, 24)
        pnlLdm.Name = "pnlLdm"
        pnlLdm.Size = New System.Drawing.Size(736, 330)
        pnlLdm.TabIndex = 16
        '
        'tpTip
        '
        Me.tpTip.BackColor = System.Drawing.Color.Transparent
        Me.tpTip.BackgroundImage = CType(resources.GetObject("tpTip.BackgroundImage"), System.Drawing.Image)
        Me.tpTip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tpTip.Dock = System.Windows.Forms.DockStyle.Top
        Me.tpTip.Location = New System.Drawing.Point(0, 0)
        Me.tpTip.Name = "tpTip"
        Me.tpTip.Size = New System.Drawing.Size(736, 64)
        Me.tpTip.TabIndex = 13
        Me.tpTip.Tip = "tpTip"
        '
        'grpOptions
        '
        Me.grpOptions.Controls.Add(tlpOptions)
        Me.grpOptions.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.grpOptions.Location = New System.Drawing.Point(0, 291)
        Me.grpOptions.Name = "grpOptions"
        Me.grpOptions.Padding = New System.Windows.Forms.Padding(0)
        Me.grpOptions.Size = New System.Drawing.Size(736, 39)
        Me.grpOptions.TabIndex = 11
        Me.grpOptions.TabStop = False
        Me.grpOptions.Text = "grpOptions"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(648, 264)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(80, 24)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "btnExit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lnkLicense
        '
        Me.lnkLicense.Location = New System.Drawing.Point(648, 168)
        Me.lnkLicense.Name = "lnkLicense"
        Me.lnkLicense.Size = New System.Drawing.Size(80, 16)
        Me.lnkLicense.TabIndex = 14
        Me.lnkLicense.TabStop = True
        Me.lnkLicense.Text = "GNU GPL 2"
        Me.lnkLicense.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnReload
        '
        Me.btnReload.Location = New System.Drawing.Point(648, 72)
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(80, 24)
        Me.btnReload.TabIndex = 9
        Me.btnReload.Text = "btnReload"
        Me.btnReload.UseVisualStyleBackColor = True
        '
        'lvwPartitions
        '
        Me.lvwPartitions.CheckBoxes = True
        Me.lvwPartitions.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chLetter, Me.chLabel, Me.chRead, Me.chWrite})
        Me.lvwPartitions.FullRowSelect = True
        Me.lvwPartitions.Location = New System.Drawing.Point(0, 72)
        Me.lvwPartitions.MultiSelect = False
        Me.lvwPartitions.Name = "lvwPartitions"
        Me.lvwPartitions.Size = New System.Drawing.Size(640, 216)
        Me.lvwPartitions.TabIndex = 8
        Me.lvwPartitions.UseCompatibleStateImageBehavior = False
        Me.lvwPartitions.View = System.Windows.Forms.View.Details
        '
        'chLetter
        '
        Me.chLetter.Text = "chLetter"
        '
        'chLabel
        '
        Me.chLabel.Text = "chLabel"
        '
        'chRead
        '
        Me.chRead.Text = "chRead"
        Me.chRead.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chWrite
        '
        Me.chWrite.Text = "chWrite"
        Me.chWrite.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tlpLdm
        '
        Me.tlpLdm.ColumnCount = 1
        Me.tlpLdm.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpLdm.Controls.Add(pnlLdm, 0, 1)
        Me.tlpLdm.Controls.Add(pnlTop, 0, 0)
        Me.tlpLdm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpLdm.Location = New System.Drawing.Point(0, 0)
        Me.tlpLdm.Name = "tlpLdm"
        Me.tlpLdm.RowCount = 2
        Me.tlpLdm.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpLdm.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpLdm.Size = New System.Drawing.Size(736, 418)
        Me.tlpLdm.TabIndex = 0
        '
        'sbLdm
        '
        Me.sbLdm.Location = New System.Drawing.Point(0, 396)
        Me.sbLdm.Name = "sbLdm"
        Me.sbLdm.Size = New System.Drawing.Size(736, 22)
        Me.sbLdm.TabIndex = 1
        Me.sbLdm.Text = "sbLdm"
        '
        'niTrayIcon
        '
        Me.niTrayIcon.Icon = CType(resources.GetObject("niTrayIcon.Icon"), System.Drawing.Icon)
        Me.niTrayIcon.Text = "NotifyIcon1"
        Me.niTrayIcon.Visible = True
        '
        'tmrFlushMem
        '
        Me.tmrFlushMem.Enabled = True
        Me.tmrFlushMem.Interval = 600000
        '
        'chkMonitorUsb
        '
        Me.chkMonitorUsb.AutoSize = True
        Me.chkMonitorUsb.Location = New System.Drawing.Point(555, 3)
        Me.chkMonitorUsb.Name = "chkMonitorUsb"
        Me.chkMonitorUsb.Size = New System.Drawing.Size(96, 17)
        Me.chkMonitorUsb.TabIndex = 3
        Me.chkMonitorUsb.Text = "chkMonitorUsb"
        Me.chkMonitorUsb.UseVisualStyleBackColor = True
        '
        'LDM
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(736, 418)
        Me.Controls.Add(Me.sbLdm)
        Me.Controls.Add(Me.tlpLdm)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "LDM"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Logical Disk Monitor"
        pnlTop.ResumeLayout(False)
        pnlTop.PerformLayout()
        CType(Me.pbLdm, System.ComponentModel.ISupportInitialize).EndInit()
        tlpOptions.ResumeLayout(False)
        tlpOptions.PerformLayout()
        pnlLdm.ResumeLayout(False)
        Me.grpOptions.ResumeLayout(False)
        Me.grpOptions.PerformLayout()
        Me.tlpLdm.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tlpLdm As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents sbLdm As System.Windows.Forms.StatusBar
    Friend WithEvents pbLdm As System.Windows.Forms.PictureBox
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents tpTip As TipPanel
    Friend WithEvents grpOptions As System.Windows.Forms.GroupBox
    Friend WithEvents chkLogonStart As System.Windows.Forms.CheckBox
    Friend WithEvents chkCloseOnTray As System.Windows.Forms.CheckBox
    Friend WithEvents chkStartMinimized As System.Windows.Forms.CheckBox
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lnkLicense As System.Windows.Forms.LinkLabel
    Friend WithEvents btnReload As System.Windows.Forms.Button
    Friend WithEvents lvwPartitions As System.Windows.Forms.ListView
    Friend WithEvents chLetter As System.Windows.Forms.ColumnHeader
    Friend WithEvents chLabel As System.Windows.Forms.ColumnHeader
    Friend WithEvents chRead As System.Windows.Forms.ColumnHeader
    Friend WithEvents chWrite As System.Windows.Forms.ColumnHeader
    Friend WithEvents niTrayIcon As System.Windows.Forms.NotifyIcon
    Friend WithEvents tmrFlushMem As System.Windows.Forms.Timer
    Friend WithEvents chkMonitorUsb As System.Windows.Forms.CheckBox

End Class
