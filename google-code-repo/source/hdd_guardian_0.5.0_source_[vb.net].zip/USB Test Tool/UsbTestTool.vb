﻿'USB Test Tool is an automatic testing tool for smartctl unknown USB bridges
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Public Class UsbTestTool

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim savedialog As New SaveFileDialog
        Dim res As DialogResult

        savedialog.DefaultExt = "txt"
        savedialog.AddExtension = True
        savedialog.Filter = "*.txt|*.txt"
        savedialog.FileName = "usbtest"
        res = savedialog.ShowDialog(Me)
        If res = DialogResult.OK Then
            IO.File.WriteAllText(savedialog.FileName, txtConsole.Text)
        End If
    End Sub

    Private Sub UsbTestTool_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Dim prompt As New Console

        btnSave.Enabled = False

        '╚╝═╔╗║

        With txtConsole
            .Clear()
            .AppendText("╔════════════════════════════════════════════════════════════════╗" & vbCrLf)
            .AppendText("║  This tool test all devices searching for unknown USB bridges  ║" & vbCrLf)
            .AppendText("╚════════════════════════════════════════════════════════════════╝" & vbCrLf)
            .AppendText(vbCrLf)

            For i As Short = 97 To 122
                .AppendText(vbCrLf)
                .AppendText("**** Scan /dev/sd" & Chr(i) & " ****" & vbCrLf)
                .AppendText(vbCrLf)
                Dim scan As String = prompt.SendCmd(" -a /dev/sd" & Chr(i))
                .AppendText(scan)
                .AppendText(vbCrLf)

                If scan.Contains("Unknown USB bridge") Then
                    .AppendText("!!!! Unknown USB bridge detected !!!" & vbCrLf)
                    .AppendText(vbCrLf)
                    .AppendText("**** Try to treat /dev/sd" & Chr(i) & " as SCSI to ATA (SAT) ****" & vbCrLf)
                    .AppendText(vbCrLf)
                    Dim sat As String = prompt.SendCmd(" -a /dev/sd" & Chr(i) & " -d sat")
                    .AppendText(sat)
                    .AppendText(vbCrLf)
                    Dim sat12 As String = prompt.SendCmd(" -a /dev/sd" & Chr(i) & " -d sat,12")
                    .AppendText(sat12)
                    .AppendText(vbCrLf)
                    .AppendText("**** Try to treat /dev/sd" & Chr(i) & " as UsbCypress ****" & vbCrLf)
                    .AppendText(vbCrLf)
                    Dim cypress As String = prompt.SendCmd(" -a /dev/sd" & Chr(i) & " -d usbcypress")
                    .AppendText(cypress)
                    .AppendText(vbCrLf)
                    .AppendText("**** Try to treat /dev/sd" & Chr(i) & " as UsbSunPlus ****" & vbCrLf)
                    .AppendText(vbCrLf)
                    Dim sunplus As String = prompt.SendCmd(" -a /dev/sd" & Chr(i) & " -d usbsunplus")
                    .AppendText(sunplus)
                    .AppendText(vbCrLf)
                    .AppendText("**** Try to treat /dev/sd" & Chr(i) & " as UsbJMicron ****" & vbCrLf)
                    .AppendText(vbCrLf)
                    Dim jmicron As String = prompt.SendCmd(" -a /dev/sd" & Chr(i) & " -d usbjmicron")
                    .AppendText(jmicron)
                    .AppendText(vbCrLf)
                    Dim jmicronx As String = prompt.SendCmd(" -a /dev/sd" & Chr(i) & " -d usbjmicron,x")
                    .AppendText(jmicronx)
                    .AppendText(vbCrLf)
                End If
            Next

            .AppendText("╔════════════════════════════════════════════════════════════════╗" & vbCrLf)
            .AppendText("║                         Scan completed                         ║" & vbCrLf)
            .AppendText("╚════════════════════════════════════════════════════════════════╝" & vbCrLf)
        End With

        btnSave.Enabled = True
    End Sub
End Class
