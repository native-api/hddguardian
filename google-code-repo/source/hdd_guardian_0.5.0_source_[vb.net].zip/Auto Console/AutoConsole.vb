﻿'Auto Console is the HDD Guardian automatic console utility
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2011-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Public Class AutoConsole

    Private Sub AutoConsole_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Dim prompt As New Console

        '╚╝═╔╗║

        btnSave.Enabled = False

        With txtConsole
            .Clear()
            .AppendText("╔═════════════════════════════════╗" & vbCrLf)
            .AppendText("║  Scan for internal ATA devices  ║" & vbCrLf)
            .AppendText("╚═════════════════════════════════╝" & vbCrLf)
            .AppendText("smartctl --scan -d ata" & vbCrLf)
            .AppendText(vbCrLf)

            Dim internal As String = prompt.SendCmd("--scan -d ata")
            .AppendText(internal)
            .AppendText(vbCrLf)

            Dim int_devices() As String
            Dim int_arr() As String = internal.Split(vbCrLf)
            Dim d As Integer = -1
            For i As Integer = 0 To int_arr.Length - 2
                If int_arr(i).Contains("#") Then
                    d += 1
                    ReDim Preserve int_devices(d)
                    Dim dev As String() = int_arr(i).Split("#")
                    int_devices(d) = dev(0).Trim
                End If
            Next

            If Not IsNothing(int_devices) Then
                .AppendText("::: " & int_devices.Count & " internal devices detected :::" & vbCrLf)
                .AppendText(vbCrLf)

                For i As Short = 0 To int_devices.Length - 1
                    Dim name() As String = int_devices(i).Split(" ")
                    .AppendText("::: Scan device " & name(0) & " :::" & vbCrLf)
                    .AppendText("smartctl -a -g all -P use " & int_devices(i) & vbCrLf)
                    .AppendText(vbCrLf)
                    .AppendText(prompt.SendCmd("-a -d ata -g all -P use " & int_devices(i)))
                    .AppendText(vbCrLf)
                Next i
            Else
                .AppendText("::: no internal devices detected :::" & vbCrLf)
                .AppendText(vbCrLf)
            End If

            .AppendText("╔═════════════════════════════════╗" & vbCrLf)
            .AppendText("║  Scan for external USB devices  ║" & vbCrLf)
            .AppendText("╚═════════════════════════════════╝" & vbCrLf)
            .AppendText("smartctl --scan -d usb" & vbCrLf)
            .AppendText(vbCrLf)

            Dim external As String = prompt.SendCmd("--scan -d usb")
            .AppendText(external)
            .AppendText(vbCrLf)

            Dim ext_devices() As String
            Dim ext_arr() As String = external.Split(vbCrLf)
            Dim de As Integer = -1
            For i As Integer = 0 To ext_arr.Length - 2
                If ext_arr(i).Contains("#") Then
                    de += 1
                    ReDim Preserve ext_devices(de)
                    Dim dev As String() = ext_arr(i).Split("#")
                    ext_devices(de) = dev(0).Trim
                End If
            Next

            If Not IsNothing(ext_devices) Then
                .AppendText("::: " & ext_devices.Count & " external devices detected :::" & vbCrLf)
                .AppendText(vbCrLf)

                For i As Short = 0 To ext_devices.Length - 1
                    Dim name() As String = ext_devices(i).Split(" ")
                    .AppendText("::: Scan device " & name(0) & " :::" & vbCrLf)
                    .AppendText("smartctl -a -g all -P use " & ext_devices(i) & vbCrLf)
                    .AppendText(vbCrLf)
                    .AppendText(prompt.SendCmd("-a -g all -P use " & ext_devices(i)))
                    .AppendText(vbCrLf)
                Next i

            Else
                .AppendText("::: no external devices detected :::" & vbCrLf)
                .AppendText(vbCrLf)
            End If


            .AppendText("╔═════════════════════════════════╗" & vbCrLf)
            .AppendText("║      Scan for SCSI devices      ║" & vbCrLf)
            .AppendText("╚═════════════════════════════════╝" & vbCrLf)
            .AppendText("smartctl --scan -d scsi" & vbCrLf)
            .AppendText(vbCrLf)

            Dim scsi As String = prompt.SendCmd("--scan -d scsi")
            .AppendText(scsi)
            .AppendText(vbCrLf)

            Dim scsi_devices() As String
            Dim scsi_arr() As String = scsi.Split(vbCrLf)
            Dim ds As Integer = -1
            For i As Integer = 0 To scsi_arr.Length - 2
                If scsi_arr(i).Contains("#") Then
                    ds += 1
                    ReDim Preserve scsi_devices(ds)
                    Dim dev As String() = scsi_arr(i).Split("#")
                    scsi_devices(ds) = dev(0).Trim
                End If
            Next

            If Not IsNothing(scsi_devices) Then
                .AppendText("::: " & scsi_devices.Count & " SCSI devices detected :::" & vbCrLf)
                .AppendText(vbCrLf)

                For i As Short = 0 To scsi_devices.Length - 1
                    Dim name() As String = scsi_devices(i).Split(" ")
                    .AppendText("::: Scan device " & name(0) & " :::" & vbCrLf)
                    .AppendText("smartctl -a -g all " & scsi_devices(i) & vbCrLf)
                    .AppendText(vbCrLf)
                    .AppendText(prompt.SendCmd("-a -g all " & scsi_devices(i)))
                    .AppendText(vbCrLf)
                Next i

            Else
                .AppendText("::: no SCSI devices detected :::" & vbCrLf)
                .AppendText(vbCrLf)
            End If

            .AppendText("╔═════════════════════════════════╗" & vbCrLf)
            .AppendText("║  Scan for Intel Matrix devices  ║" & vbCrLf)
            .AppendText("╚═════════════════════════════════╝" & vbCrLf)
            .AppendText("smartctl --scan -d csmi" & vbCrLf)
            .AppendText(vbCrLf)


            Dim intel As String = prompt.SendCmd("--scan -d csmi")
            .AppendText(intel)
            .AppendText(vbCrLf)

            Dim csmi_devices() As String
            Dim csmi_arr() As String = intel.Split(vbCrLf)
            Dim dc As Integer = -1
            For i As Integer = 0 To csmi_arr.Length - 2
                If csmi_arr(i).Contains("#") Then
                    dc += 1
                    ReDim Preserve csmi_devices(dc)
                    Dim dev As String() = csmi_arr(i).Split("#")
                    csmi_devices(dc) = dev(0).Trim
                End If
            Next

            If Not IsNothing(csmi_devices) Then
                .AppendText("::: " & csmi_devices.Count & " Intel Matrix connected devices detected :::" & vbCrLf)
                .AppendText(vbCrLf)

                For i As Short = 0 To csmi_devices.Length - 1
                    Dim name() As String = csmi_devices(i).Split(" ")
                    .AppendText("::: Scan device " & name(0) & " :::" & vbCrLf)
                    .AppendText("smartctl -a -g all -P use " & csmi_devices(i) & vbCrLf)
                    .AppendText(vbCrLf)
                    .AppendText(prompt.SendCmd("-a -g all -P use " & csmi_devices(i)))
                    .AppendText(vbCrLf)
                Next i

            Else
                .AppendText("::: no Intel Matrix connected devices detected :::" & vbCrLf)
                .AppendText(vbCrLf)
            End If

        End With

        btnSave.Enabled = True
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim savedialog As New SaveFileDialog
        Dim res As DialogResult

        savedialog.DefaultExt = "txt"
        savedialog.AddExtension = True
        savedialog.Filter = "*.txt|*.txt"
        savedialog.FileName = "output"
        res = savedialog.ShowDialog(Me)
        If res = DialogResult.OK Then
            IO.File.WriteAllText(savedialog.FileName, txtConsole.Text)
        End If
    End Sub
End Class
