﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Xml

Partial Class Main

    Dim m_attributesmeanings As New AttrMeanings
    Dim m_MicronMeanings As New MicronMeanings
    Dim m_IntelMeanings As New IntelMeanings
    Dim m_IndilinxMeanings As New IndilinxMeanings
    Dim m_JMicronMeanings As New JmicronMeanings
    Dim m_SamsungMeanings As New SamsungMeanings
    Dim m_SandForceMeanings As New SandForceMeanings
    Dim m_SmartMeanings As New SmartMeanings

#Region "Private meanings classes"
    Private Class AttrMeanings
        Inherits List(Of AttrTable)
    End Class

    Private Class MicronMeanings
        Inherits List(Of AttrTable)
    End Class

    Private Class IntelMeanings
        Inherits List(Of AttrTable)
    End Class

    Private Class IndilinxMeanings
        Inherits List(Of AttrTable)
    End Class

    Private Class JmicronMeanings
        Inherits List(Of AttrTable)
    End Class

    Private Class SamsungMeanings
        Inherits List(Of AttrTable)
    End Class

    Private Class SandForceMeanings
        Inherits List(Of AttrTable)
    End Class

    Private Class SmartMeanings
        Inherits List(Of AttrTable)
    End Class
#End Region

    Private Structure AttrTable
        Dim SmartctlName, Name, Description As String
    End Structure

    Private Sub LoadAttribInfos()
        Dim curculture As String = My.Computer.Info.InstalledUICulture.Name 'it gets, by example, "es-AR"
        Dim languagesfolder As String = My.Application.Info.DirectoryPath & "\languages\"
        Dim cult() As String = curculture.Split("-")
        Dim curculturefolder0 As String = languagesfolder & curculture
        Dim curculturefolder1 As String = languagesfolder & cult(0)
        Dim m_external As Boolean = False

        Dim m_xmldoc As New XmlDocument
        Dim e_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        'load internal (english) attributes meanings
        m_xmldoc.LoadXml(My.Resources.dafault_attributes)
        m_nodelist = m_xmldoc.SelectNodes("/table/attribute")

        m_attributesmeanings.Clear()
        For Each m_node In m_nodelist
            Dim group As String = m_node.Attributes.GetNamedItem("group").Value
            Dim smartctlname As String = m_node.Attributes.GetNamedItem("smartctl").Value
            Dim attr As New AttrTable

            If smartctlname.Length > 0 Then
                attr.SmartctlName = smartctlname.Replace("_", " ")
                attr.Name = m_node.ChildNodes.Item(0).InnerText
                attr.Description = m_node.ChildNodes.Item(1).InnerText.Replace(vbCrLf, "").Trim
            End If

            'separate meanings by group, for a faster vendor-based meaning search...
            Select Case group
                Case Is = "Generic"
                    m_attributesmeanings.Add(attr)
                Case Is = "Micron"
                    m_MicronMeanings.Add(attr)
                Case Is = "Intel"
                    m_IntelMeanings.Add(attr)
                Case Is = "Indilinx"
                    m_IndilinxMeanings.Add(attr)
                Case Is = "JMicron"
                    m_JMicronMeanings.Add(attr)
                Case Is = "Samsung"
                    m_SamsungMeanings.Add(attr)
                Case Is = "SandForce"
                    m_SandForceMeanings.Add(attr)
                Case Is = "Smart"
                    m_SmartMeanings.Add(attr)
            End Select
        Next

        'search if exists an external translation for current culture, following, for sample, culture "es-AR"
        If FileIO.FileSystem.DirectoryExists(curculturefolder0) Then 'check if subfolder named "es-AR" exists
            e_xmldoc.Load(curculturefolder0 & "\attributes.xml")
            m_external = True
        ElseIf FileIO.FileSystem.DirectoryExists(curculturefolder1) Then 'check if subfolder named "es" exists
            e_xmldoc.Load(curculturefolder1 & "\attributes.xml")
            m_external = True
        End If

        'replace translation strings that exists into the external translation:
        'if external translation is incomplete, are used the strings into the internal translation
        If m_external Then
            Try
                m_nodelist = e_xmldoc.SelectNodes("/table/attribute")

                For Each m_node In m_nodelist
                    Dim group As String = m_node.Attributes.GetNamedItem("group").Value
                    Dim smartctlname As String = m_node.Attributes.GetNamedItem("smartctl").Value.Replace("_", " ")
                    Dim attr As New AttrTable

                    attr.SmartctlName = smartctlname
                    attr.Name = m_node.ChildNodes.Item(0).InnerText
                    attr.Description = m_node.ChildNodes.Item(1).InnerText.Replace(vbCrLf, "").Trim

                    If smartctlname.Length > 0 Then
                        Select Case group
                            Case Is = "Generic"
                                For i As Short = 0 To m_attributesmeanings.Count - 1
                                    If m_attributesmeanings(i).SmartctlName = smartctlname Then
                                        m_attributesmeanings.RemoveAt(i)
                                        m_attributesmeanings.Add(attr)
                                        Exit For
                                    End If
                                Next
                            Case Is = "Micron"
                                For i As Short = 0 To m_MicronMeanings.Count - 1
                                    If m_MicronMeanings(i).SmartctlName = smartctlname Then
                                        m_MicronMeanings.RemoveAt(i)
                                        m_MicronMeanings.Add(attr)
                                        Exit For
                                    End If
                                Next
                            Case Is = "Intel"
                                For i As Short = 0 To m_IntelMeanings.Count - 1
                                    If m_IntelMeanings(i).SmartctlName = smartctlname Then
                                        m_IntelMeanings.RemoveAt(i)
                                        m_IntelMeanings.Add(attr)
                                        Exit For
                                    End If
                                Next
                            Case Is = "Indilinx"
                                For i As Short = 0 To m_IndilinxMeanings.Count - 1
                                    If m_IndilinxMeanings(i).SmartctlName = smartctlname Then
                                        m_IndilinxMeanings.RemoveAt(i)
                                        m_IndilinxMeanings.Add(attr)
                                        Exit For
                                    End If
                                Next
                            Case Is = "JMicron"
                                For i As Short = 0 To m_JMicronMeanings.Count - 1
                                    If m_JMicronMeanings(i).SmartctlName = smartctlname Then
                                        m_JMicronMeanings.RemoveAt(i)
                                        m_JMicronMeanings.Add(attr)
                                        Exit For
                                    End If
                                Next
                            Case Is = "Samsung"
                                For i As Short = 0 To m_SamsungMeanings.Count - 1
                                    If m_SamsungMeanings(i).SmartctlName = smartctlname Then
                                        m_SamsungMeanings.RemoveAt(i)
                                        m_SamsungMeanings.Add(attr)
                                        Exit For
                                    End If
                                Next
                            Case Is = "SandForce"
                                For i As Short = 0 To m_SandForceMeanings.Count - 1
                                    If m_SandForceMeanings(i).SmartctlName = smartctlname Then
                                        m_SandForceMeanings.RemoveAt(i)
                                        m_SandForceMeanings.Add(attr)
                                        Exit For
                                    End If
                                Next
                            Case Is = "Smart"
                                For i As Short = 0 To m_SmartMeanings.Count - 1
                                    If m_SmartMeanings(i).SmartctlName = smartctlname Then
                                        m_SmartMeanings.RemoveAt(i)
                                        m_SmartMeanings.Add(attr)
                                        Exit For
                                    End If
                                Next
                        End Select
                    End If
                Next
            Catch
            End Try
        End If
    End Sub

End Class
