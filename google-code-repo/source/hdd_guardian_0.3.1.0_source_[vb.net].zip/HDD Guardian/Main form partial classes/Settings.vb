﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

'This loading and saving settings routines are based upon the media type were is stored HDD Guardian executable:
'with fixed media (local hard disk) settings are stored into the user settings folder, otherwise, with a non-fixed
'media, settings are stored into the main folder of HDD Guardian executable.

Partial Class Main
    Dim devtype As New IO.DriveInfo(IO.Path.GetPathRoot(My.Application.Info.DirectoryPath))
    Dim m_sharingfolder As String

    Private Sub LoadSettings()
        If devtype.DriveType = IO.DriveType.Fixed Then 'we are using a fixed media
            isloading_settings = True
            With My.Settings
                .Upgrade()
                'look n' feel settings
                chkStartupLink.Checked = ShortcutExists()
                chkRunMinimized.Checked = .StartMinimized
                chkMinimizeInTray.Checked = .MinimizeOnTray
                chkCloseOnTray.Checked = .CloseOnTray
                chkAlwaysShowTray.Checked = .AlwaysShowTrayIcon
                chkConfirmExit.Checked = .ConfirmOnExit

                'update setting
                'internal
                numUpdate.Value = .DataUpdate
                tmrRefresh.Interval = .DataUpdate * 60 * 1000
                tmrRefresh.Enabled = True
                'external
                numUpdateExt.Value = .ExternalDevicesUpdate
                tmrRefreshExt.Interval = .ExternalDevicesUpdate * 60 * 1000
                If My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
                    tmrRefreshExt.Enabled = True
                    numUpdateExt.Enabled = True
                Else
                    tmrRefreshExt.Enabled = False
                    numUpdateExt.Enabled = False
                End If
                'virtual
                numUpdateVirtual.Value = .VirtualDevicesUpdate
                tmrRefreshVirtual.Interval = .VirtualDevicesUpdate * 60 * 1000
                tmrRefreshVirtual.Enabled = True

                'warning settings
                chkFailure.Checked = .ImminentFailure
                chkTempThresh.Checked = .TemperatureThreshold
                chkParamChng.Checked = .VitalParameters
                chkReallSectCt.Checked = .ReallocatedSector
                chkSpinRetryCt.Checked = .SpinRetry
                chkTemp.Checked = .Temperature
                chkReallEvCt.Checked = .ReallocatedEvent
                chkCurPenSect.Checked = .CurrentPendingSector
                chkOfflUnc.Checked = .CurrentPendingSector
                chkOfflUnc.Checked = .OfflineUncorrectable
                chkSoftReadErr.Checked = .SoftReadErrorRate
                chkDiskShift.Checked = .DiskShift
                'SSD warning settings
                chkIndilinx.Checked = .Indilinx
                chkIntel.Checked = .Intel
                chkMicron.Checked = .Micron
                chkSamsung.Checked = .Samsung
                chkSandForce.Checked = .SandForce

                'share setting
                lblFolder.Text = ""
                lblFolder.Text = .SharingFolder
                m_sharingfolder = .SharingFolder
            End With
        isloading_settings = False
        Else 'we are using a non-fixed (network, removable, CD-Rom, ...) media

        End If
    End Sub

    Private Sub SaveSettings()
        If devtype.DriveType = IO.DriveType.Fixed Then 'we are using a fixed media
            With My.Settings
                'look n' feel settings
                'startup link setting is not saved
                .StartMinimized = chkRunMinimized.Checked
                .MinimizeOnTray = chkMinimizeInTray.Checked
                .CloseOnTray = chkCloseOnTray.Checked
                .AlwaysShowTrayIcon = chkAlwaysShowTray.Checked
                .ConfirmOnExit = chkConfirmExit.Checked

                'update setting
                .DataUpdate = numUpdate.Value
                .ExternalDevicesUpdate = numUpdateExt.Value
                .VirtualDevicesUpdate = numUpdateVirtual.Value

                'warning settings
                .ImminentFailure = chkFailure.Checked
                .TemperatureThreshold = chkTempThresh.Checked
                .VitalParameters = chkParamChng.Checked
                .ReallocatedSector = chkReallSectCt.Checked
                .SpinRetry = chkSpinRetryCt.Checked
                .Temperature = chkTemp.Checked
                .ReallocatedEvent = chkReallEvCt.Checked
                .CurrentPendingSector = chkCurPenSect.Checked
                .OfflineUncorrectable = chkOfflUnc.Checked
                .SoftReadErrorRate = chkSoftReadErr.Checked
                .DiskShift = chkDiskShift.Checked
                'SSD warning settings
                .Indilinx = chkIndilinx.Checked
                .Intel = chkIntel.Checked
                .Micron = chkMicron.Checked
                .Samsung = chkSamsung.Checked
                .SandForce = chkSandForce.Checked

                'share setting
                .SharingFolder = lblFolder.Text

                'save settings
                .Save()
            End With
        Else 'we are using a non-fixed (network, removable, CD-Rom, ...) media
            'with removable devices settings are not saved because, in the most of the cases,
            'this program is running only to test pourposes.
        End If
    End Sub

End Class
