﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main

    Private Class Oldest
        Inherits List(Of Vitals)
    End Class

    Private Class Newest
        Inherits List(Of Vitals)
    End Class

    Dim oldvitals As New Oldest
    Dim newvitals As New Newest
    Dim err, tempthresh, chkhealth As String

    Private Sub VitalsCheck()
        err = ""
        If My.Settings.VitalParameters = False Then Exit Sub

        oldvitals.Clear()
        If newvitals.Count > 0 Then
            For i As Short = 0 To newvitals.Count - 1
                oldvitals.Add(newvitals(i))
            Next
        End If
        newvitals.Clear()
        For i As Short = 0 To devicelist.Count - 1
            newvitals.Add(devicelist(i).VitalParameters)
            If oldvitals.Count < newvitals.Count Then oldvitals.Add(devicelist(i).VitalParameters)
        Next

        Dim logfilename As String = Now.Year & String.Format("{0:D2}", Now.Month) & _
            String.Format("{0:D2}", Now.Day) & ".log"
        If Not IO.Directory.Exists(healthlogpath) Then IO.Directory.CreateDirectory(healthlogpath)
        Dim logfullpath As String = healthlogpath & logfilename

        For i As Short = 0 To devicelist.Count - 1
            Dim havechanges As Boolean = False
            Dim dev As Device = devicelist(i)
            Dim model As String = dev.Model
            Dim olds, news As Vitals
            Dim d As Short = 0
            Dim txt As String = ""
            Dim errors As String = ""
            olds = oldvitals(i)
            news = newvitals(i)

            If err.Length > 0 Then err += vbCrLf

            'now, compare vital parameters for each type of vital checked
            With My.Settings
                If .ReallocatedSector Then 'ID #5: Reallocated sector count
                    Dim idname As String = "Reallocated sector count"
                    txt = ""
                    If IsNumeric(olds.ReallSect) And IsNumeric(news.ReallSect) Then
                        d = Convert.ToSingle(news.ReallSect) - Convert.ToSingle(olds.ReallSect)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.ReallSect & _
                                    " " & m_to & " " & news.ReallSect & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.ReallSect & _
                                    " " & m_to & " " & news.ReallSect & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.ReallSect & vbTab & news.ReallSect & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .SpinRetry Then 'ID #10: Spin retry count
                    Dim idname As String = "Spin retry count"
                    txt = ""
                    If IsNumeric(olds.SpinRetry) And IsNumeric(news.SpinRetry) Then
                        d = Convert.ToSingle(news.SpinRetry) - Convert.ToSingle(olds.SpinRetry)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.SpinRetry & _
                                    " " & m_to & " " & news.SpinRetry & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.SpinRetry & _
                                    " " & m_to & " " & news.SpinRetry & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.SpinRetry & vbTab & news.SpinRetry & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .ReallocatedEvent Then 'ID #196: Rellocated event count
                    Dim idname As String = "Rellocated event count"
                    txt = ""
                    If IsNumeric(olds.ReallEvent) And IsNumeric(news.ReallEvent) Then
                        d = Convert.ToSingle(news.ReallEvent) - Convert.ToSingle(olds.ReallEvent)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.ReallEvent & _
                                    " " & m_to & " " & news.ReallEvent & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.ReallEvent & _
                                    " " & m_to & " " & news.ReallEvent & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.ReallEvent & vbTab & news.ReallEvent & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .CurrentPendingSector Then 'ID #197: Current pending sector
                    Dim idname As String = "Current pending sector"
                    txt = ""
                    If IsNumeric(olds.CurPending) And IsNumeric(news.CurPending) Then
                        d = Convert.ToSingle(news.CurPending) - Convert.ToSingle(olds.CurPending)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.CurPending & _
                                    " " & m_to & " " & news.CurPending & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.CurPending & _
                                    " " & m_to & " " & news.CurPending & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.CurPending & vbTab & news.CurPending & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .OfflineUncorrectable Then 'ID #198: Offline uncorrectable
                    Dim idname As String = "Offline uncorrectable"
                    txt = ""
                    If IsNumeric(olds.OfflineUnc) And IsNumeric(news.OfflineUnc) Then
                        d = Convert.ToSingle(news.OfflineUnc) - Convert.ToSingle(olds.OfflineUnc)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.OfflineUnc & _
                                    " " & m_to & " " & news.OfflineUnc & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.OfflineUnc & _
                                    " " & m_to & " " & news.OfflineUnc & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.OfflineUnc & vbTab & news.OfflineUnc & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .SoftReadErrorRate Then 'ID #201: Soft read error rate
                    Dim idname As String = "Soft read error rate"
                    txt = ""
                    If IsNumeric(olds.SoftRead) And IsNumeric(news.SoftRead) Then
                        d = Convert.ToSingle(news.SoftRead) - Convert.ToSingle(olds.SoftRead)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.SoftRead & _
                                    " " & m_to & " " & news.SoftRead & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.SoftRead & _
                                    " " & m_to & " " & news.SoftRead & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.SoftRead & vbTab & news.SoftRead & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .DiskShift Then 'ID #220: Disk shift
                    Dim idname As String = "Disk shift"
                    txt = ""
                    If IsNumeric(olds.DiskShift) And IsNumeric(news.DiskShift) Then
                        d = Convert.ToSingle(news.DiskShift) - Convert.ToSingle(olds.DiskShift)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.DiskShift & _
                                    " " & m_to & " " & news.DiskShift & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.DiskShift & _
                                    " " & m_to & " " & news.DiskShift & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.DiskShift & vbTab & news.DiskShift & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .Temperature Then 'ID #194: Temperature
                    Dim idname As String = "Temperature"
                    txt = ""
                    If IsNumeric(olds.Temperature) And IsNumeric(news.Temperature) Then
                        d = Convert.ToSingle(news.Temperature) - Convert.ToSingle(olds.Temperature)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Temperature & "°C" & _
                                    " " & m_to & " " & news.Temperature & "°C [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Temperature & "°C" & _
                                    " " & m_to & " " & news.Temperature & "°C [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.Temperature & "°C" & vbTab & news.Temperature & "°C" & vbTab & d & "°C" & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .Indilinx Then 'ID #209: Remaining Life (%)
                    Dim idname As String = "Remaining Life (%)"
                    txt = ""
                    If IsNumeric(olds.Indilinx) And IsNumeric(news.Indilinx) Then
                        d = Convert.ToSingle(news.Indilinx) - Convert.ToSingle(olds.Indilinx)
                        'value start to 100 and go to 0
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is < 0 'sample: 99 - 100 = -1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Indilinx & _
                                    " " & m_to & " " & news.Indilinx & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 100 - 99 = 1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Indilinx & _
                                    " " & m_to & " " & news.Indilinx & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.Indilinx & vbTab & news.Indilinx & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .Intel Then 'ID #233: Media Wearout Indicator
                    Dim idname As String = "Media Wearout Indicator"
                    txt = ""
                    If IsNumeric(olds.Intel) And IsNumeric(news.Intel) Then
                        d = Convert.ToSingle(news.Intel) - Convert.ToSingle(olds.Intel)
                        'value start to 100 and go to 1
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is < 0 'sample: 99 - 100 = -1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Intel & _
                                    " " & m_to & " " & news.Intel & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 100 - 99 = 1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Intel & _
                                    " " & m_to & " " & news.Intel & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.Intel & vbTab & news.Intel & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .Micron Then 'ID #202: Percentage Lifetime Used
                    Dim idname As String = "Percentage Lifetime Used"
                    txt = ""
                    If IsNumeric(olds.Micron) And IsNumeric(news.Micron) Then
                        d = Convert.ToSingle(news.Micron) - Convert.ToSingle(olds.Micron)
                        'value start to 0 and go to 100
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0 'sample: 100 - 99 = 1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Micron & _
                                    " " & m_to & " " & news.Micron & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 99 - 100 = -1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Micron & _
                                    " " & m_to & " " & news.Micron & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.Micron & vbTab & news.Micron & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .Samsung Then 'ID #177: Wear Leveling Count
                    Dim idname As String = "Wear Leveling Count"
                    txt = ""
                    If IsNumeric(olds.Samsung) And IsNumeric(news.Samsung) Then
                        d = Convert.ToSingle(news.Samsung) - Convert.ToSingle(olds.Samsung)
                        'value start to 100 and go to 1
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is < 0 'sample: 99 - 100 = -1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Samsung & _
                                    " " & m_to & " " & news.Samsung & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 100 - 99 = 1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.Samsung & _
                                    " " & m_to & " " & news.Samsung & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.Samsung & vbTab & news.Samsung & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If .SandForce Then 'ID #231: SSD Life Left
                    Dim idname As String = "SSD Life Left"
                    txt = ""
                    If IsNumeric(olds.SandForce) And IsNumeric(news.SandForce) Then
                        d = Convert.ToSingle(news.SandForce) - Convert.ToSingle(olds.SandForce)
                        'value start to 100 and go to 1
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is < 0 'sample: 99 - 100 = -1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.SandForce & _
                                    " " & m_to & " " & news.SandForce & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 100 - 99 = 1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & olds.SandForce & _
                                    " " & m_to & " " & news.SandForce & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                olds.Samsung & vbTab & news.Samsung & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                End If
                errors += txt

                If havechanges Then
                    err = err & model & errors
                End If

            End With
        Next

        If err.Length > 0 And err.LastIndexOf(vbCrLf) = err.Length - 1 Then
            err = err.Substring(0, err.Length - 2)
        End If
    End Sub

    Private Sub TemperatureCheck()
        tempthresh = ""
        If My.Settings.TemperatureThreshold = False Then Exit Sub

        For Each Device In devicelist
            If IsNumeric(Device.Temperature) Then
                If Convert.ToSingle(Device.Temperature) > 49 Then
                    tempthresh = tempthresh & Device.Model & ": " & Device.Temperature & "°C" & vbCrLf
                End If
            End If
        Next

        If tempthresh.Length > 0 And tempthresh.LastIndexOf(vbCrLf) = tempthresh.Length - 1 Then
            tempthresh = tempthresh.Substring(0, tempthresh.Length - 2)
        End If
    End Sub

    Private Sub OverallHealthCheck()
        chkhealth = ""

        Dim failure As Boolean = False
        For Each Device In devicelist
            If Device.Health = Status.Failed Then
                chkhealth += Device.Model & vbCrLf
                failure = True
            End If
        Next

        'HDD Guardian tray icon type change between combinations of devices failure and program updates...
        If failure Then
            Dim healthicon As Bitmap
            If pnlUpdate.Visible Then healthicon = My.Resources.update_ko Else healthicon = My.Resources.some_problems
            Dim geticon As IntPtr = healthicon.Clone(New Rectangle(0, 0, 16, 16), healthicon.PixelFormat).GetHicon
            niTrayIcon.Icon = Icon.FromHandle(geticon)
        Else
            Dim healthicon As Bitmap
            If pnlUpdate.Visible Then healthicon = My.Resources.update_ok Else healthicon = My.Resources.all_ok
            Dim geticon As IntPtr = healthicon.Clone(New Rectangle(0, 0, 16, 16), healthicon.PixelFormat).GetHicon
            niTrayIcon.Icon = Icon.FromHandle(geticon)
        End If

        If chkhealth.Length > 0 And chkhealth.LastIndexOf(vbCrLf) = chkhealth.Length - 1 Then
            chkhealth = chkhealth.Substring(0, chkhealth.Length - 2)
        End If

        If My.Settings.ImminentFailure = False Then chkhealth = ""
    End Sub

#Region "Display warnings"

    Dim WithEvents tmrDelay As New Timer
    Dim Warning As Integer

    Public Sub ShowWarnings()
        VitalsCheck()
        TemperatureCheck()
        OverallHealthCheck()
        tmrDelay.Interval = 3000
        tmrDelay.Start()
        Warning = 0
    End Sub

    Private Sub DelayWarnings() Handles tmrDelay.Tick
        ShowWarningsBaloons(Warning)
        If Warning = 2 Then tmrDelay.Stop()
        Warning += 1
    End Sub

    Enum BaloonMsgs
        Failure = 0
        Temperature
        Health
    End Enum

    Private Sub ShowWarningsBaloons(ByVal Baloon As BaloonMsgs)
        With niTrayIcon
            Select Case Baloon
                Case BaloonMsgs.Failure
                    'device failure message
                    If chkhealth.Length > 0 And niTrayIcon.Visible = True Then
                        With niTrayIcon
                            .BalloonTipIcon = ToolTipIcon.Error
                            .BalloonTipTitle = m_failuretitle
                            .BalloonTipText = m_failuretxt.Replace("%", chkhealth)
                            .ShowBalloonTip(3000)
                        End With
                    End If
                Case BaloonMsgs.Temperature
                    'device temperature message
                    If tempthresh.Length > 0 And niTrayIcon.Visible = True Then
                        With niTrayIcon
                            .BalloonTipIcon = ToolTipIcon.Warning
                            .BalloonTipTitle = m_temperaturealarm
                            .BalloonTipText = tempthresh
                            .ShowBalloonTip(3000)
                        End With
                    End If
                Case BaloonMsgs.Health
                    'raw values variation message
                    If err.Length > 0 And niTrayIcon.Visible = True Then
                        With niTrayIcon
                            .BalloonTipIcon = ToolTipIcon.Warning
                            .BalloonTipTitle = m_alarmdevstatus
                            .BalloonTipText = err
                            .ShowBalloonTip(3000)
                        End With
                    End If
            End Select
        End With
    End Sub

#End Region

End Class
