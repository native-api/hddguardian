﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Public Class TipPanel

    Public Property Tip As String
        Get
            Return lblTip.Text
        End Get
        Set(ByVal value As String)
            lblTip.Text = value
        End Set
    End Property

    Public Sub SetIcons(ByVal firsticon As Image, Optional ByVal secondicon As Image = Nothing)
        picIcon.Image = firsticon
        picAdmin.Image = secondicon
    End Sub

    Public Sub New()

        ' Chiamata richiesta dalla finestra di progettazione.
        InitializeComponent()

        ' Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent().
        lblTip.Text = Me.Name
        DrawBorder()
    End Sub

    Private Sub TipPanel_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        With lblTip
            Dim max As Size = New Size(Me.Width - .Left - 8, 0)
            .MaximumSize = max
            DrawBorder()
        End With
    End Sub

    Private Sub DrawBorder()
        Dim g As Graphics = Me.CreateGraphics
        Dim pen As New Pen(Brushes.DarkGray, 1)

        g.DrawRectangle(pen, 0, 0, Me.Width - 1, Me.Height - 1)
    End Sub

    Private Sub TipPanel_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        DrawBorder()
    End Sub
End Class
