﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Public Class AddVirtual

    Dim content() As String

    Private Function GetInfo(ByVal info As String) As String
        Dim value As String = "N/A"
        For i As Integer = 0 To content.Length - 1
            If content(i).Contains(info) Then
                Dim result() As String = content(i).Split(":", 2, StringSplitOptions.RemoveEmptyEntries)
                If result(1).Trim.Contains("[No Information Found]") Then
                    Return "N/A"
                Else
                    Return result(1).Trim
                End If
            End If
        Next
        Return value
    End Function

    Private Sub AddVirtual_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtDescription.Text = ""
        lblFile.Text = ""
        btnAdd.Enabled = False
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        btnAdd.Enabled = False

        With dlgVirtual
            .FileName = ""
            .Filter = "*.txt|*.txt"
            If .ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                content = IO.File.ReadAllLines(.FileName)
                Dim havedata As Boolean = False
                For i As Short = 0 To content.Length - 1
                    If content(i).Contains("START OF INFORMATION SECTION") Then
                        havedata = True
                        Exit For
                    End If
                Next
                If havedata Then
                    lblFile.Text = IO.Path.GetFileNameWithoutExtension(.FileName)
                    lblFile.Tag = .FileName
                    btnAdd.Enabled = True
                Else
                    MsgBox(Main.m_nogooddata, MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, Main.m_dataerror)
                End If
            End If
        End With
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim virtualfolder As String = My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData _
                                      .Substring(0, My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData.LastIndexOf("\")) _
                                      & "\Virtual devices\"

        'get size, device model, serial number, firmware
        Dim devmodel As String = GetInfo("Device Model")
        Dim devsize As String = GetInfo("User Capacity")
        Dim serial As String = GetInfo("Serial Number")
        Dim firmware As String = GetInfo("Firmware Version")

        'create a new configuration file containing some informations about the device
        '(model, size, serial number and firmware) and the virtual device file location
        Dim content As String = lblFile.Tag & vbCrLf & txtDescription.Text & vbCrLf & _
            devmodel & vbCrLf & devsize & vbCrLf & serial & vbCrLf & firmware
        If Not IO.Directory.Exists(virtualfolder) Then IO.Directory.CreateDirectory(virtualfolder)
        IO.File.WriteAllText(virtualfolder & devmodel.Replace("/", "") & "_" & serial.Replace("/", "") & ".vd", content, System.Text.Encoding.Default)

        'add virtual device to devices listview and collection
        With Main
            .devicelist.Add(New Device(lblFile.Tag, DeviceType.Virtual))
            Dim dev As Device = .devicelist(.devicelist.Count - 1)
            Dim info As VirtualDeviceInfo
            With info
                .Description = txtDescription.Text
                .Model = devmodel
                .UserSize = devsize
                .SerialNumber = serial
                .Firmware = firmware
            End With
            dev.VirtualDeviceInfo = info

            With .lvwDevices
                Dim lvi As New ListViewItem(dev.Model, 1, .Groups(2))
                .Items.Add(lvi)
                Dim i As Short = .Items.Count - 1
                .Items(i).UseItemStyleForSubItems = False

                Select Case dev.Health
                    Case Status.Unkonwn
                        .Items(i).ForeColor = Color.DarkGray
                    Case Status.Failed
                        .Items(i).ForeColor = Color.Red
                        .Items(i).ImageIndex = 0
                    Case Status.Passed
                        .Items(i).ForeColor = Color.Blue
                End Select

                If IsNumeric(dev.Temperature) Then
                    .Items(i).SubItems.Add(dev.Temperature & "°C")
                    Select Case Val(dev.Temperature)
                        Case 0 To 49
                            .Items(i).SubItems(1).ForeColor = Color.Blue
                        Case 50 To 54
                            .Items(i).SubItems(1).ForeColor = Color.DarkOrange
                        Case Is >= 55
                            .Items(i).SubItems(1).ForeColor = Color.Red
                    End Select
                Else
                    .Items(i).SubItems.Add(dev.Temperature)
                    .Items(i).SubItems(1).ForeColor = Color.DarkGray
                End If
                .Items(i).Selected = True
                .Items(i).EnsureVisible()
                .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                .Columns(0).Width = .ClientSize.Width - .Columns(1).Width
                .Groups(2).Header = .Groups(2).Tag & " - " & .Groups(2).Items.Count
            End With
        End With

        'exit from sub
        Me.Close()
    End Sub
End Class