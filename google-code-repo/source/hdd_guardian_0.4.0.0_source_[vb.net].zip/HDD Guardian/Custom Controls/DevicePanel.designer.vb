﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DevicePanel
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpInfo = New System.Windows.Forms.TableLayoutPanel()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblLocation = New System.Windows.Forms.Label()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.lnkWeb = New System.Windows.Forms.LinkLabel()
        Me.lblSerial = New System.Windows.Forms.Label()
        Me.lblFirmware = New System.Windows.Forms.Label()
        Me.tlpInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'tlpInfo
        '
        Me.tlpInfo.BackColor = System.Drawing.Color.Transparent
        Me.tlpInfo.ColumnCount = 2
        Me.tlpInfo.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tlpInfo.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tlpInfo.Controls.Add(Me.lblModel, 0, 0)
        Me.tlpInfo.Controls.Add(Me.lblLocation, 0, 1)
        Me.tlpInfo.Controls.Add(Me.lblSize, 0, 2)
        Me.tlpInfo.Controls.Add(Me.lnkWeb, 1, 2)
        Me.tlpInfo.Controls.Add(Me.lblSerial, 1, 0)
        Me.tlpInfo.Controls.Add(Me.lblFirmware, 1, 1)
        Me.tlpInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpInfo.Location = New System.Drawing.Point(0, 0)
        Me.tlpInfo.Margin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.tlpInfo.Name = "tlpInfo"
        Me.tlpInfo.RowCount = 3
        Me.tlpInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpInfo.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpInfo.Size = New System.Drawing.Size(656, 56)
        Me.tlpInfo.TabIndex = 1
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.BackColor = System.Drawing.Color.Transparent
        Me.lblModel.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblModel.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblModel.ForeColor = System.Drawing.Color.White
        Me.lblModel.Location = New System.Drawing.Point(0, 0)
        Me.lblModel.Margin = New System.Windows.Forms.Padding(0)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(83, 18)
        Me.lblModel.TabIndex = 0
        Me.lblModel.Text = "Device Name"
        Me.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLocation
        '
        Me.lblLocation.AutoSize = True
        Me.lblLocation.BackColor = System.Drawing.Color.Transparent
        Me.lblLocation.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblLocation.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblLocation.Location = New System.Drawing.Point(0, 18)
        Me.lblLocation.Margin = New System.Windows.Forms.Padding(0)
        Me.lblLocation.Name = "lblLocation"
        Me.lblLocation.Size = New System.Drawing.Size(48, 18)
        Me.lblLocation.TabIndex = 1
        Me.lblLocation.Text = "Location"
        Me.lblLocation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSize
        '
        Me.lblSize.AutoSize = True
        Me.lblSize.BackColor = System.Drawing.Color.Transparent
        Me.lblSize.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblSize.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblSize.Location = New System.Drawing.Point(0, 36)
        Me.lblSize.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSize.Name = "lblSize"
        Me.lblSize.Size = New System.Drawing.Size(27, 20)
        Me.lblSize.TabIndex = 2
        Me.lblSize.Text = "Size"
        Me.lblSize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lnkWeb
        '
        Me.lnkWeb.AutoSize = True
        Me.lnkWeb.BackColor = System.Drawing.Color.Transparent
        Me.lnkWeb.Dock = System.Windows.Forms.DockStyle.Left
        Me.lnkWeb.LinkColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lnkWeb.Location = New System.Drawing.Point(265, 36)
        Me.lnkWeb.Name = "lnkWeb"
        Me.lnkWeb.Size = New System.Drawing.Size(89, 20)
        Me.lnkWeb.TabIndex = 3
        Me.lnkWeb.TabStop = True
        Me.lnkWeb.Text = "Manufacturer site"
        Me.lnkWeb.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSerial
        '
        Me.lblSerial.AutoSize = True
        Me.lblSerial.BackColor = System.Drawing.Color.Transparent
        Me.lblSerial.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblSerial.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblSerial.Location = New System.Drawing.Point(265, 0)
        Me.lblSerial.Name = "lblSerial"
        Me.lblSerial.Size = New System.Drawing.Size(73, 18)
        Me.lblSerial.TabIndex = 4
        Me.lblSerial.Text = "Serial Number"
        Me.lblSerial.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFirmware
        '
        Me.lblFirmware.AutoSize = True
        Me.lblFirmware.BackColor = System.Drawing.Color.Transparent
        Me.lblFirmware.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblFirmware.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblFirmware.Location = New System.Drawing.Point(265, 18)
        Me.lblFirmware.Name = "lblFirmware"
        Me.lblFirmware.Size = New System.Drawing.Size(49, 18)
        Me.lblFirmware.TabIndex = 5
        Me.lblFirmware.Text = "Firmware"
        Me.lblFirmware.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DevicePanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.Controls.Add(Me.tlpInfo)
        Me.DoubleBuffered = True
        Me.Name = "DevicePanel"
        Me.Size = New System.Drawing.Size(656, 56)
        Me.tlpInfo.ResumeLayout(False)
        Me.tlpInfo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Protected WithEvents tlpInfo As System.Windows.Forms.TableLayoutPanel
    Protected WithEvents lblModel As System.Windows.Forms.Label
    Protected WithEvents lblLocation As System.Windows.Forms.Label
    Protected WithEvents lblSize As System.Windows.Forms.Label
    Protected WithEvents lnkWeb As System.Windows.Forms.LinkLabel
    Protected WithEvents lblSerial As System.Windows.Forms.Label
    Protected WithEvents lblFirmware As System.Windows.Forms.Label

End Class
