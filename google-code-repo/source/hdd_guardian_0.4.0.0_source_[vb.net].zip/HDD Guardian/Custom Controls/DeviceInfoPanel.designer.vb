﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DeviceInfoPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpGrid = New System.Windows.Forms.TableLayoutPanel()
        Me.lblFamily = New System.Windows.Forms.Label()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblSerial = New System.Windows.Forms.Label()
        Me.lblFirmware = New System.Windows.Forms.Label()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.lblDatabase = New System.Windows.Forms.Label()
        Me.lblAtaVersion = New System.Windows.Forms.Label()
        Me.lblAtaStandard = New System.Windows.Forms.Label()
        Me.lblLastCheck = New System.Windows.Forms.Label()
        Me.lblSmartAvailable = New System.Windows.Forms.Label()
        Me.lblSmartEnabled = New System.Windows.Forms.Label()
        Me.lblFamilyValue = New System.Windows.Forms.Label()
        Me.lblModelValue = New System.Windows.Forms.Label()
        Me.lblSerialValue = New System.Windows.Forms.Label()
        Me.lblFirmwareValue = New System.Windows.Forms.Label()
        Me.lblSizeValue = New System.Windows.Forms.Label()
        Me.lblDatabaseValue = New System.Windows.Forms.Label()
        Me.lblAtaVersionValue = New System.Windows.Forms.Label()
        Me.lblAtaStandardValue = New System.Windows.Forms.Label()
        Me.lblLastCheckValue = New System.Windows.Forms.Label()
        Me.lblSmartAvailableValue = New System.Windows.Forms.Label()
        Me.lblSmartEnabledValue = New System.Windows.Forms.Label()
        Me.lblSectorSize = New System.Windows.Forms.Label()
        Me.lblSectorSizeValue = New System.Windows.Forms.Label()
        Me.lblWwn = New System.Windows.Forms.Label()
        Me.lblWwnValue = New System.Windows.Forms.Label()
        Me.tlpGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'tlpGrid
        '
        Me.tlpGrid.AutoSize = True
        Me.tlpGrid.ColumnCount = 2
        Me.tlpGrid.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpGrid.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpGrid.Controls.Add(Me.lblFamily, 0, 0)
        Me.tlpGrid.Controls.Add(Me.lblModel, 0, 1)
        Me.tlpGrid.Controls.Add(Me.lblSerial, 0, 2)
        Me.tlpGrid.Controls.Add(Me.lblFirmware, 0, 4)
        Me.tlpGrid.Controls.Add(Me.lblSize, 0, 5)
        Me.tlpGrid.Controls.Add(Me.lblDatabase, 0, 7)
        Me.tlpGrid.Controls.Add(Me.lblAtaVersion, 0, 8)
        Me.tlpGrid.Controls.Add(Me.lblAtaStandard, 0, 9)
        Me.tlpGrid.Controls.Add(Me.lblLastCheck, 0, 10)
        Me.tlpGrid.Controls.Add(Me.lblSmartAvailable, 0, 11)
        Me.tlpGrid.Controls.Add(Me.lblSmartEnabled, 0, 12)
        Me.tlpGrid.Controls.Add(Me.lblFamilyValue, 1, 0)
        Me.tlpGrid.Controls.Add(Me.lblModelValue, 1, 1)
        Me.tlpGrid.Controls.Add(Me.lblSerialValue, 1, 2)
        Me.tlpGrid.Controls.Add(Me.lblFirmwareValue, 1, 4)
        Me.tlpGrid.Controls.Add(Me.lblSizeValue, 1, 5)
        Me.tlpGrid.Controls.Add(Me.lblDatabaseValue, 1, 7)
        Me.tlpGrid.Controls.Add(Me.lblAtaVersionValue, 1, 8)
        Me.tlpGrid.Controls.Add(Me.lblAtaStandardValue, 1, 9)
        Me.tlpGrid.Controls.Add(Me.lblLastCheckValue, 1, 10)
        Me.tlpGrid.Controls.Add(Me.lblSmartAvailableValue, 1, 11)
        Me.tlpGrid.Controls.Add(Me.lblSmartEnabledValue, 1, 12)
        Me.tlpGrid.Controls.Add(Me.lblSectorSize, 0, 6)
        Me.tlpGrid.Controls.Add(Me.lblSectorSizeValue, 1, 6)
        Me.tlpGrid.Controls.Add(Me.lblWwn, 0, 3)
        Me.tlpGrid.Controls.Add(Me.lblWwnValue, 1, 3)
        Me.tlpGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpGrid.Location = New System.Drawing.Point(0, 0)
        Me.tlpGrid.Name = "tlpGrid"
        Me.tlpGrid.RowCount = 13
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpGrid.Size = New System.Drawing.Size(451, 208)
        Me.tlpGrid.TabIndex = 0
        '
        'lblFamily
        '
        Me.lblFamily.AutoSize = True
        Me.lblFamily.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFamily.ForeColor = System.Drawing.Color.DimGray
        Me.lblFamily.Location = New System.Drawing.Point(3, 0)
        Me.lblFamily.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblFamily.Name = "lblFamily"
        Me.lblFamily.Size = New System.Drawing.Size(87, 16)
        Me.lblFamily.TabIndex = 0
        Me.lblFamily.Text = "lblFamily"
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblModel.ForeColor = System.Drawing.Color.DimGray
        Me.lblModel.Location = New System.Drawing.Point(3, 16)
        Me.lblModel.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(87, 16)
        Me.lblModel.TabIndex = 1
        Me.lblModel.Text = "lblModel"
        '
        'lblSerial
        '
        Me.lblSerial.AutoSize = True
        Me.lblSerial.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSerial.ForeColor = System.Drawing.Color.DimGray
        Me.lblSerial.Location = New System.Drawing.Point(3, 32)
        Me.lblSerial.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSerial.Name = "lblSerial"
        Me.lblSerial.Size = New System.Drawing.Size(87, 16)
        Me.lblSerial.TabIndex = 2
        Me.lblSerial.Text = "lblSerial"
        '
        'lblFirmware
        '
        Me.lblFirmware.AutoSize = True
        Me.lblFirmware.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFirmware.ForeColor = System.Drawing.Color.DimGray
        Me.lblFirmware.Location = New System.Drawing.Point(3, 64)
        Me.lblFirmware.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblFirmware.Name = "lblFirmware"
        Me.lblFirmware.Size = New System.Drawing.Size(87, 16)
        Me.lblFirmware.TabIndex = 3
        Me.lblFirmware.Text = "lblFirmware"
        '
        'lblSize
        '
        Me.lblSize.AutoSize = True
        Me.lblSize.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSize.ForeColor = System.Drawing.Color.DimGray
        Me.lblSize.Location = New System.Drawing.Point(3, 80)
        Me.lblSize.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSize.Name = "lblSize"
        Me.lblSize.Size = New System.Drawing.Size(87, 16)
        Me.lblSize.TabIndex = 4
        Me.lblSize.Text = "lblSize"
        '
        'lblDatabase
        '
        Me.lblDatabase.AutoSize = True
        Me.lblDatabase.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDatabase.ForeColor = System.Drawing.Color.DimGray
        Me.lblDatabase.Location = New System.Drawing.Point(3, 112)
        Me.lblDatabase.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblDatabase.Name = "lblDatabase"
        Me.lblDatabase.Size = New System.Drawing.Size(87, 16)
        Me.lblDatabase.TabIndex = 5
        Me.lblDatabase.Text = "lblDatabase"
        '
        'lblAtaVersion
        '
        Me.lblAtaVersion.AutoSize = True
        Me.lblAtaVersion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblAtaVersion.ForeColor = System.Drawing.Color.DimGray
        Me.lblAtaVersion.Location = New System.Drawing.Point(3, 128)
        Me.lblAtaVersion.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblAtaVersion.Name = "lblAtaVersion"
        Me.lblAtaVersion.Size = New System.Drawing.Size(87, 16)
        Me.lblAtaVersion.TabIndex = 6
        Me.lblAtaVersion.Text = "lblAtaVersion"
        '
        'lblAtaStandard
        '
        Me.lblAtaStandard.AutoSize = True
        Me.lblAtaStandard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblAtaStandard.ForeColor = System.Drawing.Color.DimGray
        Me.lblAtaStandard.Location = New System.Drawing.Point(3, 144)
        Me.lblAtaStandard.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblAtaStandard.Name = "lblAtaStandard"
        Me.lblAtaStandard.Size = New System.Drawing.Size(87, 16)
        Me.lblAtaStandard.TabIndex = 7
        Me.lblAtaStandard.Text = "lblAtaStandard"
        '
        'lblLastCheck
        '
        Me.lblLastCheck.AutoSize = True
        Me.lblLastCheck.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblLastCheck.ForeColor = System.Drawing.Color.DimGray
        Me.lblLastCheck.Location = New System.Drawing.Point(3, 160)
        Me.lblLastCheck.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblLastCheck.Name = "lblLastCheck"
        Me.lblLastCheck.Size = New System.Drawing.Size(87, 16)
        Me.lblLastCheck.TabIndex = 8
        Me.lblLastCheck.Text = "lblLastCheck"
        '
        'lblSmartAvailable
        '
        Me.lblSmartAvailable.AutoSize = True
        Me.lblSmartAvailable.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSmartAvailable.ForeColor = System.Drawing.Color.DimGray
        Me.lblSmartAvailable.Location = New System.Drawing.Point(3, 176)
        Me.lblSmartAvailable.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSmartAvailable.Name = "lblSmartAvailable"
        Me.lblSmartAvailable.Size = New System.Drawing.Size(87, 16)
        Me.lblSmartAvailable.TabIndex = 9
        Me.lblSmartAvailable.Text = "lblSmartAvailable"
        '
        'lblSmartEnabled
        '
        Me.lblSmartEnabled.AutoSize = True
        Me.lblSmartEnabled.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSmartEnabled.ForeColor = System.Drawing.Color.DimGray
        Me.lblSmartEnabled.Location = New System.Drawing.Point(3, 192)
        Me.lblSmartEnabled.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSmartEnabled.Name = "lblSmartEnabled"
        Me.lblSmartEnabled.Size = New System.Drawing.Size(87, 16)
        Me.lblSmartEnabled.TabIndex = 10
        Me.lblSmartEnabled.Text = "lblSmartEnabled"
        '
        'lblFamilyValue
        '
        Me.lblFamilyValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFamilyValue.Location = New System.Drawing.Point(96, 0)
        Me.lblFamilyValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblFamilyValue.Name = "lblFamilyValue"
        Me.lblFamilyValue.Size = New System.Drawing.Size(352, 16)
        Me.lblFamilyValue.TabIndex = 11
        Me.lblFamilyValue.Text = "lblFamilyValue"
        '
        'lblModelValue
        '
        Me.lblModelValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblModelValue.Location = New System.Drawing.Point(96, 16)
        Me.lblModelValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblModelValue.Name = "lblModelValue"
        Me.lblModelValue.Size = New System.Drawing.Size(352, 16)
        Me.lblModelValue.TabIndex = 12
        Me.lblModelValue.Text = "lblModelValue"
        '
        'lblSerialValue
        '
        Me.lblSerialValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSerialValue.Location = New System.Drawing.Point(96, 32)
        Me.lblSerialValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSerialValue.Name = "lblSerialValue"
        Me.lblSerialValue.Size = New System.Drawing.Size(352, 16)
        Me.lblSerialValue.TabIndex = 13
        Me.lblSerialValue.Text = "lblSerialValue"
        '
        'lblFirmwareValue
        '
        Me.lblFirmwareValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFirmwareValue.Location = New System.Drawing.Point(96, 64)
        Me.lblFirmwareValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblFirmwareValue.Name = "lblFirmwareValue"
        Me.lblFirmwareValue.Size = New System.Drawing.Size(352, 16)
        Me.lblFirmwareValue.TabIndex = 14
        Me.lblFirmwareValue.Text = "lblFirmwareValue"
        '
        'lblSizeValue
        '
        Me.lblSizeValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSizeValue.Location = New System.Drawing.Point(96, 80)
        Me.lblSizeValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSizeValue.Name = "lblSizeValue"
        Me.lblSizeValue.Size = New System.Drawing.Size(352, 16)
        Me.lblSizeValue.TabIndex = 15
        Me.lblSizeValue.Text = "lblSizeValue"
        '
        'lblDatabaseValue
        '
        Me.lblDatabaseValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDatabaseValue.Location = New System.Drawing.Point(96, 112)
        Me.lblDatabaseValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblDatabaseValue.Name = "lblDatabaseValue"
        Me.lblDatabaseValue.Size = New System.Drawing.Size(352, 16)
        Me.lblDatabaseValue.TabIndex = 16
        Me.lblDatabaseValue.Text = "lblDatabaseValue"
        '
        'lblAtaVersionValue
        '
        Me.lblAtaVersionValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblAtaVersionValue.Location = New System.Drawing.Point(96, 128)
        Me.lblAtaVersionValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblAtaVersionValue.Name = "lblAtaVersionValue"
        Me.lblAtaVersionValue.Size = New System.Drawing.Size(352, 16)
        Me.lblAtaVersionValue.TabIndex = 17
        Me.lblAtaVersionValue.Text = "lblAtaVersionValue"
        '
        'lblAtaStandardValue
        '
        Me.lblAtaStandardValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblAtaStandardValue.Location = New System.Drawing.Point(96, 144)
        Me.lblAtaStandardValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblAtaStandardValue.Name = "lblAtaStandardValue"
        Me.lblAtaStandardValue.Size = New System.Drawing.Size(352, 16)
        Me.lblAtaStandardValue.TabIndex = 18
        Me.lblAtaStandardValue.Text = "lblAtaStandardValue"
        '
        'lblLastCheckValue
        '
        Me.lblLastCheckValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblLastCheckValue.Location = New System.Drawing.Point(96, 160)
        Me.lblLastCheckValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblLastCheckValue.Name = "lblLastCheckValue"
        Me.lblLastCheckValue.Size = New System.Drawing.Size(352, 16)
        Me.lblLastCheckValue.TabIndex = 19
        Me.lblLastCheckValue.Text = "lblLastCheckValue"
        '
        'lblSmartAvailableValue
        '
        Me.lblSmartAvailableValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSmartAvailableValue.Location = New System.Drawing.Point(96, 176)
        Me.lblSmartAvailableValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSmartAvailableValue.Name = "lblSmartAvailableValue"
        Me.lblSmartAvailableValue.Size = New System.Drawing.Size(352, 16)
        Me.lblSmartAvailableValue.TabIndex = 20
        Me.lblSmartAvailableValue.Text = "lblSmartAvailableValue"
        '
        'lblSmartEnabledValue
        '
        Me.lblSmartEnabledValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSmartEnabledValue.Location = New System.Drawing.Point(96, 192)
        Me.lblSmartEnabledValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSmartEnabledValue.Name = "lblSmartEnabledValue"
        Me.lblSmartEnabledValue.Size = New System.Drawing.Size(352, 16)
        Me.lblSmartEnabledValue.TabIndex = 21
        Me.lblSmartEnabledValue.Text = "lblSmartEnabledValue"
        '
        'lblSectorSize
        '
        Me.lblSectorSize.AutoSize = True
        Me.lblSectorSize.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSectorSize.ForeColor = System.Drawing.Color.DimGray
        Me.lblSectorSize.Location = New System.Drawing.Point(3, 96)
        Me.lblSectorSize.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSectorSize.Name = "lblSectorSize"
        Me.lblSectorSize.Size = New System.Drawing.Size(87, 16)
        Me.lblSectorSize.TabIndex = 22
        Me.lblSectorSize.Text = "lblSectorSize"
        '
        'lblSectorSizeValue
        '
        Me.lblSectorSizeValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSectorSizeValue.Location = New System.Drawing.Point(96, 96)
        Me.lblSectorSizeValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSectorSizeValue.Name = "lblSectorSizeValue"
        Me.lblSectorSizeValue.Size = New System.Drawing.Size(352, 16)
        Me.lblSectorSizeValue.TabIndex = 23
        Me.lblSectorSizeValue.Text = "lblSectorSizeValue"
        '
        'lblWwn
        '
        Me.lblWwn.AutoSize = True
        Me.lblWwn.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblWwn.ForeColor = System.Drawing.Color.DimGray
        Me.lblWwn.Location = New System.Drawing.Point(3, 48)
        Me.lblWwn.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblWwn.Name = "lblWwn"
        Me.lblWwn.Size = New System.Drawing.Size(87, 16)
        Me.lblWwn.TabIndex = 24
        Me.lblWwn.Text = "lblWwn"
        '
        'lblWwnValue
        '
        Me.lblWwnValue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblWwnValue.Location = New System.Drawing.Point(96, 48)
        Me.lblWwnValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblWwnValue.Name = "lblWwnValue"
        Me.lblWwnValue.Size = New System.Drawing.Size(352, 16)
        Me.lblWwnValue.TabIndex = 25
        Me.lblWwnValue.Text = "lblWwnValue"
        '
        'DeviceInfoPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Controls.Add(Me.tlpGrid)
        Me.Name = "DeviceInfoPanel"
        Me.Size = New System.Drawing.Size(451, 208)
        Me.tlpGrid.ResumeLayout(False)
        Me.tlpGrid.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Protected WithEvents tlpGrid As System.Windows.Forms.TableLayoutPanel
    Protected WithEvents lblFamily As System.Windows.Forms.Label
    Protected WithEvents lblModel As System.Windows.Forms.Label
    Protected WithEvents lblSerial As System.Windows.Forms.Label
    Protected WithEvents lblFirmware As System.Windows.Forms.Label
    Protected WithEvents lblSize As System.Windows.Forms.Label
    Protected WithEvents lblDatabase As System.Windows.Forms.Label
    Protected WithEvents lblAtaVersion As System.Windows.Forms.Label
    Protected WithEvents lblAtaStandard As System.Windows.Forms.Label
    Protected WithEvents lblLastCheck As System.Windows.Forms.Label
    Protected WithEvents lblSmartAvailable As System.Windows.Forms.Label
    Protected WithEvents lblSmartEnabled As System.Windows.Forms.Label
    Protected WithEvents lblFamilyValue As System.Windows.Forms.Label
    Protected WithEvents lblModelValue As System.Windows.Forms.Label
    Protected WithEvents lblSerialValue As System.Windows.Forms.Label
    Protected WithEvents lblFirmwareValue As System.Windows.Forms.Label
    Protected WithEvents lblSizeValue As System.Windows.Forms.Label
    Protected WithEvents lblDatabaseValue As System.Windows.Forms.Label
    Protected WithEvents lblAtaVersionValue As System.Windows.Forms.Label
    Protected WithEvents lblAtaStandardValue As System.Windows.Forms.Label
    Protected WithEvents lblLastCheckValue As System.Windows.Forms.Label
    Protected WithEvents lblSmartAvailableValue As System.Windows.Forms.Label
    Protected WithEvents lblSmartEnabledValue As System.Windows.Forms.Label
    Protected WithEvents lblSectorSize As System.Windows.Forms.Label
    Protected WithEvents lblSectorSizeValue As System.Windows.Forms.Label
    Protected WithEvents lblWwn As System.Windows.Forms.Label
    Protected WithEvents lblWwnValue As System.Windows.Forms.Label

End Class
