﻿'HDD Guardian is a GUI for smartcl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

'================================================================================
'This partial class is created to keep tracking of SMART vital parameters between
'different HDD Guardian sessions.

Partial Class Main

    Public Sub LoadValues(ByVal dev As Device)
        If installdevice = StoringDevice.Removable Then Exit Sub
        Dim filename As String = dev.Model & "_" & dev.SerialNumber & ".smart"
        'replace all non valid characters for file names
        filename = filename.Replace("\", "").Replace("/", "").Replace(":", "").Replace("?", "").Replace("""", "") _
            .Replace("<", "").Replace(">", "").Replace("|", "")

        Dim i As Short = devsettingsfolder.LastIndexOf("\")
        Dim folder As String = devsettingsfolder.Substring(0, i + 1) & "smart\"

        If IO.File.Exists(folder & filename) Then
            Dim values As String = IO.File.ReadAllText(folder & filename, System.Text.Encoding.Default)

            If values.Length > 0 And values.Contains("|") Then
                Dim valsplit() As String = values.Split("|")
                Dim vitalval As New Vitals
                With vitalval
                    .CurPending = valsplit(0)
                    .DiskShift = valsplit(1)
                    .Errors = valsplit(2)
                    .Indilinx = valsplit(3)
                    .Intel = valsplit(4)
                    .Micron = valsplit(5)
                    .OfflineUnc = valsplit(6)
                    .ReallEvent = valsplit(7)
                    .ReallSect = valsplit(8)
                    .Samsung = valsplit(9)
                    .SandForce = valsplit(10)
                    .SoftRead = valsplit(11)
                    .SpinRetry = valsplit(12)
                    .Temperature = valsplit(13)
                End With
                newvitals.Add(vitalval)
            End If
        End If
    End Sub

    Public Sub SaveValues(ByVal dev As Device)
        If installdevice = StoringDevice.Removable Then Exit Sub
        Dim filename As String = dev.Model & "_" & dev.SerialNumber & ".smart"
        'replace all non valid characters for file names
        filename = filename.Replace("\", "").Replace("/", "").Replace(":", "").Replace("?", "").Replace("""", "") _
            .Replace("<", "").Replace(">", "").Replace("|", "")

        Dim i As Short = devsettingsfolder.LastIndexOf("\")
        Dim folder As String = devsettingsfolder.Substring(0, i + 1) & "smart\"

        Dim content As String
        With dev.VitalParameters
            content = .CurPending & "|" & _
                .DiskShift & "|" & _
                .Errors & "|" & _
                .Indilinx & "|" & _
                .Intel & "|" & _
                .Micron & "|" & _
                .OfflineUnc & "|" & _
                .ReallEvent & "|" & _
                .ReallSect & "|" & _
                .Samsung & "|" & _
                .SandForce & "|" & _
                .SoftRead & "|" & _
                .SpinRetry & "|" & _
                .Temperature
        End With

        If Not IO.Directory.Exists(folder) Then IO.Directory.CreateDirectory(folder)
        FileIO.FileSystem.WriteAllText(folder & filename, content, False)

    End Sub

End Class
