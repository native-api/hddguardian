﻿'HDD Guardian is a GUI for smartcl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System
Imports System.Management
Imports System.ComponentModel

Partial Class Main

    Dim WithEvents device_arrival As New BackgroundWorker
    Dim WithEvents device_remove As New BackgroundWorker

#Region "Old beta code"

    'Dim WithEvents usbnotificator As New BackgroundWorker

    'Sub StartUsbMonitoring() Handles usbnotificator.DoWork
    'Try
    '*** WARNING ***
    'This notificator can't work under Windows XP!

    'EventType=2 is for a new device arrival
    'EventType=3 is for a device removal
    'Dim usbEvent As New WqlEventQuery("SELECT * FROM Win32_DeviceChangeEvent WHERE EventType = 2 OR EventType = 3")

    'start watching...
    'Dim watcher = New ManagementEventWatcher(usbEvent)
    'Dim ConnectEvent As ManagementBaseObject = watcher.WaitForNextEvent()
    'Catch

    'End Try
    'End Sub

    'Sub UsbNotification() Handles usbnotificator.RunWorkerCompleted
    'UsbDevicesComparison()
    'restart monitoring devices changes...
    'usbnotificator.RunWorkerAsync()
    'End Sub

#End Region

#Region "New code"
    'note: this code works also with Windows XP!

    Sub UsbDevicesComparison()
        Dim smartctl As New Console
        Dim usb() As String = Nothing

        'querying smartctl for usb devices
        Dim usbscan() As String = smartctl.SendCmd("--scan -d usb")
        For i As Integer = 0 To usbscan.Count - 2 'the last item is an empty line
            If InStr(usbscan(i), "/dev/sd") < InStr(usbscan(i), "#") And InStr(usbscan(i), "/dev/sd") >= 0 Then
                ReDim Preserve usb(i)
                Dim usbdev As String() = usbscan(i).Split("#")
                usb(i) = usbdev(0).Trim
            End If
        Next

        'Debug.Print("USB devices modification")

        If Not IsNothing(usb) Then
            With lvwDevices
                'count usb already connected
                Dim connected As Short = 0
                For c As Short = 0 To devicelist.Count - 1
                    If devicelist(c).Type = DeviceType.Removable Then
                        Debug.Print(devicelist(c).Location)
                        connected += 1
                    End If

                Next

                'Debug.Print("usb: " & connected & ";" & usb.Count)

                Select Case connected
                    Case Is > usb.Count
                        'a device is removed
                        For i As Short = 0 To devicelist.Count - 1
                            If devicelist(i).Type = DeviceType.Removable Then
                                Dim toRemove As Boolean = True
                                For c As Short = 0 To usb.Length - 1
                                    If usb(c).Contains(devicelist(i).Location) Then toRemove = False
                                    Exit For
                                Next
                                If toRemove Then
                                    devicelist.RemoveAt(i)
                                    oldvitals.RemoveAt(i)
                                    newvitals.RemoveAt(i)
                                    .Items(i).Remove()
                                    .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                                End If
                            End If
                        Next
                        'update tray icons
                        DestroyTrayIcons()
                        SetTrayIcons()
                    Case Is < usb.Count
                        'a device is connected
                        For i As Short = 0 To usb.Length - 1
                            Dim toAdd As Boolean = True
                            For c As Short = 0 To devicelist.Count - 1
                                If devicelist(c).Type = DeviceType.Removable Then
                                    If devicelist(c).Location.Contains(usb(i)) Then toAdd = False
                                    Exit For
                                End If
                            Next
                            If toAdd Then
                                Dim newusb As New Device(usb(i), DeviceType.Removable)
                                If newusb.IsDetected Then
                                    devicelist.Add(New Device(usb(i), DeviceType.Removable))
                                    Dim dev As Device = devicelist(devicelist.Count - 1)

                                    Dim lvi As New ListViewItem(dev.Model, 1, .Groups(1))
                                    .Items.Add(lvi)
                                    Dim a As Short = .Items.Count - 1
                                    .Items(a).UseItemStyleForSubItems = False

                                    Select Case dev.Health
                                        Case Status.Unkonwn
                                            .Items(a).ForeColor = Color.DarkGray
                                        Case Status.Failed
                                            .Items(a).ForeColor = Color.Red
                                            .Items(a).ImageIndex = 0
                                        Case Status.Passed
                                            .Items(a).ForeColor = Color.Blue
                                    End Select

                                    If IsNumeric(dev.Temperature) Then
                                        .Items(a).SubItems.Add(dev.Temperature & "°C")
                                        Select Case Val(dev.Temperature)
                                            Case 0 To 49
                                                .Items(a).SubItems(1).ForeColor = Color.Blue
                                            Case 50 To 54
                                                .Items(a).SubItems(1).ForeColor = Color.DarkOrange
                                            Case Is >= 55
                                                .Items(a).SubItems(1).ForeColor = Color.Red
                                        End Select
                                    Else
                                        .Items(a).SubItems.Add(dev.Temperature)
                                        .Items(a).SubItems(1).ForeColor = Color.DarkGray
                                    End If
                                    .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                                    .Columns(0).Width = .ClientSize.Width - .Columns(1).Width
                                    .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                                    'load device settings and monitoring options
                                    LoadDeviceSettings(dev)
                                    LoadMonitoringSettings(dev)
                                    LoadValues(dev)
                                End If
                            End If
                        Next
                        'update tray icons
                        If devicelist(devicelist.Count - 1).ShowTrayIcon Then
                            DestroyTrayIcons()
                            SetTrayIcons()
                        End If
                        'update all removable device vitals...
                        UpdateAll(DeviceType.Removable)
                    Case Is = usb.Count
                        'do nothing: a new device is connected but is not recognized by smartctl
                        'this appen in case of an usb key is added to system devices
                End Select
            End With
        Else
            'count usb already in list
            Dim connected As Short = 0
            For c As Short = 0 To devicelist.Count - 1
                If devicelist(c).Type = DeviceType.Removable Then connected += 1
            Next

            If connected > 0 Then
                'remove all usb devices...
                lvwDevices.Items(0).Selected = True
                For i As Short = 0 To devicelist.Count - 1
                    If i > devicelist.Count - 1 Then Exit For
                    If devicelist(i).Type = DeviceType.Removable Then
                        devicelist.RemoveAt(i)
                        oldvitals.RemoveAt(i)
                        newvitals.RemoveAt(i)
                        With lvwDevices
                            .Items(i).Remove()
                            .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                        End With
                    End If
                Next
                'update tray icons
                DestroyTrayIcons()
                SetTrayIcons()
            End If
        End If
    End Sub

    Sub eSataDevicesComparison()
        Dim smartctl As New Console
        Dim esata() As String = Nothing

        'querying smartctl for ata devices: eSATA are visualized with ATA (fixed) devices!
        Dim esatascan() As String = smartctl.SendCmd("--scan -d ata")
        For i As Integer = 0 To esatascan.Count - 2 'the last item is an empty line
            If InStr(esatascan(i), "/dev/sd") < InStr(esatascan(i), "#") And InStr(esatascan(i), "/dev/sd") >= 0 Then
                ReDim Preserve esata(i)
                Dim esatadev As String() = esatascan(i).Split("#")
                esata(i) = esatadev(0).Trim
            End If
        Next

        'Debug.Print("eSata devices modification")

        With lvwDevices
            'count usb already connected
            Dim connected As Short = 0
            For c As Short = 0 To devicelist.Count - 1
                If devicelist(c).Type = DeviceType.Internal Then connected += 1
            Next

            'Debug.Print("eSata: " & connected & ";" & esata.Count)

            Select Case connected
                Case Is > esata.Count
                    'a device is removed
                    For i As Short = 0 To devicelist.Count - 1
                        If devicelist(i).Type = DeviceType.Internal Then
                            Dim toRemove As Boolean = True
                            For c As Short = 0 To esata.Length - 1
                                If esata(c).Contains(devicelist(i).Location) Then toRemove = False
                                Exit For
                            Next
                            If toRemove Then
                                devicelist.RemoveAt(i)
                                oldvitals.RemoveAt(i)
                                newvitals.RemoveAt(i)
                                .Items(i).Remove()
                                .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                            End If
                        End If
                    Next
                    'update tray icons
                    DestroyTrayIcons()
                    SetTrayIcons()
                Case Is < esata.Count
                    'a device is connected
                    For i As Short = 0 To esata.Length - 1
                        Dim toAdd As Boolean = True
                        For c As Short = 0 To devicelist.Count - 1
                            If devicelist(c).Type = DeviceType.Internal Then
                                If devicelist(c).Location.Contains(esata(i)) Then toAdd = False
                                Exit For
                            End If
                        Next
                        If toAdd Then
                            Dim newesata As New Device(esata(i), DeviceType.Internal)
                            If newesata.IsDetected Then
                                devicelist.Add(newesata)
                                Dim dev As Device = devicelist(devicelist.Count - 1)

                                Dim lvi As New ListViewItem(dev.Model, 1, .Groups(1))
                                .Items.Add(lvi)
                                Dim a As Short = .Items.Count - 1
                                .Items(a).UseItemStyleForSubItems = False

                                Select Case dev.Health
                                    Case Status.Unkonwn
                                        .Items(a).ForeColor = Color.DarkGray
                                    Case Status.Failed
                                        .Items(a).ForeColor = Color.Red
                                        .Items(a).ImageIndex = 0
                                    Case Status.Passed
                                        .Items(a).ForeColor = Color.Blue
                                End Select

                                If IsNumeric(dev.Temperature) Then
                                    .Items(a).SubItems.Add(dev.Temperature & "°C")
                                    Select Case Val(dev.Temperature)
                                        Case 0 To 49
                                            .Items(a).SubItems(1).ForeColor = Color.Blue
                                        Case 50 To 54
                                            .Items(a).SubItems(1).ForeColor = Color.DarkOrange
                                        Case Is >= 55
                                            .Items(a).SubItems(1).ForeColor = Color.Red
                                    End Select
                                Else
                                    .Items(a).SubItems.Add(dev.Temperature)
                                    .Items(a).SubItems(1).ForeColor = Color.DarkGray
                                End If
                                .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                                .Columns(0).Width = .ClientSize.Width - .Columns(1).Width
                                .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
                                'load device settings and monitoring options
                                LoadDeviceSettings(dev)
                                LoadMonitoringSettings(dev)
                                LoadValues(dev)
                            End If
                        End If
                    Next
                    'update tray icons
                    DestroyTrayIcons()
                    SetTrayIcons()
                    'update all removable device vitals...
                    UpdateAll(DeviceType.Internal)
                Case Is = esata.Count
                    'do nothing: a new device is connected but is not recognized by smartctl
                    'this appen in case of an usb key is added to system devices
            End Select
        End With
        'restart monitoring devices changes...
    End Sub

    Private Sub StartMonitorDevicesInstances()
        device_arrival.RunWorkerAsync()
        device_remove.RunWorkerAsync()
    End Sub

    Private Sub DeviceArrival() Handles device_arrival.DoWork
        Try
            Dim arrivalevent As New WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 1 WHERE TargetInstance ISA 'Win32_DiskDrive'")

            'start watching...
            Dim watcher = New ManagementEventWatcher(arrivalevent)
            Dim ConnectEvent As ManagementBaseObject = watcher.WaitForNextEvent()
        Catch

        End Try
    End Sub

    Private Sub DeviceArrivalNotification() Handles device_arrival.RunWorkerCompleted
        UsbDevicesComparison()
        eSataDevicesComparison()
        'restart monitoring devices changes...
        device_arrival.RunWorkerAsync()
    End Sub

    Private Sub DeviceRemoval() Handles device_remove.DoWork
        Try
            Dim removalevent As New WqlEventQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 1  WHERE TargetInstance ISA 'Win32_DiskDrive'")

            'start watching...
            Dim watcher = New ManagementEventWatcher(removalevent)
            Dim ConnectEvent As ManagementBaseObject = watcher.WaitForNextEvent()
        Catch

        End Try
    End Sub

    Private Sub DeviceRemovalNotification() Handles device_remove.RunWorkerCompleted
        UsbDevicesComparison()
        eSataDevicesComparison()
        'restart monitoring devices changes...
        device_remove.RunWorkerAsync()
    End Sub

#End Region
End Class
