﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


'Here is gathered data about geometry of selected hard disk and their partitions details

Imports System.Management
Imports System.ComponentModel

Partial Class Main

    Private Structure Geometry
        Dim DeviceName, Index, Partitons, TotalSize, AvailableSize, _
            Cylinders, Heads, Sectors, Tracks, _
            BytesPerSector, SectorsPerTrack, TracksPerCylinder As String
    End Structure

    Private Structure Partition
        Dim Label, Letter, SerialNumber, FileSystem, TotalSize, FreeSize, _
            NumberOfBlocks, BlockSize, Type, Bootable, BootPartition, PrimaryPartition As String
    End Structure

    Private Class GeometryList
        Inherits List(Of Geometry)
    End Class

    Private Class PartitionList
        Inherits List(Of Partition)
    End Class

    Dim WithEvents wmiBgWorker As New BackgroundWorker
    Dim GeometryDetails As New GeometryList
    Dim Partitions As New PartitionList
    Dim selected As String = ""

    Private Sub GeometryAndPartitions()
        'Try
        'On Error Resume Next

        lblGathering.Top = tpGeometryPartitions.Height / 2 - lblGathering.Height / 2
        lblGathering.Visible = False

        If IsNothing(lvwDevices.SelectedItems(0).Index) Then Exit Sub

        If devicelist(lvwDevices.SelectedItems(0).Index).Type <> DeviceType.Virtual Then
            lvwGeometry.Items.Clear()
            lvwGeometry.Visible = False
            lblGathering.Image = pic_hourglass
            lblGathering.Text = "       " & m_gathering
            lblGathering.Left = tpGeometryPartitions.Width / 2 - lblGathering.Width / 2
            lblGathering.Visible = True
            wmiBgWorker.WorkerSupportsCancellation = True

            If Not wmiBgWorker.IsBusy Then
                wmiBgWorker.RunWorkerAsync(lvwDevices.SelectedItems(0).Text)
                selected = lvwDevices.SelectedItems(0).Text
            End If
        Else
            lvwGeometry.Visible = False
            lblGathering.Image = pic_info
            lblGathering.Text = "       " & m_notforvirtual
            lblGathering.Left = tpGeometryPartitions.Width / 2 - lblGathering.Width / 2
            lblGathering.Visible = True
        End If
        'Catch
        'End Try
    End Sub

    Private Sub AnalyzeDevice(ByVal sender As Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles wmiBgWorker.DoWork
        Analyze(e.Argument)
    End Sub

    Private Sub AnalyzeDone() Handles wmiBgWorker.RunWorkerCompleted
        If selected <> lvwDevices.SelectedItems(0).Text Then
            selected = lvwDevices.SelectedItems(0).Text
            wmiBgWorker.RunWorkerAsync(lvwDevices.SelectedItems(0).Text)
        Else
            PopulateGeometryList()
        End If
    End Sub

    Private Sub Analyze(ByVal device As String)
        On Error Resume Next

        Dim searcher As New ManagementObjectSearcher( _
                    "root\CIMV2", _
                    "SELECT * FROM Win32_DiskDrive WHERE Model LIKE " & """%" & device & "%""")

        'geometrical characteristics
        For Each queryObj As ManagementObject In searcher.Get()
            Dim index As String = queryObj("Index")
            Dim full As String = queryObj("Size")
            Dim partitioninfos As New ManagementObjectSearcher( _
            "root\CIMV2", _
            "SELECT * FROM Win32_DiskPartition WHERE DiskIndex = " & index)
            For Each queryPartition As ManagementObject In partitioninfos.Get
                Dim deviceid As String = queryPartition("DeviceID")

                Dim volumes As New ManagementObjectSearcher( _
                    "root\CIMV2", _
                    "SELECT * FROM Win32_LogicalDiskToPartition")
                For Each queryVolume As ManagementObject In volumes.Get
                    Dim queryResult As String = queryVolume("Antecedent")
                    If queryResult.Contains(deviceid) Then
                        Dim disk() As String = queryVolume("Dependent").ToString.Split("=")
                        Dim letter As String = disk(1).Replace("""", "'")

                        Dim volume As New ManagementObjectSearcher( _
                            "root\CIMV2", _
                            "SELECT * FROM Win32_LogicalDisk WHERE DeviceID = " & letter)
                        For Each queryDetails As ManagementObject In volume.Get
                            If wmiBgWorker.CancellationPending Then Exit Sub
                            full = full - queryDetails("Size")
                        Next
                    End If
                Next
            Next

            Dim g As New Geometry
            With g
                .DeviceName = device
                .Index = queryObj("Index")
                .Partitons = queryObj("Partitions")
                .TotalSize = Format(queryObj("Size") / 1024 ^ 3, "#,###") & " GiB / " _
                    & Format(queryObj("Size") / 1000 ^ 3, "#,###") & " GB"
                Select Case Val(full)
                    Case 0 To 1024
                        .AvailableSize = Format(Val(full), "#,###") & " Bytes"
                    Case 1024 To 1024 ^ 2
                        .AvailableSize = Format(Val(full) / 1024, "#,###") & " KiB / " _
                                                              & Format(Val(full) / 1000, "#,###") & " KB"
                    Case 1024 ^ 2 To 1024 ^ 3
                        .AvailableSize = Format(Val(full) / 1024 ^ 2, "#,###") & " MiB / " _
                                                              & Format(Val(full) / 1000 ^ 2, "#,###") & " MB"
                    Case Else
                        .AvailableSize = Format(Val(full) / 1024 ^ 3, "#,###") & " GiB / " _
                                                              & Format(Val(full) / 1000 ^ 3, "#,###") & " GB"
                End Select
                .Cylinders = Format(queryObj("TotalCylinders"), "#,###")
                .Heads = Format(queryObj("TotalHeads"), "#,###")
                .Sectors = Format(queryObj("TotalSectors"), "#,###")
                .Tracks = Format(queryObj("TotalTracks"), "#,###")
                .BytesPerSector = Format(queryObj("BytesPerSector"), "#,###")
                .SectorsPerTrack = Format(queryObj("SectorsPerTrack"), "#,###")
                .TracksPerCylinder = Format(queryObj("TracksPerCylinder"), "#,###")
            End With
            GeometryDetails.Clear()
            GeometryDetails.Add(g)
        Next

        'partitions details
        Partitions.Clear()
        For Each queryObj As ManagementObject In searcher.Get()
            Dim index As String = queryObj("Index")
            Dim partitioninfos As New ManagementObjectSearcher( _
                "root\CIMV2", _
                "SELECT * FROM Win32_DiskPartition WHERE DiskIndex = " & index)
            For Each queryPartition As ManagementObject In partitioninfos.Get
                Dim deviceid As String = queryPartition("DeviceID")
                Dim bootable As String = queryPartition("Bootable").ToString.Replace("False", m_no).Replace("True", m_yes)
                Dim bootpartition As String = queryPartition("BootPartition").ToString.Replace("False", m_no).Replace("True", m_yes)
                Dim description As String = queryPartition("Description")
                Dim numberofblocks As String = Format(queryPartition("NumberOfBlocks"), "#,###")
                Dim blocksize As String = queryPartition("BlockSize") & " bytes"
                Dim primarypartition As String = queryPartition("PrimaryPartition").ToString.Replace("False", m_no).Replace("True", m_yes)

                Dim volumes As New ManagementObjectSearcher( _
                    "root\CIMV2", _
                    "SELECT * FROM Win32_LogicalDiskToPartition")
                For Each queryVolume As ManagementObject In volumes.Get
                    Dim queryResult As String = queryVolume("Antecedent")
                    If queryResult.Contains(deviceid) Then
                        Dim disk() As String = queryVolume("Dependent").ToString.Split("=")
                        Dim letter As String = disk(1).Replace("""", "'")

                        Dim volume As New ManagementObjectSearcher( _
                            "root\CIMV2", _
                            "SELECT * FROM Win32_LogicalDisk WHERE DeviceID = " & letter)
                        For Each queryDetails As ManagementObject In volume.Get
                            Dim p As New Partition
                            With p
                                .Label = queryDetails("VolumeName")
                                .Letter = letter.Replace("'", "")
                                .SerialNumber = queryDetails("VolumeSerialNumber").ToString.Insert(4, "-")
                                .FileSystem = queryDetails("FileSystem")

                                Dim tot As ULong = queryDetails("Size")
                                Select Case tot
                                    Case 0 To 1024
                                        .TotalSize = Format(tot, "#,###") & " Bytes"
                                    Case 1024 To 1024 ^ 2
                                        .TotalSize = Format(tot / 1024, "#,###") & " KiB / " _
                                            & Format(tot / 1000, "#,###") & " KB"
                                    Case 1024 ^ 2 To 1024 ^ 3
                                        .TotalSize = Format(tot / 1024 ^ 2, "#,###") & " MiB / " _
                                            & Format(tot / 1000 ^ 2, "#,###") & " MB"
                                    Case Else
                                        .TotalSize = Format(tot / 1024 ^ 3, "#,###") & " GiB / " _
                                            & Format(tot / 1000 ^ 3, "#,###") & " GB"
                                End Select

                                Dim free As ULong = queryDetails("FreeSpace")
                                Select Case free
                                    Case 0 To 1024
                                        .FreeSize = Format(free, "#,###") & " Bytes"
                                    Case 1024 To 1024 ^ 2
                                        .FreeSize = Format(free / 1024, "#,###") & " KiB / " _
                                            & Format(free / 1000, "#,###") & " KB"
                                    Case 1024 ^ 2 To 1024 ^ 3
                                        .FreeSize = Format(free / 1024 ^ 2, "#,###") & " MiB / " _
                                            & Format(free / 1000 ^ 2, "#,###") & " MB"
                                    Case Else
                                        .FreeSize = Format(free / 1024 ^ 3, "#,###") & " GiB / " _
                                            & Format(free / 1000 ^ 3, "#,###") & " GB"
                                End Select

                                .NumberOfBlocks = numberofblocks
                                .Type = description
                                .BlockSize = blocksize
                                .Bootable = bootable
                                .BootPartition = bootpartition
                                .PrimaryPartition = primarypartition
                            End With
                            Partitions.Add(p)
                        Next
                    End If
                Next
            Next
        Next
    End Sub

    Private Sub PopulateGeometryList()
        With lvwGeometry

            '.Items.Clear()
            .Items.Add(GeometryDetails(0).DeviceName, 1)
            .Items(.Items.Count - 1).SubItems.Add(m_diskgeometry)
            .Items(.Items.Count - 1).BackColor = Color.GhostWhite

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_deviceindex & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add("/dev/sd" & Chr(97 + GeometryDetails(0).Index))

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_partitions & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).Partitons)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_totalsize & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).TotalSize)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_availablesize & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).AvailableSize)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_cylinders & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).Cylinders)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_heads & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).Heads)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_sectors & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).Sectors)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_tracks & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).Tracks)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_bytespersector & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).BytesPerSector)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_sectorspertrack & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).SectorsPerTrack)

            .Items.Add("")
            .Items(.Items.Count - 1).UseItemStyleForSubItems = False
            .Items(.Items.Count - 1).SubItems.Add(m_trackspercylinder & ":")
            .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
            .Items(.Items.Count - 1).SubItems.Add(GeometryDetails(0).TracksPerCylinder)



            For i As Short = 0 To Partitions.Count - 1

                .Items.Add(Partitions(i).Label & " (" & Partitions(i).Letter & ")", 2)
                .Items(.Items.Count - 1).SubItems.Add(m_partitiondetails)
                .Items(.Items.Count - 1).BackColor = Color.GhostWhite

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_serialnumber & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).SerialNumber)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_filesystem & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).FileSystem)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_totalsize & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).TotalSize)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_availablesize & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).FreeSize)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_numofblocks & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).NumberOfBlocks)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_blocksize & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).BlockSize)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_type & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).Type)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_bootable & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).Bootable)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_bootpartition & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).BootPartition)

                .Items.Add("")
                .Items(.Items.Count - 1).UseItemStyleForSubItems = False
                .Items(.Items.Count - 1).SubItems.Add(m_primarypartition & ":")
                .Items(.Items.Count - 1).SubItems(1).ForeColor = Color.Gray
                .Items(.Items.Count - 1).SubItems.Add(Partitions(i).PrimaryPartition)
            Next

            .Top = 0
            .Height = tpGeometryPartitions.Height
            .Columns(0).Width = 179
            .Columns(1).Width = 179
            .Columns(2).Width = 179
            lblGathering.Visible = False
            .Visible = True
        End With
    End Sub
End Class
