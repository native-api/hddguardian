﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main

    Private Sub SetRating()
        If lvwDevices.Items.Count = 0 Then Exit Sub

        Dim curdevice As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        picStars.Image = Nothing
        If Not My.Settings.EnableRating Then Exit Sub
        Select Case curdevice.ReliabilityRating.Overall
            Case 5
                picStars.Image = My.Resources.r5_star
            Case 4
                picStars.Image = My.Resources.r4_star
            Case 3
                picStars.Image = My.Resources.r3_star
            Case 2
                picStars.Image = My.Resources.r2_star
            Case 1
                picStars.Image = My.Resources.r1_star
            Case 0
                picStars.Image = My.Resources.r0_star
        End Select
    End Sub

    Public Sub SetReliabilityDetails()
        Dim reliability As Ratings
        With lvwDevices
            If Not IsNothing(.SelectedItems.Count) Then
                Dim i As Short = .SelectedItems(0).Index
                Dim d As Device = devicelist(i)

                If Not IsNumeric(d.VitalParameters.CurPending) Then
                    lblCurPendingValue.Text = "N/A"
                Else
                    lblCurPendingValue.Text = d.VitalParameters.CurPending & "/" & My.Settings.Tune197
                End If

                If Not IsNumeric(d.VitalParameters.Errors) Then
                    lblErrValue.Text = "N/A"
                Else
                    lblErrValue.Text = d.VitalParameters.Errors & "/" & My.Settings.TuneErrors
                End If

                If Not IsNumeric(d.VitalParameters.OfflineUnc) Then
                    lblOfflUncValue.Text = "N/A"
                Else
                    lblOfflUncValue.Text = d.VitalParameters.OfflineUnc & "/" & My.Settings.Tune198
                End If

                If Not IsNumeric(d.VitalParameters.ReallSect) Then
                    lblReallSectValue.Text = "N/A"
                Else
                    lblReallSectValue.Text = d.VitalParameters.ReallSect & "/" & d.BadSectorsThreshold
                End If

                If Not IsNumeric(d.VitalParameters.Indilinx) Then
                    lblIndilinxValue.Text = "N/A"
                Else
                    lblIndilinxValue.Text = d.VitalParameters.Indilinx & "/100"
                End If

                If Not IsNumeric(d.VitalParameters.Intel) Then
                    lblIntelValue.Text = "N/A"
                Else
                    lblIntelValue.Text = d.VitalParameters.Intel & "/100"
                End If

                If Not IsNumeric(d.VitalParameters.Micron) Then
                    lblMicronValue.Text = "N/A"
                Else
                    lblMicronValue.Text = d.VitalParameters.Micron & "/0"
                End If

                If Not IsNumeric(d.VitalParameters.Samsung) Then
                    lblSamsungValue.Text = "N/A"
                Else
                    lblSamsungValue.Text = d.VitalParameters.Samsung & "/100"
                End If

                If Not IsNumeric(d.VitalParameters.SandForce) Then
                    lblSandForceValue.Text = "N/A"
                Else
                    lblSandForceValue.Text = d.VitalParameters.SandForce & "/100"
                End If

                reliability = d.ReliabilityRating

                With picCurPending
                    Select Case reliability.CurrentPending
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With

                With picErrors
                    Select Case reliability.Errors
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With
                With picOfflUnc
                    Select Case reliability.OfflineUncorrectable
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With
                With picReallSect
                    Select Case reliability.ReallocationCount
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With
                With picIndilinx
                    Select Case reliability.Indilinx
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With
                With picIntel
                    Select Case reliability.Intel
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With
                With picMicron
                    Select Case reliability.Micron
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With
                With picSamsung
                    Select Case reliability.Samsung
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With
                With picSandForce
                    Select Case reliability.SandForce
                        Case 5
                            .Image = My.Resources.r5_star
                        Case 4
                            .Image = My.Resources.r4_star
                        Case 3
                            .Image = My.Resources.r3_star
                        Case 2
                            .Image = My.Resources.r2_star
                        Case 1
                            .Image = My.Resources.r1_star
                        Case Else
                            .Image = My.Resources.r0_star
                    End Select
                End With

            End If
        End With
    End Sub

End Class
