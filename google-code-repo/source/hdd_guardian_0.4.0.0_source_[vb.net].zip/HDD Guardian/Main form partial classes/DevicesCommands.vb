﻿'HDD Guardian is a GUI for smartcl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main
    Public devices() As String
    Public usbdevices() As String
    Public devicelist As New DeviceCollection

    Private Sub Search()
        Dim smartctl As New Console

        'search devices: now, the local devices are searched by smartctl with "--scan -d ata" option
        'the "-d ata" option at the end collect only fixed (non removable, like usb) devices
        Dim scan() As String = smartctl.SendCmd("--scan -d ata")
        For i As Integer = 0 To scan.Count - 2 'the last item is an empty line
            If InStr(scan(i), "/dev/sd") < InStr(scan(i), "#") And InStr(scan(i), "/dev/sd") >= 0 Then
                ReDim Preserve devices(i)
                Dim dev As String() = scan(i).Split("#")
                devices(i) = dev(0).Trim
            End If
        Next

        'collect usb devices: smartctl with "--scan -d usb" option is able to find devices under known interfaces
        'the "-d usb" option at the end collect only removable, like usb, devices
        Dim usbscan() As String = smartctl.SendCmd("--scan -d usb")
        For i As Integer = 0 To usbscan.Count - 2 'the last item is an empty line
            If InStr(usbscan(i), "/dev/sd") < InStr(usbscan(i), "#") And InStr(usbscan(i), "/dev/sd") >= 0 Then
                ReDim Preserve usbdevices(i)
                Dim usbdev As String() = usbscan(i).Split("#")
                usbdevices(i) = usbdev(0).Trim
            End If
        Next

        'if no devices are founded on system, display a message and then exits from application...
        If devices.Count = 0 Then
            MsgBox(m_nodevices, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, m_error)
            End
        End If
    End Sub

    Private Sub CollectDevices()
        'first, add local devices...
        For d As Integer = 0 To devices.Count - 1
            Dim devtoadd As New Device(devices(d), DeviceType.Internal)
            If devtoadd.IsDetected Then
                devicelist.Add(devtoadd)
                LoadDeviceSettings(devicelist(d))
                LoadMonitoringSettings(devicelist(d))
                LoadValues(devicelist(d))
                devicelist(d).Update()
            End If
        Next
        'then add usb devices...
        If Not IsNothing(usbdevices) Then
            For d As Integer = 0 To usbdevices.Count - 1
                devicelist.Add(New Device(usbdevices(d), DeviceType.Removable))
                LoadDeviceSettings(devicelist(devicelist.Count - 1))
                LoadMonitoringSettings(devicelist(devicelist.Count - 1))
                LoadValues(devicelist(devicelist.Count - 1))
                devicelist(devicelist.Count - 1).Update()
            Next
        End If
        'then, finally, add virtual devices (files)
        Dim virtualfolder As String = My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData _
                                      .Substring(0, My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData.LastIndexOf("\")) _
                                      & "\Virtual devices\"

        If IO.Directory.Exists(virtualfolder) And installdevice = StoringDevice.Fixed Then
            If IO.Directory.EnumerateFiles(virtualfolder, "*.vd").Count = 0 Then Exit Sub
            For Each file As String In IO.Directory.GetFiles(virtualfolder, "*.vd")
                Dim content() As String = IO.File.ReadAllLines(file)
                devicelist.Add(New Device(content(0), DeviceType.Virtual))
                Dim vd As Device = devicelist(devicelist.Count - 1)
                Dim vdi As VirtualDeviceInfo
                With vdi
                    .Description = content(1)
                    .Model = content(2)
                    .UserSize = content(3)
                    .SerialNumber = content(4)
                    .Firmware = content(5)
                End With
                vd.VirtualDeviceInfo = vdi
            Next
        End If
    End Sub

    Private Sub PopulateDeviceList()
        'listview item scheme
        '
        'ColHead    |Model      |Temp       |
        '           -------------------------
        'Item       |Icon+model |temperature|
        'the listview follow the same indexing of "DeviceList" array
        'each string is colored differently: model string color is related to device health,
        'temperature string color is related to three different temperature ranges

        With lvwDevices
            For Each dev As Device In devicelist
                If dev.Type = DeviceType.Internal Then
                    Dim lvi As New ListViewItem(dev.Model, 1, .Groups(0))
                    .Items.Add(lvi)
                ElseIf dev.Type = DeviceType.Virtual Then
                    Dim lvi As New ListViewItem(dev.Model, 1, .Groups(2))
                    .Items.Add(lvi)
                Else 'device is sure a removable one...
                    Dim lvi As New ListViewItem(dev.Model, 1, .Groups(1))
                    .Items.Add(lvi)
                End If

                Dim i As Integer = .Items.Count - 1
                .Items(i).UseItemStyleForSubItems = False

                Select Case dev.Health
                    Case Status.Unkonwn
                        .Items(i).ForeColor = Color.DarkGray
                    Case Status.Failed
                        .Items(i).ForeColor = Color.Red
                        .Items(i).ImageIndex = 0
                    Case Status.Passed
                        .Items(i).ForeColor = Color.Blue
                End Select

                If IsNumeric(dev.Temperature) Then
                    .Items(i).SubItems.Add(dev.Temperature & "°C")
                    Select Case Val(dev.Temperature)
                        Case 0 To 49
                            .Items(i).SubItems(1).ForeColor = Color.Blue
                        Case 50 To 54
                            .Items(i).SubItems(1).ForeColor = Color.DarkOrange
                        Case Is >= 55
                            .Items(i).SubItems(1).ForeColor = Color.Red
                    End Select
                Else
                    .Items(i).SubItems.Add(dev.Temperature)
                    .Items(i).SubItems(1).ForeColor = Color.DarkGray
                End If
            Next
            .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
            .Columns(0).Width = .ClientSize.Width - .Columns(1).Width
            .Items(0).Selected = True

            .Groups(0).Header = .Groups(0).Tag & " - " & .Groups(0).Items.Count
            .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
            .Groups(2).Header = .Groups(2).Tag & " - " & .Groups(2).Items.Count
        End With
        cboTest.SelectedIndex = 0
    End Sub

    Private Sub PopulateTopPanel()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        Dim size, model, path, firmware, serial As String

        If (dev.Type = DeviceType.Internal Or dev.Type = DeviceType.Removable) _
            Or (dev.Type = DeviceType.Virtual And IO.File.Exists(dev.Location)) Then
            If Not dev.Type = DeviceType.Virtual Then
                Dim loc() As String = dev.Location.ToString.Split(" ")
                path = loc(0)
            Else
                path = dev.VirtualDeviceInfo.Description
            End If
            model = dev.Model
            size = dev.UserCapacity
            firmware = dev.FirmwareVersion
            serial = dev.SerialNumber
        Else
            With dev.VirtualDeviceInfo
                path = .Description
                model = .Model
                Dim s() As String = .UserSize.Split("bytes")
                size = ""
                For i As Integer = 0 To s(0).Length - 1
                    If IsNumeric(s(0).Chars(i)) Then size = size & s(0).Chars(i)
                Next
                Dim iec As String
                If Val(size / 1024 ^ 3) > 1000 Then
                    iec = Format(Val(size / 1024 ^ 4), "#.#") & " TiB"
                Else
                    iec = Format(Val(size / 1024 ^ 3), "#,###") & " GiB"
                End If
                Dim si As String '= Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                If Val(size / 1000 ^ 3) > 1000 Then
                    si = Format(Val(size / 1000 ^ 4), "#.#") & " TB"
                Else
                    si = Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                End If
                size = iec & " / " & si
                firmware = .Firmware
                serial = .SerialNumber
            End With
        End If

        With devPanel
            .Visible = False
            If IsNumeric(size) Then
                'Dim iec As String = Format(Val(size / 1024 ^ 3), "#,###") & " GiB"
                'Dim si As String = Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                Dim iec As String
                If Val(size / 1024 ^ 3) > 1000 Then
                    iec = Format(Val(size / 1024 ^ 4), "#.0") & " TiB"
                Else
                    iec = Format(Val(size / 1024 ^ 3), "#,###") & " GiB"
                End If
                Dim si As String '= Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                If Val(size / 1000 ^ 3) > 1000 Then
                    si = Format(Val(size / 1000 ^ 4), "#.0") & " TB"
                Else
                    si = Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                End If
                .TotalSize = iec & " / " & si
            Else
                .TotalSize = size
            End If
            .Model = model
            .Path = path
            .Firmware = d_firmware & firmware
            .Serial = d_serial & serial
            .Web = ""
            .Visible = True
        End With
    End Sub

    Private Sub SetHealthPanel()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        'this is Main->Summary panel
        With hpSummary
            .Visible = False
            'temperature
            .Temperature(dev.Temperature)
            'last test results
            Dim res As String = dev.LastTestResults.Status
            If Not IsNothing(res) Then
                For i As Short = 0 To m_testresults.Count - 1
                    res = res.Replace(m_testresults(i).Original, m_testresults(i).Change)
                Next
            End If
            Select Case dev.LastTestResults.IsPassed
                Case Status.Failed
                    Dim remaining As Short = 100 - Val(dev.LastTestResults.Remaining)
                    .LastTest(res & " " & remaining & "%", _
                          HealthPanel.WarningLevel.Warning)
                Case Status.Passed
                    .LastTest(res, HealthPanel.WarningLevel.Ok)
                Case Status.Unkonwn
                    .LastTest(res, HealthPanel.WarningLevel.NA)
            End Select
            'overall health test
            Select Case dev.Health
                Case Status.Failed
                    .OverallHealth(h_overallfailed, HealthPanel.WarningLevel.Alarm)
                Case Status.Passed
                    .OverallHealth(h_overallpassed, HealthPanel.WarningLevel.Ok)
                Case Status.Unkonwn
                    .OverallHealth("N/A", HealthPanel.WarningLevel.NA)
            End Select
            'bad sectors
            Select Case dev.BadSectorsCount
                Case 0
                    .BadSectors(badsect_no, dev.BadSectorsCount)
                Case 1
                    .BadSectors(badsect_one.Replace("%", dev.BadSectorsCount), dev.BadSectorsCount)
                Case 2 To 50
                    .BadSectors(badsect_few.Replace("%", dev.BadSectorsCount), dev.BadSectorsCount)
                Case Is > 50
                    .BadSectors(badsect_several.Replace("%", dev.BadSectorsCount), dev.BadSectorsCount)
            End Select
            'error count
            Select Case Val(dev.TotalErrors)
                Case 0
                    .Errors(error_no, dev.TotalErrors)
                Case 1
                    .Errors(error_one.Replace("%", dev.TotalErrors), dev.TotalErrors)
                Case 2 To 10
                    .Errors(error_few.Replace("%", dev.TotalErrors), dev.TotalErrors)
                Case Is > 10
                    .Errors(error_several.Replace("%", dev.TotalErrors), dev.TotalErrors)
            End Select
            'last update
            .LastUpdate(dev.LastCheck)
            'warnings
            If dev.Warning.Warning <> "" Then
                .Warning(HealthPanel.WarningLevel.Warning, _
                         dev.Warning.Warning, True, _
                         dev.Warning.Link1, dev.Warning.Link2, dev.Warning.Link3)
            Else
                If dev.SmartSupport = Support.Available Then
                    If dev.SmartEnabled = Support.Enabled Then
                        .Warning(HealthPanel.WarningLevel.Ok, w_no, False)
                    Else
                        .Warning(HealthPanel.WarningLevel.Warning, w_smartdisabled, False)
                    End If
                Else
                    .Warning(HealthPanel.WarningLevel.Halt, w_smartunavailble, False)
                End If
                If dev.Type = DeviceType.Virtual Then
                    If Not IO.File.Exists(dev.Location) Then
                        .Warning(HealthPanel.WarningLevel.Alarm, w_repunavailabe, False)
                    End If
                End If
            End If
            .Visible = True
        End With
    End Sub

    Private Sub SetSwitches()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        'set to "on", "off" or "na" the SMART switch and
        'the Offline Data Collection switch
        Select Case dev.SmartEnabled
            Case Support.Enabled
                If dev.Type <> DeviceType.Virtual Then
                    picSmart.Image = My.Resources.switch_on
                Else
                    picSmart.Image = My.Resources.switch_on_placeholder
                End If

                'the offline collection is available only if SMART is enabled
                If dev.OfflineCollectionStatus = Support.Enabled Then
                    If dev.Type <> DeviceType.Virtual Then
                        picOfflineTest.Image = My.Resources.switch_on
                    Else
                        picOfflineTest.Image = My.Resources.switch_on_placeholder
                    End If
                Else
                    If dev.Type <> DeviceType.Virtual Then
                        picOfflineTest.Image = My.Resources.switch_off
                    Else
                        picOfflineTest.Image = My.Resources.switch_off_placeholder
                    End If
                    End If
            Case Support.Disabled
                If dev.Type <> DeviceType.Virtual Then
                    picSmart.Image = My.Resources.switch_off
                    picOfflineTest.Image = My.Resources.switch_off
                Else
                    picSmart.Image = My.Resources.switch_off_placeholder
                    picOfflineTest.Image = My.Resources.switch_off_placeholder
                End If
            Case Support.Unknown
                picSmart.Image = My.Resources.switch_na
                picOfflineTest.Image = My.Resources.switch_na
        End Select

        'the attribute autosave is setted when smartctl option are parsed

        'set tray icon switch
        If dev.ShowTrayIcon = True Then
            picTrayIcon.Image = My.Resources.switch_on
        Else
            picTrayIcon.Image = My.Resources.switch_off
        End If

        'set share switch
        If IO.Directory.Exists(My.Settings.SharingFolder) Then
            picShareOutput.Enabled = True
            If dev.IsShared = True Then
                picShareOutput.Image = My.Resources.switch_on
            Else
                picShareOutput.Image = My.Resources.switch_off
            End If
        Else
            picShareOutput.Enabled = False
            picShareOutput.Image = My.Resources.switch_na
        End If

        If (dev.Type = DeviceType.Internal Or dev.Type = DeviceType.Removable) And installdevice = StoringDevice.Fixed Then
            'selected device is a physical one and hddguardian is installed into a fixed device:
            'monitoring features are available
            lblMonFeatures.Visible = True
            tlpMonitoring.Visible = True
        Else
            lblMonFeatures.Visible = False
            tlpMonitoring.Visible = False
        End If
    End Sub

    Private Sub PopulateSmartctlPanels()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        'put complete output into the Smartctl->Output section
        txtReport.Text = dev.Output
        'populate (if necessary) the section under Smartctl->Tolerance, Smartctl->Attributes remap
        'and Smartctl->Firmware debug
        ParseOptions(dev.Options)
    End Sub

    Private Sub PopulateSmartAttributes()
        'listview item scheme
        '
        'ColHead    |Type |ID    |Attribute |Current |Worst  |Thresh     |When Failed |Raw       |
        '           ------------------------------------------------------------------------------
        'Item       |icon |.ID   |.Name     |.Value  |.Worst |.Threshold |.WhenFailed |.RawValue |
        'tag        |     |.Flag |          |        |       |           |            |          |
        'the "type" column show only an icon
        'Try

        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        With lvwSmart
            .Items.Clear()
            'set the first column to sort the listview, but it have no values to sort...
            .ListViewItemSorter = New ListViewComparer(0, SortOrder.None)
            For Each attr As Attribute In dev.Attributes

                If attr.Type = AttributeType.PreFail Then
                    .Items.Add("", 0)
                Else
                    .Items.Add("", 1)
                End If

                Dim i As Integer = .Items.Count - 1
                .Items(i).SubItems.Add(attr.ID)
                .Items(i).SubItems(0).Tag = attr.Flag
                .Items(i).SubItems.Add(attr.Name)
                .Items(i).SubItems.Add(attr.Value)
                .Items(i).SubItems.Add(attr.Worst)
                .Items(i).SubItems.Add(attr.Threshold)
                .Items(i).SubItems.Add(attr.WhenFailed)
                .Items(i).SubItems.Add(attr.RawValue)
            Next
            'set the second column (ID) to sort the listview...
            .ListViewItemSorter = New ListViewComparer(1, SortOrder.Ascending)

            For Item As Short = 0 To lvwSmart.Items.Count - 1
                'alternate backgroung color
                If Item Mod 2 <> 0 Then
                    .Items(Item).BackColor = Color.FromArgb(243, 245, 247)
                End If

                'check ID name and then, if raw value is a number and if it's >0
                'change background color of row
                Dim idname As String = .Items(Item).SubItems(2).Text
                If idname = "Reallocated Sector Ct" Or _
                        idname = "Spin Retry Count" Or _
                        idname = "Reallocated Event Count" Or _
                        idname = "Current Pending Sector" Or _
                        idname = "Offline Uncorrectable" Or _
                        idname = "Soft Read Error Rate" Or _
                        idname = "Disk Shift" Then
                    If IsNumeric(.Items(Item).SubItems(7).Text) Then
                        If Convert.ToSingle(.Items(Item).SubItems(7).Text) > 0 Then
                            .Items(Item).ForeColor = Color.DeepPink
                        End If
                    End If
                End If

                'evaluate if value is failing now or are failed in the past...
                Dim WhenFailed As String = .Items(Item).SubItems(6).Text
                Select Case WhenFailed
                    Case "FAILING NOW"
                        .Items.Item(Item).ForeColor = Color.Firebrick
                    Case "In the past"
                        .Items.Item(Item).ForeColor = Color.DarkOrange
                End Select
            Next

            For ColumnIndex = 0 To lvwSmart.Columns.Count - 1
                .Columns(ColumnIndex).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
            Next ColumnIndex

        End With

        lblDataStructure.Text = lblDataStructure.Tag & dev.DataStructuresRev.AttributesTable
        'Catch 'ex As Exception

        'End Try

    End Sub

    Private Sub PopulateDeviceInfo()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        With dipInfo
            .ModelFamily(dev.Family)
            .DeviceModel(dev.Model)
            .SerialNumber(dev.SerialNumber)
            .WorldWideName(dev.WorldWideName)
            .FirmwareVersion(dev.FirmwareVersion)
            If IsNumeric(dev.UserCapacity) Then
                .UserCapacity(Format(Val(dev.UserCapacity), "#,###") & " bytes")
            Else
                .UserCapacity("N/A")
            End If
            .SectorSize(dev.SectorSize)
            If dev.InDatabase Then
                .InDatabase(m_yes)
            Else
                .InDatabase(m_no)
            End If
            .AtaVersion(dev.AtaVersion)
            .AtaStandard(dev.AtaStandard)
            .LastCheck(dev.LastCheck)
            Select Case dev.SmartSupport
                Case Support.Available
                    .SmartAvailable(m_available)
                Case Support.Unavailable
                    .SmartAvailable(m_unavailable)
                Case Support.Ambiguous
                    .SmartAvailable(m_ambiguous)
                Case Support.Unknown
                    .SmartAvailable(m_unknown)
            End Select
            Select Case dev.SmartEnabled
                Case Support.Enabled
                    .SmartEnabled(m_enabled)
                Case Support.Disabled
                    .SmartEnabled(m_disabled)
                Case Support.Unknown
                    .SmartEnabled(m_unknown)
            End Select
        End With
    End Sub

    Private Sub PopulateCapabilities()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        With clCapabilities
            .Clear()
            For i As Short = 0 To dev.Capabilities.Count - 1
                .Add(dev.Capabilities(i).Name, _
                     dev.Capabilities(i).Value, _
                     dev.Capabilities(i).Meaning)
            Next
        End With
    End Sub

    Private Sub PopulateATAErrors()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        Dim err As Short = dev.TotalErrors
        optError1.Visible = False
        optError1.Checked = False
        optError2.Visible = False
        optError2.Checked = False
        optError3.Visible = False
        optError3.Checked = False
        optError4.Visible = False
        optError4.Checked = False
        optError5.Visible = False
        optError5.Checked = False
        lblErrLogVer.Text = lblErrLogVer.Tag & dev.DataStructuresRev.ErrorLog

        If dev.IsSupportedErrorLogging Then
            lblErrLogVer.Visible = True
            If err = 0 Then
                flwError.Visible = False
                lblErrorLog.Text = e_noerror
                Exit Sub
            Else
                lblErrorLog.Text = e_select
            End If

            optError1.Checked = True

            For i As Short = 0 To 4 'only the last 5 errors are stored into the log
                If err - i < 1 Then Exit For
                Select Case i
                    Case 0
                        optError1.Text = err - i
                        optError1.Visible = True
                    Case 1
                        optError2.Text = err - i
                        optError2.Visible = True
                    Case 2
                        optError3.Text = err - i
                        optError3.Visible = True
                    Case 3
                        optError4.Text = err - i
                        optError4.Visible = True
                    Case 4
                        optError5.Text = err - i
                        optError5.Visible = True
                End Select
            Next
        Else
            lblErrorLog.Text = e_noerrorlogging
            lblErrLogVer.Visible = False
            flwError.Visible = False
        End If
    End Sub

    Private Sub DisplayATAError(ByVal e As Integer)
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        If dev.Errors.Count > 0 Then
            Dim err As SmartError = dev.Errors(e - 1)
            Dim reg As Register = err.Registers

            flwError.Visible = True
            lblPowerOn.Text = lblPowerOn.Tag.ToString.Replace("%", err.Number) & err.Lifetime
            Dim errstatus As String = err.Status
            For i As Short = 0 To m_devicestatus.Count - 1
                errstatus = errstatus.Replace(m_devicestatus(i).Original, m_devicestatus(i).Change)
            Next
            lblDeviceStatus.Text = lblDeviceStatus.Tag & " " & errstatus ' err.Status

            RegistersPanel1.SetRegisters(reg.ER, reg.ST, reg.SC, reg.SN, reg.CL, reg.CH, reg.DH, reg.ErrorText)

            CommandsPanel1.HideRows(5 - err.Commands.Count)
            If err.Commands(0).PowerUp.Contains(":") Then
                CommandsPanel1.SetPowerUpTooltip(t_poweron, t_powerontxt)
            Else
                CommandsPanel1.SetPowerUpTooltip(t_timestamp, t_timestamptxt)
            End If
            For i As Short = 0 To err.Commands.Count - 1
                CommandsPanel1.AddCommand(err.Commands(i).CR, err.Commands(i).FR, err.Commands(i).SC, _
                                               err.Commands(i).SN, err.Commands(i).CL, err.Commands(i).CH, _
                                               err.Commands(i).DH, err.Commands(i).DC, err.Commands(i).PowerUp, _
                                               err.Commands(i).Feature)
            Next
        End If
    End Sub

    Private Sub PopulateSelfTestLog()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        If dev.IsSupportedSeftTest Then
            lblSelfTest.Text = lblSelfTest.Tag.ToString.Replace("%", dev.DataStructuresRev.SelfTestLog)
            With lvwSelfTest
                .Visible = True
                .Enabled = True
                .Items.Clear()
                If dev.SelfTests.Count > 0 Then
                    For i As Short = 0 To dev.SelfTests.Count - 1
                        Dim st As SelfTest = dev.SelfTests(i)
                        .Items.Add(st.Num)
                        .Items(.Items.Count - 1).SubItems.Add(st.Description)
                        .Items(.Items.Count - 1).SubItems.Add(st.Status)
                        .Items(.Items.Count - 1).SubItems.Add(st.Remaining)
                        .Items(.Items.Count - 1).SubItems.Add(st.LifeTime)
                        .Items(.Items.Count - 1).SubItems.Add(st.FirstError)
                        If i Mod 2 <> 0 Then .Items(.Items.Count - 1).BackColor = Color.FromArgb(243, 245, 247)
                    Next
                    .HeaderStyle = ColumnHeaderStyle.Nonclickable
                    .Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    .Columns(2).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    .Columns(3).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(4).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(5).Width = .ClientSize.Width - .Columns(0).Width - .Columns(1).Width - .Columns(2).Width - _
                        .Columns(3).Width - .Columns(4).Width
                Else
                    .HeaderStyle = ColumnHeaderStyle.None
                    .Items.Add(l_noselftestlog)
                    .Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    For i As Short = 1 To 5
                        .Columns(i).Width = 0
                    Next
                    .Enabled = False
                End If
            End With
        Else
            lblSelfTest.Text = l_noselftest
            lvwSelfTest.Visible = False
        End If
    End Sub

    Private Sub PopulateSelectiveSelfTestLog()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        If dev.IsSupportedSelective Then
            lblSelective.Text = lblSelective.Tag.ToString.Replace("%", dev.DataStructuresRev.SelectiveSelfTestLog)
            With lvwSelective
                .Visible = True
                .Enabled = True
                .Items.Clear()
                If dev.SelectiveSelfTest.Count > 0 Then
                    For i As Short = 0 To dev.SelectiveSelfTest.Count - 1
                        Dim sel As Selectives = dev.SelectiveSelfTest(i)
                        .Items.Add(sel.Span)
                        .Items(.Items.Count - 1).SubItems.Add(sel.MinLba)
                        .Items(.Items.Count - 1).SubItems.Add(sel.MaxLba)
                        .Items(.Items.Count - 1).SubItems.Add(sel.Status)
                        If i Mod 2 <> 0 Then .Items(.Items.Count - 1).BackColor = Color.FromArgb(243, 245, 247)
                    Next
                    .Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(2).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(3).Width = .ClientSize.Width - .Columns(0).Width - .Columns(1).Width - .Columns(2).Width
                Else
                    .HeaderStyle = ColumnHeaderStyle.None
                    .Items.Add(l_noselectivelog)
                    .Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    For i As Short = 1 To 3
                        .Columns(i).Width = 0
                    Next
                    .Enabled = False
                End If
            End With
        Else
            lblSelective.Text = l_noselective
            lvwSelective.Visible = False
        End If
    End Sub

    Private Sub UpdateTestTiming()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        'update label containig selected test timing
        btnRun.Visible = True
        If Not (My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator)) _
            Or dev.Type = DeviceType.Virtual Then
            pnlTest.Visible = False
        Else
            pnlTest.Visible = True
        End If

        Select Case cboTest.SelectedIndex
            Case 0
                lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.OfflineData
            Case 1
                lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ShortTest
            Case 2
                lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ExtendedTest
            Case 3
                lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ConveyanceTest
        End Select
        If lblDuration.Text.Contains("N/A") Or dev.Type = DeviceType.Virtual Then btnRun.Visible = False
    End Sub

    Private Sub DisableFunctions()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        'disable some functions not available for virtual devices
        If dev.Type = DeviceType.Virtual Then
            chkTolerance.Checked = False
            chkTolerance.Enabled = False
            chkAttributes.Checked = False
            chkAttributes.Enabled = False
            chkFirmware.Checked = False
            chkFirmware.Enabled = False
            picAttrAutosave.Image = My.Resources.switch_na
            picTrayIcon.Image = My.Resources.switch_na
            picShareOutput.Image = My.Resources.switch_na
        End If
    End Sub

    Private Sub PopulateAll()
        PopulateTopPanel()
        'Main panel
        PopulateDeviceInfo()
        SetHealthPanel()
        SetSwitches()
        'Advanced panel
        PopulateSmartAttributes()
        PopulateCapabilities()
        PopulateATAErrors()
        PopulateSelfTestLog()
        PopulateSelectiveSelfTestLog()
        UpdateTestTiming()
        'Smartctl panel
        PopulateSmartctlPanels()
        'set os and manufacturer pictures 
        SetManufacturerPicture()
        SetOsPicture()
        'reliability
        SetRating()
        SetReliabilityDetails()
        'Analyze(lvwDevices.SelectedItems(0).Text)
        DisableFunctions()
    End Sub

    'the following sub is public because is called when a virtual device is added
    'from the dialog box
    Public Sub UpdateAll(ByVal type As DeviceType)
        Dim updateview As Boolean = False

        With lvwDevices
            'update devices smartctl output
            For Each dev As Device In devicelist
                If dev.Type = type Then
                    dev.Update()
                    'this boolean variable checks if they're some
                    'devices of selected type
                    updateview = True
                    'save current SMART values into a file
                    SaveValues(dev)
                End If
            Next

            If updateview = True Then
                For i As Short = 0 To .Items.Count - 1
                    If devicelist(i).Type = type Then
                        'update color of device name and displayed icon
                        Select Case devicelist(i).Health
                            Case Status.Unkonwn
                                .Items(i).ForeColor = Color.DarkGray
                                .Items(i).ImageIndex = 1
                            Case Status.Failed
                                .Items(i).ForeColor = Color.Red
                                .Items(i).ImageIndex = 0
                            Case Status.Passed
                                .Items(i).ForeColor = Color.Blue
                                .Items(i).ImageIndex = 1
                        End Select
                        'update device temperatures and colors
                        If IsNumeric(devicelist(i).Temperature) Then
                            .Items(i).SubItems(1).Text = devicelist(i).Temperature & "°C"
                            Select Case Val(devicelist(i).Temperature)
                                Case 0 To 49
                                    .Items(i).SubItems(1).ForeColor = Color.Blue
                                Case 50 To 54
                                    .Items(i).SubItems(1).ForeColor = Color.DarkOrange
                                Case Is >= 55
                                    .Items(i).SubItems(1).ForeColor = Color.Red
                            End Select
                        Else
                            .Items(i).SubItems(1).Text = devicelist(i).Temperature
                            .Items(i).SubItems(1).ForeColor = Color.DarkGray
                        End If
                    End If
                Next
                .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                .Columns(0).Width = .ClientSize.Width - .Columns(1).Width

                'check if the currently displayed device is of the type
                'that are currently updated
                If devicelist(.SelectedItems(0).Index).Type = type Then
                    PopulateAll()
                    UpdateTrayIcons()
                    ShowWarnings()
                    ShareOutput()
                End If
                'update also the log of today...
                With Now
                    LoadLog(.Year, .Month, .Day)
                End With

                'and now, from 0.4.0.0, export a Xml report!
                If My.Settings.ExportToXml And IO.Directory.Exists(My.Settings.XmlFolder) Then
                    ExportToXml()
                End If
            End If
        End With
    End Sub

    Private Sub UpdateCurrent()
        With lvwDevices
            Dim i As Short = .SelectedItems(0).Index

            devicelist(i).Update()

            'update color of device name
            Select Case devicelist(i).Health
                Case status.Unkonwn
                    .Items(i).ForeColor = Color.DarkGray
                Case status.Failed
                    .Items(i).ForeColor = Color.Red
                    .Items(i).ImageIndex = 0
                Case status.Passed
                    .Items(i).ForeColor = Color.Blue
            End Select
            'update device temperatures and colors
            If IsNumeric(devicelist(i).Temperature) Then
                .Items(i).SubItems(1).Text = devicelist(i).Temperature & "°C"
                Select Case Val(devicelist(i).Temperature)
                    Case 0 To 49
                        .Items(i).SubItems(1).ForeColor = Color.Blue
                    Case 50 To 54
                        .Items(i).SubItems(1).ForeColor = Color.DarkOrange
                    Case Is >= 55
                        .Items(i).SubItems(1).ForeColor = Color.Red
                End Select
            Else
                .Items(i).SubItems(1).Text = devicelist(i).Temperature
                .Items(i).SubItems(1).ForeColor = Color.DarkGray
            End If
            .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
            .Columns(0).Width = .ClientSize.Width - .Columns(1).Width

            PopulateAll()
            UpdateTrayIcons()
            ShowWarnings()
            ShareOutput()
            SaveValues(devicelist(i))
        End With
    End Sub

    Private Sub ShareOutput()
        Dim outputfolder = My.Settings.SharingFolder

        If IO.Directory.Exists(outputfolder) Then
            For i As Short = 0 To devicelist.Count - 1
                Dim dev As Device = devicelist(i)
                If dev.Type = DeviceType.Internal And dev.IsShared = True Then
                    IO.File.WriteAllText(outputfolder & "\" & dev.Model & "_" & dev.SerialNumber & ".txt", dev.Output)
                End If
            Next
        End If
    End Sub
End Class
