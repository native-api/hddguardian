﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.IO

Public Class Main

    Enum StoringDevice
        Fixed = 0
        Removable = 1
    End Enum

    Dim installdevice As StoringDevice = StoringDevice.Fixed
    Dim tab_size As Size = New Size(568, 321)
    Dim tab_loc As Point = New Point(184, 88)
    Dim isloading As Boolean = True

#Region "Main form"

    Private Sub frmMain_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate
        On Error Resume Next
        If My.Settings.MinimizeOnTray Then
            If Me.WindowState = FormWindowState.Minimized Then
                Me.ShowInTaskbar = False
                Me.Visible = False
                niTrayIcon.Visible = True
            Else
                Me.ShowInTaskbar = True
                Me.Visible = True
                niTrayIcon.Visible = My.Settings.AlwaysShowTrayIcon
            End If
        End If

        Memory.FlushMemory()
    End Sub

    Private Sub frmMain_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        DestroyTrayIcons()
        niTrayIcon.Visible = False
        Me.Dispose()
        End
    End Sub

    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim confirm As MsgBoxResult

        If My.Settings.CloseOnTray Then
            If Me.WindowState = FormWindowState.Normal Then
                e.Cancel = True
                Me.WindowState = FormWindowState.Minimized
                Me.ShowInTaskbar = False
                Me.Visible = False
                niTrayIcon.Visible = True
            End If
        End If

        If My.Settings.ConfirmOnExit And e.CloseReason = CloseReason.UserClosing Then
            confirm = MsgBox(m_exitmsg, MsgBoxStyle.OkCancel + MsgBoxStyle.Exclamation, m_exit)
            If confirm = MsgBoxResult.Cancel Then e.Cancel = True
        End If
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        isloading = True

        InterfaceTranslation()

        'check if smartctl.exe is in the hdd guardian folder:
        'if not, the program will be closed.
        If Not IO.File.Exists(My.Application.Info.DirectoryPath & "\smartctl.exe") Then
            MsgBox(m_nosmartctl, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, m_error)
            Me.Dispose()
            End
        End If

        'hide update panel at main window bottom
        pnlUpdate.Visible = False

        LoadSettings()

        'set main window title
        With My.Application.Info
            Me.Text = .Title.ToString & " " & .Version.ToString
            If My.Resources.rc.Length > 0 Then Me.Text += " RC " & My.Resources.rc
            niTrayIcon.Text = Me.Text
        End With

        'set .NET Framework version label (now, you see the version you're runnig!)
        With System.Environment.Version
            lblFramework.Text = ".NET Framework version " & .ToString
        End With

        'uncheck and hide device options
        chkAttributes.Checked = False
        pnlAttributes.Visible = False
        chkFirmware.Checked = False
        pnlFirmware.Visible = False
        chkTolerance.Checked = False
        pnlTolerance.Visible = False

        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False

        'determine the device type and then show or hide the usb icon
        If devtype.DriveType <> DriveType.Fixed Then
            'if hddguardian in stored into a non fixed
            '(removable media, cd-rom, network, etc.) drive, user
            'can't modify the basics settings, can't show devices icons
            'in tray area, can't share the output, can't add or remove
            'virtual devices, and can't modify the behaviour of smartctl
            '(normally if a program is stored into a removable device is
            'used for purposes of a quick check)
            'picUsb.Visible = True
            gbSettings.Collapsed = True
            gbSettings.Enabled = False
            installdevice = StoringDevice.Removable
            tlpMonitoring.Visible = False
            lblMonFeatures.Visible = False
            mnuRemoveVirtual.Enabled = False
            mnuAddVirtual.Enabled = False
            chkAttributes.Enabled = False
            chkFirmware.Enabled = False
            chkTolerance.Enabled = False
        Else
            'picUsb.Visible = False
            gbSettings.Collapsed = False
        End If

        LoadAttribInfos()
        'from version 0.3.0.0 devices database is no more updated and not available
        'because the xml file was builded into package for a better performance at
        'startup, but in reality it is updated many time from smartmontools developers
        'and is saved in a c++ form; loading it as an external file generates a slower
        'startup of HDD Guardian...
        'LoadXmlDB()
        'database page is available into the interface project, but is removed at startup!
        tabSmartctl.TabPages.Remove(tpDatabase)
        LoadManufacturers()
        LoadOs()
        LoadIcons()
        Search()
        CollectDevices()
        PopulateDeviceList()
        VitalsCheck()
        OverallHealthCheck()
        SetTrayIcons()

        gbMain.Checked = True
        With tabMain
            .Size = tab_size
            .Location = tab_loc
            .BringToFront()
        End With
        tlpStatusBar.BringToFront()

        'load today log
        With Now
            LoadLog(.Year, .Month, .Day)
        End With

        'About section:
        'load license
        lblLicense.Text = My.Resources.License
        'set version and copyright
        With My.Application.Info
            lblVersion.Text = .Version.ToString
            If My.Resources.rc.Length > 0 Then lblVersion.Text += " RC " & My.Resources.rc
            lblCopyright.Text = .Copyright
        End With

        If My.Settings.StartMinimized Then
            Me.WindowState = FormWindowState.Minimized
            If My.Settings.MinimizeOnTray Then
                Me.ShowInTaskbar = False
                Me.Visible = False
                niTrayIcon.Visible = True
            End If
        End If

        'start monitoring for incoming/outcoming devices
        'only if user have administration rights, because smartctl
        'fail to open usb ports if user have a limited account :-(
        If My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
            'usbnotificator.RunWorkerAsync()
            device_arrival.RunWorkerAsync()
            device_remove.RunWorkerAsync()
        End If

        'populate all panels for the first device in list
        GeometryAndPartitions()
        PopulateAll()

        Memory.FlushMemory()
        isloading = False
    End Sub
#End Region

#Region "Flush memory timer"
    Private Sub tmrFlushMem_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrFlushMem.Tick
        Memory.FlushMemory()
    End Sub
#End Region

#Region "Power off button"
    Private Sub pbPower_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picPower.MouseEnter
        picPower.BackgroundImage = My.Resources.power_selected
    End Sub

    Private Sub pbPower_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picPower.MouseLeave
        picPower.BackgroundImage = My.Resources.power_deselected
    End Sub

    Private Sub pbPower_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picPower.Click
        Dim confirm As MsgBoxResult
        If My.Settings.ConfirmOnExit Then
            confirm = MsgBox(m_exitmsg, MsgBoxStyle.OkCancel + MsgBoxStyle.Exclamation, m_exit)
            If confirm = MsgBoxResult.Cancel Then Exit Sub
        End If

        DestroyTrayIcons()
        niTrayIcon.Visible = False
        Me.Dispose()
        End
    End Sub
#End Region

#Region "Navigation buttons"
    Private Sub gbMain_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles gbMain.Click
        With tabMain
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            picHelp.Tag = .SelectedTab.Tag
        End With
        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub gbAdvanced_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles gbAdvanced.Click
        With tabAdvanced
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            picHelp.Tag = .SelectedTab.Tag
        End With
        tabMain.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub gbSmartctl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles gbSmartctl.Click
        With tabSmartctl
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            picHelp.Tag = .SelectedTab.Tag
        End With
        tabMain.Enabled = False
        tabAdvanced.Enabled = False
        tabSettings.Enabled = False
        tabAbout.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub gbSettings_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles gbSettings.Click
        With tabSettings
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            picHelp.Tag = .SelectedTab.Tag
        End With
        tabMain.Enabled = False
        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabAbout.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub

    Private Sub gbAbout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles gbAbout.Click
        With tabAbout
            .Size = tab_size
            .Location = tab_loc
            .Enabled = True
            .BringToFront()
            .Focus()
            picHelp.Tag = "http://code.google.com/p/hddguardian/wiki/Project_purpose"
        End With
        tabMain.Enabled = False
        tabAdvanced.Enabled = False
        tabSmartctl.Enabled = False
        tabSettings.Enabled = False
        tlpStatusBar.BringToFront()
    End Sub
#End Region

#Region "Devices list"
    Dim current As Short
    Dim loadnow As Boolean = True

    Private Sub lvwDevices_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvwDevices.MouseDown
        Dim lvItem As ListViewItem
        current = lvwDevices.SelectedItems(0).Index

        lvItem = lvwDevices.GetItemAt(e.X, e.Y)
        If e.Button = MouseButtons.Right And Not IsNothing(lvItem) Then
            Dim dev As Device = devicelist(lvItem.Index)
            mnuUpdate.Enabled = True
            If dev.Type = DeviceType.Internal Or dev.Type = DeviceType.Removable Then
                mnuRemoveVirtual.Enabled = False
            Else
                mnuRemoveVirtual.Enabled = True
            End If
            mnuDevices.Show(CType(sender, ListView), New Point(e.X, e.Y))
        ElseIf e.Button = MouseButtons.Right And IsNothing(lvItem) Then
            mnuRemoveVirtual.Enabled = False
            mnuUpdate.Enabled = False
            mnuDevices.Show(CType(sender, ListView), New Point(e.X, e.Y))
        End If
    End Sub

    Private Sub lvwDevices_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvwDevices.MouseUp
        Dim lvItem As ListViewItem

        lvItem = lvwDevices.GetItemAt(e.X, e.Y)
        If IsNothing(lvItem) Then
            loadnow = False
            lvwDevices.Items(current).Selected = True
            loadnow = True
        End If
    End Sub

    Private Sub lvwDevices_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvwDevices.ItemSelectionChanged
        If isloading Then Exit Sub
        If e.IsSelected And loadnow And Not Me.ResizeRedraw Then

            GeometryAndPartitions()
            PopulateAll()

            Dim dev As Device = devicelist(e.ItemIndex)

            If dev.SmartEnabled = Support.Enabled Then
                gbAdvanced.Enabled = True
            Else
                gbAdvanced.Enabled = False
                If gbAdvanced.Checked Then
                    gbMain_Click(gbMain, System.EventArgs.Empty)
                    gbMain.Checked = True
                End If
            End If

            If dev.TestIsRunnig Then
                pnlProgress.Visible = True
                flwTest.Enabled = False
                btnRun.Enabled = False
                tmrTest.Start()
            Else
                pnlProgress.Visible = False
                flwTest.Enabled = True
                btnRun.Enabled = True
                tmrTest.Stop()
            End If
        End If
    End Sub
#End Region

#Region "Devices list context menu"

    Private Sub mnuRemoveVirtual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuRemoveVirtual.Click
        Dim virtualfolder As String = My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData _
                                      .Substring(0, My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData.LastIndexOf("\")) _
                                      & "\Virtual devices\"
        Dim i As Short = lvwDevices.SelectedItems(0).Index

        With lvwDevices
            .Items(i).Remove()
            .Groups(2).Header = .Groups(2).Tag & " - " & .Groups(2).Items.Count
            .Items(i - 1).Selected = True
            .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
            .Columns(0).Width = .ClientSize.Width - .Columns(1).Width
        End With
        File.Delete(virtualfolder & devicelist(i).Model.Replace("/", "") & "_" & devicelist(i).SerialNumber.Replace("/", "") & ".vd")
        devicelist.RemoveAt(i)
        oldvitals.RemoveAt(i)
        newvitals.RemoveAt(i)
    End Sub

    Private Sub mnuAddVirtual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAddVirtual.Click
        AddVirtual.ShowDialog(Me)
        UpdateCurrent()

        Memory.FlushMemory()
    End Sub

    Private Sub mnuUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuUpdate.Click
        UpdateCurrent()

        Memory.FlushMemory()
    End Sub

    Private Sub mnuUpdateAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuUpdateAll.Click
        UpdateDevicesDB()
        CheckForUpdates()
        UpdateAll(DeviceType.Internal)
        UpdateAll(DeviceType.Removable)
        UpdateAll(DeviceType.Virtual)

        Memory.FlushMemory()
    End Sub

    Private Sub mnuRescanExternal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuRescanExternal.Click, mnuRescanRemovable.Click
        UsbDevicesComparison()
        eSataDevicesComparison()

        Memory.FlushMemory()
    End Sub

#End Region

#Region "Tray icon"
    Private Sub niTrayIcon_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles niTrayIcon.MouseDown
        Select Case e.Button
            Case Windows.Forms.MouseButtons.Left
                'restore main screen
                Me.WindowState = FormWindowState.Normal
                Me.ShowInTaskbar = True
                Me.Visible = True
                Me.Activate()
                niTrayIcon.Visible = My.Settings.AlwaysShowTrayIcon
            Case Windows.Forms.MouseButtons.Middle
                'if is pressed the middle button refresh all devices
                UpdateAll(DeviceType.Internal)
                UpdateAll(DeviceType.Removable)
                UpdateAll(DeviceType.Virtual)
            Case Windows.Forms.MouseButtons.Right
                'none. Automatically shows trayicon context menu
        End Select
    End Sub
#End Region

#Region "Timers"
    Private Sub RefreshNonRemovalbe(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefresh.Tick
        UpdateDevicesDB()
        CheckForUpdates()
        UpdateAll(DeviceType.Internal)
    End Sub

    Private Sub RefreshRemovable(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefreshExt.Tick
        UpdateAll(DeviceType.Removable)
    End Sub

    Private Sub RefreshVirtual(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefreshVirtual.Tick
        UpdateAll(DeviceType.Virtual)
    End Sub
#End Region

#Region "Tray icon context menu"
    Private Sub DevRefresh(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuRefresh.Click
        UpdateDevicesDB()
        CheckForUpdates()
        UpdateAll(DeviceType.Internal)
        UpdateAll(DeviceType.Removable)
        UpdateAll(DeviceType.Virtual)

        Memory.FlushMemory()
    End Sub

    Private Sub mnuRestore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuRestore.Click
        If Me.WindowState = FormWindowState.Minimized Then
            Me.Size = New Size(757, 460)
            Me.WindowState = FormWindowState.Normal
            Me.ShowInTaskbar = True
            Me.Visible = True
            Me.Activate()
            niTrayIcon.Visible = My.Settings.AlwaysShowTrayIcon
        End If
    End Sub

    Private Sub ExitProgram(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        Dim confirm As MsgBoxResult
        If My.Settings.ConfirmOnExit Then
            confirm = MsgBox(m_exitmsg, MsgBoxStyle.OkCancel + MsgBoxStyle.Exclamation, m_exit)
            If confirm = MsgBoxResult.Cancel Then Exit Sub
        End If

        DestroyTrayIcons()
        niTrayIcon.Visible = False
        Me.Dispose()
        End
    End Sub
#End Region

#Region "Summary"
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        UpdateCurrent()
    End Sub

    Private Sub btnDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetails.Click
        gbAdvanced_Click(gbAdvanced, System.EventArgs.Empty)
        gbAdvanced.Checked = True
        tabAdvanced.SelectedTab = tpAttributes
    End Sub

    Private Sub btnRunTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRunTest.Click
        gbAdvanced_Click(gbAdvanced, System.EventArgs.Empty)
        gbAdvanced.Checked = True
        tabAdvanced.SelectedTab = tpRunTest
    End Sub
#End Region

#Region "Enable/disable features"
    Private Sub pbSmart_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles picSmart.Click
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Then Exit Sub

        Select Case dev.SmartEnabled
            Case Support.Enabled
                Dim qst As MsgBoxResult = MsgBox(m_qdisablesmart.Replace("%", dev.Model), MsgBoxStyle.YesNo + MsgBoxStyle.Question, m_question)
                If qst = MsgBoxResult.Yes Then
                    dev.SetSmartStatus(SmartFeature.Disable)
                    dev.Update()
                    picSmart.Image = My.Resources.switch_off
                    MsgBox(m_smartdisabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                End If
            Case Support.Disabled
                dev.SetSmartStatus(SmartFeature.Enable)
                dev.Update()
                Select Case dev.SmartEnabled
                    Case Support.Enabled
                        MsgBox(m_smartenabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                        picSmart.Image = My.Resources.switch_on
                    Case Support.Ambiguous
                        MsgBox(m_smartambiguous.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, m_message)
                        picSmart.Image = My.Resources.switch_off
                    Case Support.Disabled
                        MsgBox(m_smartnotsupported.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, m_message)
                        picSmart.Image = My.Resources.switch_off
                End Select
        End Select
    End Sub

    Private Sub pbOfflineTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picOfflineTest.Click
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Then Exit Sub

        Select Case dev.OfflineCollectionStatus
            Case Support.Disabled
                dev.SetOfflineCollectionStatus(SmartFeature.Enable)
                dev.Update()
                txtReport.Text = dev.Output
                Select Case dev.OfflineCollectionStatus
                    Case Support.Enabled
                        MsgBox(m_offldataenabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                        picOfflineTest.Image = My.Resources.switch_on
                    Case Support.Disabled
                        MsgBox(m_offldatanotsupported.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, m_message)
                        picOfflineTest.Image = My.Resources.switch_off
                End Select
            Case Support.Enabled
                Dim qst As MsgBoxResult = MsgBox(m_qdisableoffldata.Replace("%", dev.Model), MsgBoxStyle.YesNo + MsgBoxStyle.Question, m_question)
                If qst = MsgBoxResult.Yes Then
                    dev.SetOfflineCollectionStatus(SmartFeature.Disable)
                    dev.Update()
                    If dev.OfflineCollectionStatus = Support.Disabled Then
                        picOfflineTest.Image = My.Resources.switch_off
                        MsgBox(m_offldatadisabled.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                    ElseIf dev.OfflineCollectionStatus = Support.Enabled Then
                        picOfflineTest.Image = My.Resources.switch_on
                        MsgBox(m_unabletodisable.Replace("%", dev.Model), MsgBoxStyle.OkOnly + MsgBoxStyle.Information, m_message)
                    End If
                End If
        End Select

        PopulateCapabilities()
    End Sub

    Private Sub pbAttrAutosave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picAttrAutosave.Click
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Then Exit Sub

        Debug.Print(picAttrAutosave.Tag)

        If picAttrAutosave.Tag = "on" Then
            picAttrAutosave.Image = My.Resources.switch_off
            picAttrAutosave.Tag = ""
        Else
            picAttrAutosave.Image = My.Resources.switch_on
            picAttrAutosave.Tag = "on"
        End If

        If installdevice = StoringDevice.Fixed Then
            SaveDeviceSettings()
        Else
            dev.Options = "-S on"
        End If

    End Sub

    Private Sub pbTrayIcon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picTrayIcon.Click
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Then Exit Sub

        If dev.ShowTrayIcon = False Then
            dev.ShowTrayIcon = True
            picTrayIcon.Image = My.Resources.switch_on
        Else
            dev.ShowTrayIcon = False
            picTrayIcon.Image = My.Resources.switch_off
        End If

        SaveMonitoringSettings()
        DestroyTrayIcons()
        SetTrayIcons()
    End Sub

    Private Sub pbShareOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picShareOutput.Click
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        If dev.Type = DeviceType.Virtual Then Exit Sub

        If dev.IsShared = False Then
            dev.IsShared = True
            picShareOutput.Image = My.Resources.switch_on
        Else
            dev.IsShared = False
            picShareOutput.Image = My.Resources.switch_off
        End If

        SaveMonitoringSettings()
    End Sub

    Private Sub lnkSetFolder_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkSetFolder.LinkClicked
        gbSettings_Click(gbSettings, System.EventArgs.Empty)
        gbSettings.Checked = True
        tabSettings.SelectedTab = tpShare
    End Sub
#End Region

#Region "Log events"
    'log events are all stored into "LogEvents.vb"
#End Region

#Region "SMART attributes"

    Private Sub CatchAttributeInfo(ByVal itemname As String, ByVal type As String, ByVal update As String)
        Dim haveinfo As Boolean = False
        Dim family As String = devicelist(lvwDevices.SelectedItems(0).Index).Family

        'SSD devices
        If family.StartsWith("Crucial/Micron") Then
            With apAttributes
                For i As Short = 0 To m_MicronMeanings.Count - 1
                    If m_MicronMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_MicronMeanings(i).Name, _
                                 m_MicronMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("SandForce") Then
            With apAttributes
                For i As Short = 0 To m_SandForceMeanings.Count - 1
                    If m_SandForceMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_SandForceMeanings(i).Name, _
                                 m_SandForceMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next

            End With
        ElseIf family.StartsWith("Indilinx") Then
            With apAttributes
                For i As Short = 0 To m_IndilinxMeanings.Count - 1
                    If m_IndilinxMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_IndilinxMeanings(i).Name, _
                                 m_IndilinxMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("Intel") Or family.StartsWith("Kingston") Then 'some Intel SSDs are branded Kingston
            With apAttributes
                For i As Short = 0 To m_IntelMeanings.Count - 1
                    If m_IntelMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_IntelMeanings(i).Name, _
                                 m_IntelMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("JMicron") Then
            With apAttributes
                For i As Short = 0 To m_JMicronMeanings.Count - 1
                    If m_JMicronMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_JMicronMeanings(i).Name, _
                                 m_JMicronMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("Samsung based SSDs") Then
            With apAttributes
                For i As Short = 0 To m_SamsungMeanings.Count - 1
                    If m_SamsungMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_SamsungMeanings(i).Name, _
                                 m_SamsungMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        ElseIf family.StartsWith("SMART") Then
            With apAttributes
                For i As Short = 0 To m_SmartMeanings.Count - 1
                    If m_SmartMeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_SmartMeanings(i).Name, _
                                 m_SmartMeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        Else 'HDD
            With apAttributes
                For i As Short = 0 To m_attributesmeanings.Count - 1
                    If m_attributesmeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_attributesmeanings(i).Name, _
                                 m_attributesmeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End With
        End If

        With apAttributes
            If haveinfo = False Then
                For i As Short = 0 To m_attributesmeanings.Count - 1
                    If m_attributesmeanings(i).SmartctlName = itemname Then
                        .SetInfo(m_attributesmeanings(i).Name, _
                                 m_attributesmeanings(i).Description, _
                                 type, update)
                        haveinfo = True
                        Exit For
                    End If
                Next
            End If
            If haveinfo = False Then
                .SetInfo(m_attributesmeanings(0).Name, _
                         m_attributesmeanings(0).Description, _
                         type, update)
            End If
        End With
    End Sub

    Private Sub lvwSmart_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwSmart.Enter
        Dim itemname As String = ""
        Dim type As String = ""
        Dim update As String = ""
        Dim flags As AttributeFlags


        If lvwSmart.SelectedItems.Count > 0 Then
            With lvwSmart.SelectedItems(0)
                FlagsPanel1.GetFlags(.SubItems(0).Tag)
                ValuesPanel1.SetProgressBarsValues(Val(.SubItems(5).Text), Val(.SubItems(3).Text), Val(.SubItems(4).Text))
                itemname = .SubItems(2).Text
                flags = .SubItems(0).Tag
                If flags.HasFlag(AttributeFlags.UpdatedOnline) Then Update = m_always Else Update = m_offline
                If flags.HasFlag(AttributeFlags.Prefailure) Then Type = m_prefail Else Type = m_oldage
            End With

            CatchAttributeInfo(itemname, type, update)
        End If
    End Sub

    Private Sub lvwSmart_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwSmart.Leave
        apAttributes.SetInfo(m_tip, m_tiptext, "", "")
        FlagsPanel1.Reset()
        ValuesPanel1.SetProgressBarsValues(0, 0, 0)
    End Sub
    Private Sub lvwSmart_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwSmart.SelectedIndexChanged
        Dim itemname As String = ""
        Dim type As String = ""
        Dim update As String = ""
        Dim flags As AttributeFlags
        Dim haveinfo As Boolean = False

        If lvwSmart.SelectedItems.Count > 0 Then
            With lvwSmart.SelectedItems(0)
                FlagsPanel1.GetFlags(.SubItems(0).Tag)
                ValuesPanel1.SetProgressBarsValues(Val(.SubItems(5).Text), Val(.SubItems(3).Text), Val(.SubItems(4).Text))
                itemname = .SubItems(2).Text
                flags = .SubItems(0).Tag
                If flags.HasFlag(AttributeFlags.UpdatedOnline) Then update = m_always Else update = m_offline
                If flags.HasFlag(AttributeFlags.Prefailure) Then type = m_prefail Else type = m_oldage
            End With

            CatchAttributeInfo(itemname, type, update)
        End If
    End Sub

    Private Sub lnkShowInfo_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkShowInfo.LinkClicked
        If lvwSmart.Width = 360 Then
            apAttributes.Visible = False
            lvwSmart.Width = 560
        Else
            apAttributes.Visible = True
            lvwSmart.Width = 360
        End If
    End Sub
#End Region

#Region "Smart error log"
    Private Sub Error_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
            Handles optError1.CheckedChanged, optError2.CheckedChanged, optError3.CheckedChanged, _
            optError4.CheckedChanged, optError5.CheckedChanged
        Try
            Dim err As Short = Val(sender.Name.ToString.Substring(8, 1))
            DisplayATAError(err)
        Catch
        End Try
    End Sub
#End Region

#Region "Run test"
    Private Sub cboTest_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTest.SelectedIndexChanged
        lblTestInfo.Text = m_tests(cboTest.SelectedIndex).Info
        pnlProgress.Visible = False
        btnRun.Visible = True

        If lvwDevices.SelectedItems.Count > 0 Then
            Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
            Select Case cboTest.SelectedIndex
                Case 0
                    lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.OfflineData
                Case 1
                    lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ShortTest
                Case 2
                    lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ExtendedTest
                Case 3
                    lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ConveyanceTest
            End Select
        End If

        If lblDuration.Text.Contains("N/A") Then btnRun.Visible = False
    End Sub

    Private Sub btnRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRun.Click
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        Select Case cboTest.SelectedIndex
            Case 0 'offline data collection
                dev.RunTest(TestType.Offline)
            Case 1 'short test
                dev.RunTest(TestType.ShortTest)
            Case 2 'extended test
                dev.RunTest(TestType.LongTest)
            Case 3 'conveyance test
                dev.RunTest(TestType.Conveyance)
        End Select

        flwTest.Enabled = False
        btnRun.Enabled = False
        prbTestProgress.Value = 0
        prbTestProgress.Maximum = dev.TestTiming.Duration
        lblProgress.Text = "0%"
        lblExtimatedEnd.Text = lblExtimatedEnd.Tag & dev.TestTiming.Conclusion
        btnStop.Enabled = True
        pnlProgress.Visible = True
        tmrTest.Start()
    End Sub

    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        Dim response As MsgBoxResult = MsgBox(m_abortmsg, MsgBoxStyle.Question + MsgBoxStyle.YesNo, m_aborttitle)
        If response = MsgBoxResult.Yes Then
            Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
            dev.RunTest(TestType.Abort)
        End If
    End Sub

    Private Sub tmrTest_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrTest.Tick
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        If dev.TestIsRunnig Then
            Dim span As TimeSpan = Now - dev.TestTiming.Start
            If span.TotalSeconds <= dev.TestTiming.Duration Then
                prbTestProgress.Maximum = dev.TestTiming.Duration
                prbTestProgress.Value = span.TotalSeconds
                lblProgress.Text = span.TotalSeconds * 100 \ dev.TestTiming.Duration & "%"
            Else
                UpdateAll(DeviceType.Internal)
                UpdateAll(DeviceType.Removable)
                pnlProgress.Visible = False
                prbTestProgress.Value = 0
                flwTest.Enabled = True
                btnRun.Enabled = True
                dev.TestIsRunnig = False
                tmrTest.Stop()
            End If
        End If
    End Sub
#End Region

#Region "Database"
    'no more available from version 0.3.0
    'Private Sub cboDatabase_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDatabase.SelectedIndexChanged
    '    ShowDbEntryDetails()
    'End Sub
#End Region

#Region "Device output"
    Private Sub btnSaveOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveOutput.Click
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        Dim savedialog As New SaveFileDialog
        Dim res As DialogResult

        savedialog.DefaultExt = "txt"
        savedialog.AddExtension = True
        savedialog.Filter = "*.txt|*.txt"
        savedialog.FileName = dev.Model & "_" & dev.SerialNumber
        res = savedialog.ShowDialog(Me)
        If res = DialogResult.OK Then
            File.WriteAllText(savedialog.FileName, txtReport.Text)
        End If
    End Sub
#End Region

#Region "Smartctl remap"
    Dim isloading_devsettings As Boolean = False

#Region "Tolerance"
    Private Sub chkTolerance_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTolerance.CheckedChanged
        pnlTolerance.Visible = chkTolerance.Checked
        If Not pnlTolerance.Enabled Then cboTolerance.SelectedIndex = 0
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

    Private Sub cboTolerance_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTolerance.SelectedIndexChanged
        ttMain.SetToolTip(picTolerance, m_tolerance(cboTolerance.SelectedIndex + 1))
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub
#End Region

#Region "Attributes remap"
    Private Sub chkAttributes_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAttributes.CheckedChanged
        pnlAttributes.Visible = chkAttributes.Checked
        btnRemove.Enabled = False
        If Not pnlAttributes.Enabled Then
            cboAttributes.SelectedIndex = 0
            cboID.SelectedIndex = 0
            cboFormat.SelectedIndex = 0
            txtName.Text = ""
            btnAdd.Enabled = False
            lvwAttrFormat.Items.Clear()
        End If
        If chkAttributes.Checked = False Then
            SaveDeviceSettings()
        End If
    End Sub

    Private Sub cboAttributes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboAttributes.SelectedIndexChanged
        Dim cboBox As ComboBox = sender

        picAttributes.Visible = True
        If cboAttributes.SelectedIndex > 0 Then
            ttMain.SetToolTip(picAttributes, m_attributes(cboAttributes.SelectedIndex))
        End If

        Select Case cboBox.SelectedIndex
            Case 0
                cboID.SelectedIndex = 0
                cboFormat.SelectedIndex = 0
                txtName.Text = ""
                picAttributes.Visible = False
            Case 1
                cboID.SelectedIndex = 10
                cboFormat.SelectedIndex = 10
                txtName.Text = "Power_On_Minutes"
            Case 2
                cboID.SelectedIndex = 10
                cboFormat.SelectedIndex = 11
                txtName.Text = "Power_On_Seconds"
            Case 3
                cboID.SelectedIndex = 10
                cboFormat.SelectedIndex = 12
                txtName.Text = "Power_On_Half_Minutes"
            Case 4
                cboID.SelectedIndex = 10
                cboFormat.SelectedIndex = 13
                txtName.Text = "Temperature_Celsius"
            Case 5
                cboID.SelectedIndex = 193
                cboFormat.SelectedIndex = 6
                txtName.Text = "Emerg_Retract_Cycle_Ct"
            Case 6
                cboID.SelectedIndex = 194
                cboFormat.SelectedIndex = 5
                txtName.Text = "Load-Unload_Cycle_Count"
            Case 7
                cboID.SelectedIndex = 195
                cboFormat.SelectedIndex = 14
                txtName.Text = "Temperature_Celsius_x10"
            Case 8
                cboID.SelectedIndex = 195
                cboFormat.SelectedIndex = 6
                txtName.Text = "Unknown_Attribute"
            Case 9
                cboID.SelectedIndex = 198
                cboFormat.SelectedIndex = 6
                txtName.Text = "Total_Pending_Sectors"
            Case 10
                cboID.SelectedIndex = 199
                cboFormat.SelectedIndex = 6
                txtName.Text = "Total_Offl_Uncorrectabl"
            Case 11
                cboID.SelectedIndex = 199
                cboFormat.SelectedIndex = 6
                txtName.Text = "Offline_Scan_UNC_SectCt"
            Case 12
                cboID.SelectedIndex = 201
                cboFormat.SelectedIndex = 6
                txtName.Text = "Write_Error_Count"
            Case 13
                cboID.SelectedIndex = 202
                cboFormat.SelectedIndex = 6
                txtName.Text = "Detected_TA_Count"
            Case 14
                cboID.SelectedIndex = 221
                cboFormat.SelectedIndex = 6
                txtName.Text = "Temperature_Celsius"
        End Select
        If cboID.SelectedIndex > 0 Then cboID.Enabled = False Else cboID.Enabled = True
        If cboFormat.SelectedIndex > 0 Then cboFormat.Enabled = False Else cboFormat.Enabled = True
        If txtName.Text.Length > 0 Then txtName.Enabled = False Else txtName.Enabled = True

        btnAdd.Enabled = ValidateEntries()
    End Sub

    Private Sub cboFormat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFormat.SelectedIndexChanged
        If cboFormat.SelectedIndex = 0 Then
            picAttrFormat.Visible = False
        Else
            picAttrFormat.Visible = True
            ttMain.SetToolTip(picAttrFormat, m_formats(cboFormat.SelectedIndex))
        End If
    End Sub

    Private Sub cboID_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboID.SelectedIndexChanged
        Dim cboBox As ComboBox = sender

        Select Case cboBox.SelectedItem.ToString
            Case ""
                cboFormat.SelectedIndex = 0
            Case "3"
                cboFormat.SelectedIndex = 3
            Case "5"
                cboFormat.SelectedIndex = 4
            Case "190"
                cboFormat.SelectedIndex = 13
            Case "194"
                cboFormat.SelectedIndex = 13
            Case "196"
                cboFormat.SelectedIndex = 4
            Case Else
                cboFormat.SelectedIndex = 6
        End Select
        btnAdd.Enabled = ValidateEntries()
    End Sub

    Private Sub txtName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtName.KeyPress
        Select Case e.KeyChar.ToString
            Case "-", "a" To "z", "A" To "Z", "0" To "9", "_", ControlChars.Back.ToString
                'accept ONLY letters, numbers, undescores, lines and backspaces (for editing) digits;
                'arrow keys and cancel key is also accepted by textbox.
            Case Else
                'discard all the others digits.
                e.KeyChar = ""
        End Select
    End Sub

    Private Function ValidateEntries() As Boolean
        If cboFormat.SelectedIndex = 0 Or cboID.SelectedIndex = 0 Then Return False Else Return True
    End Function

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        With lvwAttrFormat
            .Items.Add(cboID.Text)
            .Items(.Items.Count - 1).SubItems.Add(cboFormat.Text)
            .Items(.Items.Count - 1).SubItems.Add(txtName.Text)
        End With
        btnRemove.Enabled = False
        SaveDeviceSettings()
    End Sub

    Private Sub lvwAttrFormat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwAttrFormat.SelectedIndexChanged
        If lvwAttrFormat.SelectedItems.Count > 0 Then btnRemove.Enabled = True
    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        lvwAttrFormat.SelectedItems(0).Remove()
        btnRemove.Enabled = False
        SaveDeviceSettings()
    End Sub
#End Region

#Region "Firmware debug"
    Private Sub chkFirmware_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFirmware.CheckedChanged
        pnlFirmware.Visible = chkFirmware.Checked
        If Not pnlFirmware.Enabled Then
            cboFirmware.SelectedIndex = 0
            chkFixSwap.Checked = False
        End If
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub

    Private Sub cboFirmware_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFirmware.SelectedIndexChanged
        ttMain.SetToolTip(picFirmware, m_firmware(cboFirmware.SelectedIndex + 1))
        If Not isloading_devsettings Then SaveDeviceSettings()
    End Sub
#End Region
#End Region

#Region "General settings tab"
    Dim isloading_settings As Boolean = True

#Region "Look n' feel"
    Private Sub chkStartupLink_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkStartupLink.CheckedChanged
        If chkStartupLink.Checked Then
            If Not ShortcutExists() Then CreateShortcut()
        Else
            DeleteShortcut()
        End If
    End Sub

    Private Sub look_n_feel(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        chkRunMinimized.CheckedChanged, chkMinimizeInTray.CheckedChanged, chkCloseOnTray.CheckedChanged, _
        chkAlwaysShowTray.CheckedChanged, chkConfirmExit.CheckedChanged
        If Not isloading_settings Then SaveSettings()
        niTrayIcon.Visible = chkAlwaysShowTray.Checked
    End Sub
#End Region

#Region "Update"
    Private Sub numUpdate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles numUpdate.ValueChanged
        If Not isloading_settings Then SaveSettings()
        tmrRefresh.Interval = numUpdate.Value * 60 * 1000
        tmrRefresh.Enabled = True
    End Sub

    Private Sub numUpdateExt_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles numUpdateExt.ValueChanged
        If Not isloading_settings Then SaveSettings()
        tmrRefreshExt.Interval = numUpdateExt.Value * 60 * 1000
        tmrRefreshExt.Enabled = True
    End Sub

    Private Sub numUpdateVirtual_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles numUpdateVirtual.ValueChanged
        If Not isloading_settings Then SaveSettings()
        tmrRefreshVirtual.Interval = numUpdateVirtual.Value * 60 * 1000
        tmrRefreshVirtual.Enabled = True
    End Sub
#End Region

#Region "Monitoring"
    Private Sub lnkInvertSel_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkInvertSel.Click
        'this is a trick: setting to true the variable 'isloading_settings',
        'prevent a multiple writing of the settings file!
        isloading_settings = True

        chkReallEvCt.Checked = Not chkReallEvCt.Checked
        chkReallSectCt.Checked = Not chkReallSectCt.Checked
        chkSoftReadErr.Checked = Not chkSoftReadErr.Checked
        chkSpinRetryCt.Checked = Not chkSpinRetryCt.Checked
        chkTemp.Checked = Not chkTemp.Checked
        chkCurPenSect.Checked = Not chkCurPenSect.Checked
        chkOfflUnc.Checked = Not chkOfflUnc.Checked
        chkDiskShift.Checked = Not chkDiskShift.Checked

        SaveSettings()
        isloading_settings = False
    End Sub

    Private Sub lnkInvertSelSSD_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkInvertSelSSD.Click
        'this is a trick: setting to true the variable 'isloading_settings',
        'prevent a multiple writing of the settings file!
        isloading_settings = True

        chkIndilinx.Checked = Not chkIndilinx.Checked
        chkIntel.Checked = Not chkIntel.Checked
        chkMicron.Checked = Not chkMicron.Checked
        chkSamsung.Checked = Not chkSamsung.Checked
        chkSandForce.Checked = Not chkSandForce.Checked

        SaveSettings()
        isloading_settings = False
    End Sub

    Private Sub monitoring(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        chkReallEvCt.CheckedChanged, chkReallSectCt.CheckedChanged, chkSoftReadErr.CheckedChanged, _
        chkSpinRetryCt.CheckedChanged, chkTemp.CheckedChanged, chkCurPenSect.CheckedChanged, _
        chkOfflUnc.CheckedChanged, chkDiskShift.CheckedChanged, chkIndilinx.CheckedChanged, _
        chkIntel.CheckedChanged, chkMicron.CheckedChanged, chkSamsung.CheckedChanged, chkSandForce.CheckedChanged

        If Not isloading_settings Then SaveSettings()
    End Sub
#End Region

#Region "Warnings"
    Private Sub warnings(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        chkFailure.CheckedChanged, chkTempThresh.CheckedChanged, chkParamChng.CheckedChanged

        If Not isloading_settings Then SaveSettings()
    End Sub
#End Region

#Region "Sharing"
    Private Sub btnBrwsFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrwsFolder.Click
        With dlgFolder
            .Description = lblSelFolder.Text
            Dim result As DialogResult = .ShowDialog(Me)
            If result = DialogResult.OK Then
                lblFolder.Text = .SelectedPath
                lblFolder.Visible = True
                picShareOutput.Enabled = True
                Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
                If dev.IsShared Then
                    picShareOutput.Image = My.Resources.switch_on
                Else
                    picShareOutput.Image = My.Resources.switch_off
                End If
                SaveSettings()
            End If
        End With
    End Sub

    Private Sub chkXml_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkXml.CheckedChanged
        btnXml.Enabled = chkXml.Checked
        If Not isloading_settings Then SaveSettings()
    End Sub

    Private Sub btnXml_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXml.Click
        With dlgFolder
            .Description = lblXml.Text
            Dim result As DialogResult = .ShowDialog(Me)
            If result = DialogResult.OK Then
                lblXmlPath.Text = .SelectedPath
                lblXmlPath.Visible = True
                SaveSettings()
            End If
        End With
    End Sub
#End Region

#Region "Reliability"
    Private Sub chkRating_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRating.CheckedChanged
        chkTuneUp.Enabled = chkRating.Checked
        If Not isloading_settings Then SaveSettings()

        If chkRating.Checked Then
            If Not isloading_settings Then SetRating()
        Else
            picStars.Image = Nothing
        End If
    End Sub

    Private Sub chkTuneUp_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTuneUp.CheckedChanged
        tlpTuneUp.Enabled = chkTuneUp.Checked
        If Not isloading_settings Then SaveSettings()
    End Sub

    Private Sub TunersValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        numErrors.ValueChanged, numCurPend.ValueChanged, numOfflUnc.ValueChanged
        On Error Resume Next
        SetRating()
        SetReliabilityDetails()
        If Not isloading_settings Then SaveSettings()
    End Sub

    Private Sub Reset(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkResetErrors.LinkClicked, lnkResetCurPend.LinkClicked, lnkResetOfflUnc.LinkClicked
        Select Case sender.Name
            Case lnkResetErrors.Name
                numErrors.Value = numErrors.Tag
            Case lnkResetCurPend.Name
                numCurPend.Value = numCurPend.Tag
            Case lnkResetOfflUnc.Name
                numOfflUnc.Value = numOfflUnc.Tag
        End Select
    End Sub

#End Region
#End Region

#Region "Links"
    Private Sub TextLinks(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        lnkBrandsOfTheWorld.Click, lnkFamFamFam.Click, lnkKamiyamane.Click, lnkPremiumPixels.Click, _
        lnkSmartMonTools.Click, lnkWesternDigital.Click, lnkGnomeGit.Click, lnkCoolerMaster.Click
        Try
            System.Diagnostics.Process.Start(sender.Text)
        Catch
        End Try
    End Sub

    Private Sub TagLinks(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
         lnkGpl.Click, lnkCcBy.Click, lnkGnome.Click, lnkGplGnome.Click, picVersion.Click, _
         lnkHddGuardian.Click, lnkGroup.Click, lnkEmail.Click, lnkUpdate.Click, lnkPlus.Click
        Try
            System.Diagnostics.Process.Start(sender.Tag)
        Catch
        End Try
    End Sub
#End Region

#Region "Online help"
    Private Sub picHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picHelp.Click
        Try
            System.Diagnostics.Process.Start(sender.Tag)
        Catch
        End Try
    End Sub

    Private Sub tabSettings_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabSettings.SelectedIndexChanged
        picHelp.Tag = tabSettings.SelectedTab.Tag
    End Sub

    Private Sub tabAdvanced_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabAdvanced.SelectedIndexChanged
        picHelp.Tag = tabAdvanced.SelectedTab.Tag
    End Sub

    Private Sub tabSmartctl_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabSmartctl.SelectedIndexChanged
        picHelp.Tag = tabSmartctl.SelectedTab.Tag
    End Sub

    Private Sub tabMain_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabMain.SelectedIndexChanged
        picHelp.Tag = tabMain.SelectedTab.Tag
    End Sub
#End Region

    Private Sub picStars_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picStars.Click
        If gbAdvanced.Enabled Then
            gbAdvanced_Click(gbAdvanced, System.EventArgs.Empty)
            gbAdvanced.Checked = True
            tabAdvanced.SelectedTab = tpReliability
        End If
    End Sub
End Class
