﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim flwButtons As System.Windows.Forms.FlowLayoutPanel
        Dim tlpMenu As System.Windows.Forms.TableLayoutPanel
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Dim picLeft As System.Windows.Forms.PictureBox
        Dim picRight As System.Windows.Forms.PictureBox
        Dim tlpDatabase As System.Windows.Forms.TableLayoutPanel
        Dim flwOutput As System.Windows.Forms.FlowLayoutPanel
        Dim pnlDatabase As System.Windows.Forms.Panel
        Dim flwShare As System.Windows.Forms.FlowLayoutPanel
        Dim ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
        Dim ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
        Dim ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
        Dim pnlTopInfo As System.Windows.Forms.Panel
        Dim tlpSummary As System.Windows.Forms.TableLayoutPanel
        Dim pnlInfobox As System.Windows.Forms.Panel
        Dim tpAbout As System.Windows.Forms.TabPage
        Dim tlpContacts As System.Windows.Forms.TableLayoutPanel
        Dim picOSI As System.Windows.Forms.PictureBox
        Dim picLicense As System.Windows.Forms.PictureBox
        Dim picLogo As System.Windows.Forms.PictureBox
        Dim tpCredits As System.Windows.Forms.TabPage
        Dim Label11 As System.Windows.Forms.Label
        Dim Label5 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Label12 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label14 As System.Windows.Forms.Label
        Dim Label13 As System.Windows.Forms.Label
        Dim Label24 As System.Windows.Forms.Label
        Dim Label1 As System.Windows.Forms.Label
        Dim Label21 As System.Windows.Forms.Label
        Dim Label23 As System.Windows.Forms.Label
        Dim Label22 As System.Windows.Forms.Label
        Dim Label33 As System.Windows.Forms.Label
        Dim tpLicense As System.Windows.Forms.TabPage
        Dim Label6 As System.Windows.Forms.Label
        Dim Label7 As System.Windows.Forms.Label
        Dim Label8 As System.Windows.Forms.Label
        Dim Label9 As System.Windows.Forms.Label
        Dim Label10 As System.Windows.Forms.Label
        Dim pnlRefresh As System.Windows.Forms.Panel
        Dim tlpParameters As System.Windows.Forms.TableLayoutPanel
        Dim tlpSSD As System.Windows.Forms.TableLayoutPanel
        Dim flwMonitoring As System.Windows.Forms.FlowLayoutPanel
        Dim flwXml As System.Windows.Forms.FlowLayoutPanel
        Dim ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
        Dim ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
        Dim tlpReliability As System.Windows.Forms.TableLayoutPanel
        Dim lblHDD As System.Windows.Forms.Label
        Dim Label16 As System.Windows.Forms.Label
        Dim ListViewGroup1 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("Phisycal", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewGroup2 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("External", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewGroup3 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("Virtual", System.Windows.Forms.HorizontalAlignment.Left)
        Me.btnRunTest = New System.Windows.Forms.Button()
        Me.btnDetails = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.picLanguageFlag = New System.Windows.Forms.PictureBox()
        Me.gbAbout = New hdd_guardian.GraphicalButton()
        Me.gbSmartctl = New hdd_guardian.GraphicalButton()
        Me.gbAdvanced = New hdd_guardian.GraphicalButton()
        Me.gbSettings = New hdd_guardian.GraphicalButton()
        Me.gbMain = New hdd_guardian.GraphicalButton()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblFirmware = New System.Windows.Forms.Label()
        Me.lblFamily = New System.Windows.Forms.Label()
        Me.lblAttrOptions = New System.Windows.Forms.Label()
        Me.lblModelValue = New System.Windows.Forms.Label()
        Me.lblFirmwareValue = New System.Windows.Forms.Label()
        Me.lblFamilyValue = New System.Windows.Forms.Label()
        Me.lblAttrOptionsValue = New System.Windows.Forms.Label()
        Me.lblWarningsValue = New System.Windows.Forms.Label()
        Me.lblOtherOptValue = New System.Windows.Forms.Label()
        Me.lblWarnings = New System.Windows.Forms.Label()
        Me.lblOtherOpt = New System.Windows.Forms.Label()
        Me.btnSaveOutput = New System.Windows.Forms.Button()
        Me.btnBrwsFolder = New System.Windows.Forms.Button()
        Me.lblFolder = New System.Windows.Forms.Label()
        Me.picHelp = New System.Windows.Forms.PictureBox()
        Me.picStars = New System.Windows.Forms.PictureBox()
        Me.picPower = New System.Windows.Forms.PictureBox()
        Me.devPanel = New hdd_guardian.DevicePanel()
        Me.picDeviceImage = New System.Windows.Forms.PictureBox()
        Me.picUsb = New System.Windows.Forms.PictureBox()
        Me.picManufacturer = New System.Windows.Forms.PictureBox()
        Me.picAdmin = New System.Windows.Forms.PictureBox()
        Me.picOsIcon = New System.Windows.Forms.PictureBox()
        Me.picHome = New System.Windows.Forms.PictureBox()
        Me.lnkHddGuardian = New System.Windows.Forms.LinkLabel()
        Me.lnkGroup = New System.Windows.Forms.LinkLabel()
        Me.picEmail = New System.Windows.Forms.PictureBox()
        Me.lnkEmail = New System.Windows.Forms.LinkLabel()
        Me.picGroup = New System.Windows.Forms.PictureBox()
        Me.picPlus = New System.Windows.Forms.PictureBox()
        Me.lnkPlus = New System.Windows.Forms.LinkLabel()
        Me.lblFramework = New System.Windows.Forms.Label()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lblCopyright = New System.Windows.Forms.Label()
        Me.lnkCoolerMaster = New System.Windows.Forms.LinkLabel()
        Me.lnkGnomeGit = New System.Windows.Forms.LinkLabel()
        Me.lnkGnome = New System.Windows.Forms.LinkLabel()
        Me.lnkGplGnome = New System.Windows.Forms.LinkLabel()
        Me.lnkCcBy = New System.Windows.Forms.LinkLabel()
        Me.lnkGpl = New System.Windows.Forms.LinkLabel()
        Me.lnkWesternDigital = New System.Windows.Forms.LinkLabel()
        Me.lnkPremiumPixels = New System.Windows.Forms.LinkLabel()
        Me.lnkSmartMonTools = New System.Windows.Forms.LinkLabel()
        Me.lnkBrandsOfTheWorld = New System.Windows.Forms.LinkLabel()
        Me.lnkFamFamFam = New System.Windows.Forms.LinkLabel()
        Me.lnkKamiyamane = New System.Windows.Forms.LinkLabel()
        Me.lblLicense = New System.Windows.Forms.Label()
        Me.tlpUpdate = New System.Windows.Forms.TableLayoutPanel()
        Me.lblVirtual = New System.Windows.Forms.Label()
        Me.numUpdateVirtual = New System.Windows.Forms.NumericUpDown()
        Me.lblMinutesVirt = New System.Windows.Forms.Label()
        Me.lblExternal = New System.Windows.Forms.Label()
        Me.numUpdateExt = New System.Windows.Forms.NumericUpDown()
        Me.lblMinutesExt = New System.Windows.Forms.Label()
        Me.lblMinutes = New System.Windows.Forms.Label()
        Me.numUpdate = New System.Windows.Forms.NumericUpDown()
        Me.lblInternal = New System.Windows.Forms.Label()
        Me.lblUpdate = New System.Windows.Forms.Label()
        Me.chkReallSectCt = New System.Windows.Forms.CheckBox()
        Me.chkSpinRetryCt = New System.Windows.Forms.CheckBox()
        Me.chkTemp = New System.Windows.Forms.CheckBox()
        Me.chkReallEvCt = New System.Windows.Forms.CheckBox()
        Me.chkCurPenSect = New System.Windows.Forms.CheckBox()
        Me.chkOfflUnc = New System.Windows.Forms.CheckBox()
        Me.chkSoftReadErr = New System.Windows.Forms.CheckBox()
        Me.lnkInvertSel = New System.Windows.Forms.LinkLabel()
        Me.chkDiskShift = New System.Windows.Forms.CheckBox()
        Me.chkIndilinx = New System.Windows.Forms.CheckBox()
        Me.lnkInvertSelSSD = New System.Windows.Forms.LinkLabel()
        Me.chkSandForce = New System.Windows.Forms.CheckBox()
        Me.chkIntel = New System.Windows.Forms.CheckBox()
        Me.chkSamsung = New System.Windows.Forms.CheckBox()
        Me.chkMicron = New System.Windows.Forms.CheckBox()
        Me.lblGeneric = New System.Windows.Forms.Label()
        Me.lblSSD = New System.Windows.Forms.Label()
        Me.lblXml = New System.Windows.Forms.Label()
        Me.btnXml = New System.Windows.Forms.Button()
        Me.lblXmlPath = New System.Windows.Forms.Label()
        Me.lblErrors = New System.Windows.Forms.Label()
        Me.lblReallSect = New System.Windows.Forms.Label()
        Me.lblCurPending = New System.Windows.Forms.Label()
        Me.lblOfflUnc = New System.Windows.Forms.Label()
        Me.lblIndilinx = New System.Windows.Forms.Label()
        Me.lblIntel = New System.Windows.Forms.Label()
        Me.lblMicron = New System.Windows.Forms.Label()
        Me.lblSamsung = New System.Windows.Forms.Label()
        Me.lblSandForce = New System.Windows.Forms.Label()
        Me.picErrors = New System.Windows.Forms.PictureBox()
        Me.picReallSect = New System.Windows.Forms.PictureBox()
        Me.picCurPending = New System.Windows.Forms.PictureBox()
        Me.picOfflUnc = New System.Windows.Forms.PictureBox()
        Me.picIndilinx = New System.Windows.Forms.PictureBox()
        Me.picIntel = New System.Windows.Forms.PictureBox()
        Me.picMicron = New System.Windows.Forms.PictureBox()
        Me.picSamsung = New System.Windows.Forms.PictureBox()
        Me.picSandForce = New System.Windows.Forms.PictureBox()
        Me.lblErrValue = New System.Windows.Forms.Label()
        Me.lblReallSectValue = New System.Windows.Forms.Label()
        Me.lblCurPendingValue = New System.Windows.Forms.Label()
        Me.lblOfflUncValue = New System.Windows.Forms.Label()
        Me.lblIndilinxValue = New System.Windows.Forms.Label()
        Me.lblIntelValue = New System.Windows.Forms.Label()
        Me.lblMicronValue = New System.Windows.Forms.Label()
        Me.lblSamsungValue = New System.Windows.Forms.Label()
        Me.lblSandForceValue = New System.Windows.Forms.Label()
        Me.chkXml = New System.Windows.Forms.CheckBox()
        Me.picVersion = New System.Windows.Forms.PictureBox()
        Me.flwLog = New System.Windows.Forms.FlowLayoutPanel()
        Me.btnDelLog = New System.Windows.Forms.Button()
        Me.btnDelAllLogs = New System.Windows.Forms.Button()
        Me.imlAttr = New System.Windows.Forms.ImageList(Me.components)
        Me.ttMain = New System.Windows.Forms.ToolTip(Me.components)
        Me.mnuTrayIcon = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuRefresh = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRescanRemovable = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRestore = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.niTrayIcon = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.tmrRefresh = New System.Windows.Forms.Timer(Me.components)
        Me.mnuGuide = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDevices = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuUpdate = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUpdateAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRescanExternal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAddVirtual = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRemoveVirtual = New System.Windows.Forms.ToolStripMenuItem()
        Me.tpSelfTests = New System.Windows.Forms.TabPage()
        Me.picAdminSelective = New System.Windows.Forms.PictureBox()
        Me.picAdminSelfTest = New System.Windows.Forms.PictureBox()
        Me.lvwSelective = New System.Windows.Forms.ListView()
        Me.chSpan = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chLbaMin = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chLbaMax = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chCurTestStatus = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lblSelective = New System.Windows.Forms.Label()
        Me.lvwSelfTest = New System.Windows.Forms.ListView()
        Me.chNum = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chTestType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chTestStatus = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chRemaining = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chAge = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chFirstError = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lblSelfTest = New System.Windows.Forms.Label()
        Me.tpErrors = New System.Windows.Forms.TabPage()
        Me.lblErrLogVer = New System.Windows.Forms.Label()
        Me.picAdminError = New System.Windows.Forms.PictureBox()
        Me.flwError = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblPowerOn = New System.Windows.Forms.Label()
        Me.lblDeviceStatus = New System.Windows.Forms.Label()
        Me.lblRegisters = New System.Windows.Forms.Label()
        Me.RegistersPanel1 = New hdd_guardian.RegistersPanel()
        Me.lblCommands = New System.Windows.Forms.Label()
        Me.CommandsPanel1 = New hdd_guardian.CommandsPanel()
        Me.flwErrorLog = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblErrorLog = New System.Windows.Forms.Label()
        Me.optError1 = New System.Windows.Forms.RadioButton()
        Me.optError2 = New System.Windows.Forms.RadioButton()
        Me.optError3 = New System.Windows.Forms.RadioButton()
        Me.optError4 = New System.Windows.Forms.RadioButton()
        Me.optError5 = New System.Windows.Forms.RadioButton()
        Me.tpCapabilities = New System.Windows.Forms.TabPage()
        Me.clCapabilities = New hdd_guardian.CapabilitesList()
        Me.tpAttributes = New System.Windows.Forms.TabPage()
        Me.lvwSmart = New System.Windows.Forms.ListView()
        Me.chType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chAttribute = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chCurrent = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chWorst = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chThreshold = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chWhenFailed = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chRawValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.apAttributes = New hdd_guardian.AttributeInfoPanel()
        Me.lnkShowInfo = New System.Windows.Forms.LinkLabel()
        Me.lblDataStructure = New System.Windows.Forms.Label()
        Me.FlagsPanel1 = New hdd_guardian.FlagsPanel()
        Me.ValuesPanel1 = New hdd_guardian.ValuesPanel()
        Me.tabAdvanced = New System.Windows.Forms.TabControl()
        Me.tpReliability = New System.Windows.Forms.TabPage()
        Me.tpRunTest = New System.Windows.Forms.TabPage()
        Me.tipTest = New hdd_guardian.TipPanel()
        Me.pnlTest = New System.Windows.Forms.Panel()
        Me.pnlProgress = New System.Windows.Forms.Panel()
        Me.lblExtimatedEnd = New System.Windows.Forms.Label()
        Me.prbTestProgress = New System.Windows.Forms.ProgressBar()
        Me.lblProgress = New System.Windows.Forms.Label()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.flwTest = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblSelectTest = New System.Windows.Forms.Label()
        Me.cboTest = New System.Windows.Forms.ComboBox()
        Me.lblDuration = New System.Windows.Forms.Label()
        Me.btnRun = New System.Windows.Forms.Button()
        Me.lblTestInfo = New System.Windows.Forms.Label()
        Me.picTestInfo = New System.Windows.Forms.PictureBox()
        Me.flwFeatures = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblDevFeatures = New System.Windows.Forms.Label()
        Me.tlpFeatures = New System.Windows.Forms.TableLayoutPanel()
        Me.picSmart = New System.Windows.Forms.PictureBox()
        Me.picOfflineTest = New System.Windows.Forms.PictureBox()
        Me.picAttrAutosave = New System.Windows.Forms.PictureBox()
        Me.lblSmart = New System.Windows.Forms.Label()
        Me.lblOfflineTest = New System.Windows.Forms.Label()
        Me.lblAttrAutosave = New System.Windows.Forms.Label()
        Me.lblEnableSmart = New System.Windows.Forms.Label()
        Me.lblEnableOffline = New System.Windows.Forms.Label()
        Me.lblEnableAutosave = New System.Windows.Forms.Label()
        Me.picAdminSmart = New System.Windows.Forms.PictureBox()
        Me.picAdminOffline = New System.Windows.Forms.PictureBox()
        Me.picAdminAutosave = New System.Windows.Forms.PictureBox()
        Me.lblMonFeatures = New System.Windows.Forms.Label()
        Me.tlpMonitoring = New System.Windows.Forms.TableLayoutPanel()
        Me.picTrayIcon = New System.Windows.Forms.PictureBox()
        Me.picShareOutput = New System.Windows.Forms.PictureBox()
        Me.lblDevTrayIcon = New System.Windows.Forms.Label()
        Me.lblShare = New System.Windows.Forms.Label()
        Me.lblEnableTray = New System.Windows.Forms.Label()
        Me.lblEnableShare = New System.Windows.Forms.Label()
        Me.lnkSetFolder = New System.Windows.Forms.LinkLabel()
        Me.tmrFlushMem = New System.Windows.Forms.Timer(Me.components)
        Me.tmrTest = New System.Windows.Forms.Timer(Me.components)
        Me.lvwDevices = New System.Windows.Forms.ListView()
        Me.chDevice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chTemp = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.imlDevice = New System.Windows.Forms.ImageList(Me.components)
        Me.tabMain = New System.Windows.Forms.TabControl()
        Me.tpSummary = New System.Windows.Forms.TabPage()
        Me.hpSummary = New hdd_guardian.HealthPanel()
        Me.tpInfo = New System.Windows.Forms.TabPage()
        Me.dipInfo = New hdd_guardian.DeviceInfoPanel()
        Me.tpGeometryPartitions = New System.Windows.Forms.TabPage()
        Me.lblGathering = New System.Windows.Forms.Label()
        Me.lvwGeometry = New System.Windows.Forms.ListView()
        Me.chOne = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chTwo = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chThree = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.tpFeatures = New System.Windows.Forms.TabPage()
        Me.tpLog = New System.Windows.Forms.TabPage()
        Me.lblNoLog = New System.Windows.Forms.Label()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnToday = New System.Windows.Forms.Button()
        Me.btnPrev = New System.Windows.Forms.Button()
        Me.btnReload = New System.Windows.Forms.Button()
        Me.lvwLog = New System.Windows.Forms.ListView()
        Me.chDeviceLog = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chTime = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chAttrLog = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chFrom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chTo = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chVariation = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.dteLog = New System.Windows.Forms.DateTimePicker()
        Me.tabSmartctl = New System.Windows.Forms.TabControl()
        Me.tpOutput = New System.Windows.Forms.TabPage()
        Me.txtReport = New System.Windows.Forms.TextBox()
        Me.tpTolerance = New System.Windows.Forms.TabPage()
        Me.tipTolerance = New hdd_guardian.TipPanel()
        Me.pnlTolerance = New System.Windows.Forms.Panel()
        Me.cboTolerance = New System.Windows.Forms.ComboBox()
        Me.picTolerance = New System.Windows.Forms.PictureBox()
        Me.chkTolerance = New System.Windows.Forms.CheckBox()
        Me.tpAttFormat = New System.Windows.Forms.TabPage()
        Me.tipAttributes = New hdd_guardian.TipPanel()
        Me.pnlAttributes = New System.Windows.Forms.Panel()
        Me.picAttrFormat = New System.Windows.Forms.PictureBox()
        Me.picAttributes = New System.Windows.Forms.PictureBox()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lvwAttrFormat = New System.Windows.Forms.ListView()
        Me.chAttrID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chAttrFormat = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chAttrName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.cboFormat = New System.Windows.Forms.ComboBox()
        Me.lblFormat = New System.Windows.Forms.Label()
        Me.cboID = New System.Windows.Forms.ComboBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.cboAttributes = New System.Windows.Forms.ComboBox()
        Me.chkAttributes = New System.Windows.Forms.CheckBox()
        Me.tpFirmware = New System.Windows.Forms.TabPage()
        Me.tipFirmware = New hdd_guardian.TipPanel()
        Me.pnlFirmware = New System.Windows.Forms.Panel()
        Me.picSwap = New System.Windows.Forms.PictureBox()
        Me.picFirmware = New System.Windows.Forms.PictureBox()
        Me.chkFixSwap = New System.Windows.Forms.CheckBox()
        Me.cboFirmware = New System.Windows.Forms.ComboBox()
        Me.chkFirmware = New System.Windows.Forms.CheckBox()
        Me.tpDatabase = New System.Windows.Forms.TabPage()
        Me.cboDatabase = New System.Windows.Forms.ComboBox()
        Me.lblDatabase = New System.Windows.Forms.Label()
        Me.tabSettings = New System.Windows.Forms.TabControl()
        Me.tpLooknfeel = New System.Windows.Forms.TabPage()
        Me.chkCloseOnTray = New System.Windows.Forms.CheckBox()
        Me.chkStartupLink = New System.Windows.Forms.CheckBox()
        Me.chkRunMinimized = New System.Windows.Forms.CheckBox()
        Me.chkMinimizeInTray = New System.Windows.Forms.CheckBox()
        Me.chkConfirmExit = New System.Windows.Forms.CheckBox()
        Me.picWindow = New System.Windows.Forms.PictureBox()
        Me.chkAlwaysShowTray = New System.Windows.Forms.CheckBox()
        Me.tpUpdate = New System.Windows.Forms.TabPage()
        Me.picUpdate = New System.Windows.Forms.PictureBox()
        Me.tpMonitoring = New System.Windows.Forms.TabPage()
        Me.lblMonitoring = New System.Windows.Forms.Label()
        Me.picMonitoring = New System.Windows.Forms.PictureBox()
        Me.tpWarning = New System.Windows.Forms.TabPage()
        Me.lblWarning = New System.Windows.Forms.Label()
        Me.chkFailure = New System.Windows.Forms.CheckBox()
        Me.chkTempThresh = New System.Windows.Forms.CheckBox()
        Me.picWarning = New System.Windows.Forms.PictureBox()
        Me.chkParamChng = New System.Windows.Forms.CheckBox()
        Me.tpShare = New System.Windows.Forms.TabPage()
        Me.picXml = New System.Windows.Forms.PictureBox()
        Me.lblSelFolder = New System.Windows.Forms.Label()
        Me.picShare = New System.Windows.Forms.PictureBox()
        Me.tpRating = New System.Windows.Forms.TabPage()
        Me.chkTuneUp = New System.Windows.Forms.CheckBox()
        Me.tlpTuneUp = New System.Windows.Forms.TableLayoutPanel()
        Me.lnkResetCurPend = New System.Windows.Forms.LinkLabel()
        Me.lblCurPendTune = New System.Windows.Forms.Label()
        Me.lnkResetErrors = New System.Windows.Forms.LinkLabel()
        Me.lblErrorsTune = New System.Windows.Forms.Label()
        Me.lblOfflUncTune = New System.Windows.Forms.Label()
        Me.lnkResetOfflUnc = New System.Windows.Forms.LinkLabel()
        Me.numErrors = New System.Windows.Forms.NumericUpDown()
        Me.numCurPend = New System.Windows.Forms.NumericUpDown()
        Me.numOfflUnc = New System.Windows.Forms.NumericUpDown()
        Me.chkRating = New System.Windows.Forms.CheckBox()
        Me.picRating = New System.Windows.Forms.PictureBox()
        Me.imlLog = New System.Windows.Forms.ImageList(Me.components)
        Me.tlpStatusBar = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlUpdate = New System.Windows.Forms.Panel()
        Me.lnkUpdate = New System.Windows.Forms.LinkLabel()
        Me.dlgFolder = New System.Windows.Forms.FolderBrowserDialog()
        Me.tabAbout = New System.Windows.Forms.TabControl()
        Me.tpContributors = New System.Windows.Forms.TabPage()
        Me.tmrRefreshExt = New System.Windows.Forms.Timer(Me.components)
        Me.tmrRefreshVirtual = New System.Windows.Forms.Timer(Me.components)
        flwButtons = New System.Windows.Forms.FlowLayoutPanel()
        tlpMenu = New System.Windows.Forms.TableLayoutPanel()
        picLeft = New System.Windows.Forms.PictureBox()
        picRight = New System.Windows.Forms.PictureBox()
        tlpDatabase = New System.Windows.Forms.TableLayoutPanel()
        flwOutput = New System.Windows.Forms.FlowLayoutPanel()
        pnlDatabase = New System.Windows.Forms.Panel()
        flwShare = New System.Windows.Forms.FlowLayoutPanel()
        ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        pnlTopInfo = New System.Windows.Forms.Panel()
        tlpSummary = New System.Windows.Forms.TableLayoutPanel()
        pnlInfobox = New System.Windows.Forms.Panel()
        tpAbout = New System.Windows.Forms.TabPage()
        tlpContacts = New System.Windows.Forms.TableLayoutPanel()
        picOSI = New System.Windows.Forms.PictureBox()
        picLicense = New System.Windows.Forms.PictureBox()
        picLogo = New System.Windows.Forms.PictureBox()
        tpCredits = New System.Windows.Forms.TabPage()
        Label11 = New System.Windows.Forms.Label()
        Label5 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Label12 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label14 = New System.Windows.Forms.Label()
        Label13 = New System.Windows.Forms.Label()
        Label24 = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        Label21 = New System.Windows.Forms.Label()
        Label23 = New System.Windows.Forms.Label()
        Label22 = New System.Windows.Forms.Label()
        Label33 = New System.Windows.Forms.Label()
        tpLicense = New System.Windows.Forms.TabPage()
        Label6 = New System.Windows.Forms.Label()
        Label7 = New System.Windows.Forms.Label()
        Label8 = New System.Windows.Forms.Label()
        Label9 = New System.Windows.Forms.Label()
        Label10 = New System.Windows.Forms.Label()
        pnlRefresh = New System.Windows.Forms.Panel()
        tlpParameters = New System.Windows.Forms.TableLayoutPanel()
        tlpSSD = New System.Windows.Forms.TableLayoutPanel()
        flwMonitoring = New System.Windows.Forms.FlowLayoutPanel()
        flwXml = New System.Windows.Forms.FlowLayoutPanel()
        ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        tlpReliability = New System.Windows.Forms.TableLayoutPanel()
        lblHDD = New System.Windows.Forms.Label()
        Label16 = New System.Windows.Forms.Label()
        flwButtons.SuspendLayout()
        tlpMenu.SuspendLayout()
        CType(Me.picLanguageFlag, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(picLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(picRight, System.ComponentModel.ISupportInitialize).BeginInit()
        tlpDatabase.SuspendLayout()
        flwOutput.SuspendLayout()
        pnlDatabase.SuspendLayout()
        flwShare.SuspendLayout()
        pnlTopInfo.SuspendLayout()
        CType(Me.picHelp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStars, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPower, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDeviceImage, System.ComponentModel.ISupportInitialize).BeginInit()
        tlpSummary.SuspendLayout()
        pnlInfobox.SuspendLayout()
        CType(Me.picUsb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picManufacturer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAdmin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOsIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        tpAbout.SuspendLayout()
        tlpContacts.SuspendLayout()
        CType(Me.picHome, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEmail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(picOSI, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(picLicense, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        tpCredits.SuspendLayout()
        tpLicense.SuspendLayout()
        pnlRefresh.SuspendLayout()
        Me.tlpUpdate.SuspendLayout()
        CType(Me.numUpdateVirtual, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numUpdateExt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numUpdate, System.ComponentModel.ISupportInitialize).BeginInit()
        tlpParameters.SuspendLayout()
        tlpSSD.SuspendLayout()
        flwMonitoring.SuspendLayout()
        flwXml.SuspendLayout()
        tlpReliability.SuspendLayout()
        CType(Me.picErrors, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picReallSect, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCurPending, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOfflUnc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picIndilinx, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picIntel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMicron, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSamsung, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSandForce, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.flwLog.SuspendLayout()
        Me.mnuTrayIcon.SuspendLayout()
        Me.mnuDevices.SuspendLayout()
        Me.tpSelfTests.SuspendLayout()
        CType(Me.picAdminSelective, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAdminSelfTest, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpErrors.SuspendLayout()
        CType(Me.picAdminError, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.flwError.SuspendLayout()
        Me.flwErrorLog.SuspendLayout()
        Me.tpCapabilities.SuspendLayout()
        Me.tpAttributes.SuspendLayout()
        Me.tabAdvanced.SuspendLayout()
        Me.tpReliability.SuspendLayout()
        Me.tpRunTest.SuspendLayout()
        Me.pnlTest.SuspendLayout()
        Me.pnlProgress.SuspendLayout()
        Me.flwTest.SuspendLayout()
        CType(Me.picTestInfo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.flwFeatures.SuspendLayout()
        Me.tlpFeatures.SuspendLayout()
        CType(Me.picSmart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOfflineTest, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAttrAutosave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAdminSmart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAdminOffline, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAdminAutosave, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tlpMonitoring.SuspendLayout()
        CType(Me.picTrayIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picShareOutput, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabMain.SuspendLayout()
        Me.tpSummary.SuspendLayout()
        Me.tpInfo.SuspendLayout()
        Me.tpGeometryPartitions.SuspendLayout()
        Me.tpFeatures.SuspendLayout()
        Me.tpLog.SuspendLayout()
        Me.tabSmartctl.SuspendLayout()
        Me.tpOutput.SuspendLayout()
        Me.tpTolerance.SuspendLayout()
        Me.pnlTolerance.SuspendLayout()
        CType(Me.picTolerance, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpAttFormat.SuspendLayout()
        Me.pnlAttributes.SuspendLayout()
        CType(Me.picAttrFormat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAttributes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpFirmware.SuspendLayout()
        Me.pnlFirmware.SuspendLayout()
        CType(Me.picSwap, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFirmware, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpDatabase.SuspendLayout()
        Me.tabSettings.SuspendLayout()
        Me.tpLooknfeel.SuspendLayout()
        CType(Me.picWindow, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpUpdate.SuspendLayout()
        CType(Me.picUpdate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpMonitoring.SuspendLayout()
        CType(Me.picMonitoring, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpWarning.SuspendLayout()
        CType(Me.picWarning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpShare.SuspendLayout()
        CType(Me.picXml, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picShare, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpRating.SuspendLayout()
        Me.tlpTuneUp.SuspendLayout()
        CType(Me.numErrors, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numCurPend, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numOfflUnc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRating, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tlpStatusBar.SuspendLayout()
        Me.pnlUpdate.SuspendLayout()
        Me.tabAbout.SuspendLayout()
        Me.tpContributors.SuspendLayout()
        Me.SuspendLayout()
        '
        'flwButtons
        '
        flwButtons.AutoSize = True
        flwButtons.Controls.Add(Me.btnRunTest)
        flwButtons.Controls.Add(Me.btnDetails)
        flwButtons.Controls.Add(Me.btnUpdate)
        flwButtons.Dock = System.Windows.Forms.DockStyle.Bottom
        flwButtons.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft
        flwButtons.Location = New System.Drawing.Point(280, 0)
        flwButtons.Margin = New System.Windows.Forms.Padding(0)
        flwButtons.Name = "flwButtons"
        flwButtons.Size = New System.Drawing.Size(280, 30)
        flwButtons.TabIndex = 4
        '
        'btnRunTest
        '
        Me.btnRunTest.Location = New System.Drawing.Point(197, 3)
        Me.btnRunTest.Name = "btnRunTest"
        Me.btnRunTest.Size = New System.Drawing.Size(80, 24)
        Me.btnRunTest.TabIndex = 3
        Me.btnRunTest.Text = "Run test"
        Me.btnRunTest.UseVisualStyleBackColor = True
        '
        'btnDetails
        '
        Me.btnDetails.Location = New System.Drawing.Point(111, 3)
        Me.btnDetails.Name = "btnDetails"
        Me.btnDetails.Size = New System.Drawing.Size(80, 24)
        Me.btnDetails.TabIndex = 2
        Me.btnDetails.Text = "Details"
        Me.btnDetails.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(25, 3)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(80, 24)
        Me.btnUpdate.TabIndex = 1
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'tlpMenu
        '
        tlpMenu.BackgroundImage = Global.hdd_guardian.My.Resources.Resources.deselected
        tlpMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        tlpMenu.ColumnCount = 8
        tlpMenu.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpMenu.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpMenu.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpMenu.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpMenu.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpMenu.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpMenu.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpMenu.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpMenu.Controls.Add(Me.picLanguageFlag, 1, 0)
        tlpMenu.Controls.Add(Me.gbAbout, 7, 0)
        tlpMenu.Controls.Add(Me.gbSmartctl, 5, 0)
        tlpMenu.Controls.Add(Me.gbAdvanced, 4, 0)
        tlpMenu.Controls.Add(Me.gbSettings, 6, 0)
        tlpMenu.Controls.Add(picLeft, 0, 0)
        tlpMenu.Controls.Add(picRight, 2, 0)
        tlpMenu.Controls.Add(Me.gbMain, 3, 0)
        tlpMenu.Location = New System.Drawing.Point(0, 64)
        tlpMenu.Name = "tlpMenu"
        tlpMenu.RowCount = 1
        tlpMenu.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpMenu.Size = New System.Drawing.Size(752, 24)
        tlpMenu.TabIndex = 11
        '
        'picLanguageFlag
        '
        Me.picLanguageFlag.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picLanguageFlag.BackColor = System.Drawing.Color.Transparent
        Me.picLanguageFlag.Image = Global.hdd_guardian.My.Resources.Resources.worldflag
        Me.picLanguageFlag.Location = New System.Drawing.Point(6, 6)
        Me.picLanguageFlag.Margin = New System.Windows.Forms.Padding(5, 3, 3, 3)
        Me.picLanguageFlag.MaximumSize = New System.Drawing.Size(16, 11)
        Me.picLanguageFlag.MinimumSize = New System.Drawing.Size(16, 11)
        Me.picLanguageFlag.Name = "picLanguageFlag"
        Me.picLanguageFlag.Size = New System.Drawing.Size(16, 11)
        Me.picLanguageFlag.TabIndex = 0
        Me.picLanguageFlag.TabStop = False
        '
        'gbAbout
        '
        Me.gbAbout.AutoSize = True
        Me.gbAbout.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gbAbout.BackgroundImage = CType(resources.GetObject("gbAbout.BackgroundImage"), System.Drawing.Image)
        Me.gbAbout.Caption = "About"
        Me.gbAbout.Location = New System.Drawing.Point(708, 0)
        Me.gbAbout.Margin = New System.Windows.Forms.Padding(0)
        Me.gbAbout.MaximumSize = New System.Drawing.Size(0, 24)
        Me.gbAbout.MinimumSize = New System.Drawing.Size(24, 24)
        Me.gbAbout.Name = "gbAbout"
        Me.gbAbout.Size = New System.Drawing.Size(44, 24)
        Me.gbAbout.TabIndex = 4
        '
        'gbSmartctl
        '
        Me.gbSmartctl.AutoSize = True
        Me.gbSmartctl.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gbSmartctl.BackgroundImage = CType(resources.GetObject("gbSmartctl.BackgroundImage"), System.Drawing.Image)
        Me.gbSmartctl.Caption = "Smartctl"
        Me.gbSmartctl.Location = New System.Drawing.Point(600, 0)
        Me.gbSmartctl.Margin = New System.Windows.Forms.Padding(0)
        Me.gbSmartctl.MaximumSize = New System.Drawing.Size(0, 24)
        Me.gbSmartctl.MinimumSize = New System.Drawing.Size(24, 24)
        Me.gbSmartctl.Name = "gbSmartctl"
        Me.gbSmartctl.Size = New System.Drawing.Size(54, 24)
        Me.gbSmartctl.TabIndex = 2
        '
        'gbAdvanced
        '
        Me.gbAdvanced.AutoSize = True
        Me.gbAdvanced.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gbAdvanced.BackgroundImage = CType(resources.GetObject("gbAdvanced.BackgroundImage"), System.Drawing.Image)
        Me.gbAdvanced.Caption = "Advanced"
        Me.gbAdvanced.Location = New System.Drawing.Point(537, 0)
        Me.gbAdvanced.Margin = New System.Windows.Forms.Padding(0)
        Me.gbAdvanced.MaximumSize = New System.Drawing.Size(0, 24)
        Me.gbAdvanced.MinimumSize = New System.Drawing.Size(24, 24)
        Me.gbAdvanced.Name = "gbAdvanced"
        Me.gbAdvanced.Size = New System.Drawing.Size(63, 24)
        Me.gbAdvanced.TabIndex = 1
        '
        'gbSettings
        '
        Me.gbSettings.AutoSize = True
        Me.gbSettings.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gbSettings.BackgroundImage = CType(resources.GetObject("gbSettings.BackgroundImage"), System.Drawing.Image)
        Me.gbSettings.Caption = "Settings"
        Me.gbSettings.Location = New System.Drawing.Point(654, 0)
        Me.gbSettings.Margin = New System.Windows.Forms.Padding(0)
        Me.gbSettings.MaximumSize = New System.Drawing.Size(0, 24)
        Me.gbSettings.MinimumSize = New System.Drawing.Size(24, 24)
        Me.gbSettings.Name = "gbSettings"
        Me.gbSettings.Size = New System.Drawing.Size(54, 24)
        Me.gbSettings.TabIndex = 3
        '
        'picLeft
        '
        picLeft.Image = Global.hdd_guardian.My.Resources.Resources.deselected_left
        picLeft.Location = New System.Drawing.Point(0, 0)
        picLeft.Margin = New System.Windows.Forms.Padding(0)
        picLeft.Name = "picLeft"
        picLeft.Size = New System.Drawing.Size(1, 24)
        picLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        picLeft.TabIndex = 6
        picLeft.TabStop = False
        '
        'picRight
        '
        picRight.Image = Global.hdd_guardian.My.Resources.Resources.deselected
        picRight.Location = New System.Drawing.Point(499, 0)
        picRight.Margin = New System.Windows.Forms.Padding(0)
        picRight.Name = "picRight"
        picRight.Size = New System.Drawing.Size(1, 24)
        picRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        picRight.TabIndex = 7
        picRight.TabStop = False
        '
        'gbMain
        '
        Me.gbMain.AutoSize = True
        Me.gbMain.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gbMain.BackgroundImage = CType(resources.GetObject("gbMain.BackgroundImage"), System.Drawing.Image)
        Me.gbMain.Caption = "Main"
        Me.gbMain.Location = New System.Drawing.Point(500, 0)
        Me.gbMain.Margin = New System.Windows.Forms.Padding(0)
        Me.gbMain.MaximumSize = New System.Drawing.Size(0, 24)
        Me.gbMain.MinimumSize = New System.Drawing.Size(24, 24)
        Me.gbMain.Name = "gbMain"
        Me.gbMain.Size = New System.Drawing.Size(37, 24)
        Me.gbMain.TabIndex = 0
        '
        'tlpDatabase
        '
        tlpDatabase.AutoSize = True
        tlpDatabase.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        tlpDatabase.ColumnCount = 2
        tlpDatabase.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpDatabase.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpDatabase.Controls.Add(Me.lblModel, 0, 0)
        tlpDatabase.Controls.Add(Me.lblFirmware, 0, 1)
        tlpDatabase.Controls.Add(Me.lblFamily, 0, 2)
        tlpDatabase.Controls.Add(Me.lblAttrOptions, 0, 3)
        tlpDatabase.Controls.Add(Me.lblModelValue, 1, 0)
        tlpDatabase.Controls.Add(Me.lblFirmwareValue, 1, 1)
        tlpDatabase.Controls.Add(Me.lblFamilyValue, 1, 2)
        tlpDatabase.Controls.Add(Me.lblAttrOptionsValue, 1, 3)
        tlpDatabase.Controls.Add(Me.lblWarningsValue, 1, 5)
        tlpDatabase.Controls.Add(Me.lblOtherOptValue, 1, 4)
        tlpDatabase.Controls.Add(Me.lblWarnings, 0, 5)
        tlpDatabase.Controls.Add(Me.lblOtherOpt, 0, 4)
        tlpDatabase.Location = New System.Drawing.Point(0, 0)
        tlpDatabase.MaximumSize = New System.Drawing.Size(536, 0)
        tlpDatabase.MinimumSize = New System.Drawing.Size(536, 88)
        tlpDatabase.Name = "tlpDatabase"
        tlpDatabase.RowCount = 6
        tlpDatabase.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpDatabase.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpDatabase.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpDatabase.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpDatabase.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpDatabase.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpDatabase.Size = New System.Drawing.Size(536, 88)
        tlpDatabase.TabIndex = 14
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.ForeColor = System.Drawing.Color.DimGray
        Me.lblModel.Location = New System.Drawing.Point(3, 0)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(45, 13)
        Me.lblModel.TabIndex = 0
        Me.lblModel.Text = "lblModel"
        '
        'lblFirmware
        '
        Me.lblFirmware.AutoSize = True
        Me.lblFirmware.ForeColor = System.Drawing.Color.DimGray
        Me.lblFirmware.Location = New System.Drawing.Point(3, 13)
        Me.lblFirmware.Name = "lblFirmware"
        Me.lblFirmware.Size = New System.Drawing.Size(61, 13)
        Me.lblFirmware.TabIndex = 1
        Me.lblFirmware.Text = "lblFirmware"
        '
        'lblFamily
        '
        Me.lblFamily.AutoSize = True
        Me.lblFamily.ForeColor = System.Drawing.Color.DimGray
        Me.lblFamily.Location = New System.Drawing.Point(3, 26)
        Me.lblFamily.Name = "lblFamily"
        Me.lblFamily.Size = New System.Drawing.Size(47, 13)
        Me.lblFamily.TabIndex = 2
        Me.lblFamily.Text = "lblFamily"
        '
        'lblAttrOptions
        '
        Me.lblAttrOptions.AutoSize = True
        Me.lblAttrOptions.ForeColor = System.Drawing.Color.DimGray
        Me.lblAttrOptions.Location = New System.Drawing.Point(3, 39)
        Me.lblAttrOptions.Name = "lblAttrOptions"
        Me.lblAttrOptions.Size = New System.Drawing.Size(73, 13)
        Me.lblAttrOptions.TabIndex = 3
        Me.lblAttrOptions.Text = "lblAttrOptions"
        '
        'lblModelValue
        '
        Me.lblModelValue.AutoSize = True
        Me.lblModelValue.Location = New System.Drawing.Point(82, 0)
        Me.lblModelValue.Name = "lblModelValue"
        Me.lblModelValue.Size = New System.Drawing.Size(71, 13)
        Me.lblModelValue.TabIndex = 5
        Me.lblModelValue.Text = "lblModelValue"
        '
        'lblFirmwareValue
        '
        Me.lblFirmwareValue.AutoSize = True
        Me.lblFirmwareValue.Location = New System.Drawing.Point(82, 13)
        Me.lblFirmwareValue.Name = "lblFirmwareValue"
        Me.lblFirmwareValue.Size = New System.Drawing.Size(87, 13)
        Me.lblFirmwareValue.TabIndex = 6
        Me.lblFirmwareValue.Text = "lblFirmwareValue"
        '
        'lblFamilyValue
        '
        Me.lblFamilyValue.AutoSize = True
        Me.lblFamilyValue.Location = New System.Drawing.Point(82, 26)
        Me.lblFamilyValue.Name = "lblFamilyValue"
        Me.lblFamilyValue.Size = New System.Drawing.Size(73, 13)
        Me.lblFamilyValue.TabIndex = 7
        Me.lblFamilyValue.Text = "lblFamilyValue"
        '
        'lblAttrOptionsValue
        '
        Me.lblAttrOptionsValue.AutoSize = True
        Me.lblAttrOptionsValue.Location = New System.Drawing.Point(82, 39)
        Me.lblAttrOptionsValue.Name = "lblAttrOptionsValue"
        Me.lblAttrOptionsValue.Size = New System.Drawing.Size(99, 13)
        Me.lblAttrOptionsValue.TabIndex = 8
        Me.lblAttrOptionsValue.Text = "lblAttrOptionsValue"
        '
        'lblWarningsValue
        '
        Me.lblWarningsValue.AutoSize = True
        Me.lblWarningsValue.Location = New System.Drawing.Point(82, 65)
        Me.lblWarningsValue.Name = "lblWarningsValue"
        Me.lblWarningsValue.Size = New System.Drawing.Size(88, 13)
        Me.lblWarningsValue.TabIndex = 9
        Me.lblWarningsValue.Text = "lblWarningsValue"
        '
        'lblOtherOptValue
        '
        Me.lblOtherOptValue.AutoSize = True
        Me.lblOtherOptValue.Location = New System.Drawing.Point(82, 52)
        Me.lblOtherOptValue.Name = "lblOtherOptValue"
        Me.lblOtherOptValue.Size = New System.Drawing.Size(89, 13)
        Me.lblOtherOptValue.TabIndex = 10
        Me.lblOtherOptValue.Text = "lblOtherOptValue"
        '
        'lblWarnings
        '
        Me.lblWarnings.AutoSize = True
        Me.lblWarnings.ForeColor = System.Drawing.Color.DimGray
        Me.lblWarnings.Location = New System.Drawing.Point(3, 65)
        Me.lblWarnings.Name = "lblWarnings"
        Me.lblWarnings.Size = New System.Drawing.Size(62, 13)
        Me.lblWarnings.TabIndex = 4
        Me.lblWarnings.Text = "lblWarnings"
        '
        'lblOtherOpt
        '
        Me.lblOtherOpt.AutoSize = True
        Me.lblOtherOpt.ForeColor = System.Drawing.Color.DimGray
        Me.lblOtherOpt.Location = New System.Drawing.Point(3, 52)
        Me.lblOtherOpt.Name = "lblOtherOpt"
        Me.lblOtherOpt.Size = New System.Drawing.Size(63, 13)
        Me.lblOtherOpt.TabIndex = 11
        Me.lblOtherOpt.Text = "lblOtherOpt"
        '
        'flwOutput
        '
        flwOutput.AutoSize = True
        flwOutput.Controls.Add(Me.btnSaveOutput)
        flwOutput.Dock = System.Windows.Forms.DockStyle.Bottom
        flwOutput.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft
        flwOutput.Location = New System.Drawing.Point(0, 265)
        flwOutput.Name = "flwOutput"
        flwOutput.Size = New System.Drawing.Size(560, 29)
        flwOutput.TabIndex = 3
        '
        'btnSaveOutput
        '
        Me.btnSaveOutput.Location = New System.Drawing.Point(477, 3)
        Me.btnSaveOutput.Name = "btnSaveOutput"
        Me.btnSaveOutput.Size = New System.Drawing.Size(80, 23)
        Me.btnSaveOutput.TabIndex = 1
        Me.btnSaveOutput.Text = "btnSaveOutput"
        Me.btnSaveOutput.UseVisualStyleBackColor = True
        '
        'pnlDatabase
        '
        pnlDatabase.AutoScroll = True
        pnlDatabase.Controls.Add(tlpDatabase)
        pnlDatabase.Location = New System.Drawing.Point(0, 56)
        pnlDatabase.Name = "pnlDatabase"
        pnlDatabase.Size = New System.Drawing.Size(560, 232)
        pnlDatabase.TabIndex = 15
        '
        'flwShare
        '
        flwShare.AutoSize = True
        flwShare.Controls.Add(Me.btnBrwsFolder)
        flwShare.Controls.Add(Me.lblFolder)
        flwShare.Location = New System.Drawing.Point(24, 27)
        flwShare.MaximumSize = New System.Drawing.Size(528, 0)
        flwShare.Name = "flwShare"
        flwShare.Size = New System.Drawing.Size(528, 0)
        flwShare.TabIndex = 0
        '
        'btnBrwsFolder
        '
        flwShare.SetFlowBreak(Me.btnBrwsFolder, True)
        Me.btnBrwsFolder.Location = New System.Drawing.Point(0, 0)
        Me.btnBrwsFolder.Margin = New System.Windows.Forms.Padding(0)
        Me.btnBrwsFolder.Name = "btnBrwsFolder"
        Me.btnBrwsFolder.Size = New System.Drawing.Size(75, 23)
        Me.btnBrwsFolder.TabIndex = 0
        Me.btnBrwsFolder.Text = "btnBrwsFolder"
        Me.btnBrwsFolder.UseVisualStyleBackColor = True
        '
        'lblFolder
        '
        Me.lblFolder.AutoSize = True
        Me.lblFolder.ForeColor = System.Drawing.Color.DimGray
        Me.lblFolder.Location = New System.Drawing.Point(3, 23)
        Me.lblFolder.MinimumSize = New System.Drawing.Size(0, 23)
        Me.lblFolder.Name = "lblFolder"
        Me.lblFolder.Size = New System.Drawing.Size(46, 23)
        Me.lblFolder.TabIndex = 1
        Me.lblFolder.Text = "lblFolder"
        Me.lblFolder.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripSeparator2
        '
        ToolStripSeparator2.Name = "ToolStripSeparator2"
        ToolStripSeparator2.Size = New System.Drawing.Size(192, 6)
        '
        'ToolStripSeparator1
        '
        ToolStripSeparator1.Name = "ToolStripSeparator1"
        ToolStripSeparator1.Size = New System.Drawing.Size(192, 6)
        '
        'ToolStripSeparator4
        '
        ToolStripSeparator4.Name = "ToolStripSeparator4"
        ToolStripSeparator4.Size = New System.Drawing.Size(174, 6)
        '
        'pnlTopInfo
        '
        pnlTopInfo.BackColor = System.Drawing.Color.Transparent
        pnlTopInfo.BackgroundImage = CType(resources.GetObject("pnlTopInfo.BackgroundImage"), System.Drawing.Image)
        pnlTopInfo.Controls.Add(Me.picHelp)
        pnlTopInfo.Controls.Add(Me.picStars)
        pnlTopInfo.Controls.Add(Me.picPower)
        pnlTopInfo.Controls.Add(Me.devPanel)
        pnlTopInfo.Controls.Add(Me.picDeviceImage)
        pnlTopInfo.Location = New System.Drawing.Point(0, 0)
        pnlTopInfo.Name = "pnlTopInfo"
        pnlTopInfo.Size = New System.Drawing.Size(752, 64)
        pnlTopInfo.TabIndex = 10
        '
        'picHelp
        '
        Me.picHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.picHelp.Location = New System.Drawing.Point(728, 40)
        Me.picHelp.Name = "picHelp"
        Me.picHelp.Size = New System.Drawing.Size(16, 16)
        Me.picHelp.TabIndex = 13
        Me.picHelp.TabStop = False
        Me.ttMain.SetToolTip(Me.picHelp, "Help")
        '
        'picStars
        '
        Me.picStars.Image = Global.hdd_guardian.My.Resources.Resources.r0_star
        Me.picStars.Location = New System.Drawing.Point(8, 52)
        Me.picStars.Name = "picStars"
        Me.picStars.Size = New System.Drawing.Size(48, 8)
        Me.picStars.TabIndex = 12
        Me.picStars.TabStop = False
        '
        'picPower
        '
        Me.picPower.BackgroundImage = Global.hdd_guardian.My.Resources.Resources.power_deselected
        Me.picPower.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.picPower.Location = New System.Drawing.Point(728, 8)
        Me.picPower.Name = "picPower"
        Me.picPower.Size = New System.Drawing.Size(16, 16)
        Me.picPower.TabIndex = 11
        Me.picPower.TabStop = False
        '
        'devPanel
        '
        Me.devPanel.BackColor = System.Drawing.Color.Transparent
        Me.devPanel.Location = New System.Drawing.Point(64, 0)
        Me.devPanel.Name = "devPanel"
        Me.devPanel.Size = New System.Drawing.Size(656, 64)
        Me.devPanel.TabIndex = 10
        Me.devPanel.TabStop = False
        '
        'picDeviceImage
        '
        Me.picDeviceImage.BackgroundImage = Global.hdd_guardian.My.Resources.Resources.Raptor_X
        Me.picDeviceImage.Location = New System.Drawing.Point(8, 4)
        Me.picDeviceImage.Name = "picDeviceImage"
        Me.picDeviceImage.Size = New System.Drawing.Size(48, 48)
        Me.picDeviceImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picDeviceImage.TabIndex = 9
        Me.picDeviceImage.TabStop = False
        '
        'tlpSummary
        '
        tlpSummary.AutoSize = True
        tlpSummary.ColumnCount = 2
        tlpSummary.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpSummary.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpSummary.Controls.Add(flwButtons, 1, 0)
        tlpSummary.Controls.Add(pnlInfobox, 0, 0)
        tlpSummary.Dock = System.Windows.Forms.DockStyle.Bottom
        tlpSummary.Location = New System.Drawing.Point(0, 264)
        tlpSummary.Name = "tlpSummary"
        tlpSummary.RowCount = 1
        tlpSummary.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpSummary.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        tlpSummary.Size = New System.Drawing.Size(560, 30)
        tlpSummary.TabIndex = 6
        '
        'pnlInfobox
        '
        pnlInfobox.Anchor = System.Windows.Forms.AnchorStyles.Left
        pnlInfobox.BackColor = System.Drawing.Color.Transparent
        pnlInfobox.BackgroundImage = Global.hdd_guardian.My.Resources.Resources.Infobox_XL
        pnlInfobox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        pnlInfobox.Controls.Add(Me.picUsb)
        pnlInfobox.Controls.Add(Me.picManufacturer)
        pnlInfobox.Controls.Add(Me.picAdmin)
        pnlInfobox.Controls.Add(Me.picOsIcon)
        pnlInfobox.Location = New System.Drawing.Point(5, 5)
        pnlInfobox.Margin = New System.Windows.Forms.Padding(5, 2, 0, 2)
        pnlInfobox.Name = "pnlInfobox"
        pnlInfobox.Size = New System.Drawing.Size(250, 20)
        pnlInfobox.TabIndex = 8
        '
        'picUsb
        '
        Me.picUsb.Location = New System.Drawing.Point(199, 2)
        Me.picUsb.Name = "picUsb"
        Me.picUsb.Size = New System.Drawing.Size(16, 16)
        Me.picUsb.TabIndex = 1
        Me.picUsb.TabStop = False
        '
        'picManufacturer
        '
        Me.picManufacturer.Location = New System.Drawing.Point(32, 3)
        Me.picManufacturer.Margin = New System.Windows.Forms.Padding(0)
        Me.picManufacturer.Name = "picManufacturer"
        Me.picManufacturer.Size = New System.Drawing.Size(160, 15)
        Me.picManufacturer.TabIndex = 1
        Me.picManufacturer.TabStop = False
        '
        'picAdmin
        '
        Me.picAdmin.Location = New System.Drawing.Point(217, 2)
        Me.picAdmin.Name = "picAdmin"
        Me.picAdmin.Size = New System.Drawing.Size(16, 16)
        Me.picAdmin.TabIndex = 0
        Me.picAdmin.TabStop = False
        '
        'picOsIcon
        '
        Me.picOsIcon.Location = New System.Drawing.Point(7, 2)
        Me.picOsIcon.Margin = New System.Windows.Forms.Padding(0)
        Me.picOsIcon.Name = "picOsIcon"
        Me.picOsIcon.Size = New System.Drawing.Size(16, 16)
        Me.picOsIcon.TabIndex = 0
        Me.picOsIcon.TabStop = False
        '
        'tpAbout
        '
        tpAbout.Controls.Add(tlpContacts)
        tpAbout.Controls.Add(Me.lblFramework)
        tpAbout.Controls.Add(picOSI)
        tpAbout.Controls.Add(picLicense)
        tpAbout.Controls.Add(Me.lblVersion)
        tpAbout.Controls.Add(Me.lblCopyright)
        tpAbout.Controls.Add(picLogo)
        tpAbout.Location = New System.Drawing.Point(4, 22)
        tpAbout.Name = "tpAbout"
        tpAbout.Size = New System.Drawing.Size(560, 294)
        tpAbout.TabIndex = 2
        tpAbout.Text = "HDD Guardian"
        tpAbout.UseVisualStyleBackColor = True
        '
        'tlpContacts
        '
        tlpContacts.ColumnCount = 4
        tlpContacts.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        tlpContacts.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpContacts.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpContacts.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        tlpContacts.Controls.Add(Me.picHome, 0, 0)
        tlpContacts.Controls.Add(Me.lnkHddGuardian, 1, 0)
        tlpContacts.Controls.Add(Me.lnkGroup, 2, 0)
        tlpContacts.Controls.Add(Me.picEmail, 0, 1)
        tlpContacts.Controls.Add(Me.lnkEmail, 1, 1)
        tlpContacts.Controls.Add(Me.picGroup, 3, 0)
        tlpContacts.Controls.Add(Me.picPlus, 3, 1)
        tlpContacts.Controls.Add(Me.lnkPlus, 2, 1)
        tlpContacts.Location = New System.Drawing.Point(144, 112)
        tlpContacts.Name = "tlpContacts"
        tlpContacts.RowCount = 2
        tlpContacts.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpContacts.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpContacts.Size = New System.Drawing.Size(272, 48)
        tlpContacts.TabIndex = 13
        '
        'picHome
        '
        Me.picHome.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picHome.Location = New System.Drawing.Point(4, 4)
        Me.picHome.Name = "picHome"
        Me.picHome.Size = New System.Drawing.Size(16, 16)
        Me.picHome.TabIndex = 8
        Me.picHome.TabStop = False
        '
        'lnkHddGuardian
        '
        Me.lnkHddGuardian.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkHddGuardian.Location = New System.Drawing.Point(27, 4)
        Me.lnkHddGuardian.Name = "lnkHddGuardian"
        Me.lnkHddGuardian.Size = New System.Drawing.Size(106, 16)
        Me.lnkHddGuardian.TabIndex = 0
        Me.lnkHddGuardian.TabStop = True
        Me.lnkHddGuardian.Tag = "http://code.google.com/p/hddguardian/"
        Me.lnkHddGuardian.Text = "Project home page"
        Me.lnkHddGuardian.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lnkGroup
        '
        Me.lnkGroup.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lnkGroup.AutoSize = True
        Me.lnkGroup.Location = New System.Drawing.Point(169, 5)
        Me.lnkGroup.Name = "lnkGroup"
        Me.lnkGroup.Size = New System.Drawing.Size(76, 13)
        Me.lnkGroup.TabIndex = 10
        Me.lnkGroup.TabStop = True
        Me.lnkGroup.Tag = "http://groups.google.com/group/hddguardian"
        Me.lnkGroup.Text = "Support group"
        Me.lnkGroup.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'picEmail
        '
        Me.picEmail.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picEmail.Location = New System.Drawing.Point(4, 28)
        Me.picEmail.Name = "picEmail"
        Me.picEmail.Size = New System.Drawing.Size(16, 16)
        Me.picEmail.TabIndex = 11
        Me.picEmail.TabStop = False
        '
        'lnkEmail
        '
        Me.lnkEmail.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkEmail.Location = New System.Drawing.Point(27, 28)
        Me.lnkEmail.Name = "lnkEmail"
        Me.lnkEmail.Size = New System.Drawing.Size(64, 16)
        Me.lnkEmail.TabIndex = 12
        Me.lnkEmail.TabStop = True
        Me.lnkEmail.Tag = "mailto:hddguardian@googlegroups.com"
        Me.lnkEmail.Text = "E-mail"
        Me.lnkEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'picGroup
        '
        Me.picGroup.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picGroup.Location = New System.Drawing.Point(252, 4)
        Me.picGroup.Name = "picGroup"
        Me.picGroup.Size = New System.Drawing.Size(16, 16)
        Me.picGroup.TabIndex = 9
        Me.picGroup.TabStop = False
        '
        'picPlus
        '
        Me.picPlus.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picPlus.Location = New System.Drawing.Point(252, 28)
        Me.picPlus.Name = "picPlus"
        Me.picPlus.Size = New System.Drawing.Size(16, 16)
        Me.picPlus.TabIndex = 13
        Me.picPlus.TabStop = False
        '
        'lnkPlus
        '
        Me.lnkPlus.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lnkPlus.AutoSize = True
        Me.lnkPlus.Location = New System.Drawing.Point(197, 29)
        Me.lnkPlus.Name = "lnkPlus"
        Me.lnkPlus.Size = New System.Drawing.Size(48, 13)
        Me.lnkPlus.TabIndex = 14
        Me.lnkPlus.TabStop = True
        Me.lnkPlus.Tag = "https://plus.google.com/106826995603694539889/"
        Me.lnkPlus.Text = "Google+"
        '
        'lblFramework
        '
        Me.lblFramework.ForeColor = System.Drawing.Color.DimGray
        Me.lblFramework.Location = New System.Drawing.Point(0, 168)
        Me.lblFramework.Name = "lblFramework"
        Me.lblFramework.Size = New System.Drawing.Size(560, 13)
        Me.lblFramework.TabIndex = 7
        Me.lblFramework.Text = "lblFramework"
        Me.lblFramework.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'picOSI
        '
        picOSI.Image = Global.hdd_guardian.My.Resources.Resources.OSI
        picOSI.Location = New System.Drawing.Point(280, 224)
        picOSI.Name = "picOSI"
        picOSI.Size = New System.Drawing.Size(280, 64)
        picOSI.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        picOSI.TabIndex = 5
        picOSI.TabStop = False
        '
        'picLicense
        '
        picLicense.Image = Global.hdd_guardian.My.Resources.Resources.gnu_gpl2
        picLicense.Location = New System.Drawing.Point(0, 240)
        picLicense.Name = "picLicense"
        picLicense.Size = New System.Drawing.Size(280, 40)
        picLicense.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        picLicense.TabIndex = 4
        picLicense.TabStop = False
        '
        'lblVersion
        '
        Me.lblVersion.ForeColor = System.Drawing.Color.DimGray
        Me.lblVersion.Location = New System.Drawing.Point(0, 64)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(560, 13)
        Me.lblVersion.TabIndex = 3
        Me.lblVersion.Text = "lblVersion"
        Me.lblVersion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCopyright
        '
        Me.lblCopyright.ForeColor = System.Drawing.Color.DimGray
        Me.lblCopyright.Location = New System.Drawing.Point(0, 88)
        Me.lblCopyright.Name = "lblCopyright"
        Me.lblCopyright.Size = New System.Drawing.Size(560, 13)
        Me.lblCopyright.TabIndex = 2
        Me.lblCopyright.Text = "lblCopyright"
        Me.lblCopyright.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picLogo
        '
        picLogo.Image = CType(resources.GetObject("picLogo.Image"), System.Drawing.Image)
        picLogo.Location = New System.Drawing.Point(0, 0)
        picLogo.Name = "picLogo"
        picLogo.Size = New System.Drawing.Size(560, 56)
        picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        picLogo.TabIndex = 1
        picLogo.TabStop = False
        '
        'tpCredits
        '
        tpCredits.Controls.Add(Me.lnkCoolerMaster)
        tpCredits.Controls.Add(Label11)
        tpCredits.Controls.Add(Me.lnkGnomeGit)
        tpCredits.Controls.Add(Me.lnkGnome)
        tpCredits.Controls.Add(Me.lnkGplGnome)
        tpCredits.Controls.Add(Label5)
        tpCredits.Controls.Add(Label4)
        tpCredits.Controls.Add(Me.lnkCcBy)
        tpCredits.Controls.Add(Me.lnkGpl)
        tpCredits.Controls.Add(Me.lnkWesternDigital)
        tpCredits.Controls.Add(Label2)
        tpCredits.Controls.Add(Label12)
        tpCredits.Controls.Add(Me.lnkPremiumPixels)
        tpCredits.Controls.Add(Me.lnkSmartMonTools)
        tpCredits.Controls.Add(Label3)
        tpCredits.Controls.Add(Label14)
        tpCredits.Controls.Add(Label13)
        tpCredits.Controls.Add(Me.lnkBrandsOfTheWorld)
        tpCredits.Controls.Add(Label24)
        tpCredits.Controls.Add(Label1)
        tpCredits.Controls.Add(Label21)
        tpCredits.Controls.Add(Label23)
        tpCredits.Controls.Add(Label22)
        tpCredits.Controls.Add(Me.lnkFamFamFam)
        tpCredits.Controls.Add(Me.lnkKamiyamane)
        tpCredits.Controls.Add(Label33)
        tpCredits.Location = New System.Drawing.Point(4, 22)
        tpCredits.Name = "tpCredits"
        tpCredits.Padding = New System.Windows.Forms.Padding(3)
        tpCredits.Size = New System.Drawing.Size(560, 294)
        tpCredits.TabIndex = 1
        tpCredits.Text = "Credits"
        tpCredits.UseVisualStyleBackColor = True
        '
        'lnkCoolerMaster
        '
        Me.lnkCoolerMaster.AutoSize = True
        Me.lnkCoolerMaster.Location = New System.Drawing.Point(336, 192)
        Me.lnkCoolerMaster.Name = "lnkCoolerMaster"
        Me.lnkCoolerMaster.Size = New System.Drawing.Size(120, 13)
        Me.lnkCoolerMaster.TabIndex = 39
        Me.lnkCoolerMaster.TabStop = True
        Me.lnkCoolerMaster.Text = "www.coolermaster.com"
        '
        'Label11
        '
        Label11.AutoSize = True
        Label11.Location = New System.Drawing.Point(16, 192)
        Label11.Name = "Label11"
        Label11.Size = New System.Drawing.Size(319, 13)
        Label11.TabIndex = 38
        Label11.Text = "The basic top-left removable hard disk are a CoolerMaster XCraft"
        '
        'lnkGnomeGit
        '
        Me.lnkGnomeGit.AutoSize = True
        Me.lnkGnomeGit.Location = New System.Drawing.Point(336, 256)
        Me.lnkGnomeGit.Name = "lnkGnomeGit"
        Me.lnkGnomeGit.Size = New System.Drawing.Size(111, 13)
        Me.lnkGnomeGit.TabIndex = 10
        Me.lnkGnomeGit.TabStop = True
        Me.lnkGnomeGit.Text = "http://git.gnome.org/"
        '
        'lnkGnome
        '
        Me.lnkGnome.AutoSize = True
        Me.lnkGnome.Location = New System.Drawing.Point(136, 256)
        Me.lnkGnome.Name = "lnkGnome"
        Me.lnkGnome.Size = New System.Drawing.Size(98, 13)
        Me.lnkGnome.TabIndex = 8
        Me.lnkGnome.TabStop = True
        Me.lnkGnome.Tag = "http://www.gnome.org/"
        Me.lnkGnome.Text = "The Gnome Project"
        '
        'lnkGplGnome
        '
        Me.lnkGplGnome.AutoSize = True
        Me.lnkGplGnome.Location = New System.Drawing.Point(256, 256)
        Me.lnkGplGnome.Name = "lnkGplGnome"
        Me.lnkGplGnome.Size = New System.Drawing.Size(58, 13)
        Me.lnkGplGnome.TabIndex = 9
        Me.lnkGplGnome.TabStop = True
        Me.lnkGplGnome.Tag = "http://www.gnu.org/licenses/gpl-2.0.html"
        Me.lnkGplGnome.Text = "GNU GPL 2"
        '
        'Label5
        '
        Label5.Location = New System.Drawing.Point(16, 216)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(320, 40)
        Label5.TabIndex = 37
        Label5.Text = "HDD Guardian icon (256x256, 48x48, 32x32 and 24x24 px sizes)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and logo are create" & _
            "d using icons from Gnome Icon Theme" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "ver. 2.30.2.1"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Location = New System.Drawing.Point(248, 88)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(71, 13)
        Label4.TabIndex = 36
        Label4.Text = "Public domain"
        '
        'lnkCcBy
        '
        Me.lnkCcBy.AutoSize = True
        Me.lnkCcBy.Location = New System.Drawing.Point(248, 64)
        Me.lnkCcBy.Name = "lnkCcBy"
        Me.lnkCcBy.Size = New System.Drawing.Size(56, 13)
        Me.lnkCcBy.TabIndex = 2
        Me.lnkCcBy.TabStop = True
        Me.lnkCcBy.Tag = "http://creativecommons.org/licenses/by/3.0/"
        Me.lnkCcBy.Text = "CC-BY 3.0"
        '
        'lnkGpl
        '
        Me.lnkGpl.AutoSize = True
        Me.lnkGpl.Location = New System.Drawing.Point(248, 24)
        Me.lnkGpl.Name = "lnkGpl"
        Me.lnkGpl.Size = New System.Drawing.Size(58, 13)
        Me.lnkGpl.TabIndex = 0
        Me.lnkGpl.TabStop = True
        Me.lnkGpl.Tag = "http://www.gnu.org/licenses/gpl-2.0.html"
        Me.lnkGpl.Text = "GNU GPL 2"
        '
        'lnkWesternDigital
        '
        Me.lnkWesternDigital.AutoSize = True
        Me.lnkWesternDigital.Location = New System.Drawing.Point(336, 168)
        Me.lnkWesternDigital.Name = "lnkWesternDigital"
        Me.lnkWesternDigital.Size = New System.Drawing.Size(77, 13)
        Me.lnkWesternDigital.TabIndex = 7
        Me.lnkWesternDigital.TabStop = True
        Me.lnkWesternDigital.Text = "www.wdc.com"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Location = New System.Drawing.Point(16, 168)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(286, 13)
        Label2.TabIndex = 32
        Label2.Text = "The basic top-left hard disk are a Western Digital Raptor X"
        '
        'Label12
        '
        Label12.Dock = System.Windows.Forms.DockStyle.Bottom
        Label12.Location = New System.Drawing.Point(3, 278)
        Label12.Name = "Label12"
        Label12.Size = New System.Drawing.Size(554, 13)
        Label12.TabIndex = 15
        Label12.Text = "All logos and images are intellectual property of the copyright and/or trademark " & _
            "holder."
        Label12.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lnkPremiumPixels
        '
        Me.lnkPremiumPixels.AutoSize = True
        Me.lnkPremiumPixels.Location = New System.Drawing.Point(336, 136)
        Me.lnkPremiumPixels.Name = "lnkPremiumPixels"
        Me.lnkPremiumPixels.Size = New System.Drawing.Size(161, 26)
        Me.lnkPremiumPixels.TabIndex = 6
        Me.lnkPremiumPixels.TabStop = True
        Me.lnkPremiumPixels.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "http://www.premiumpixels.com/"
        '
        'lnkSmartMonTools
        '
        Me.lnkSmartMonTools.AutoSize = True
        Me.lnkSmartMonTools.Location = New System.Drawing.Point(336, 24)
        Me.lnkSmartMonTools.Name = "lnkSmartMonTools"
        Me.lnkSmartMonTools.Size = New System.Drawing.Size(195, 13)
        Me.lnkSmartMonTools.TabIndex = 1
        Me.lnkSmartMonTools.TabStop = True
        Me.lnkSmartMonTools.Text = "http://smartmontools.sourceforge.net/"
        '
        'Label3
        '
        Label3.Location = New System.Drawing.Point(16, 136)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(320, 26)
        Label3.TabIndex = 30
        Label3.Text = "Interface graphics are derived from Orman Clark's samples," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "all available on Prem" & _
            "iumPixels"
        '
        'Label14
        '
        Label14.AutoSize = True
        Label14.Location = New System.Drawing.Point(16, 24)
        Label14.Name = "Label14"
        Label14.Size = New System.Drawing.Size(123, 13)
        Label14.TabIndex = 17
        Label14.Text = "Copyright © Bruce Allen"
        '
        'Label13
        '
        Label13.AutoSize = True
        Label13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label13.Location = New System.Drawing.Point(0, 8)
        Label13.Name = "Label13"
        Label13.Size = New System.Drawing.Size(159, 13)
        Label13.TabIndex = 16
        Label13.Text = "S.M.A.R.T. Monitoring Tools"
        '
        'lnkBrandsOfTheWorld
        '
        Me.lnkBrandsOfTheWorld.AutoSize = True
        Me.lnkBrandsOfTheWorld.Location = New System.Drawing.Point(336, 112)
        Me.lnkBrandsOfTheWorld.Name = "lnkBrandsOfTheWorld"
        Me.lnkBrandsOfTheWorld.Size = New System.Drawing.Size(143, 13)
        Me.lnkBrandsOfTheWorld.TabIndex = 5
        Me.lnkBrandsOfTheWorld.TabStop = True
        Me.lnkBrandsOfTheWorld.Text = "www.brandsoftheworld.com"
        '
        'Label24
        '
        Label24.AutoSize = True
        Label24.Location = New System.Drawing.Point(16, 112)
        Label24.Name = "Label24"
        Label24.Size = New System.Drawing.Size(201, 13)
        Label24.TabIndex = 28
        Label24.Text = "Most logos are from Brands of the World"
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label1.Location = New System.Drawing.Point(0, 48)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(136, 13)
        Label1.TabIndex = 0
        Label1.Text = "HDD Guardian graphics"
        '
        'Label21
        '
        Label21.AutoSize = True
        Label21.Location = New System.Drawing.Point(16, 64)
        Label21.Name = "Label21"
        Label21.Size = New System.Drawing.Size(64, 13)
        Label21.TabIndex = 7
        Label21.Text = "Fugue icons"
        '
        'Label23
        '
        Label23.AutoSize = True
        Label23.Location = New System.Drawing.Point(136, 88)
        Label23.Name = "Label23"
        Label23.Size = New System.Drawing.Size(63, 13)
        Label23.TabIndex = 27
        Label23.Text = "Mark James"
        '
        'Label22
        '
        Label22.AutoSize = True
        Label22.Location = New System.Drawing.Point(136, 64)
        Label22.Name = "Label22"
        Label22.Size = New System.Drawing.Size(104, 13)
        Label22.TabIndex = 8
        Label22.Text = "Yusuke Kamiyamane"
        '
        'lnkFamFamFam
        '
        Me.lnkFamFamFam.AutoSize = True
        Me.lnkFamFamFam.Location = New System.Drawing.Point(336, 88)
        Me.lnkFamFamFam.Name = "lnkFamFamFam"
        Me.lnkFamFamFam.Size = New System.Drawing.Size(221, 13)
        Me.lnkFamFamFam.TabIndex = 4
        Me.lnkFamFamFam.TabStop = True
        Me.lnkFamFamFam.Text = "http://www.famfamfam.com/lab/icons/flags/"
        '
        'lnkKamiyamane
        '
        Me.lnkKamiyamane.AutoSize = True
        Me.lnkKamiyamane.Location = New System.Drawing.Point(336, 64)
        Me.lnkKamiyamane.Name = "lnkKamiyamane"
        Me.lnkKamiyamane.Size = New System.Drawing.Size(169, 13)
        Me.lnkKamiyamane.TabIndex = 3
        Me.lnkKamiyamane.TabStop = True
        Me.lnkKamiyamane.Text = "http://p.yusukekamiyamane.com/"
        '
        'Label33
        '
        Label33.AutoSize = True
        Label33.Location = New System.Drawing.Point(16, 88)
        Label33.Name = "Label33"
        Label33.Size = New System.Drawing.Size(59, 13)
        Label33.TabIndex = 6
        Label33.Text = "Flags icons"
        '
        'tpLicense
        '
        tpLicense.AutoScroll = True
        tpLicense.Controls.Add(Me.lblLicense)
        tpLicense.Location = New System.Drawing.Point(4, 22)
        tpLicense.Name = "tpLicense"
        tpLicense.Size = New System.Drawing.Size(560, 294)
        tpLicense.TabIndex = 3
        tpLicense.Text = "License"
        tpLicense.UseVisualStyleBackColor = True
        '
        'lblLicense
        '
        Me.lblLicense.AutoSize = True
        Me.lblLicense.Location = New System.Drawing.Point(8, 8)
        Me.lblLicense.MaximumSize = New System.Drawing.Size(544, 0)
        Me.lblLicense.MinimumSize = New System.Drawing.Size(544, 0)
        Me.lblLicense.Name = "lblLicense"
        Me.lblLicense.Size = New System.Drawing.Size(544, 13)
        Me.lblLicense.TabIndex = 0
        Me.lblLicense.Text = "lblLicense"
        '
        'Label6
        '
        Label6.AutoSize = True
        Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label6.Location = New System.Drawing.Point(0, 32)
        Label6.Name = "Label6"
        Label6.Size = New System.Drawing.Size(72, 13)
        Label6.TabIndex = 0
        Label6.Text = "Translators"
        '
        'Label7
        '
        Label7.AutoSize = True
        Label7.Location = New System.Drawing.Point(24, 48)
        Label7.Name = "Label7"
        Label7.Size = New System.Drawing.Size(106, 13)
        Label7.TabIndex = 1
        Label7.Text = "Kutfej Béla (magyar)"
        '
        'Label8
        '
        Label8.AutoSize = True
        Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label8.Location = New System.Drawing.Point(0, 168)
        Label8.Name = "Label8"
        Label8.Size = New System.Drawing.Size(50, 13)
        Label8.TabIndex = 2
        Label8.Text = "Testers"
        '
        'Label9
        '
        Label9.AutoSize = True
        Label9.Location = New System.Drawing.Point(24, 184)
        Label9.Name = "Label9"
        Label9.Size = New System.Drawing.Size(76, 13)
        Label9.TabIndex = 3
        Label9.Text = "Carolo Andrea"
        '
        'Label10
        '
        Label10.AutoSize = True
        Label10.Location = New System.Drawing.Point(0, 8)
        Label10.Name = "Label10"
        Label10.Size = New System.Drawing.Size(423, 13)
        Label10.TabIndex = 4
        Label10.Text = "Thanks to all the peolpe that have supported this project with their spontaneous " & _
            "work!"
        '
        'pnlRefresh
        '
        pnlRefresh.Controls.Add(Me.tlpUpdate)
        pnlRefresh.Controls.Add(Me.lblUpdate)
        pnlRefresh.Location = New System.Drawing.Point(24, 8)
        pnlRefresh.Name = "pnlRefresh"
        pnlRefresh.Size = New System.Drawing.Size(528, 136)
        pnlRefresh.TabIndex = 16
        '
        'tlpUpdate
        '
        Me.tlpUpdate.ColumnCount = 3
        Me.tlpUpdate.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpUpdate.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpUpdate.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpUpdate.Controls.Add(Me.lblVirtual, 0, 2)
        Me.tlpUpdate.Controls.Add(Me.numUpdateVirtual, 1, 2)
        Me.tlpUpdate.Controls.Add(Me.lblMinutesVirt, 2, 2)
        Me.tlpUpdate.Controls.Add(Me.lblExternal, 0, 1)
        Me.tlpUpdate.Controls.Add(Me.numUpdateExt, 1, 1)
        Me.tlpUpdate.Controls.Add(Me.lblMinutesExt, 2, 1)
        Me.tlpUpdate.Controls.Add(Me.lblMinutes, 2, 0)
        Me.tlpUpdate.Controls.Add(Me.numUpdate, 1, 0)
        Me.tlpUpdate.Controls.Add(Me.lblInternal, 0, 0)
        Me.tlpUpdate.Location = New System.Drawing.Point(0, 24)
        Me.tlpUpdate.Name = "tlpUpdate"
        Me.tlpUpdate.RowCount = 3
        Me.tlpUpdate.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpUpdate.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpUpdate.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpUpdate.Size = New System.Drawing.Size(520, 88)
        Me.tlpUpdate.TabIndex = 1
        '
        'lblVirtual
        '
        Me.lblVirtual.AutoSize = True
        Me.lblVirtual.Location = New System.Drawing.Point(0, 55)
        Me.lblVirtual.Margin = New System.Windows.Forms.Padding(0, 1, 3, 3)
        Me.lblVirtual.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblVirtual.Name = "lblVirtual"
        Me.lblVirtual.Size = New System.Drawing.Size(47, 21)
        Me.lblVirtual.TabIndex = 9
        Me.lblVirtual.Text = "lblVirtual"
        Me.lblVirtual.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'numUpdateVirtual
        '
        Me.numUpdateVirtual.Location = New System.Drawing.Point(63, 57)
        Me.numUpdateVirtual.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.numUpdateVirtual.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numUpdateVirtual.Name = "numUpdateVirtual"
        Me.numUpdateVirtual.ReadOnly = True
        Me.numUpdateVirtual.Size = New System.Drawing.Size(40, 21)
        Me.numUpdateVirtual.TabIndex = 8
        Me.numUpdateVirtual.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numUpdateVirtual.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'lblMinutesVirt
        '
        Me.lblMinutesVirt.AutoSize = True
        Me.lblMinutesVirt.Location = New System.Drawing.Point(109, 55)
        Me.lblMinutesVirt.Margin = New System.Windows.Forms.Padding(3, 1, 3, 3)
        Me.lblMinutesVirt.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblMinutesVirt.Name = "lblMinutesVirt"
        Me.lblMinutesVirt.Size = New System.Drawing.Size(70, 21)
        Me.lblMinutesVirt.TabIndex = 10
        Me.lblMinutesVirt.Text = "lblMinutesVirt"
        Me.lblMinutesVirt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblExternal
        '
        Me.lblExternal.AutoSize = True
        Me.lblExternal.Location = New System.Drawing.Point(0, 28)
        Me.lblExternal.Margin = New System.Windows.Forms.Padding(0, 1, 3, 3)
        Me.lblExternal.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblExternal.Name = "lblExternal"
        Me.lblExternal.Size = New System.Drawing.Size(57, 21)
        Me.lblExternal.TabIndex = 6
        Me.lblExternal.Text = "lblExternal"
        Me.lblExternal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'numUpdateExt
        '
        Me.numUpdateExt.Location = New System.Drawing.Point(63, 30)
        Me.numUpdateExt.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.numUpdateExt.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numUpdateExt.Name = "numUpdateExt"
        Me.numUpdateExt.ReadOnly = True
        Me.numUpdateExt.Size = New System.Drawing.Size(40, 21)
        Me.numUpdateExt.TabIndex = 5
        Me.numUpdateExt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numUpdateExt.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'lblMinutesExt
        '
        Me.lblMinutesExt.AutoSize = True
        Me.lblMinutesExt.Location = New System.Drawing.Point(109, 28)
        Me.lblMinutesExt.Margin = New System.Windows.Forms.Padding(3, 1, 3, 3)
        Me.lblMinutesExt.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblMinutesExt.Name = "lblMinutesExt"
        Me.lblMinutesExt.Size = New System.Drawing.Size(70, 21)
        Me.lblMinutesExt.TabIndex = 7
        Me.lblMinutesExt.Text = "lblMinutesExt"
        Me.lblMinutesExt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblMinutes
        '
        Me.lblMinutes.AutoSize = True
        Me.lblMinutes.Location = New System.Drawing.Point(109, 1)
        Me.lblMinutes.Margin = New System.Windows.Forms.Padding(3, 1, 3, 3)
        Me.lblMinutes.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblMinutes.Name = "lblMinutes"
        Me.lblMinutes.Size = New System.Drawing.Size(54, 21)
        Me.lblMinutes.TabIndex = 3
        Me.lblMinutes.Text = "lblMinutes"
        Me.lblMinutes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'numUpdate
        '
        Me.numUpdate.Location = New System.Drawing.Point(63, 3)
        Me.numUpdate.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.numUpdate.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numUpdate.Name = "numUpdate"
        Me.numUpdate.ReadOnly = True
        Me.numUpdate.Size = New System.Drawing.Size(40, 21)
        Me.numUpdate.TabIndex = 0
        Me.numUpdate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numUpdate.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'lblInternal
        '
        Me.lblInternal.AutoSize = True
        Me.lblInternal.Location = New System.Drawing.Point(0, 1)
        Me.lblInternal.Margin = New System.Windows.Forms.Padding(0, 1, 3, 3)
        Me.lblInternal.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblInternal.Name = "lblInternal"
        Me.lblInternal.Size = New System.Drawing.Size(55, 21)
        Me.lblInternal.TabIndex = 4
        Me.lblInternal.Text = "lblInternal"
        Me.lblInternal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblUpdate
        '
        Me.lblUpdate.AutoSize = True
        Me.lblUpdate.Location = New System.Drawing.Point(0, 0)
        Me.lblUpdate.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblUpdate.Name = "lblUpdate"
        Me.lblUpdate.Size = New System.Drawing.Size(52, 16)
        Me.lblUpdate.TabIndex = 0
        Me.lblUpdate.Text = "lblUpdate"
        Me.lblUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tlpParameters
        '
        tlpParameters.ColumnCount = 2
        tlpParameters.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpParameters.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpParameters.Controls.Add(Me.chkReallSectCt, 0, 0)
        tlpParameters.Controls.Add(Me.chkSpinRetryCt, 0, 1)
        tlpParameters.Controls.Add(Me.chkTemp, 0, 2)
        tlpParameters.Controls.Add(Me.chkReallEvCt, 0, 3)
        tlpParameters.Controls.Add(Me.chkCurPenSect, 1, 0)
        tlpParameters.Controls.Add(Me.chkOfflUnc, 1, 1)
        tlpParameters.Controls.Add(Me.chkSoftReadErr, 1, 2)
        tlpParameters.Controls.Add(Me.lnkInvertSel, 1, 4)
        tlpParameters.Controls.Add(Me.chkDiskShift, 1, 3)
        flwMonitoring.SetFlowBreak(tlpParameters, True)
        tlpParameters.Location = New System.Drawing.Point(0, 16)
        tlpParameters.Margin = New System.Windows.Forms.Padding(0, 3, 3, 3)
        tlpParameters.Name = "tlpParameters"
        tlpParameters.RowCount = 5
        tlpParameters.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpParameters.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpParameters.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpParameters.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpParameters.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpParameters.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpParameters.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpParameters.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpParameters.Size = New System.Drawing.Size(525, 120)
        tlpParameters.TabIndex = 21
        '
        'chkReallSectCt
        '
        Me.chkReallSectCt.AutoSize = True
        Me.chkReallSectCt.Location = New System.Drawing.Point(3, 3)
        Me.chkReallSectCt.Name = "chkReallSectCt"
        Me.chkReallSectCt.Size = New System.Drawing.Size(97, 17)
        Me.chkReallSectCt.TabIndex = 0
        Me.chkReallSectCt.Text = "chkReallSectCt"
        Me.chkReallSectCt.UseVisualStyleBackColor = True
        '
        'chkSpinRetryCt
        '
        Me.chkSpinRetryCt.AutoSize = True
        Me.chkSpinRetryCt.Location = New System.Drawing.Point(3, 26)
        Me.chkSpinRetryCt.Name = "chkSpinRetryCt"
        Me.chkSpinRetryCt.Size = New System.Drawing.Size(100, 17)
        Me.chkSpinRetryCt.TabIndex = 1
        Me.chkSpinRetryCt.Text = "chkSpinRetryCt"
        Me.chkSpinRetryCt.UseVisualStyleBackColor = True
        '
        'chkTemp
        '
        Me.chkTemp.AutoSize = True
        Me.chkTemp.Location = New System.Drawing.Point(3, 49)
        Me.chkTemp.Name = "chkTemp"
        Me.chkTemp.Size = New System.Drawing.Size(68, 17)
        Me.chkTemp.TabIndex = 2
        Me.chkTemp.Text = "chkTemp"
        Me.chkTemp.UseVisualStyleBackColor = True
        '
        'chkReallEvCt
        '
        Me.chkReallEvCt.AutoSize = True
        Me.chkReallEvCt.Location = New System.Drawing.Point(3, 72)
        Me.chkReallEvCt.Name = "chkReallEvCt"
        Me.chkReallEvCt.Size = New System.Drawing.Size(88, 17)
        Me.chkReallEvCt.TabIndex = 3
        Me.chkReallEvCt.Text = "chkReallEvCt"
        Me.chkReallEvCt.UseVisualStyleBackColor = True
        '
        'chkCurPenSect
        '
        Me.chkCurPenSect.AutoSize = True
        Me.chkCurPenSect.Location = New System.Drawing.Point(265, 3)
        Me.chkCurPenSect.Name = "chkCurPenSect"
        Me.chkCurPenSect.Size = New System.Drawing.Size(98, 17)
        Me.chkCurPenSect.TabIndex = 4
        Me.chkCurPenSect.Text = "chkCurPenSect"
        Me.chkCurPenSect.UseVisualStyleBackColor = True
        '
        'chkOfflUnc
        '
        Me.chkOfflUnc.AutoSize = True
        Me.chkOfflUnc.Location = New System.Drawing.Point(265, 26)
        Me.chkOfflUnc.Name = "chkOfflUnc"
        Me.chkOfflUnc.Size = New System.Drawing.Size(78, 17)
        Me.chkOfflUnc.TabIndex = 5
        Me.chkOfflUnc.Text = "chkOfflUnc"
        Me.chkOfflUnc.UseVisualStyleBackColor = True
        '
        'chkSoftReadErr
        '
        Me.chkSoftReadErr.AutoSize = True
        Me.chkSoftReadErr.Location = New System.Drawing.Point(265, 49)
        Me.chkSoftReadErr.Name = "chkSoftReadErr"
        Me.chkSoftReadErr.Size = New System.Drawing.Size(101, 17)
        Me.chkSoftReadErr.TabIndex = 6
        Me.chkSoftReadErr.Text = "chkSoftReadErr"
        Me.chkSoftReadErr.UseVisualStyleBackColor = True
        '
        'lnkInvertSel
        '
        Me.lnkInvertSel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lnkInvertSel.AutoSize = True
        Me.lnkInvertSel.Location = New System.Drawing.Point(458, 95)
        Me.lnkInvertSel.Margin = New System.Windows.Forms.Padding(3)
        Me.lnkInvertSel.MinimumSize = New System.Drawing.Size(0, 17)
        Me.lnkInvertSel.Name = "lnkInvertSel"
        Me.lnkInvertSel.Size = New System.Drawing.Size(64, 17)
        Me.lnkInvertSel.TabIndex = 8
        Me.lnkInvertSel.TabStop = True
        Me.lnkInvertSel.Text = "lnkInvertSel"
        Me.lnkInvertSel.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'chkDiskShift
        '
        Me.chkDiskShift.AutoSize = True
        Me.chkDiskShift.Location = New System.Drawing.Point(265, 72)
        Me.chkDiskShift.Name = "chkDiskShift"
        Me.chkDiskShift.Size = New System.Drawing.Size(83, 17)
        Me.chkDiskShift.TabIndex = 7
        Me.chkDiskShift.Text = "chkDiskShift"
        Me.chkDiskShift.UseVisualStyleBackColor = True
        '
        'tlpSSD
        '
        tlpSSD.ColumnCount = 2
        tlpSSD.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpSSD.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        tlpSSD.Controls.Add(Me.chkIndilinx, 0, 0)
        tlpSSD.Controls.Add(Me.lnkInvertSelSSD, 1, 3)
        tlpSSD.Controls.Add(Me.chkSandForce, 1, 1)
        tlpSSD.Controls.Add(Me.chkIntel, 0, 1)
        tlpSSD.Controls.Add(Me.chkSamsung, 1, 0)
        tlpSSD.Controls.Add(Me.chkMicron, 0, 2)
        tlpSSD.Location = New System.Drawing.Point(0, 155)
        tlpSSD.Margin = New System.Windows.Forms.Padding(0, 3, 3, 3)
        tlpSSD.Name = "tlpSSD"
        tlpSSD.RowCount = 4
        tlpSSD.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpSSD.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpSSD.RowStyles.Add(New System.Windows.Forms.RowStyle())
        tlpSSD.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpSSD.Size = New System.Drawing.Size(525, 96)
        tlpSSD.TabIndex = 21
        '
        'chkIndilinx
        '
        Me.chkIndilinx.AutoSize = True
        Me.chkIndilinx.Location = New System.Drawing.Point(3, 3)
        Me.chkIndilinx.Name = "chkIndilinx"
        Me.chkIndilinx.Size = New System.Drawing.Size(76, 17)
        Me.chkIndilinx.TabIndex = 10
        Me.chkIndilinx.Text = "chkIndilinx"
        Me.chkIndilinx.UseVisualStyleBackColor = True
        '
        'lnkInvertSelSSD
        '
        Me.lnkInvertSelSSD.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lnkInvertSelSSD.AutoSize = True
        Me.lnkInvertSelSSD.Location = New System.Drawing.Point(439, 72)
        Me.lnkInvertSelSSD.Margin = New System.Windows.Forms.Padding(3)
        Me.lnkInvertSelSSD.MinimumSize = New System.Drawing.Size(0, 17)
        Me.lnkInvertSelSSD.Name = "lnkInvertSelSSD"
        Me.lnkInvertSelSSD.Size = New System.Drawing.Size(83, 17)
        Me.lnkInvertSelSSD.TabIndex = 8
        Me.lnkInvertSelSSD.TabStop = True
        Me.lnkInvertSelSSD.Text = "lnkInvertSelSSD"
        Me.lnkInvertSelSSD.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'chkSandForce
        '
        Me.chkSandForce.AutoSize = True
        Me.chkSandForce.Location = New System.Drawing.Point(265, 26)
        Me.chkSandForce.Name = "chkSandForce"
        Me.chkSandForce.Size = New System.Drawing.Size(93, 17)
        Me.chkSandForce.TabIndex = 14
        Me.chkSandForce.Text = "chkSandForce"
        Me.chkSandForce.UseVisualStyleBackColor = True
        '
        'chkIntel
        '
        Me.chkIntel.AutoSize = True
        Me.chkIntel.Location = New System.Drawing.Point(3, 26)
        Me.chkIntel.Name = "chkIntel"
        Me.chkIntel.Size = New System.Drawing.Size(64, 17)
        Me.chkIntel.TabIndex = 11
        Me.chkIntel.Text = "chkIntel"
        Me.chkIntel.UseVisualStyleBackColor = True
        '
        'chkSamsung
        '
        Me.chkSamsung.AutoSize = True
        Me.chkSamsung.Location = New System.Drawing.Point(265, 3)
        Me.chkSamsung.Name = "chkSamsung"
        Me.chkSamsung.Size = New System.Drawing.Size(85, 17)
        Me.chkSamsung.TabIndex = 13
        Me.chkSamsung.Text = "chkSamsung"
        Me.chkSamsung.UseVisualStyleBackColor = True
        '
        'chkMicron
        '
        Me.chkMicron.AutoSize = True
        Me.chkMicron.Location = New System.Drawing.Point(3, 49)
        Me.chkMicron.Name = "chkMicron"
        Me.chkMicron.Size = New System.Drawing.Size(73, 17)
        Me.chkMicron.TabIndex = 12
        Me.chkMicron.Text = "chkMicron"
        Me.chkMicron.UseVisualStyleBackColor = True
        '
        'flwMonitoring
        '
        flwMonitoring.Controls.Add(Me.lblGeneric)
        flwMonitoring.Controls.Add(tlpParameters)
        flwMonitoring.Controls.Add(Me.lblSSD)
        flwMonitoring.Controls.Add(tlpSSD)
        flwMonitoring.Location = New System.Drawing.Point(24, 32)
        flwMonitoring.Name = "flwMonitoring"
        flwMonitoring.Size = New System.Drawing.Size(528, 256)
        flwMonitoring.TabIndex = 23
        '
        'lblGeneric
        '
        Me.lblGeneric.AutoSize = True
        flwMonitoring.SetFlowBreak(Me.lblGeneric, True)
        Me.lblGeneric.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGeneric.Location = New System.Drawing.Point(0, 0)
        Me.lblGeneric.Margin = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.lblGeneric.Name = "lblGeneric"
        Me.lblGeneric.Size = New System.Drawing.Size(63, 13)
        Me.lblGeneric.TabIndex = 0
        Me.lblGeneric.Text = "lblGeneric"
        '
        'lblSSD
        '
        Me.lblSSD.AutoSize = True
        Me.lblSSD.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSSD.Location = New System.Drawing.Point(0, 139)
        Me.lblSSD.Margin = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.lblSSD.Name = "lblSSD"
        Me.lblSSD.Size = New System.Drawing.Size(42, 13)
        Me.lblSSD.TabIndex = 22
        Me.lblSSD.Text = "lblSSD"
        '
        'flwXml
        '
        flwXml.AutoSize = True
        flwXml.Controls.Add(Me.lblXml)
        flwXml.Controls.Add(Me.btnXml)
        flwXml.Controls.Add(Me.lblXmlPath)
        flwXml.Location = New System.Drawing.Point(24, 112)
        flwXml.MaximumSize = New System.Drawing.Size(528, 0)
        flwXml.Name = "flwXml"
        flwXml.Size = New System.Drawing.Size(528, 0)
        flwXml.TabIndex = 21
        '
        'lblXml
        '
        Me.lblXml.AutoSize = True
        flwXml.SetFlowBreak(Me.lblXml, True)
        Me.lblXml.Location = New System.Drawing.Point(3, 0)
        Me.lblXml.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblXml.Name = "lblXml"
        Me.lblXml.Size = New System.Drawing.Size(34, 16)
        Me.lblXml.TabIndex = 20
        Me.lblXml.Text = "lblXml"
        Me.lblXml.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnXml
        '
        flwXml.SetFlowBreak(Me.btnXml, True)
        Me.btnXml.Location = New System.Drawing.Point(0, 23)
        Me.btnXml.Margin = New System.Windows.Forms.Padding(0)
        Me.btnXml.Name = "btnXml"
        Me.btnXml.Size = New System.Drawing.Size(75, 23)
        Me.btnXml.TabIndex = 0
        Me.btnXml.Text = "btnXml"
        Me.btnXml.UseVisualStyleBackColor = True
        '
        'lblXmlPath
        '
        Me.lblXmlPath.AutoSize = True
        flwXml.SetFlowBreak(Me.lblXmlPath, True)
        Me.lblXmlPath.ForeColor = System.Drawing.Color.DimGray
        Me.lblXmlPath.Location = New System.Drawing.Point(3, 46)
        Me.lblXmlPath.MinimumSize = New System.Drawing.Size(0, 23)
        Me.lblXmlPath.Name = "lblXmlPath"
        Me.lblXmlPath.Size = New System.Drawing.Size(56, 23)
        Me.lblXmlPath.TabIndex = 1
        Me.lblXmlPath.Text = "lblXmlPath"
        Me.lblXmlPath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripSeparator3
        '
        ToolStripSeparator3.Name = "ToolStripSeparator3"
        ToolStripSeparator3.Size = New System.Drawing.Size(174, 6)
        '
        'ToolStripSeparator5
        '
        ToolStripSeparator5.Name = "ToolStripSeparator5"
        ToolStripSeparator5.Size = New System.Drawing.Size(192, 6)
        '
        'tlpReliability
        '
        tlpReliability.BackColor = System.Drawing.Color.Transparent
        tlpReliability.ColumnCount = 3
        tlpReliability.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        tlpReliability.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 54.0!))
        tlpReliability.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        tlpReliability.Controls.Add(lblHDD, 0, 0)
        tlpReliability.Controls.Add(Me.lblErrors, 0, 1)
        tlpReliability.Controls.Add(Me.lblReallSect, 0, 2)
        tlpReliability.Controls.Add(Me.lblCurPending, 0, 3)
        tlpReliability.Controls.Add(Me.lblOfflUnc, 0, 4)
        tlpReliability.Controls.Add(Label16, 0, 6)
        tlpReliability.Controls.Add(Me.lblIndilinx, 0, 7)
        tlpReliability.Controls.Add(Me.lblIntel, 0, 8)
        tlpReliability.Controls.Add(Me.lblMicron, 0, 9)
        tlpReliability.Controls.Add(Me.lblSamsung, 0, 10)
        tlpReliability.Controls.Add(Me.lblSandForce, 0, 11)
        tlpReliability.Controls.Add(Me.picErrors, 1, 1)
        tlpReliability.Controls.Add(Me.picReallSect, 1, 2)
        tlpReliability.Controls.Add(Me.picCurPending, 1, 3)
        tlpReliability.Controls.Add(Me.picOfflUnc, 1, 4)
        tlpReliability.Controls.Add(Me.picIndilinx, 1, 7)
        tlpReliability.Controls.Add(Me.picIntel, 1, 8)
        tlpReliability.Controls.Add(Me.picMicron, 1, 9)
        tlpReliability.Controls.Add(Me.picSamsung, 1, 10)
        tlpReliability.Controls.Add(Me.picSandForce, 1, 11)
        tlpReliability.Controls.Add(Me.lblErrValue, 2, 1)
        tlpReliability.Controls.Add(Me.lblReallSectValue, 2, 2)
        tlpReliability.Controls.Add(Me.lblCurPendingValue, 2, 3)
        tlpReliability.Controls.Add(Me.lblOfflUncValue, 2, 4)
        tlpReliability.Controls.Add(Me.lblIndilinxValue, 2, 7)
        tlpReliability.Controls.Add(Me.lblIntelValue, 2, 8)
        tlpReliability.Controls.Add(Me.lblMicronValue, 2, 9)
        tlpReliability.Controls.Add(Me.lblSamsungValue, 2, 10)
        tlpReliability.Controls.Add(Me.lblSandForceValue, 2, 11)
        tlpReliability.Dock = System.Windows.Forms.DockStyle.Fill
        tlpReliability.Location = New System.Drawing.Point(0, 0)
        tlpReliability.Name = "tlpReliability"
        tlpReliability.RowCount = 13
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        tlpReliability.Size = New System.Drawing.Size(560, 294)
        tlpReliability.TabIndex = 1
        '
        'lblHDD
        '
        lblHDD.Anchor = System.Windows.Forms.AnchorStyles.Left
        lblHDD.AutoEllipsis = True
        lblHDD.AutoSize = True
        lblHDD.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblHDD.Location = New System.Drawing.Point(3, 3)
        lblHDD.Name = "lblHDD"
        lblHDD.Size = New System.Drawing.Size(100, 13)
        lblHDD.TabIndex = 0
        lblHDD.Text = "Hard Disk Drives"
        '
        'lblErrors
        '
        Me.lblErrors.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblErrors.AutoEllipsis = True
        Me.lblErrors.AutoSize = True
        Me.lblErrors.Location = New System.Drawing.Point(3, 23)
        Me.lblErrors.Name = "lblErrors"
        Me.lblErrors.Size = New System.Drawing.Size(46, 13)
        Me.lblErrors.TabIndex = 1
        Me.lblErrors.Text = "lblErrors"
        '
        'lblReallSect
        '
        Me.lblReallSect.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblReallSect.AutoEllipsis = True
        Me.lblReallSect.AutoSize = True
        Me.lblReallSect.Location = New System.Drawing.Point(3, 43)
        Me.lblReallSect.Name = "lblReallSect"
        Me.lblReallSect.Size = New System.Drawing.Size(61, 13)
        Me.lblReallSect.TabIndex = 3
        Me.lblReallSect.Text = "lblReallSect"
        '
        'lblCurPending
        '
        Me.lblCurPending.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblCurPending.AutoEllipsis = True
        Me.lblCurPending.AutoSize = True
        Me.lblCurPending.Location = New System.Drawing.Point(3, 63)
        Me.lblCurPending.Name = "lblCurPending"
        Me.lblCurPending.Size = New System.Drawing.Size(72, 13)
        Me.lblCurPending.TabIndex = 4
        Me.lblCurPending.Text = "lblCurPending"
        '
        'lblOfflUnc
        '
        Me.lblOfflUnc.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblOfflUnc.AutoEllipsis = True
        Me.lblOfflUnc.AutoSize = True
        Me.lblOfflUnc.Location = New System.Drawing.Point(3, 83)
        Me.lblOfflUnc.Name = "lblOfflUnc"
        Me.lblOfflUnc.Size = New System.Drawing.Size(53, 13)
        Me.lblOfflUnc.TabIndex = 5
        Me.lblOfflUnc.Text = "lblOfflUnc"
        '
        'Label16
        '
        Label16.Anchor = System.Windows.Forms.AnchorStyles.Left
        Label16.AutoEllipsis = True
        Label16.AutoSize = True
        Label16.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label16.Location = New System.Drawing.Point(3, 123)
        Label16.Name = "Label16"
        Label16.Size = New System.Drawing.Size(101, 13)
        Label16.TabIndex = 6
        Label16.Text = "Solid State Disks"
        '
        'lblIndilinx
        '
        Me.lblIndilinx.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblIndilinx.AutoEllipsis = True
        Me.lblIndilinx.AutoSize = True
        Me.lblIndilinx.Location = New System.Drawing.Point(3, 143)
        Me.lblIndilinx.Name = "lblIndilinx"
        Me.lblIndilinx.Size = New System.Drawing.Size(51, 13)
        Me.lblIndilinx.TabIndex = 7
        Me.lblIndilinx.Text = "lblIndilinx"
        '
        'lblIntel
        '
        Me.lblIntel.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblIntel.AutoEllipsis = True
        Me.lblIntel.AutoSize = True
        Me.lblIntel.Location = New System.Drawing.Point(3, 163)
        Me.lblIntel.Name = "lblIntel"
        Me.lblIntel.Size = New System.Drawing.Size(39, 13)
        Me.lblIntel.TabIndex = 8
        Me.lblIntel.Text = "lblIntel"
        '
        'lblMicron
        '
        Me.lblMicron.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblMicron.AutoEllipsis = True
        Me.lblMicron.AutoSize = True
        Me.lblMicron.Location = New System.Drawing.Point(3, 183)
        Me.lblMicron.Name = "lblMicron"
        Me.lblMicron.Size = New System.Drawing.Size(48, 13)
        Me.lblMicron.TabIndex = 9
        Me.lblMicron.Text = "lblMicron"
        '
        'lblSamsung
        '
        Me.lblSamsung.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblSamsung.AutoEllipsis = True
        Me.lblSamsung.AutoSize = True
        Me.lblSamsung.Location = New System.Drawing.Point(3, 203)
        Me.lblSamsung.Name = "lblSamsung"
        Me.lblSamsung.Size = New System.Drawing.Size(60, 13)
        Me.lblSamsung.TabIndex = 10
        Me.lblSamsung.Text = "lblSamsung"
        '
        'lblSandForce
        '
        Me.lblSandForce.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblSandForce.AutoEllipsis = True
        Me.lblSandForce.AutoSize = True
        Me.lblSandForce.Location = New System.Drawing.Point(3, 223)
        Me.lblSandForce.Name = "lblSandForce"
        Me.lblSandForce.Size = New System.Drawing.Size(68, 13)
        Me.lblSandForce.TabIndex = 11
        Me.lblSandForce.Text = "lblSandForce"
        '
        'picErrors
        '
        Me.picErrors.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picErrors.Location = New System.Drawing.Point(110, 26)
        Me.picErrors.Name = "picErrors"
        Me.picErrors.Size = New System.Drawing.Size(48, 8)
        Me.picErrors.TabIndex = 12
        Me.picErrors.TabStop = False
        '
        'picReallSect
        '
        Me.picReallSect.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picReallSect.Location = New System.Drawing.Point(110, 46)
        Me.picReallSect.Name = "picReallSect"
        Me.picReallSect.Size = New System.Drawing.Size(48, 8)
        Me.picReallSect.TabIndex = 13
        Me.picReallSect.TabStop = False
        '
        'picCurPending
        '
        Me.picCurPending.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picCurPending.Location = New System.Drawing.Point(110, 66)
        Me.picCurPending.Name = "picCurPending"
        Me.picCurPending.Size = New System.Drawing.Size(48, 8)
        Me.picCurPending.TabIndex = 14
        Me.picCurPending.TabStop = False
        '
        'picOfflUnc
        '
        Me.picOfflUnc.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picOfflUnc.Location = New System.Drawing.Point(110, 86)
        Me.picOfflUnc.Name = "picOfflUnc"
        Me.picOfflUnc.Size = New System.Drawing.Size(48, 8)
        Me.picOfflUnc.TabIndex = 15
        Me.picOfflUnc.TabStop = False
        '
        'picIndilinx
        '
        Me.picIndilinx.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picIndilinx.Location = New System.Drawing.Point(110, 146)
        Me.picIndilinx.Name = "picIndilinx"
        Me.picIndilinx.Size = New System.Drawing.Size(48, 8)
        Me.picIndilinx.TabIndex = 17
        Me.picIndilinx.TabStop = False
        '
        'picIntel
        '
        Me.picIntel.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picIntel.Location = New System.Drawing.Point(110, 166)
        Me.picIntel.Name = "picIntel"
        Me.picIntel.Size = New System.Drawing.Size(48, 8)
        Me.picIntel.TabIndex = 18
        Me.picIntel.TabStop = False
        '
        'picMicron
        '
        Me.picMicron.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picMicron.Location = New System.Drawing.Point(110, 186)
        Me.picMicron.Name = "picMicron"
        Me.picMicron.Size = New System.Drawing.Size(48, 8)
        Me.picMicron.TabIndex = 19
        Me.picMicron.TabStop = False
        '
        'picSamsung
        '
        Me.picSamsung.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picSamsung.Location = New System.Drawing.Point(110, 206)
        Me.picSamsung.Name = "picSamsung"
        Me.picSamsung.Size = New System.Drawing.Size(48, 8)
        Me.picSamsung.TabIndex = 20
        Me.picSamsung.TabStop = False
        '
        'picSandForce
        '
        Me.picSandForce.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picSandForce.Location = New System.Drawing.Point(110, 226)
        Me.picSandForce.Name = "picSandForce"
        Me.picSandForce.Size = New System.Drawing.Size(48, 8)
        Me.picSandForce.TabIndex = 21
        Me.picSandForce.TabStop = False
        '
        'lblErrValue
        '
        Me.lblErrValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblErrValue.AutoEllipsis = True
        Me.lblErrValue.AutoSize = True
        Me.lblErrValue.Location = New System.Drawing.Point(164, 23)
        Me.lblErrValue.Name = "lblErrValue"
        Me.lblErrValue.Size = New System.Drawing.Size(57, 13)
        Me.lblErrValue.TabIndex = 22
        Me.lblErrValue.Text = "lblErrValue"
        '
        'lblReallSectValue
        '
        Me.lblReallSectValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblReallSectValue.AutoEllipsis = True
        Me.lblReallSectValue.AutoSize = True
        Me.lblReallSectValue.Location = New System.Drawing.Point(164, 43)
        Me.lblReallSectValue.Name = "lblReallSectValue"
        Me.lblReallSectValue.Size = New System.Drawing.Size(87, 13)
        Me.lblReallSectValue.TabIndex = 23
        Me.lblReallSectValue.Text = "lblReallSectValue"
        '
        'lblCurPendingValue
        '
        Me.lblCurPendingValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblCurPendingValue.AutoEllipsis = True
        Me.lblCurPendingValue.AutoSize = True
        Me.lblCurPendingValue.Location = New System.Drawing.Point(164, 63)
        Me.lblCurPendingValue.Name = "lblCurPendingValue"
        Me.lblCurPendingValue.Size = New System.Drawing.Size(98, 13)
        Me.lblCurPendingValue.TabIndex = 24
        Me.lblCurPendingValue.Text = "lblCurPendingValue"
        '
        'lblOfflUncValue
        '
        Me.lblOfflUncValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblOfflUncValue.AutoEllipsis = True
        Me.lblOfflUncValue.AutoSize = True
        Me.lblOfflUncValue.Location = New System.Drawing.Point(164, 83)
        Me.lblOfflUncValue.Name = "lblOfflUncValue"
        Me.lblOfflUncValue.Size = New System.Drawing.Size(79, 13)
        Me.lblOfflUncValue.TabIndex = 25
        Me.lblOfflUncValue.Text = "lblOfflUncValue"
        '
        'lblIndilinxValue
        '
        Me.lblIndilinxValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblIndilinxValue.AutoEllipsis = True
        Me.lblIndilinxValue.AutoSize = True
        Me.lblIndilinxValue.Location = New System.Drawing.Point(164, 143)
        Me.lblIndilinxValue.Name = "lblIndilinxValue"
        Me.lblIndilinxValue.Size = New System.Drawing.Size(77, 13)
        Me.lblIndilinxValue.TabIndex = 26
        Me.lblIndilinxValue.Text = "lblIndilinxValue"
        '
        'lblIntelValue
        '
        Me.lblIntelValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblIntelValue.AutoEllipsis = True
        Me.lblIntelValue.AutoSize = True
        Me.lblIntelValue.Location = New System.Drawing.Point(164, 163)
        Me.lblIntelValue.Name = "lblIntelValue"
        Me.lblIntelValue.Size = New System.Drawing.Size(65, 13)
        Me.lblIntelValue.TabIndex = 27
        Me.lblIntelValue.Text = "lblIntelValue"
        '
        'lblMicronValue
        '
        Me.lblMicronValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblMicronValue.AutoEllipsis = True
        Me.lblMicronValue.AutoSize = True
        Me.lblMicronValue.Location = New System.Drawing.Point(164, 183)
        Me.lblMicronValue.Name = "lblMicronValue"
        Me.lblMicronValue.Size = New System.Drawing.Size(74, 13)
        Me.lblMicronValue.TabIndex = 28
        Me.lblMicronValue.Text = "lblMicronValue"
        '
        'lblSamsungValue
        '
        Me.lblSamsungValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblSamsungValue.AutoEllipsis = True
        Me.lblSamsungValue.AutoSize = True
        Me.lblSamsungValue.Location = New System.Drawing.Point(164, 203)
        Me.lblSamsungValue.Name = "lblSamsungValue"
        Me.lblSamsungValue.Size = New System.Drawing.Size(86, 13)
        Me.lblSamsungValue.TabIndex = 29
        Me.lblSamsungValue.Text = "lblSamsungValue"
        '
        'lblSandForceValue
        '
        Me.lblSandForceValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblSandForceValue.AutoEllipsis = True
        Me.lblSandForceValue.AutoSize = True
        Me.lblSandForceValue.Location = New System.Drawing.Point(164, 223)
        Me.lblSandForceValue.Name = "lblSandForceValue"
        Me.lblSandForceValue.Size = New System.Drawing.Size(94, 13)
        Me.lblSandForceValue.TabIndex = 30
        Me.lblSandForceValue.Text = "lblSandForceValue"
        '
        'chkXml
        '
        Me.chkXml.AutoSize = True
        Me.chkXml.Location = New System.Drawing.Point(24, 88)
        Me.chkXml.Name = "chkXml"
        Me.chkXml.Size = New System.Drawing.Size(61, 17)
        Me.chkXml.TabIndex = 2
        Me.chkXml.Text = "chkXml"
        Me.chkXml.UseVisualStyleBackColor = True
        '
        'picVersion
        '
        Me.picVersion.Location = New System.Drawing.Point(0, 0)
        Me.picVersion.Name = "picVersion"
        Me.picVersion.Size = New System.Drawing.Size(16, 16)
        Me.picVersion.TabIndex = 12
        Me.picVersion.TabStop = False
        Me.picVersion.Tag = "http://code.google.com/p/hddguardian/downloads"
        '
        'flwLog
        '
        Me.flwLog.AutoSize = True
        Me.flwLog.Controls.Add(Me.btnDelLog)
        Me.flwLog.Controls.Add(Me.btnDelAllLogs)
        Me.flwLog.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.flwLog.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft
        Me.flwLog.Location = New System.Drawing.Point(0, 264)
        Me.flwLog.Name = "flwLog"
        Me.flwLog.Size = New System.Drawing.Size(560, 30)
        Me.flwLog.TabIndex = 13
        '
        'btnDelLog
        '
        Me.btnDelLog.Location = New System.Drawing.Point(533, 3)
        Me.btnDelLog.Name = "btnDelLog"
        Me.btnDelLog.Size = New System.Drawing.Size(24, 24)
        Me.btnDelLog.TabIndex = 8
        Me.btnDelLog.UseVisualStyleBackColor = True
        '
        'btnDelAllLogs
        '
        Me.btnDelAllLogs.Location = New System.Drawing.Point(503, 3)
        Me.btnDelAllLogs.Name = "btnDelAllLogs"
        Me.btnDelAllLogs.Size = New System.Drawing.Size(24, 24)
        Me.btnDelAllLogs.TabIndex = 7
        Me.btnDelAllLogs.UseVisualStyleBackColor = True
        '
        'imlAttr
        '
        Me.imlAttr.ImageStream = CType(resources.GetObject("imlAttr.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlAttr.TransparentColor = System.Drawing.Color.Transparent
        Me.imlAttr.Images.SetKeyName(0, "mechanic")
        Me.imlAttr.Images.SetKeyName(1, "old")
        '
        'mnuTrayIcon
        '
        Me.mnuTrayIcon.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuRefresh, ToolStripSeparator2, Me.mnuRescanRemovable, ToolStripSeparator5, Me.mnuRestore, ToolStripSeparator1, Me.mnuExit})
        Me.mnuTrayIcon.Name = "ContextMenuStrip1"
        Me.mnuTrayIcon.Size = New System.Drawing.Size(196, 110)
        '
        'mnuRefresh
        '
        Me.mnuRefresh.Name = "mnuRefresh"
        Me.mnuRefresh.Size = New System.Drawing.Size(195, 22)
        Me.mnuRefresh.Text = "mnuRefresh"
        '
        'mnuRescanRemovable
        '
        Me.mnuRescanRemovable.Name = "mnuRescanRemovable"
        Me.mnuRescanRemovable.Size = New System.Drawing.Size(195, 22)
        Me.mnuRescanRemovable.Text = "mnuRescanRemovable"
        '
        'mnuRestore
        '
        Me.mnuRestore.Name = "mnuRestore"
        Me.mnuRestore.Size = New System.Drawing.Size(195, 22)
        Me.mnuRestore.Text = "mnuRestore"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(195, 22)
        Me.mnuExit.Text = "mnuExit"
        '
        'niTrayIcon
        '
        Me.niTrayIcon.ContextMenuStrip = Me.mnuTrayIcon
        Me.niTrayIcon.Icon = CType(resources.GetObject("niTrayIcon.Icon"), System.Drawing.Icon)
        Me.niTrayIcon.Text = "HDD Guardian"
        '
        'tmrRefresh
        '
        '
        'mnuGuide
        '
        Me.mnuGuide.Name = "mnuGuide"
        Me.mnuGuide.ShowShortcutKeys = False
        Me.mnuGuide.Size = New System.Drawing.Size(123, 22)
        Me.mnuGuide.Text = "mnuGuide"
        Me.mnuGuide.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.mnuGuide.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(120, 6)
        '
        'mnuInfo
        '
        Me.mnuInfo.Name = "mnuInfo"
        Me.mnuInfo.ShowShortcutKeys = False
        Me.mnuInfo.Size = New System.Drawing.Size(123, 22)
        Me.mnuInfo.Text = "mnuInfo"
        Me.mnuInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.mnuInfo.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'mnuDevices
        '
        Me.mnuDevices.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuUpdate, Me.mnuUpdateAll, ToolStripSeparator3, Me.mnuRescanExternal, ToolStripSeparator4, Me.mnuAddVirtual, Me.mnuRemoveVirtual})
        Me.mnuDevices.Name = "cmuDevices"
        Me.mnuDevices.Size = New System.Drawing.Size(178, 126)
        Me.mnuDevices.Text = "cmuDevices"
        '
        'mnuUpdate
        '
        Me.mnuUpdate.Name = "mnuUpdate"
        Me.mnuUpdate.Size = New System.Drawing.Size(177, 22)
        Me.mnuUpdate.Text = "mnuUpdate"
        '
        'mnuUpdateAll
        '
        Me.mnuUpdateAll.Name = "mnuUpdateAll"
        Me.mnuUpdateAll.Size = New System.Drawing.Size(177, 22)
        Me.mnuUpdateAll.Text = "mnuUpdateAll"
        '
        'mnuRescanExternal
        '
        Me.mnuRescanExternal.Name = "mnuRescanExternal"
        Me.mnuRescanExternal.Size = New System.Drawing.Size(177, 22)
        Me.mnuRescanExternal.Text = "mnuRescanExternal"
        '
        'mnuAddVirtual
        '
        Me.mnuAddVirtual.Name = "mnuAddVirtual"
        Me.mnuAddVirtual.Size = New System.Drawing.Size(177, 22)
        Me.mnuAddVirtual.Text = "mnuAddVirtual"
        '
        'mnuRemoveVirtual
        '
        Me.mnuRemoveVirtual.Name = "mnuRemoveVirtual"
        Me.mnuRemoveVirtual.Size = New System.Drawing.Size(177, 22)
        Me.mnuRemoveVirtual.Text = "mnuRemoveVirtual"
        '
        'tpSelfTests
        '
        Me.tpSelfTests.Controls.Add(Me.picAdminSelective)
        Me.tpSelfTests.Controls.Add(Me.picAdminSelfTest)
        Me.tpSelfTests.Controls.Add(Me.lvwSelective)
        Me.tpSelfTests.Controls.Add(Me.lblSelective)
        Me.tpSelfTests.Controls.Add(Me.lvwSelfTest)
        Me.tpSelfTests.Controls.Add(Me.lblSelfTest)
        Me.tpSelfTests.Location = New System.Drawing.Point(4, 22)
        Me.tpSelfTests.Name = "tpSelfTests"
        Me.tpSelfTests.Size = New System.Drawing.Size(560, 294)
        Me.tpSelfTests.TabIndex = 3
        Me.tpSelfTests.Tag = "http://code.google.com/p/hddguardian/wiki/smart_selftest_log"
        Me.tpSelfTests.Text = "Self-tests Logs"
        Me.tpSelfTests.UseVisualStyleBackColor = True
        '
        'picAdminSelective
        '
        Me.picAdminSelective.Location = New System.Drawing.Point(544, 149)
        Me.picAdminSelective.Name = "picAdminSelective"
        Me.picAdminSelective.Size = New System.Drawing.Size(16, 16)
        Me.picAdminSelective.TabIndex = 5
        Me.picAdminSelective.TabStop = False
        '
        'picAdminSelfTest
        '
        Me.picAdminSelfTest.Location = New System.Drawing.Point(544, 5)
        Me.picAdminSelfTest.Name = "picAdminSelfTest"
        Me.picAdminSelfTest.Size = New System.Drawing.Size(16, 16)
        Me.picAdminSelfTest.TabIndex = 4
        Me.picAdminSelfTest.TabStop = False
        '
        'lvwSelective
        '
        Me.lvwSelective.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chSpan, Me.chLbaMin, Me.chLbaMax, Me.chCurTestStatus})
        Me.lvwSelective.FullRowSelect = True
        Me.lvwSelective.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwSelective.Location = New System.Drawing.Point(0, 168)
        Me.lvwSelective.Name = "lvwSelective"
        Me.lvwSelective.Size = New System.Drawing.Size(560, 120)
        Me.lvwSelective.TabIndex = 3
        Me.lvwSelective.UseCompatibleStateImageBehavior = False
        Me.lvwSelective.View = System.Windows.Forms.View.Details
        '
        'chSpan
        '
        Me.chSpan.Text = "Span"
        '
        'chLbaMin
        '
        Me.chLbaMin.Text = "LBA Min"
        Me.chLbaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chLbaMax
        '
        Me.chLbaMax.Text = "LBA Max"
        Me.chLbaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chCurTestStatus
        '
        Me.chCurTestStatus.Text = "Current test status"
        Me.chCurTestStatus.Width = 114
        '
        'lblSelective
        '
        Me.lblSelective.AutoSize = True
        Me.lblSelective.Location = New System.Drawing.Point(0, 152)
        Me.lblSelective.Name = "lblSelective"
        Me.lblSelective.Size = New System.Drawing.Size(60, 13)
        Me.lblSelective.TabIndex = 2
        Me.lblSelective.Text = "lblSelective"
        '
        'lvwSelfTest
        '
        Me.lvwSelfTest.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chNum, Me.chTestType, Me.chTestStatus, Me.chRemaining, Me.chAge, Me.chFirstError})
        Me.lvwSelfTest.FullRowSelect = True
        Me.lvwSelfTest.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwSelfTest.Location = New System.Drawing.Point(0, 24)
        Me.lvwSelfTest.Name = "lvwSelfTest"
        Me.lvwSelfTest.Size = New System.Drawing.Size(560, 120)
        Me.lvwSelfTest.TabIndex = 1
        Me.lvwSelfTest.UseCompatibleStateImageBehavior = False
        Me.lvwSelfTest.View = System.Windows.Forms.View.Details
        '
        'chNum
        '
        Me.chNum.Text = "Num"
        '
        'chTestType
        '
        Me.chTestType.Text = "Test Type"
        '
        'chTestStatus
        '
        Me.chTestStatus.Text = "Status"
        Me.chTestStatus.Width = 61
        '
        'chRemaining
        '
        Me.chRemaining.Text = "Remaining"
        Me.chRemaining.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.chRemaining.Width = 72
        '
        'chAge
        '
        Me.chAge.Text = "Device age"
        Me.chAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.chAge.Width = 73
        '
        'chFirstError
        '
        Me.chFirstError.Text = "LBA first error"
        Me.chFirstError.Width = 87
        '
        'lblSelfTest
        '
        Me.lblSelfTest.AutoSize = True
        Me.lblSelfTest.Location = New System.Drawing.Point(0, 8)
        Me.lblSelfTest.Name = "lblSelfTest"
        Me.lblSelfTest.Size = New System.Drawing.Size(56, 13)
        Me.lblSelfTest.TabIndex = 0
        Me.lblSelfTest.Text = "lblSelfTest"
        '
        'tpErrors
        '
        Me.tpErrors.Controls.Add(Me.lblErrLogVer)
        Me.tpErrors.Controls.Add(Me.picAdminError)
        Me.tpErrors.Controls.Add(Me.flwError)
        Me.tpErrors.Controls.Add(Me.flwErrorLog)
        Me.tpErrors.Location = New System.Drawing.Point(4, 22)
        Me.tpErrors.Name = "tpErrors"
        Me.tpErrors.Size = New System.Drawing.Size(560, 294)
        Me.tpErrors.TabIndex = 2
        Me.tpErrors.Tag = "http://code.google.com/p/hddguardian/wiki/smart_error_log"
        Me.tpErrors.Text = "Errors Log"
        Me.tpErrors.UseVisualStyleBackColor = True
        '
        'lblErrLogVer
        '
        Me.lblErrLogVer.AutoSize = True
        Me.lblErrLogVer.Dock = System.Windows.Forms.DockStyle.Right
        Me.lblErrLogVer.Location = New System.Drawing.Point(480, 0)
        Me.lblErrLogVer.MinimumSize = New System.Drawing.Size(0, 23)
        Me.lblErrLogVer.Name = "lblErrLogVer"
        Me.lblErrLogVer.Size = New System.Drawing.Size(64, 23)
        Me.lblErrLogVer.TabIndex = 20
        Me.lblErrLogVer.Text = "lblErrLogVer"
        Me.lblErrLogVer.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'picAdminError
        '
        Me.picAdminError.Dock = System.Windows.Forms.DockStyle.Right
        Me.picAdminError.Location = New System.Drawing.Point(544, 0)
        Me.picAdminError.MaximumSize = New System.Drawing.Size(16, 23)
        Me.picAdminError.MinimumSize = New System.Drawing.Size(16, 23)
        Me.picAdminError.Name = "picAdminError"
        Me.picAdminError.Size = New System.Drawing.Size(16, 23)
        Me.picAdminError.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.picAdminError.TabIndex = 19
        Me.picAdminError.TabStop = False
        '
        'flwError
        '
        Me.flwError.Controls.Add(Me.lblPowerOn)
        Me.flwError.Controls.Add(Me.lblDeviceStatus)
        Me.flwError.Controls.Add(Me.lblRegisters)
        Me.flwError.Controls.Add(Me.RegistersPanel1)
        Me.flwError.Controls.Add(Me.lblCommands)
        Me.flwError.Controls.Add(Me.CommandsPanel1)
        Me.flwError.Location = New System.Drawing.Point(0, 32)
        Me.flwError.Margin = New System.Windows.Forms.Padding(0)
        Me.flwError.Name = "flwError"
        Me.flwError.Size = New System.Drawing.Size(560, 256)
        Me.flwError.TabIndex = 1
        '
        'lblPowerOn
        '
        Me.lblPowerOn.AutoSize = True
        Me.flwError.SetFlowBreak(Me.lblPowerOn, True)
        Me.lblPowerOn.Location = New System.Drawing.Point(3, 0)
        Me.lblPowerOn.Name = "lblPowerOn"
        Me.lblPowerOn.Size = New System.Drawing.Size(61, 13)
        Me.lblPowerOn.TabIndex = 0
        Me.lblPowerOn.Text = "lblPowerOn"
        '
        'lblDeviceStatus
        '
        Me.lblDeviceStatus.AutoSize = True
        Me.flwError.SetFlowBreak(Me.lblDeviceStatus, True)
        Me.lblDeviceStatus.Location = New System.Drawing.Point(3, 19)
        Me.lblDeviceStatus.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblDeviceStatus.Name = "lblDeviceStatus"
        Me.lblDeviceStatus.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.lblDeviceStatus.Size = New System.Drawing.Size(91, 13)
        Me.lblDeviceStatus.TabIndex = 1
        Me.lblDeviceStatus.Text = "lblDeviceStatus"
        '
        'lblRegisters
        '
        Me.lblRegisters.AutoSize = True
        Me.flwError.SetFlowBreak(Me.lblRegisters, True)
        Me.lblRegisters.Location = New System.Drawing.Point(3, 39)
        Me.lblRegisters.Margin = New System.Windows.Forms.Padding(3, 5, 3, 0)
        Me.lblRegisters.Name = "lblRegisters"
        Me.lblRegisters.Size = New System.Drawing.Size(61, 13)
        Me.lblRegisters.TabIndex = 2
        Me.lblRegisters.Text = "lblRegisters"
        '
        'RegistersPanel1
        '
        Me.flwError.SetFlowBreak(Me.RegistersPanel1, True)
        Me.RegistersPanel1.Location = New System.Drawing.Point(3, 55)
        Me.RegistersPanel1.MinimumSize = New System.Drawing.Size(554, 0)
        Me.RegistersPanel1.Name = "RegistersPanel1"
        Me.RegistersPanel1.Size = New System.Drawing.Size(554, 30)
        Me.RegistersPanel1.TabIndex = 3
        Me.RegistersPanel1.TabStop = False
        '
        'lblCommands
        '
        Me.lblCommands.AutoSize = True
        Me.flwError.SetFlowBreak(Me.lblCommands, True)
        Me.lblCommands.Location = New System.Drawing.Point(3, 93)
        Me.lblCommands.Margin = New System.Windows.Forms.Padding(3, 5, 3, 0)
        Me.lblCommands.Name = "lblCommands"
        Me.lblCommands.Size = New System.Drawing.Size(69, 13)
        Me.lblCommands.TabIndex = 4
        Me.lblCommands.Text = "lblCommands"
        '
        'CommandsPanel1
        '
        Me.CommandsPanel1.AutoSize = True
        Me.CommandsPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.CommandsPanel1.Location = New System.Drawing.Point(3, 109)
        Me.CommandsPanel1.MinimumSize = New System.Drawing.Size(554, 0)
        Me.CommandsPanel1.Name = "CommandsPanel1"
        Me.CommandsPanel1.Size = New System.Drawing.Size(554, 100)
        Me.CommandsPanel1.TabIndex = 5
        Me.CommandsPanel1.TabStop = False
        '
        'flwErrorLog
        '
        Me.flwErrorLog.AutoSize = True
        Me.flwErrorLog.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.flwErrorLog.Controls.Add(Me.lblErrorLog)
        Me.flwErrorLog.Controls.Add(Me.optError1)
        Me.flwErrorLog.Controls.Add(Me.optError2)
        Me.flwErrorLog.Controls.Add(Me.optError3)
        Me.flwErrorLog.Controls.Add(Me.optError4)
        Me.flwErrorLog.Controls.Add(Me.optError5)
        Me.flwErrorLog.Location = New System.Drawing.Point(0, 0)
        Me.flwErrorLog.Name = "flwErrorLog"
        Me.flwErrorLog.Size = New System.Drawing.Size(219, 23)
        Me.flwErrorLog.TabIndex = 0
        '
        'lblErrorLog
        '
        Me.lblErrorLog.AutoSize = True
        Me.lblErrorLog.Location = New System.Drawing.Point(0, 0)
        Me.lblErrorLog.Margin = New System.Windows.Forms.Padding(0)
        Me.lblErrorLog.MinimumSize = New System.Drawing.Size(0, 23)
        Me.lblErrorLog.Name = "lblErrorLog"
        Me.lblErrorLog.Size = New System.Drawing.Size(104, 23)
        Me.lblErrorLog.TabIndex = 0
        Me.lblErrorLog.Text = "Select error to show:"
        Me.lblErrorLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'optError1
        '
        Me.optError1.Appearance = System.Windows.Forms.Appearance.Button
        Me.optError1.AutoSize = True
        Me.optError1.Location = New System.Drawing.Point(104, 0)
        Me.optError1.Margin = New System.Windows.Forms.Padding(0)
        Me.optError1.Name = "optError1"
        Me.optError1.Size = New System.Drawing.Size(23, 23)
        Me.optError1.TabIndex = 0
        Me.optError1.TabStop = True
        Me.optError1.Text = "5"
        Me.optError1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optError1.UseVisualStyleBackColor = True
        '
        'optError2
        '
        Me.optError2.Appearance = System.Windows.Forms.Appearance.Button
        Me.optError2.AutoSize = True
        Me.optError2.Location = New System.Drawing.Point(127, 0)
        Me.optError2.Margin = New System.Windows.Forms.Padding(0)
        Me.optError2.Name = "optError2"
        Me.optError2.Size = New System.Drawing.Size(23, 23)
        Me.optError2.TabIndex = 1
        Me.optError2.TabStop = True
        Me.optError2.Text = "4"
        Me.optError2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optError2.UseVisualStyleBackColor = True
        '
        'optError3
        '
        Me.optError3.Appearance = System.Windows.Forms.Appearance.Button
        Me.optError3.AutoSize = True
        Me.optError3.Location = New System.Drawing.Point(150, 0)
        Me.optError3.Margin = New System.Windows.Forms.Padding(0)
        Me.optError3.Name = "optError3"
        Me.optError3.Size = New System.Drawing.Size(23, 23)
        Me.optError3.TabIndex = 2
        Me.optError3.TabStop = True
        Me.optError3.Text = "3"
        Me.optError3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optError3.UseVisualStyleBackColor = True
        '
        'optError4
        '
        Me.optError4.Appearance = System.Windows.Forms.Appearance.Button
        Me.optError4.AutoSize = True
        Me.optError4.Location = New System.Drawing.Point(173, 0)
        Me.optError4.Margin = New System.Windows.Forms.Padding(0)
        Me.optError4.Name = "optError4"
        Me.optError4.Size = New System.Drawing.Size(23, 23)
        Me.optError4.TabIndex = 3
        Me.optError4.TabStop = True
        Me.optError4.Text = "2"
        Me.optError4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optError4.UseVisualStyleBackColor = True
        '
        'optError5
        '
        Me.optError5.Appearance = System.Windows.Forms.Appearance.Button
        Me.optError5.AutoSize = True
        Me.optError5.Location = New System.Drawing.Point(196, 0)
        Me.optError5.Margin = New System.Windows.Forms.Padding(0)
        Me.optError5.Name = "optError5"
        Me.optError5.Size = New System.Drawing.Size(23, 23)
        Me.optError5.TabIndex = 4
        Me.optError5.TabStop = True
        Me.optError5.Text = "1"
        Me.optError5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optError5.UseVisualStyleBackColor = True
        '
        'tpCapabilities
        '
        Me.tpCapabilities.Controls.Add(Me.clCapabilities)
        Me.tpCapabilities.Location = New System.Drawing.Point(4, 22)
        Me.tpCapabilities.Name = "tpCapabilities"
        Me.tpCapabilities.Padding = New System.Windows.Forms.Padding(3)
        Me.tpCapabilities.Size = New System.Drawing.Size(560, 294)
        Me.tpCapabilities.TabIndex = 1
        Me.tpCapabilities.Tag = "http://code.google.com/p/hddguardian/wiki/device_capabilities"
        Me.tpCapabilities.Text = "Device capabilities"
        Me.tpCapabilities.UseVisualStyleBackColor = True
        '
        'clCapabilities
        '
        Me.clCapabilities.Location = New System.Drawing.Point(0, 8)
        Me.clCapabilities.Name = "clCapabilities"
        Me.clCapabilities.Size = New System.Drawing.Size(560, 288)
        Me.clCapabilities.TabIndex = 0
        Me.clCapabilities.TabStop = False
        '
        'tpAttributes
        '
        Me.tpAttributes.Controls.Add(Me.lvwSmart)
        Me.tpAttributes.Controls.Add(Me.apAttributes)
        Me.tpAttributes.Controls.Add(Me.lnkShowInfo)
        Me.tpAttributes.Controls.Add(Me.lblDataStructure)
        Me.tpAttributes.Controls.Add(Me.FlagsPanel1)
        Me.tpAttributes.Controls.Add(Me.ValuesPanel1)
        Me.tpAttributes.Location = New System.Drawing.Point(4, 22)
        Me.tpAttributes.Name = "tpAttributes"
        Me.tpAttributes.Size = New System.Drawing.Size(560, 294)
        Me.tpAttributes.TabIndex = 4
        Me.tpAttributes.Tag = "http://code.google.com/p/hddguardian/wiki/smart_attributes"
        Me.tpAttributes.Text = "S.M.A.R.T. attributes"
        Me.tpAttributes.UseVisualStyleBackColor = True
        '
        'lvwSmart
        '
        Me.lvwSmart.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chType, Me.chID, Me.chAttribute, Me.chCurrent, Me.chWorst, Me.chThreshold, Me.chWhenFailed, Me.chRawValue})
        Me.lvwSmart.Cursor = System.Windows.Forms.Cursors.Default
        Me.lvwSmart.FullRowSelect = True
        Me.lvwSmart.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwSmart.Location = New System.Drawing.Point(0, 24)
        Me.lvwSmart.MultiSelect = False
        Me.lvwSmart.Name = "lvwSmart"
        Me.lvwSmart.Size = New System.Drawing.Size(560, 224)
        Me.lvwSmart.SmallImageList = Me.imlAttr
        Me.lvwSmart.TabIndex = 0
        Me.lvwSmart.UseCompatibleStateImageBehavior = False
        Me.lvwSmart.View = System.Windows.Forms.View.Details
        '
        'chType
        '
        Me.chType.Text = "chType"
        '
        'chID
        '
        Me.chID.Text = "chID"
        Me.chID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chAttribute
        '
        Me.chAttribute.Text = "chAttribute"
        Me.chAttribute.Width = 75
        '
        'chCurrent
        '
        Me.chCurrent.Text = "chCurrent"
        Me.chCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chWorst
        '
        Me.chWorst.Text = "chWorst"
        Me.chWorst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chThreshold
        '
        Me.chThreshold.Text = "chThreshold"
        Me.chThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.chThreshold.Width = 71
        '
        'chWhenFailed
        '
        Me.chWhenFailed.Text = "chWhenFailed"
        Me.chWhenFailed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.chWhenFailed.Width = 81
        '
        'chRawValue
        '
        Me.chRawValue.Text = "chRawValue"
        Me.chRawValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.chRawValue.Width = 74
        '
        'apAttributes
        '
        Me.apAttributes.Location = New System.Drawing.Point(360, 24)
        Me.apAttributes.Name = "apAttributes"
        Me.apAttributes.Size = New System.Drawing.Size(200, 224)
        Me.apAttributes.TabIndex = 2
        Me.apAttributes.TabStop = False
        '
        'lnkShowInfo
        '
        Me.lnkShowInfo.AutoSize = True
        Me.lnkShowInfo.Dock = System.Windows.Forms.DockStyle.Right
        Me.lnkShowInfo.Location = New System.Drawing.Point(494, 0)
        Me.lnkShowInfo.Name = "lnkShowInfo"
        Me.lnkShowInfo.Padding = New System.Windows.Forms.Padding(0, 8, 0, 0)
        Me.lnkShowInfo.Size = New System.Drawing.Size(66, 21)
        Me.lnkShowInfo.TabIndex = 1
        Me.lnkShowInfo.TabStop = True
        Me.lnkShowInfo.Text = "lnkShowInfo"
        '
        'lblDataStructure
        '
        Me.lblDataStructure.AutoSize = True
        Me.lblDataStructure.Location = New System.Drawing.Point(0, 8)
        Me.lblDataStructure.Name = "lblDataStructure"
        Me.lblDataStructure.Size = New System.Drawing.Size(85, 13)
        Me.lblDataStructure.TabIndex = 13
        Me.lblDataStructure.Text = "lblDataStructure"
        '
        'FlagsPanel1
        '
        Me.FlagsPanel1.Location = New System.Drawing.Point(4, 258)
        Me.FlagsPanel1.MaximumSize = New System.Drawing.Size(240, 32)
        Me.FlagsPanel1.MinimumSize = New System.Drawing.Size(240, 32)
        Me.FlagsPanel1.Name = "FlagsPanel1"
        Me.FlagsPanel1.Size = New System.Drawing.Size(240, 32)
        Me.FlagsPanel1.TabIndex = 2
        Me.FlagsPanel1.TabStop = False
        '
        'ValuesPanel1
        '
        Me.ValuesPanel1.Location = New System.Drawing.Point(252, 258)
        Me.ValuesPanel1.MaximumSize = New System.Drawing.Size(305, 32)
        Me.ValuesPanel1.MinimumSize = New System.Drawing.Size(305, 32)
        Me.ValuesPanel1.Name = "ValuesPanel1"
        Me.ValuesPanel1.Size = New System.Drawing.Size(305, 32)
        Me.ValuesPanel1.TabIndex = 3
        Me.ValuesPanel1.TabStop = False
        '
        'tabAdvanced
        '
        Me.tabAdvanced.Controls.Add(Me.tpAttributes)
        Me.tabAdvanced.Controls.Add(Me.tpCapabilities)
        Me.tabAdvanced.Controls.Add(Me.tpErrors)
        Me.tabAdvanced.Controls.Add(Me.tpSelfTests)
        Me.tabAdvanced.Controls.Add(Me.tpReliability)
        Me.tabAdvanced.Controls.Add(Me.tpRunTest)
        Me.tabAdvanced.Location = New System.Drawing.Point(184, 88)
        Me.tabAdvanced.Name = "tabAdvanced"
        Me.tabAdvanced.SelectedIndex = 0
        Me.tabAdvanced.Size = New System.Drawing.Size(568, 320)
        Me.tabAdvanced.TabIndex = 2
        '
        'tpReliability
        '
        Me.tpReliability.Controls.Add(tlpReliability)
        Me.tpReliability.Location = New System.Drawing.Point(4, 22)
        Me.tpReliability.Name = "tpReliability"
        Me.tpReliability.Size = New System.Drawing.Size(560, 294)
        Me.tpReliability.TabIndex = 6
        Me.tpReliability.Tag = "http://code.google.com/p/hddguardian/wiki/reliability_details"
        Me.tpReliability.Text = "Reliabilty details"
        Me.tpReliability.UseVisualStyleBackColor = True
        '
        'tpRunTest
        '
        Me.tpRunTest.Controls.Add(Me.tipTest)
        Me.tpRunTest.Controls.Add(Me.pnlTest)
        Me.tpRunTest.Location = New System.Drawing.Point(4, 22)
        Me.tpRunTest.Name = "tpRunTest"
        Me.tpRunTest.Padding = New System.Windows.Forms.Padding(3)
        Me.tpRunTest.Size = New System.Drawing.Size(560, 294)
        Me.tpRunTest.TabIndex = 5
        Me.tpRunTest.Tag = "http://code.google.com/p/hddguardian/wiki/run_test"
        Me.tpRunTest.Text = "Run test"
        Me.tpRunTest.UseVisualStyleBackColor = True
        '
        'tipTest
        '
        Me.tipTest.BackColor = System.Drawing.Color.Transparent
        Me.tipTest.BackgroundImage = CType(resources.GetObject("tipTest.BackgroundImage"), System.Drawing.Image)
        Me.tipTest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tipTest.Location = New System.Drawing.Point(0, 0)
        Me.tipTest.Name = "tipTest"
        Me.tipTest.Size = New System.Drawing.Size(560, 88)
        Me.tipTest.TabIndex = 17
        Me.tipTest.Tip = "TipPanel"
        '
        'pnlTest
        '
        Me.pnlTest.Controls.Add(Me.pnlProgress)
        Me.pnlTest.Controls.Add(Me.flwTest)
        Me.pnlTest.Controls.Add(Me.btnRun)
        Me.pnlTest.Controls.Add(Me.lblTestInfo)
        Me.pnlTest.Controls.Add(Me.picTestInfo)
        Me.pnlTest.Location = New System.Drawing.Point(0, 96)
        Me.pnlTest.Name = "pnlTest"
        Me.pnlTest.Size = New System.Drawing.Size(560, 168)
        Me.pnlTest.TabIndex = 16
        '
        'pnlProgress
        '
        Me.pnlProgress.Controls.Add(Me.lblExtimatedEnd)
        Me.pnlProgress.Controls.Add(Me.prbTestProgress)
        Me.pnlProgress.Controls.Add(Me.lblProgress)
        Me.pnlProgress.Controls.Add(Me.btnStop)
        Me.pnlProgress.Location = New System.Drawing.Point(0, 114)
        Me.pnlProgress.Name = "pnlProgress"
        Me.pnlProgress.Size = New System.Drawing.Size(560, 48)
        Me.pnlProgress.TabIndex = 21
        '
        'lblExtimatedEnd
        '
        Me.lblExtimatedEnd.AutoSize = True
        Me.lblExtimatedEnd.Location = New System.Drawing.Point(0, 24)
        Me.lblExtimatedEnd.Name = "lblExtimatedEnd"
        Me.lblExtimatedEnd.Size = New System.Drawing.Size(83, 13)
        Me.lblExtimatedEnd.TabIndex = 2
        Me.lblExtimatedEnd.Text = "lblExtimatedEnd"
        '
        'prbTestProgress
        '
        Me.prbTestProgress.Location = New System.Drawing.Point(0, 0)
        Me.prbTestProgress.Name = "prbTestProgress"
        Me.prbTestProgress.Size = New System.Drawing.Size(288, 21)
        Me.prbTestProgress.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.prbTestProgress.TabIndex = 16
        '
        'lblProgress
        '
        Me.lblProgress.AutoSize = True
        Me.lblProgress.Location = New System.Drawing.Point(296, 0)
        Me.lblProgress.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblProgress.Name = "lblProgress"
        Me.lblProgress.Size = New System.Drawing.Size(59, 21)
        Me.lblProgress.TabIndex = 0
        Me.lblProgress.Text = "lblProgress"
        Me.lblProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnStop
        '
        Me.btnStop.Location = New System.Drawing.Point(480, 0)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(80, 23)
        Me.btnStop.TabIndex = 1
        Me.btnStop.Text = "btnStop"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'flwTest
        '
        Me.flwTest.Controls.Add(Me.lblSelectTest)
        Me.flwTest.Controls.Add(Me.cboTest)
        Me.flwTest.Controls.Add(Me.lblDuration)
        Me.flwTest.Location = New System.Drawing.Point(0, 0)
        Me.flwTest.Name = "flwTest"
        Me.flwTest.Size = New System.Drawing.Size(472, 27)
        Me.flwTest.TabIndex = 0
        '
        'lblSelectTest
        '
        Me.lblSelectTest.AutoSize = True
        Me.lblSelectTest.Location = New System.Drawing.Point(3, 3)
        Me.lblSelectTest.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblSelectTest.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblSelectTest.Name = "lblSelectTest"
        Me.lblSelectTest.Size = New System.Drawing.Size(68, 21)
        Me.lblSelectTest.TabIndex = 0
        Me.lblSelectTest.Text = "lblSelectTest"
        Me.lblSelectTest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboTest
        '
        Me.cboTest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTest.FormattingEnabled = True
        Me.cboTest.Location = New System.Drawing.Point(77, 3)
        Me.cboTest.Name = "cboTest"
        Me.cboTest.Size = New System.Drawing.Size(156, 21)
        Me.cboTest.TabIndex = 1
        '
        'lblDuration
        '
        Me.lblDuration.AutoSize = True
        Me.lblDuration.Location = New System.Drawing.Point(239, 3)
        Me.lblDuration.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblDuration.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblDuration.Name = "lblDuration"
        Me.lblDuration.Size = New System.Drawing.Size(57, 21)
        Me.lblDuration.TabIndex = 2
        Me.lblDuration.Text = "lblDuration"
        Me.lblDuration.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnRun
        '
        Me.btnRun.AutoSize = True
        Me.btnRun.Location = New System.Drawing.Point(480, 2)
        Me.btnRun.Name = "btnRun"
        Me.btnRun.Size = New System.Drawing.Size(80, 23)
        Me.btnRun.TabIndex = 1
        Me.btnRun.Text = "btnRun"
        Me.btnRun.UseVisualStyleBackColor = True
        '
        'lblTestInfo
        '
        Me.lblTestInfo.ForeColor = System.Drawing.Color.DimGray
        Me.lblTestInfo.Location = New System.Drawing.Point(24, 32)
        Me.lblTestInfo.Name = "lblTestInfo"
        Me.lblTestInfo.Size = New System.Drawing.Size(536, 82)
        Me.lblTestInfo.TabIndex = 2
        Me.lblTestInfo.Text = "lblTestInfo"
        '
        'picTestInfo
        '
        Me.picTestInfo.Location = New System.Drawing.Point(0, 32)
        Me.picTestInfo.Name = "picTestInfo"
        Me.picTestInfo.Size = New System.Drawing.Size(16, 16)
        Me.picTestInfo.TabIndex = 12
        Me.picTestInfo.TabStop = False
        '
        'flwFeatures
        '
        Me.flwFeatures.Controls.Add(Me.lblDevFeatures)
        Me.flwFeatures.Controls.Add(Me.tlpFeatures)
        Me.flwFeatures.Controls.Add(Me.lblMonFeatures)
        Me.flwFeatures.Controls.Add(Me.tlpMonitoring)
        Me.flwFeatures.Location = New System.Drawing.Point(0, 0)
        Me.flwFeatures.Name = "flwFeatures"
        Me.flwFeatures.Size = New System.Drawing.Size(560, 288)
        Me.flwFeatures.TabIndex = 1
        '
        'lblDevFeatures
        '
        Me.lblDevFeatures.AutoSize = True
        Me.flwFeatures.SetFlowBreak(Me.lblDevFeatures, True)
        Me.lblDevFeatures.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDevFeatures.Location = New System.Drawing.Point(3, 0)
        Me.lblDevFeatures.Margin = New System.Windows.Forms.Padding(3, 0, 3, 5)
        Me.lblDevFeatures.Name = "lblDevFeatures"
        Me.lblDevFeatures.Padding = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.lblDevFeatures.Size = New System.Drawing.Size(92, 16)
        Me.lblDevFeatures.TabIndex = 10
        Me.lblDevFeatures.Text = "lblDevFeatures"
        '
        'tlpFeatures
        '
        Me.tlpFeatures.AutoSize = True
        Me.tlpFeatures.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpFeatures.ColumnCount = 3
        Me.tlpFeatures.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpFeatures.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpFeatures.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpFeatures.Controls.Add(Me.picSmart, 0, 0)
        Me.tlpFeatures.Controls.Add(Me.picOfflineTest, 0, 2)
        Me.tlpFeatures.Controls.Add(Me.picAttrAutosave, 0, 4)
        Me.tlpFeatures.Controls.Add(Me.lblSmart, 1, 1)
        Me.tlpFeatures.Controls.Add(Me.lblOfflineTest, 1, 3)
        Me.tlpFeatures.Controls.Add(Me.lblAttrAutosave, 1, 5)
        Me.tlpFeatures.Controls.Add(Me.lblEnableSmart, 1, 0)
        Me.tlpFeatures.Controls.Add(Me.lblEnableOffline, 1, 2)
        Me.tlpFeatures.Controls.Add(Me.lblEnableAutosave, 1, 4)
        Me.tlpFeatures.Controls.Add(Me.picAdminSmart, 2, 0)
        Me.tlpFeatures.Controls.Add(Me.picAdminOffline, 2, 2)
        Me.tlpFeatures.Controls.Add(Me.picAdminAutosave, 2, 4)
        Me.flwFeatures.SetFlowBreak(Me.tlpFeatures, True)
        Me.tlpFeatures.Location = New System.Drawing.Point(3, 24)
        Me.tlpFeatures.MaximumSize = New System.Drawing.Size(550, 0)
        Me.tlpFeatures.MinimumSize = New System.Drawing.Size(550, 0)
        Me.tlpFeatures.Name = "tlpFeatures"
        Me.tlpFeatures.RowCount = 6
        Me.tlpFeatures.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpFeatures.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpFeatures.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpFeatures.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpFeatures.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpFeatures.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpFeatures.Size = New System.Drawing.Size(550, 105)
        Me.tlpFeatures.TabIndex = 13
        '
        'picSmart
        '
        Me.picSmart.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picSmart.Image = CType(resources.GetObject("picSmart.Image"), System.Drawing.Image)
        Me.picSmart.Location = New System.Drawing.Point(0, 0)
        Me.picSmart.Margin = New System.Windows.Forms.Padding(0)
        Me.picSmart.Name = "picSmart"
        Me.picSmart.Size = New System.Drawing.Size(52, 15)
        Me.picSmart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picSmart.TabIndex = 12
        Me.picSmart.TabStop = False
        '
        'picOfflineTest
        '
        Me.picOfflineTest.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picOfflineTest.Image = CType(resources.GetObject("picOfflineTest.Image"), System.Drawing.Image)
        Me.picOfflineTest.Location = New System.Drawing.Point(0, 35)
        Me.picOfflineTest.Margin = New System.Windows.Forms.Padding(0)
        Me.picOfflineTest.Name = "picOfflineTest"
        Me.picOfflineTest.Size = New System.Drawing.Size(52, 15)
        Me.picOfflineTest.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picOfflineTest.TabIndex = 13
        Me.picOfflineTest.TabStop = False
        '
        'picAttrAutosave
        '
        Me.picAttrAutosave.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picAttrAutosave.Image = CType(resources.GetObject("picAttrAutosave.Image"), System.Drawing.Image)
        Me.picAttrAutosave.Location = New System.Drawing.Point(0, 70)
        Me.picAttrAutosave.Margin = New System.Windows.Forms.Padding(0)
        Me.picAttrAutosave.Name = "picAttrAutosave"
        Me.picAttrAutosave.Size = New System.Drawing.Size(52, 15)
        Me.picAttrAutosave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picAttrAutosave.TabIndex = 14
        Me.picAttrAutosave.TabStop = False
        '
        'lblSmart
        '
        Me.lblSmart.AutoSize = True
        Me.lblSmart.ForeColor = System.Drawing.Color.DimGray
        Me.lblSmart.Location = New System.Drawing.Point(55, 17)
        Me.lblSmart.Margin = New System.Windows.Forms.Padding(3, 1, 3, 5)
        Me.lblSmart.MaximumSize = New System.Drawing.Size(480, 0)
        Me.lblSmart.Name = "lblSmart"
        Me.lblSmart.Size = New System.Drawing.Size(45, 13)
        Me.lblSmart.TabIndex = 1
        Me.lblSmart.Text = "lblSmart"
        '
        'lblOfflineTest
        '
        Me.lblOfflineTest.AutoSize = True
        Me.lblOfflineTest.ForeColor = System.Drawing.Color.DimGray
        Me.lblOfflineTest.Location = New System.Drawing.Point(55, 52)
        Me.lblOfflineTest.Margin = New System.Windows.Forms.Padding(3, 1, 3, 5)
        Me.lblOfflineTest.MaximumSize = New System.Drawing.Size(480, 0)
        Me.lblOfflineTest.Name = "lblOfflineTest"
        Me.lblOfflineTest.Size = New System.Drawing.Size(70, 13)
        Me.lblOfflineTest.TabIndex = 3
        Me.lblOfflineTest.Text = "lblOfflineTest"
        '
        'lblAttrAutosave
        '
        Me.lblAttrAutosave.AutoSize = True
        Me.lblAttrAutosave.ForeColor = System.Drawing.Color.DimGray
        Me.lblAttrAutosave.Location = New System.Drawing.Point(55, 87)
        Me.lblAttrAutosave.Margin = New System.Windows.Forms.Padding(3, 1, 3, 5)
        Me.lblAttrAutosave.MaximumSize = New System.Drawing.Size(480, 0)
        Me.lblAttrAutosave.Name = "lblAttrAutosave"
        Me.lblAttrAutosave.Size = New System.Drawing.Size(82, 13)
        Me.lblAttrAutosave.TabIndex = 5
        Me.lblAttrAutosave.Text = "lblAttrAutosave"
        '
        'lblEnableSmart
        '
        Me.lblEnableSmart.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblEnableSmart.AutoSize = True
        Me.lblEnableSmart.Location = New System.Drawing.Point(55, 1)
        Me.lblEnableSmart.Name = "lblEnableSmart"
        Me.lblEnableSmart.Size = New System.Drawing.Size(77, 13)
        Me.lblEnableSmart.TabIndex = 15
        Me.lblEnableSmart.Text = "lblEnableSmart"
        '
        'lblEnableOffline
        '
        Me.lblEnableOffline.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblEnableOffline.AutoSize = True
        Me.lblEnableOffline.Location = New System.Drawing.Point(55, 36)
        Me.lblEnableOffline.Name = "lblEnableOffline"
        Me.lblEnableOffline.Size = New System.Drawing.Size(81, 13)
        Me.lblEnableOffline.TabIndex = 16
        Me.lblEnableOffline.Text = "lblEnableOffline"
        '
        'lblEnableAutosave
        '
        Me.lblEnableAutosave.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblEnableAutosave.AutoSize = True
        Me.lblEnableAutosave.Location = New System.Drawing.Point(55, 71)
        Me.lblEnableAutosave.Name = "lblEnableAutosave"
        Me.lblEnableAutosave.Size = New System.Drawing.Size(95, 13)
        Me.lblEnableAutosave.TabIndex = 17
        Me.lblEnableAutosave.Text = "lblEnableAutosave"
        '
        'picAdminSmart
        '
        Me.picAdminSmart.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.picAdminSmart.Location = New System.Drawing.Point(534, 0)
        Me.picAdminSmart.Margin = New System.Windows.Forms.Padding(0)
        Me.picAdminSmart.Name = "picAdminSmart"
        Me.picAdminSmart.Size = New System.Drawing.Size(16, 16)
        Me.picAdminSmart.TabIndex = 18
        Me.picAdminSmart.TabStop = False
        '
        'picAdminOffline
        '
        Me.picAdminOffline.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.picAdminOffline.Location = New System.Drawing.Point(534, 35)
        Me.picAdminOffline.Margin = New System.Windows.Forms.Padding(0)
        Me.picAdminOffline.Name = "picAdminOffline"
        Me.picAdminOffline.Size = New System.Drawing.Size(16, 16)
        Me.picAdminOffline.TabIndex = 19
        Me.picAdminOffline.TabStop = False
        '
        'picAdminAutosave
        '
        Me.picAdminAutosave.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.picAdminAutosave.Location = New System.Drawing.Point(534, 70)
        Me.picAdminAutosave.Margin = New System.Windows.Forms.Padding(0)
        Me.picAdminAutosave.Name = "picAdminAutosave"
        Me.picAdminAutosave.Size = New System.Drawing.Size(16, 16)
        Me.picAdminAutosave.TabIndex = 20
        Me.picAdminAutosave.TabStop = False
        '
        'lblMonFeatures
        '
        Me.lblMonFeatures.AutoSize = True
        Me.flwFeatures.SetFlowBreak(Me.lblMonFeatures, True)
        Me.lblMonFeatures.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMonFeatures.Location = New System.Drawing.Point(3, 132)
        Me.lblMonFeatures.Name = "lblMonFeatures"
        Me.lblMonFeatures.Padding = New System.Windows.Forms.Padding(0, 5, 0, 5)
        Me.lblMonFeatures.Size = New System.Drawing.Size(94, 23)
        Me.lblMonFeatures.TabIndex = 11
        Me.lblMonFeatures.Text = "lblMonFeatures"
        '
        'tlpMonitoring
        '
        Me.tlpMonitoring.AutoSize = True
        Me.tlpMonitoring.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpMonitoring.ColumnCount = 3
        Me.tlpMonitoring.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpMonitoring.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpMonitoring.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpMonitoring.Controls.Add(Me.picTrayIcon, 0, 0)
        Me.tlpMonitoring.Controls.Add(Me.picShareOutput, 0, 2)
        Me.tlpMonitoring.Controls.Add(Me.lblDevTrayIcon, 1, 1)
        Me.tlpMonitoring.Controls.Add(Me.lblShare, 1, 3)
        Me.tlpMonitoring.Controls.Add(Me.lblEnableTray, 1, 0)
        Me.tlpMonitoring.Controls.Add(Me.lblEnableShare, 1, 2)
        Me.tlpMonitoring.Controls.Add(Me.lnkSetFolder, 1, 4)
        Me.tlpMonitoring.Location = New System.Drawing.Point(3, 158)
        Me.tlpMonitoring.MaximumSize = New System.Drawing.Size(550, 0)
        Me.tlpMonitoring.MinimumSize = New System.Drawing.Size(550, 0)
        Me.tlpMonitoring.Name = "tlpMonitoring"
        Me.tlpMonitoring.RowCount = 5
        Me.tlpMonitoring.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMonitoring.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMonitoring.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMonitoring.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMonitoring.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMonitoring.Size = New System.Drawing.Size(550, 79)
        Me.tlpMonitoring.TabIndex = 14
        '
        'picTrayIcon
        '
        Me.picTrayIcon.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picTrayIcon.Image = CType(resources.GetObject("picTrayIcon.Image"), System.Drawing.Image)
        Me.picTrayIcon.Location = New System.Drawing.Point(0, 0)
        Me.picTrayIcon.Margin = New System.Windows.Forms.Padding(0)
        Me.picTrayIcon.Name = "picTrayIcon"
        Me.picTrayIcon.Size = New System.Drawing.Size(52, 15)
        Me.picTrayIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picTrayIcon.TabIndex = 0
        Me.picTrayIcon.TabStop = False
        '
        'picShareOutput
        '
        Me.picShareOutput.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.picShareOutput.Image = CType(resources.GetObject("picShareOutput.Image"), System.Drawing.Image)
        Me.picShareOutput.Location = New System.Drawing.Point(0, 34)
        Me.picShareOutput.Margin = New System.Windows.Forms.Padding(0)
        Me.picShareOutput.Name = "picShareOutput"
        Me.picShareOutput.Size = New System.Drawing.Size(52, 15)
        Me.picShareOutput.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picShareOutput.TabIndex = 1
        Me.picShareOutput.TabStop = False
        '
        'lblDevTrayIcon
        '
        Me.lblDevTrayIcon.AutoSize = True
        Me.lblDevTrayIcon.ForeColor = System.Drawing.Color.DimGray
        Me.lblDevTrayIcon.Location = New System.Drawing.Point(55, 16)
        Me.lblDevTrayIcon.Margin = New System.Windows.Forms.Padding(3, 1, 3, 5)
        Me.lblDevTrayIcon.MaximumSize = New System.Drawing.Size(480, 0)
        Me.lblDevTrayIcon.Name = "lblDevTrayIcon"
        Me.lblDevTrayIcon.Size = New System.Drawing.Size(79, 13)
        Me.lblDevTrayIcon.TabIndex = 7
        Me.lblDevTrayIcon.Text = "lblDevTrayIcon"
        '
        'lblShare
        '
        Me.lblShare.AutoSize = True
        Me.lblShare.ForeColor = System.Drawing.Color.DimGray
        Me.lblShare.Location = New System.Drawing.Point(55, 50)
        Me.lblShare.Margin = New System.Windows.Forms.Padding(3, 1, 3, 0)
        Me.lblShare.MaximumSize = New System.Drawing.Size(480, 0)
        Me.lblShare.Name = "lblShare"
        Me.lblShare.Size = New System.Drawing.Size(45, 13)
        Me.lblShare.TabIndex = 9
        Me.lblShare.Text = "lblShare"
        '
        'lblEnableTray
        '
        Me.lblEnableTray.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblEnableTray.AutoSize = True
        Me.lblEnableTray.Location = New System.Drawing.Point(55, 1)
        Me.lblEnableTray.Name = "lblEnableTray"
        Me.lblEnableTray.Size = New System.Drawing.Size(71, 13)
        Me.lblEnableTray.TabIndex = 10
        Me.lblEnableTray.Text = "lblEnableTray"
        '
        'lblEnableShare
        '
        Me.lblEnableShare.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblEnableShare.AutoSize = True
        Me.lblEnableShare.Location = New System.Drawing.Point(55, 35)
        Me.lblEnableShare.Name = "lblEnableShare"
        Me.lblEnableShare.Size = New System.Drawing.Size(77, 13)
        Me.lblEnableShare.TabIndex = 11
        Me.lblEnableShare.Text = "lblEnableShare"
        '
        'lnkSetFolder
        '
        Me.lnkSetFolder.AutoSize = True
        Me.lnkSetFolder.Location = New System.Drawing.Point(55, 66)
        Me.lnkSetFolder.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lnkSetFolder.Name = "lnkSetFolder"
        Me.lnkSetFolder.Size = New System.Drawing.Size(66, 13)
        Me.lnkSetFolder.TabIndex = 12
        Me.lnkSetFolder.TabStop = True
        Me.lnkSetFolder.Text = "lnkSetFolder"
        '
        'tmrFlushMem
        '
        Me.tmrFlushMem.Enabled = True
        Me.tmrFlushMem.Interval = 10000
        '
        'tmrTest
        '
        '
        'lvwDevices
        '
        Me.lvwDevices.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chDevice, Me.chTemp})
        Me.lvwDevices.FullRowSelect = True
        ListViewGroup1.Header = "Phisycal"
        ListViewGroup1.Name = "grpPhisycal"
        ListViewGroup2.Header = "External"
        ListViewGroup2.Name = "grpExternal"
        ListViewGroup3.Header = "Virtual"
        ListViewGroup3.Name = "grpVirtual"
        Me.lvwDevices.Groups.AddRange(New System.Windows.Forms.ListViewGroup() {ListViewGroup1, ListViewGroup2, ListViewGroup3})
        Me.lvwDevices.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.lvwDevices.HideSelection = False
        Me.lvwDevices.Location = New System.Drawing.Point(0, 88)
        Me.lvwDevices.MultiSelect = False
        Me.lvwDevices.Name = "lvwDevices"
        Me.lvwDevices.Size = New System.Drawing.Size(176, 320)
        Me.lvwDevices.SmallImageList = Me.imlDevice
        Me.lvwDevices.TabIndex = 0
        Me.lvwDevices.UseCompatibleStateImageBehavior = False
        Me.lvwDevices.View = System.Windows.Forms.View.Details
        '
        'chDevice
        '
        Me.chDevice.Text = "chDevice"
        '
        'chTemp
        '
        Me.chTemp.Text = "chTemp"
        Me.chTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'imlDevice
        '
        Me.imlDevice.ImageStream = CType(resources.GetObject("imlDevice.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlDevice.TransparentColor = System.Drawing.Color.Transparent
        Me.imlDevice.Images.SetKeyName(0, "error")
        Me.imlDevice.Images.SetKeyName(1, "ok")
        '
        'tabMain
        '
        Me.tabMain.Controls.Add(Me.tpSummary)
        Me.tabMain.Controls.Add(Me.tpInfo)
        Me.tabMain.Controls.Add(Me.tpGeometryPartitions)
        Me.tabMain.Controls.Add(Me.tpFeatures)
        Me.tabMain.Controls.Add(Me.tpLog)
        Me.tabMain.Location = New System.Drawing.Point(184, 88)
        Me.tabMain.Name = "tabMain"
        Me.tabMain.SelectedIndex = 0
        Me.tabMain.Size = New System.Drawing.Size(568, 320)
        Me.tabMain.TabIndex = 1
        '
        'tpSummary
        '
        Me.tpSummary.Controls.Add(tlpSummary)
        Me.tpSummary.Controls.Add(Me.hpSummary)
        Me.tpSummary.Location = New System.Drawing.Point(4, 22)
        Me.tpSummary.Name = "tpSummary"
        Me.tpSummary.Size = New System.Drawing.Size(560, 294)
        Me.tpSummary.TabIndex = 0
        Me.tpSummary.Tag = "http://code.google.com/p/hddguardian/wiki/summary"
        Me.tpSummary.Text = "Summary"
        Me.tpSummary.UseVisualStyleBackColor = True
        '
        'hpSummary
        '
        Me.hpSummary.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.hpSummary.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hpSummary.Location = New System.Drawing.Point(0, 0)
        Me.hpSummary.MinimumSize = New System.Drawing.Size(300, 2)
        Me.hpSummary.Name = "hpSummary"
        Me.hpSummary.Size = New System.Drawing.Size(560, 256)
        Me.hpSummary.TabIndex = 0
        Me.hpSummary.TabStop = False
        '
        'tpInfo
        '
        Me.tpInfo.Controls.Add(Me.dipInfo)
        Me.tpInfo.Location = New System.Drawing.Point(4, 22)
        Me.tpInfo.Name = "tpInfo"
        Me.tpInfo.Padding = New System.Windows.Forms.Padding(3)
        Me.tpInfo.Size = New System.Drawing.Size(560, 294)
        Me.tpInfo.TabIndex = 1
        Me.tpInfo.Tag = "http://code.google.com/p/hddguardian/wiki/device_info"
        Me.tpInfo.Text = "Device info"
        Me.tpInfo.UseVisualStyleBackColor = True
        '
        'dipInfo
        '
        Me.dipInfo.AutoSize = True
        Me.dipInfo.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.dipInfo.Location = New System.Drawing.Point(0, 3)
        Me.dipInfo.Name = "dipInfo"
        Me.dipInfo.Size = New System.Drawing.Size(364, 208)
        Me.dipInfo.TabIndex = 0
        '
        'tpGeometryPartitions
        '
        Me.tpGeometryPartitions.Controls.Add(Me.lblGathering)
        Me.tpGeometryPartitions.Controls.Add(Me.lvwGeometry)
        Me.tpGeometryPartitions.Location = New System.Drawing.Point(4, 22)
        Me.tpGeometryPartitions.Name = "tpGeometryPartitions"
        Me.tpGeometryPartitions.Padding = New System.Windows.Forms.Padding(3)
        Me.tpGeometryPartitions.Size = New System.Drawing.Size(560, 294)
        Me.tpGeometryPartitions.TabIndex = 4
        Me.tpGeometryPartitions.Tag = "http://code.google.com/p/hddguardian/wiki/geometry"
        Me.tpGeometryPartitions.Text = "Geometry and partitions"
        Me.tpGeometryPartitions.UseVisualStyleBackColor = True
        '
        'lblGathering
        '
        Me.lblGathering.AutoSize = True
        Me.lblGathering.Image = Global.hdd_guardian.My.Resources.Resources.all_ok
        Me.lblGathering.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblGathering.Location = New System.Drawing.Point(96, 184)
        Me.lblGathering.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblGathering.Name = "lblGathering"
        Me.lblGathering.Size = New System.Drawing.Size(85, 16)
        Me.lblGathering.TabIndex = 1
        Me.lblGathering.Text = "       lblGathering"
        Me.lblGathering.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lvwGeometry
        '
        Me.lvwGeometry.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chOne, Me.chTwo, Me.chThree})
        Me.lvwGeometry.FullRowSelect = True
        Me.lvwGeometry.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.lvwGeometry.Location = New System.Drawing.Point(0, 8)
        Me.lvwGeometry.MultiSelect = False
        Me.lvwGeometry.Name = "lvwGeometry"
        Me.lvwGeometry.Size = New System.Drawing.Size(560, 160)
        Me.lvwGeometry.SmallImageList = Me.imlDevice
        Me.lvwGeometry.TabIndex = 0
        Me.lvwGeometry.UseCompatibleStateImageBehavior = False
        Me.lvwGeometry.View = System.Windows.Forms.View.Details
        '
        'chOne
        '
        Me.chOne.Width = 175
        '
        'chTwo
        '
        Me.chTwo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.chTwo.Width = 175
        '
        'chThree
        '
        Me.chThree.Width = 175
        '
        'tpFeatures
        '
        Me.tpFeatures.Controls.Add(Me.flwFeatures)
        Me.tpFeatures.Location = New System.Drawing.Point(4, 22)
        Me.tpFeatures.Name = "tpFeatures"
        Me.tpFeatures.Size = New System.Drawing.Size(560, 294)
        Me.tpFeatures.TabIndex = 2
        Me.tpFeatures.Tag = "http://code.google.com/p/hddguardian/wiki/enable_disable_features"
        Me.tpFeatures.Text = "Enable/disable features"
        Me.tpFeatures.UseVisualStyleBackColor = True
        '
        'tpLog
        '
        Me.tpLog.Controls.Add(Me.lblNoLog)
        Me.tpLog.Controls.Add(Me.flwLog)
        Me.tpLog.Controls.Add(Me.btnNext)
        Me.tpLog.Controls.Add(Me.btnToday)
        Me.tpLog.Controls.Add(Me.btnPrev)
        Me.tpLog.Controls.Add(Me.btnReload)
        Me.tpLog.Controls.Add(Me.lvwLog)
        Me.tpLog.Controls.Add(Me.dteLog)
        Me.tpLog.Location = New System.Drawing.Point(4, 22)
        Me.tpLog.Name = "tpLog"
        Me.tpLog.Size = New System.Drawing.Size(560, 294)
        Me.tpLog.TabIndex = 3
        Me.tpLog.Tag = "http://code.google.com/p/hddguardian/wiki/log_events"
        Me.tpLog.Text = "Log events"
        Me.tpLog.UseVisualStyleBackColor = True
        '
        'lblNoLog
        '
        Me.lblNoLog.AutoSize = True
        Me.lblNoLog.Location = New System.Drawing.Point(272, 8)
        Me.lblNoLog.MinimumSize = New System.Drawing.Size(0, 24)
        Me.lblNoLog.Name = "lblNoLog"
        Me.lblNoLog.Size = New System.Drawing.Size(47, 24)
        Me.lblNoLog.TabIndex = 14
        Me.lblNoLog.Text = "lblNoLog"
        Me.lblNoLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(240, 8)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(24, 24)
        Me.btnNext.TabIndex = 4
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnToday
        '
        Me.btnToday.Location = New System.Drawing.Point(208, 8)
        Me.btnToday.Name = "btnToday"
        Me.btnToday.Size = New System.Drawing.Size(24, 24)
        Me.btnToday.TabIndex = 3
        Me.btnToday.UseVisualStyleBackColor = True
        '
        'btnPrev
        '
        Me.btnPrev.Location = New System.Drawing.Point(176, 8)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(24, 24)
        Me.btnPrev.TabIndex = 2
        Me.btnPrev.UseVisualStyleBackColor = True
        '
        'btnReload
        '
        Me.btnReload.Location = New System.Drawing.Point(536, 8)
        Me.btnReload.MinimumSize = New System.Drawing.Size(24, 24)
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(24, 24)
        Me.btnReload.TabIndex = 5
        Me.btnReload.UseVisualStyleBackColor = True
        '
        'lvwLog
        '
        Me.lvwLog.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chDeviceLog, Me.chTime, Me.chAttrLog, Me.chFrom, Me.chTo, Me.chVariation})
        Me.lvwLog.FullRowSelect = True
        Me.lvwLog.Location = New System.Drawing.Point(0, 40)
        Me.lvwLog.MultiSelect = False
        Me.lvwLog.Name = "lvwLog"
        Me.lvwLog.Size = New System.Drawing.Size(560, 224)
        Me.lvwLog.TabIndex = 6
        Me.lvwLog.UseCompatibleStateImageBehavior = False
        Me.lvwLog.View = System.Windows.Forms.View.Details
        '
        'chDeviceLog
        '
        Me.chDeviceLog.Text = "chDeviceLog"
        '
        'chTime
        '
        Me.chTime.Text = "chTime"
        '
        'chAttrLog
        '
        Me.chAttrLog.Text = "chAttrLog"
        '
        'chFrom
        '
        Me.chFrom.Text = "chFrom"
        Me.chFrom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chTo
        '
        Me.chTo.Text = "chTo"
        Me.chTo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chVariation
        '
        Me.chVariation.Text = "chVariation"
        Me.chVariation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dteLog
        '
        Me.dteLog.Location = New System.Drawing.Point(0, 8)
        Me.dteLog.MinimumSize = New System.Drawing.Size(4, 24)
        Me.dteLog.Name = "dteLog"
        Me.dteLog.Size = New System.Drawing.Size(168, 24)
        Me.dteLog.TabIndex = 1
        '
        'tabSmartctl
        '
        Me.tabSmartctl.Controls.Add(Me.tpOutput)
        Me.tabSmartctl.Controls.Add(Me.tpTolerance)
        Me.tabSmartctl.Controls.Add(Me.tpAttFormat)
        Me.tabSmartctl.Controls.Add(Me.tpFirmware)
        Me.tabSmartctl.Controls.Add(Me.tpDatabase)
        Me.tabSmartctl.Location = New System.Drawing.Point(184, 88)
        Me.tabSmartctl.Name = "tabSmartctl"
        Me.tabSmartctl.SelectedIndex = 0
        Me.tabSmartctl.Size = New System.Drawing.Size(568, 320)
        Me.tabSmartctl.TabIndex = 3
        '
        'tpOutput
        '
        Me.tpOutput.Controls.Add(flwOutput)
        Me.tpOutput.Controls.Add(Me.txtReport)
        Me.tpOutput.Location = New System.Drawing.Point(4, 22)
        Me.tpOutput.Name = "tpOutput"
        Me.tpOutput.Size = New System.Drawing.Size(560, 294)
        Me.tpOutput.TabIndex = 1
        Me.tpOutput.Tag = "http://code.google.com/p/hddguardian/wiki/device_output"
        Me.tpOutput.Text = "Device output"
        Me.tpOutput.UseVisualStyleBackColor = True
        '
        'txtReport
        '
        Me.txtReport.BackColor = System.Drawing.SystemColors.Window
        Me.txtReport.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReport.Location = New System.Drawing.Point(0, 0)
        Me.txtReport.Multiline = True
        Me.txtReport.Name = "txtReport"
        Me.txtReport.ReadOnly = True
        Me.txtReport.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtReport.Size = New System.Drawing.Size(560, 264)
        Me.txtReport.TabIndex = 0
        Me.txtReport.WordWrap = False
        '
        'tpTolerance
        '
        Me.tpTolerance.Controls.Add(Me.tipTolerance)
        Me.tpTolerance.Controls.Add(Me.pnlTolerance)
        Me.tpTolerance.Controls.Add(Me.chkTolerance)
        Me.tpTolerance.Location = New System.Drawing.Point(4, 22)
        Me.tpTolerance.Name = "tpTolerance"
        Me.tpTolerance.Padding = New System.Windows.Forms.Padding(3)
        Me.tpTolerance.Size = New System.Drawing.Size(560, 294)
        Me.tpTolerance.TabIndex = 2
        Me.tpTolerance.Tag = "http://code.google.com/p/hddguardian/wiki/tolerance"
        Me.tpTolerance.Text = "Tolerance"
        Me.tpTolerance.UseVisualStyleBackColor = True
        '
        'tipTolerance
        '
        Me.tipTolerance.BackColor = System.Drawing.Color.Transparent
        Me.tipTolerance.BackgroundImage = CType(resources.GetObject("tipTolerance.BackgroundImage"), System.Drawing.Image)
        Me.tipTolerance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tipTolerance.Location = New System.Drawing.Point(0, 0)
        Me.tipTolerance.Name = "tipTolerance"
        Me.tipTolerance.Size = New System.Drawing.Size(552, 72)
        Me.tipTolerance.TabIndex = 6
        Me.tipTolerance.Tip = "TipPanel"
        '
        'pnlTolerance
        '
        Me.pnlTolerance.Controls.Add(Me.cboTolerance)
        Me.pnlTolerance.Controls.Add(Me.picTolerance)
        Me.pnlTolerance.Location = New System.Drawing.Point(16, 96)
        Me.pnlTolerance.Name = "pnlTolerance"
        Me.pnlTolerance.Size = New System.Drawing.Size(288, 40)
        Me.pnlTolerance.TabIndex = 5
        '
        'cboTolerance
        '
        Me.cboTolerance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTolerance.FormattingEnabled = True
        Me.cboTolerance.Location = New System.Drawing.Point(0, 0)
        Me.cboTolerance.Name = "cboTolerance"
        Me.cboTolerance.Size = New System.Drawing.Size(224, 21)
        Me.cboTolerance.TabIndex = 0
        '
        'picTolerance
        '
        Me.picTolerance.Location = New System.Drawing.Point(232, 2)
        Me.picTolerance.Name = "picTolerance"
        Me.picTolerance.Size = New System.Drawing.Size(16, 16)
        Me.picTolerance.TabIndex = 4
        Me.picTolerance.TabStop = False
        '
        'chkTolerance
        '
        Me.chkTolerance.AutoSize = True
        Me.chkTolerance.Location = New System.Drawing.Point(0, 80)
        Me.chkTolerance.Name = "chkTolerance"
        Me.chkTolerance.Size = New System.Drawing.Size(92, 17)
        Me.chkTolerance.TabIndex = 0
        Me.chkTolerance.Text = "chkTolerance"
        Me.chkTolerance.UseVisualStyleBackColor = True
        '
        'tpAttFormat
        '
        Me.tpAttFormat.Controls.Add(Me.tipAttributes)
        Me.tpAttFormat.Controls.Add(Me.pnlAttributes)
        Me.tpAttFormat.Controls.Add(Me.chkAttributes)
        Me.tpAttFormat.Location = New System.Drawing.Point(4, 22)
        Me.tpAttFormat.Name = "tpAttFormat"
        Me.tpAttFormat.Size = New System.Drawing.Size(560, 294)
        Me.tpAttFormat.TabIndex = 3
        Me.tpAttFormat.Tag = "http://code.google.com/p/hddguardian/wiki/attributes_format"
        Me.tpAttFormat.Text = "Attributes format"
        Me.tpAttFormat.UseVisualStyleBackColor = True
        '
        'tipAttributes
        '
        Me.tipAttributes.BackColor = System.Drawing.Color.Transparent
        Me.tipAttributes.BackgroundImage = CType(resources.GetObject("tipAttributes.BackgroundImage"), System.Drawing.Image)
        Me.tipAttributes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tipAttributes.Location = New System.Drawing.Point(0, 0)
        Me.tipAttributes.Name = "tipAttributes"
        Me.tipAttributes.Size = New System.Drawing.Size(560, 72)
        Me.tipAttributes.TabIndex = 8
        Me.tipAttributes.Tip = "TipPanel"
        '
        'pnlAttributes
        '
        Me.pnlAttributes.Controls.Add(Me.picAttrFormat)
        Me.pnlAttributes.Controls.Add(Me.picAttributes)
        Me.pnlAttributes.Controls.Add(Me.btnRemove)
        Me.pnlAttributes.Controls.Add(Me.btnAdd)
        Me.pnlAttributes.Controls.Add(Me.lvwAttrFormat)
        Me.pnlAttributes.Controls.Add(Me.txtName)
        Me.pnlAttributes.Controls.Add(Me.lblName)
        Me.pnlAttributes.Controls.Add(Me.cboFormat)
        Me.pnlAttributes.Controls.Add(Me.lblFormat)
        Me.pnlAttributes.Controls.Add(Me.cboID)
        Me.pnlAttributes.Controls.Add(Me.lblID)
        Me.pnlAttributes.Controls.Add(Me.cboAttributes)
        Me.pnlAttributes.Location = New System.Drawing.Point(16, 96)
        Me.pnlAttributes.Name = "pnlAttributes"
        Me.pnlAttributes.Size = New System.Drawing.Size(440, 192)
        Me.pnlAttributes.TabIndex = 7
        '
        'picAttrFormat
        '
        Me.picAttrFormat.Location = New System.Drawing.Point(360, 50)
        Me.picAttrFormat.Name = "picAttrFormat"
        Me.picAttrFormat.Size = New System.Drawing.Size(16, 16)
        Me.picAttrFormat.TabIndex = 11
        Me.picAttrFormat.TabStop = False
        '
        'picAttributes
        '
        Me.picAttributes.Location = New System.Drawing.Point(360, 2)
        Me.picAttributes.Name = "picAttributes"
        Me.picAttributes.Size = New System.Drawing.Size(16, 16)
        Me.picAttributes.TabIndex = 10
        Me.picAttributes.TabStop = False
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(360, 168)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(80, 24)
        Me.btnRemove.TabIndex = 6
        Me.btnRemove.Text = "btnRemove"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(360, 72)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(80, 24)
        Me.btnAdd.TabIndex = 4
        Me.btnAdd.Text = "btnAdd"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lvwAttrFormat
        '
        Me.lvwAttrFormat.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chAttrID, Me.chAttrFormat, Me.chAttrName})
        Me.lvwAttrFormat.FullRowSelect = True
        Me.lvwAttrFormat.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwAttrFormat.HideSelection = False
        Me.lvwAttrFormat.Location = New System.Drawing.Point(0, 104)
        Me.lvwAttrFormat.Name = "lvwAttrFormat"
        Me.lvwAttrFormat.Size = New System.Drawing.Size(352, 88)
        Me.lvwAttrFormat.TabIndex = 5
        Me.lvwAttrFormat.UseCompatibleStateImageBehavior = False
        Me.lvwAttrFormat.View = System.Windows.Forms.View.Details
        '
        'chAttrID
        '
        Me.chAttrID.Text = "chAttrID"
        '
        'chAttrFormat
        '
        Me.chAttrFormat.Text = "chAttrFormat"
        '
        'chAttrName
        '
        Me.chAttrName.Text = "chAttrName"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(112, 72)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(240, 21)
        Me.txtName.TabIndex = 3
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(0, 72)
        Me.lblName.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(44, 21)
        Me.lblName.TabIndex = 5
        Me.lblName.Text = "lblName"
        Me.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboFormat
        '
        Me.cboFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFormat.FormattingEnabled = True
        Me.cboFormat.Location = New System.Drawing.Point(112, 48)
        Me.cboFormat.Name = "cboFormat"
        Me.cboFormat.Size = New System.Drawing.Size(240, 21)
        Me.cboFormat.TabIndex = 2
        '
        'lblFormat
        '
        Me.lblFormat.AutoSize = True
        Me.lblFormat.Location = New System.Drawing.Point(0, 48)
        Me.lblFormat.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblFormat.Name = "lblFormat"
        Me.lblFormat.Size = New System.Drawing.Size(51, 21)
        Me.lblFormat.TabIndex = 3
        Me.lblFormat.Text = "lblFormat"
        Me.lblFormat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboID
        '
        Me.cboID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboID.FormattingEnabled = True
        Me.cboID.Location = New System.Drawing.Point(112, 24)
        Me.cboID.Name = "cboID"
        Me.cboID.Size = New System.Drawing.Size(240, 21)
        Me.cboID.TabIndex = 1
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(0, 24)
        Me.lblID.MinimumSize = New System.Drawing.Size(0, 21)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(28, 21)
        Me.lblID.TabIndex = 1
        Me.lblID.Text = "lblID"
        Me.lblID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboAttributes
        '
        Me.cboAttributes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAttributes.FormattingEnabled = True
        Me.cboAttributes.Location = New System.Drawing.Point(0, 0)
        Me.cboAttributes.Name = "cboAttributes"
        Me.cboAttributes.Size = New System.Drawing.Size(352, 21)
        Me.cboAttributes.TabIndex = 0
        '
        'chkAttributes
        '
        Me.chkAttributes.AutoSize = True
        Me.chkAttributes.Location = New System.Drawing.Point(0, 80)
        Me.chkAttributes.Name = "chkAttributes"
        Me.chkAttributes.Size = New System.Drawing.Size(88, 17)
        Me.chkAttributes.TabIndex = 0
        Me.chkAttributes.Text = "chkAttributes"
        Me.chkAttributes.UseVisualStyleBackColor = True
        '
        'tpFirmware
        '
        Me.tpFirmware.Controls.Add(Me.tipFirmware)
        Me.tpFirmware.Controls.Add(Me.pnlFirmware)
        Me.tpFirmware.Controls.Add(Me.chkFirmware)
        Me.tpFirmware.Location = New System.Drawing.Point(4, 22)
        Me.tpFirmware.Name = "tpFirmware"
        Me.tpFirmware.Padding = New System.Windows.Forms.Padding(3)
        Me.tpFirmware.Size = New System.Drawing.Size(560, 294)
        Me.tpFirmware.TabIndex = 4
        Me.tpFirmware.Tag = "http://code.google.com/p/hddguardian/wiki/firmware_debug"
        Me.tpFirmware.Text = "Firmware debug"
        Me.tpFirmware.UseVisualStyleBackColor = True
        '
        'tipFirmware
        '
        Me.tipFirmware.BackColor = System.Drawing.Color.Transparent
        Me.tipFirmware.BackgroundImage = CType(resources.GetObject("tipFirmware.BackgroundImage"), System.Drawing.Image)
        Me.tipFirmware.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tipFirmware.Location = New System.Drawing.Point(0, 0)
        Me.tipFirmware.Name = "tipFirmware"
        Me.tipFirmware.Size = New System.Drawing.Size(560, 72)
        Me.tipFirmware.TabIndex = 6
        Me.tipFirmware.Tip = "TipPanel"
        '
        'pnlFirmware
        '
        Me.pnlFirmware.Controls.Add(Me.picSwap)
        Me.pnlFirmware.Controls.Add(Me.picFirmware)
        Me.pnlFirmware.Controls.Add(Me.chkFixSwap)
        Me.pnlFirmware.Controls.Add(Me.cboFirmware)
        Me.pnlFirmware.Location = New System.Drawing.Point(16, 96)
        Me.pnlFirmware.Name = "pnlFirmware"
        Me.pnlFirmware.Size = New System.Drawing.Size(336, 56)
        Me.pnlFirmware.TabIndex = 5
        '
        'picSwap
        '
        Me.picSwap.Location = New System.Drawing.Point(232, 32)
        Me.picSwap.Name = "picSwap"
        Me.picSwap.Size = New System.Drawing.Size(16, 16)
        Me.picSwap.TabIndex = 5
        Me.picSwap.TabStop = False
        '
        'picFirmware
        '
        Me.picFirmware.Location = New System.Drawing.Point(232, 2)
        Me.picFirmware.Name = "picFirmware"
        Me.picFirmware.Size = New System.Drawing.Size(16, 16)
        Me.picFirmware.TabIndex = 4
        Me.picFirmware.TabStop = False
        '
        'chkFixSwap
        '
        Me.chkFixSwap.AutoSize = True
        Me.chkFixSwap.Location = New System.Drawing.Point(0, 32)
        Me.chkFixSwap.Name = "chkFixSwap"
        Me.chkFixSwap.Size = New System.Drawing.Size(84, 17)
        Me.chkFixSwap.TabIndex = 3
        Me.chkFixSwap.Text = "chkFixSwap"
        Me.chkFixSwap.UseVisualStyleBackColor = True
        '
        'cboFirmware
        '
        Me.cboFirmware.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFirmware.FormattingEnabled = True
        Me.cboFirmware.Location = New System.Drawing.Point(0, 0)
        Me.cboFirmware.Name = "cboFirmware"
        Me.cboFirmware.Size = New System.Drawing.Size(224, 21)
        Me.cboFirmware.TabIndex = 2
        '
        'chkFirmware
        '
        Me.chkFirmware.AutoSize = True
        Me.chkFirmware.Location = New System.Drawing.Point(0, 80)
        Me.chkFirmware.Name = "chkFirmware"
        Me.chkFirmware.Size = New System.Drawing.Size(86, 17)
        Me.chkFirmware.TabIndex = 1
        Me.chkFirmware.Text = "chkFirmware"
        Me.chkFirmware.UseVisualStyleBackColor = True
        '
        'tpDatabase
        '
        Me.tpDatabase.Controls.Add(pnlDatabase)
        Me.tpDatabase.Controls.Add(Me.cboDatabase)
        Me.tpDatabase.Controls.Add(Me.lblDatabase)
        Me.tpDatabase.Location = New System.Drawing.Point(4, 22)
        Me.tpDatabase.Name = "tpDatabase"
        Me.tpDatabase.Padding = New System.Windows.Forms.Padding(3)
        Me.tpDatabase.Size = New System.Drawing.Size(560, 294)
        Me.tpDatabase.TabIndex = 0
        Me.tpDatabase.Text = "Devices database"
        Me.tpDatabase.UseVisualStyleBackColor = True
        '
        'cboDatabase
        '
        Me.cboDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDatabase.FormattingEnabled = True
        Me.cboDatabase.Location = New System.Drawing.Point(0, 24)
        Me.cboDatabase.Name = "cboDatabase"
        Me.cboDatabase.Size = New System.Drawing.Size(560, 21)
        Me.cboDatabase.TabIndex = 1
        '
        'lblDatabase
        '
        Me.lblDatabase.AutoSize = True
        Me.lblDatabase.Location = New System.Drawing.Point(0, 8)
        Me.lblDatabase.Name = "lblDatabase"
        Me.lblDatabase.Size = New System.Drawing.Size(63, 13)
        Me.lblDatabase.TabIndex = 0
        Me.lblDatabase.Text = "lblDatabase"
        '
        'tabSettings
        '
        Me.tabSettings.Controls.Add(Me.tpLooknfeel)
        Me.tabSettings.Controls.Add(Me.tpUpdate)
        Me.tabSettings.Controls.Add(Me.tpMonitoring)
        Me.tabSettings.Controls.Add(Me.tpWarning)
        Me.tabSettings.Controls.Add(Me.tpShare)
        Me.tabSettings.Controls.Add(Me.tpRating)
        Me.tabSettings.Location = New System.Drawing.Point(184, 88)
        Me.tabSettings.Name = "tabSettings"
        Me.tabSettings.SelectedIndex = 0
        Me.tabSettings.Size = New System.Drawing.Size(568, 320)
        Me.tabSettings.TabIndex = 4
        '
        'tpLooknfeel
        '
        Me.tpLooknfeel.Controls.Add(Me.chkCloseOnTray)
        Me.tpLooknfeel.Controls.Add(Me.chkStartupLink)
        Me.tpLooknfeel.Controls.Add(Me.chkRunMinimized)
        Me.tpLooknfeel.Controls.Add(Me.chkMinimizeInTray)
        Me.tpLooknfeel.Controls.Add(Me.chkConfirmExit)
        Me.tpLooknfeel.Controls.Add(Me.picWindow)
        Me.tpLooknfeel.Controls.Add(Me.chkAlwaysShowTray)
        Me.tpLooknfeel.Location = New System.Drawing.Point(4, 22)
        Me.tpLooknfeel.Name = "tpLooknfeel"
        Me.tpLooknfeel.Size = New System.Drawing.Size(560, 294)
        Me.tpLooknfeel.TabIndex = 1
        Me.tpLooknfeel.Tag = "http://code.google.com/p/hddguardian/wiki/startup_and_interface"
        Me.tpLooknfeel.Text = "looknfeel"
        Me.tpLooknfeel.UseVisualStyleBackColor = True
        '
        'chkCloseOnTray
        '
        Me.chkCloseOnTray.AutoSize = True
        Me.chkCloseOnTray.Location = New System.Drawing.Point(24, 80)
        Me.chkCloseOnTray.Name = "chkCloseOnTray"
        Me.chkCloseOnTray.Size = New System.Drawing.Size(104, 17)
        Me.chkCloseOnTray.TabIndex = 3
        Me.chkCloseOnTray.Text = "chkCloseOnTray"
        Me.chkCloseOnTray.UseVisualStyleBackColor = True
        '
        'chkStartupLink
        '
        Me.chkStartupLink.AutoSize = True
        Me.chkStartupLink.Location = New System.Drawing.Point(24, 8)
        Me.chkStartupLink.Name = "chkStartupLink"
        Me.chkStartupLink.Size = New System.Drawing.Size(96, 17)
        Me.chkStartupLink.TabIndex = 0
        Me.chkStartupLink.Text = "chkStartupLink"
        Me.chkStartupLink.UseVisualStyleBackColor = True
        '
        'chkRunMinimized
        '
        Me.chkRunMinimized.AutoSize = True
        Me.chkRunMinimized.Location = New System.Drawing.Point(24, 32)
        Me.chkRunMinimized.Name = "chkRunMinimized"
        Me.chkRunMinimized.Size = New System.Drawing.Size(106, 17)
        Me.chkRunMinimized.TabIndex = 1
        Me.chkRunMinimized.Text = "chkRunMinimized"
        Me.chkRunMinimized.UseVisualStyleBackColor = True
        '
        'chkMinimizeInTray
        '
        Me.chkMinimizeInTray.AutoSize = True
        Me.chkMinimizeInTray.Location = New System.Drawing.Point(24, 56)
        Me.chkMinimizeInTray.Name = "chkMinimizeInTray"
        Me.chkMinimizeInTray.Size = New System.Drawing.Size(113, 17)
        Me.chkMinimizeInTray.TabIndex = 2
        Me.chkMinimizeInTray.Text = "chkMinimizeInTray"
        Me.chkMinimizeInTray.UseVisualStyleBackColor = True
        '
        'chkConfirmExit
        '
        Me.chkConfirmExit.AutoSize = True
        Me.chkConfirmExit.Location = New System.Drawing.Point(24, 128)
        Me.chkConfirmExit.Name = "chkConfirmExit"
        Me.chkConfirmExit.Size = New System.Drawing.Size(97, 17)
        Me.chkConfirmExit.TabIndex = 5
        Me.chkConfirmExit.Text = "chkConfirmExit"
        Me.chkConfirmExit.UseVisualStyleBackColor = True
        '
        'picWindow
        '
        Me.picWindow.Location = New System.Drawing.Point(0, 8)
        Me.picWindow.Name = "picWindow"
        Me.picWindow.Size = New System.Drawing.Size(16, 16)
        Me.picWindow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.picWindow.TabIndex = 3
        Me.picWindow.TabStop = False
        '
        'chkAlwaysShowTray
        '
        Me.chkAlwaysShowTray.AutoSize = True
        Me.chkAlwaysShowTray.Location = New System.Drawing.Point(24, 104)
        Me.chkAlwaysShowTray.Name = "chkAlwaysShowTray"
        Me.chkAlwaysShowTray.Size = New System.Drawing.Size(124, 17)
        Me.chkAlwaysShowTray.TabIndex = 4
        Me.chkAlwaysShowTray.Text = "chkAlwaysShowTray"
        Me.chkAlwaysShowTray.UseVisualStyleBackColor = True
        '
        'tpUpdate
        '
        Me.tpUpdate.Controls.Add(pnlRefresh)
        Me.tpUpdate.Controls.Add(Me.picUpdate)
        Me.tpUpdate.Location = New System.Drawing.Point(4, 22)
        Me.tpUpdate.Name = "tpUpdate"
        Me.tpUpdate.Size = New System.Drawing.Size(560, 294)
        Me.tpUpdate.TabIndex = 2
        Me.tpUpdate.Tag = "http://code.google.com/p/hddguardian/wiki/data_update"
        Me.tpUpdate.Text = "update"
        Me.tpUpdate.UseVisualStyleBackColor = True
        '
        'picUpdate
        '
        Me.picUpdate.Location = New System.Drawing.Point(0, 8)
        Me.picUpdate.Name = "picUpdate"
        Me.picUpdate.Size = New System.Drawing.Size(16, 16)
        Me.picUpdate.TabIndex = 14
        Me.picUpdate.TabStop = False
        '
        'tpMonitoring
        '
        Me.tpMonitoring.Controls.Add(flwMonitoring)
        Me.tpMonitoring.Controls.Add(Me.lblMonitoring)
        Me.tpMonitoring.Controls.Add(Me.picMonitoring)
        Me.tpMonitoring.Location = New System.Drawing.Point(4, 22)
        Me.tpMonitoring.Name = "tpMonitoring"
        Me.tpMonitoring.Size = New System.Drawing.Size(560, 294)
        Me.tpMonitoring.TabIndex = 5
        Me.tpMonitoring.Tag = "http://code.google.com/p/hddguardian/wiki/monitoring"
        Me.tpMonitoring.Text = "monitoring"
        Me.tpMonitoring.UseVisualStyleBackColor = True
        '
        'lblMonitoring
        '
        Me.lblMonitoring.AutoSize = True
        Me.lblMonitoring.Location = New System.Drawing.Point(24, 8)
        Me.lblMonitoring.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblMonitoring.Name = "lblMonitoring"
        Me.lblMonitoring.Size = New System.Drawing.Size(67, 16)
        Me.lblMonitoring.TabIndex = 19
        Me.lblMonitoring.Text = "lblMonitoring"
        Me.lblMonitoring.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'picMonitoring
        '
        Me.picMonitoring.Location = New System.Drawing.Point(0, 8)
        Me.picMonitoring.Name = "picMonitoring"
        Me.picMonitoring.Size = New System.Drawing.Size(16, 16)
        Me.picMonitoring.TabIndex = 18
        Me.picMonitoring.TabStop = False
        '
        'tpWarning
        '
        Me.tpWarning.Controls.Add(Me.lblWarning)
        Me.tpWarning.Controls.Add(Me.chkFailure)
        Me.tpWarning.Controls.Add(Me.chkTempThresh)
        Me.tpWarning.Controls.Add(Me.picWarning)
        Me.tpWarning.Controls.Add(Me.chkParamChng)
        Me.tpWarning.Location = New System.Drawing.Point(4, 22)
        Me.tpWarning.Name = "tpWarning"
        Me.tpWarning.Size = New System.Drawing.Size(560, 294)
        Me.tpWarning.TabIndex = 3
        Me.tpWarning.Tag = "http://code.google.com/p/hddguardian/wiki/warnings"
        Me.tpWarning.Text = "warning"
        Me.tpWarning.UseVisualStyleBackColor = True
        '
        'lblWarning
        '
        Me.lblWarning.AutoSize = True
        Me.lblWarning.Location = New System.Drawing.Point(24, 8)
        Me.lblWarning.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.Size = New System.Drawing.Size(57, 16)
        Me.lblWarning.TabIndex = 17
        Me.lblWarning.Text = "lblWarning"
        Me.lblWarning.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chkFailure
        '
        Me.chkFailure.AutoSize = True
        Me.chkFailure.Location = New System.Drawing.Point(24, 32)
        Me.chkFailure.Name = "chkFailure"
        Me.chkFailure.Size = New System.Drawing.Size(75, 17)
        Me.chkFailure.TabIndex = 0
        Me.chkFailure.Text = "chkFailure"
        Me.chkFailure.UseVisualStyleBackColor = True
        '
        'chkTempThresh
        '
        Me.chkTempThresh.AutoSize = True
        Me.chkTempThresh.Location = New System.Drawing.Point(24, 56)
        Me.chkTempThresh.Name = "chkTempThresh"
        Me.chkTempThresh.Size = New System.Drawing.Size(104, 17)
        Me.chkTempThresh.TabIndex = 1
        Me.chkTempThresh.Text = "chkTempThresh"
        Me.chkTempThresh.UseVisualStyleBackColor = True
        '
        'picWarning
        '
        Me.picWarning.Location = New System.Drawing.Point(0, 8)
        Me.picWarning.Name = "picWarning"
        Me.picWarning.Size = New System.Drawing.Size(16, 16)
        Me.picWarning.TabIndex = 16
        Me.picWarning.TabStop = False
        '
        'chkParamChng
        '
        Me.chkParamChng.AutoSize = True
        Me.chkParamChng.Location = New System.Drawing.Point(24, 80)
        Me.chkParamChng.Name = "chkParamChng"
        Me.chkParamChng.Size = New System.Drawing.Size(99, 17)
        Me.chkParamChng.TabIndex = 2
        Me.chkParamChng.Text = "chkParamChng"
        Me.chkParamChng.UseVisualStyleBackColor = True
        '
        'tpShare
        '
        Me.tpShare.Controls.Add(flwXml)
        Me.tpShare.Controls.Add(Me.chkXml)
        Me.tpShare.Controls.Add(Me.picXml)
        Me.tpShare.Controls.Add(flwShare)
        Me.tpShare.Controls.Add(Me.lblSelFolder)
        Me.tpShare.Controls.Add(Me.picShare)
        Me.tpShare.Location = New System.Drawing.Point(4, 22)
        Me.tpShare.Name = "tpShare"
        Me.tpShare.Size = New System.Drawing.Size(560, 294)
        Me.tpShare.TabIndex = 4
        Me.tpShare.Tag = "http://code.google.com/p/hddguardian/wiki/sharing"
        Me.tpShare.Text = "share"
        Me.tpShare.UseVisualStyleBackColor = True
        '
        'picXml
        '
        Me.picXml.Location = New System.Drawing.Point(0, 88)
        Me.picXml.Name = "picXml"
        Me.picXml.Size = New System.Drawing.Size(16, 16)
        Me.picXml.TabIndex = 19
        Me.picXml.TabStop = False
        '
        'lblSelFolder
        '
        Me.lblSelFolder.AutoSize = True
        Me.lblSelFolder.Location = New System.Drawing.Point(24, 8)
        Me.lblSelFolder.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblSelFolder.Name = "lblSelFolder"
        Me.lblSelFolder.Size = New System.Drawing.Size(61, 16)
        Me.lblSelFolder.TabIndex = 18
        Me.lblSelFolder.Text = "lblSelFolder"
        Me.lblSelFolder.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'picShare
        '
        Me.picShare.Location = New System.Drawing.Point(0, 8)
        Me.picShare.Name = "picShare"
        Me.picShare.Size = New System.Drawing.Size(16, 16)
        Me.picShare.TabIndex = 17
        Me.picShare.TabStop = False
        '
        'tpRating
        '
        Me.tpRating.Controls.Add(Me.chkTuneUp)
        Me.tpRating.Controls.Add(Me.tlpTuneUp)
        Me.tpRating.Controls.Add(Me.chkRating)
        Me.tpRating.Controls.Add(Me.picRating)
        Me.tpRating.Location = New System.Drawing.Point(4, 22)
        Me.tpRating.Name = "tpRating"
        Me.tpRating.Padding = New System.Windows.Forms.Padding(3)
        Me.tpRating.Size = New System.Drawing.Size(560, 294)
        Me.tpRating.TabIndex = 6
        Me.tpRating.Tag = "http://code.google.com/p/hddguardian/wiki/rating"
        Me.tpRating.Text = "rating"
        Me.tpRating.UseVisualStyleBackColor = True
        '
        'chkTuneUp
        '
        Me.chkTuneUp.AutoSize = True
        Me.chkTuneUp.Location = New System.Drawing.Point(24, 32)
        Me.chkTuneUp.Name = "chkTuneUp"
        Me.chkTuneUp.Size = New System.Drawing.Size(83, 17)
        Me.chkTuneUp.TabIndex = 2
        Me.chkTuneUp.Text = "chkTuneUp"
        Me.chkTuneUp.UseVisualStyleBackColor = True
        '
        'tlpTuneUp
        '
        Me.tlpTuneUp.ColumnCount = 3
        Me.tlpTuneUp.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpTuneUp.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpTuneUp.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpTuneUp.Controls.Add(Me.lnkResetCurPend, 2, 1)
        Me.tlpTuneUp.Controls.Add(Me.lblCurPendTune, 0, 1)
        Me.tlpTuneUp.Controls.Add(Me.lnkResetErrors, 2, 0)
        Me.tlpTuneUp.Controls.Add(Me.lblErrorsTune, 0, 0)
        Me.tlpTuneUp.Controls.Add(Me.lblOfflUncTune, 0, 2)
        Me.tlpTuneUp.Controls.Add(Me.lnkResetOfflUnc, 2, 2)
        Me.tlpTuneUp.Controls.Add(Me.numErrors, 1, 0)
        Me.tlpTuneUp.Controls.Add(Me.numCurPend, 1, 1)
        Me.tlpTuneUp.Controls.Add(Me.numOfflUnc, 1, 2)
        Me.tlpTuneUp.Location = New System.Drawing.Point(24, 56)
        Me.tlpTuneUp.Name = "tlpTuneUp"
        Me.tlpTuneUp.RowCount = 4
        Me.tlpTuneUp.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpTuneUp.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpTuneUp.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpTuneUp.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpTuneUp.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpTuneUp.Size = New System.Drawing.Size(528, 160)
        Me.tlpTuneUp.TabIndex = 3
        '
        'lnkResetCurPend
        '
        Me.lnkResetCurPend.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkResetCurPend.AutoSize = True
        Me.lnkResetCurPend.Location = New System.Drawing.Point(154, 34)
        Me.lnkResetCurPend.Name = "lnkResetCurPend"
        Me.lnkResetCurPend.Size = New System.Drawing.Size(89, 13)
        Me.lnkResetCurPend.TabIndex = 4
        Me.lnkResetCurPend.TabStop = True
        Me.lnkResetCurPend.Text = "lnkResetCurPend"
        '
        'lblCurPendTune
        '
        Me.lblCurPendTune.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblCurPendTune.AutoSize = True
        Me.lblCurPendTune.Location = New System.Drawing.Point(0, 34)
        Me.lblCurPendTune.Margin = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.lblCurPendTune.Name = "lblCurPendTune"
        Me.lblCurPendTune.Size = New System.Drawing.Size(82, 13)
        Me.lblCurPendTune.TabIndex = 7
        Me.lblCurPendTune.Text = "lblCurPendTune"
        '
        'lnkResetErrors
        '
        Me.lnkResetErrors.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkResetErrors.AutoSize = True
        Me.lnkResetErrors.Location = New System.Drawing.Point(154, 7)
        Me.lnkResetErrors.Name = "lnkResetErrors"
        Me.lnkResetErrors.Size = New System.Drawing.Size(77, 13)
        Me.lnkResetErrors.TabIndex = 2
        Me.lnkResetErrors.TabStop = True
        Me.lnkResetErrors.Text = "lnkResetErrors"
        '
        'lblErrorsTune
        '
        Me.lblErrorsTune.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblErrorsTune.AutoSize = True
        Me.lblErrorsTune.Location = New System.Drawing.Point(0, 7)
        Me.lblErrorsTune.Margin = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.lblErrorsTune.Name = "lblErrorsTune"
        Me.lblErrorsTune.Size = New System.Drawing.Size(70, 13)
        Me.lblErrorsTune.TabIndex = 0
        Me.lblErrorsTune.Text = "lblErrorsTune"
        '
        'lblOfflUncTune
        '
        Me.lblOfflUncTune.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblOfflUncTune.AutoSize = True
        Me.lblOfflUncTune.Location = New System.Drawing.Point(0, 61)
        Me.lblOfflUncTune.Margin = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.lblOfflUncTune.Name = "lblOfflUncTune"
        Me.lblOfflUncTune.Size = New System.Drawing.Size(77, 13)
        Me.lblOfflUncTune.TabIndex = 10
        Me.lblOfflUncTune.Text = "lblOfflUncTune"
        '
        'lnkResetOfflUnc
        '
        Me.lnkResetOfflUnc.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkResetOfflUnc.AutoSize = True
        Me.lnkResetOfflUnc.Location = New System.Drawing.Point(154, 61)
        Me.lnkResetOfflUnc.Name = "lnkResetOfflUnc"
        Me.lnkResetOfflUnc.Size = New System.Drawing.Size(84, 13)
        Me.lnkResetOfflUnc.TabIndex = 6
        Me.lnkResetOfflUnc.TabStop = True
        Me.lnkResetOfflUnc.Text = "lnkResetOfflUnc"
        '
        'numErrors
        '
        Me.numErrors.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.numErrors.Location = New System.Drawing.Point(88, 3)
        Me.numErrors.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numErrors.Name = "numErrors"
        Me.numErrors.Size = New System.Drawing.Size(60, 21)
        Me.numErrors.TabIndex = 1
        Me.numErrors.Tag = "10"
        Me.numErrors.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numErrors.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'numCurPend
        '
        Me.numCurPend.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.numCurPend.Location = New System.Drawing.Point(88, 30)
        Me.numCurPend.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numCurPend.Name = "numCurPend"
        Me.numCurPend.Size = New System.Drawing.Size(60, 21)
        Me.numCurPend.TabIndex = 3
        Me.numCurPend.Tag = "10"
        Me.numCurPend.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numCurPend.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'numOfflUnc
        '
        Me.numOfflUnc.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.numOfflUnc.Location = New System.Drawing.Point(88, 57)
        Me.numOfflUnc.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numOfflUnc.Name = "numOfflUnc"
        Me.numOfflUnc.Size = New System.Drawing.Size(60, 21)
        Me.numOfflUnc.TabIndex = 5
        Me.numOfflUnc.Tag = "10"
        Me.numOfflUnc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.numOfflUnc.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'chkRating
        '
        Me.chkRating.AutoSize = True
        Me.chkRating.Location = New System.Drawing.Point(24, 8)
        Me.chkRating.Name = "chkRating"
        Me.chkRating.Size = New System.Drawing.Size(75, 17)
        Me.chkRating.TabIndex = 1
        Me.chkRating.Text = "chkRating"
        Me.chkRating.UseVisualStyleBackColor = True
        '
        'picRating
        '
        Me.picRating.Location = New System.Drawing.Point(0, 8)
        Me.picRating.Name = "picRating"
        Me.picRating.Size = New System.Drawing.Size(16, 16)
        Me.picRating.TabIndex = 0
        Me.picRating.TabStop = False
        '
        'imlLog
        '
        Me.imlLog.ImageStream = CType(resources.GetObject("imlLog.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlLog.TransparentColor = System.Drawing.Color.Transparent
        Me.imlLog.Images.SetKeyName(0, "ok")
        Me.imlLog.Images.SetKeyName(1, "warning")
        '
        'tlpStatusBar
        '
        Me.tlpStatusBar.BackgroundImage = Global.hdd_guardian.My.Resources.Resources.pattern_metalgrid
        Me.tlpStatusBar.ColumnCount = 1
        Me.tlpStatusBar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpStatusBar.Controls.Add(Me.pnlUpdate, 0, 0)
        Me.tlpStatusBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlpStatusBar.Location = New System.Drawing.Point(0, 408)
        Me.tlpStatusBar.Name = "tlpStatusBar"
        Me.tlpStatusBar.RowCount = 1
        Me.tlpStatusBar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpStatusBar.Size = New System.Drawing.Size(751, 24)
        Me.tlpStatusBar.TabIndex = 15
        '
        'pnlUpdate
        '
        Me.pnlUpdate.BackColor = System.Drawing.Color.Transparent
        Me.pnlUpdate.Controls.Add(Me.lnkUpdate)
        Me.pnlUpdate.Controls.Add(Me.picVersion)
        Me.pnlUpdate.Location = New System.Drawing.Point(3, 3)
        Me.pnlUpdate.Name = "pnlUpdate"
        Me.pnlUpdate.Size = New System.Drawing.Size(741, 16)
        Me.pnlUpdate.TabIndex = 7
        '
        'lnkUpdate
        '
        Me.lnkUpdate.AutoSize = True
        Me.lnkUpdate.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lnkUpdate.Location = New System.Drawing.Point(16, 0)
        Me.lnkUpdate.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lnkUpdate.Name = "lnkUpdate"
        Me.lnkUpdate.Size = New System.Drawing.Size(55, 16)
        Me.lnkUpdate.TabIndex = 13
        Me.lnkUpdate.TabStop = True
        Me.lnkUpdate.Tag = "http://code.google.com/p/hddguardian/downloads"
        Me.lnkUpdate.Text = "lnkUpdate"
        Me.lnkUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tabAbout
        '
        Me.tabAbout.Controls.Add(tpAbout)
        Me.tabAbout.Controls.Add(tpCredits)
        Me.tabAbout.Controls.Add(Me.tpContributors)
        Me.tabAbout.Controls.Add(tpLicense)
        Me.tabAbout.Location = New System.Drawing.Point(184, 88)
        Me.tabAbout.Name = "tabAbout"
        Me.tabAbout.SelectedIndex = 0
        Me.tabAbout.Size = New System.Drawing.Size(568, 320)
        Me.tabAbout.TabIndex = 5
        '
        'tpContributors
        '
        Me.tpContributors.Controls.Add(Label10)
        Me.tpContributors.Controls.Add(Label9)
        Me.tpContributors.Controls.Add(Label8)
        Me.tpContributors.Controls.Add(Label7)
        Me.tpContributors.Controls.Add(Label6)
        Me.tpContributors.Location = New System.Drawing.Point(4, 22)
        Me.tpContributors.Name = "tpContributors"
        Me.tpContributors.Size = New System.Drawing.Size(560, 294)
        Me.tpContributors.TabIndex = 4
        Me.tpContributors.Text = "Contributors"
        Me.tpContributors.UseVisualStyleBackColor = True
        '
        'tmrRefreshExt
        '
        '
        'tmrRefreshVirtual
        '
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(751, 432)
        Me.Controls.Add(Me.tlpStatusBar)
        Me.Controls.Add(tlpMenu)
        Me.Controls.Add(Me.lvwDevices)
        Me.Controls.Add(pnlTopInfo)
        Me.Controls.Add(Me.tabAbout)
        Me.Controls.Add(Me.tabSettings)
        Me.Controls.Add(Me.tabAdvanced)
        Me.Controls.Add(Me.tabMain)
        Me.Controls.Add(Me.tabSmartctl)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HDD Guardian"
        flwButtons.ResumeLayout(False)
        tlpMenu.ResumeLayout(False)
        tlpMenu.PerformLayout()
        CType(Me.picLanguageFlag, System.ComponentModel.ISupportInitialize).EndInit()
        CType(picLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(picRight, System.ComponentModel.ISupportInitialize).EndInit()
        tlpDatabase.ResumeLayout(False)
        tlpDatabase.PerformLayout()
        flwOutput.ResumeLayout(False)
        pnlDatabase.ResumeLayout(False)
        pnlDatabase.PerformLayout()
        flwShare.ResumeLayout(False)
        flwShare.PerformLayout()
        pnlTopInfo.ResumeLayout(False)
        CType(Me.picHelp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStars, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPower, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDeviceImage, System.ComponentModel.ISupportInitialize).EndInit()
        tlpSummary.ResumeLayout(False)
        tlpSummary.PerformLayout()
        pnlInfobox.ResumeLayout(False)
        CType(Me.picUsb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picManufacturer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAdmin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOsIcon, System.ComponentModel.ISupportInitialize).EndInit()
        tpAbout.ResumeLayout(False)
        tlpContacts.ResumeLayout(False)
        tlpContacts.PerformLayout()
        CType(Me.picHome, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEmail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(picOSI, System.ComponentModel.ISupportInitialize).EndInit()
        CType(picLicense, System.ComponentModel.ISupportInitialize).EndInit()
        CType(picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        tpCredits.ResumeLayout(False)
        tpCredits.PerformLayout()
        tpLicense.ResumeLayout(False)
        tpLicense.PerformLayout()
        pnlRefresh.ResumeLayout(False)
        pnlRefresh.PerformLayout()
        Me.tlpUpdate.ResumeLayout(False)
        Me.tlpUpdate.PerformLayout()
        CType(Me.numUpdateVirtual, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numUpdateExt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numUpdate, System.ComponentModel.ISupportInitialize).EndInit()
        tlpParameters.ResumeLayout(False)
        tlpParameters.PerformLayout()
        tlpSSD.ResumeLayout(False)
        tlpSSD.PerformLayout()
        flwMonitoring.ResumeLayout(False)
        flwMonitoring.PerformLayout()
        flwXml.ResumeLayout(False)
        flwXml.PerformLayout()
        tlpReliability.ResumeLayout(False)
        tlpReliability.PerformLayout()
        CType(Me.picErrors, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picReallSect, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCurPending, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOfflUnc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picIndilinx, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picIntel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMicron, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSamsung, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSandForce, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.flwLog.ResumeLayout(False)
        Me.mnuTrayIcon.ResumeLayout(False)
        Me.mnuDevices.ResumeLayout(False)
        Me.tpSelfTests.ResumeLayout(False)
        Me.tpSelfTests.PerformLayout()
        CType(Me.picAdminSelective, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAdminSelfTest, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpErrors.ResumeLayout(False)
        Me.tpErrors.PerformLayout()
        CType(Me.picAdminError, System.ComponentModel.ISupportInitialize).EndInit()
        Me.flwError.ResumeLayout(False)
        Me.flwError.PerformLayout()
        Me.flwErrorLog.ResumeLayout(False)
        Me.flwErrorLog.PerformLayout()
        Me.tpCapabilities.ResumeLayout(False)
        Me.tpAttributes.ResumeLayout(False)
        Me.tpAttributes.PerformLayout()
        Me.tabAdvanced.ResumeLayout(False)
        Me.tpReliability.ResumeLayout(False)
        Me.tpRunTest.ResumeLayout(False)
        Me.pnlTest.ResumeLayout(False)
        Me.pnlTest.PerformLayout()
        Me.pnlProgress.ResumeLayout(False)
        Me.pnlProgress.PerformLayout()
        Me.flwTest.ResumeLayout(False)
        Me.flwTest.PerformLayout()
        CType(Me.picTestInfo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.flwFeatures.ResumeLayout(False)
        Me.flwFeatures.PerformLayout()
        Me.tlpFeatures.ResumeLayout(False)
        Me.tlpFeatures.PerformLayout()
        CType(Me.picSmart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOfflineTest, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAttrAutosave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAdminSmart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAdminOffline, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAdminAutosave, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tlpMonitoring.ResumeLayout(False)
        Me.tlpMonitoring.PerformLayout()
        CType(Me.picTrayIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picShareOutput, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabMain.ResumeLayout(False)
        Me.tpSummary.ResumeLayout(False)
        Me.tpSummary.PerformLayout()
        Me.tpInfo.ResumeLayout(False)
        Me.tpInfo.PerformLayout()
        Me.tpGeometryPartitions.ResumeLayout(False)
        Me.tpGeometryPartitions.PerformLayout()
        Me.tpFeatures.ResumeLayout(False)
        Me.tpLog.ResumeLayout(False)
        Me.tpLog.PerformLayout()
        Me.tabSmartctl.ResumeLayout(False)
        Me.tpOutput.ResumeLayout(False)
        Me.tpOutput.PerformLayout()
        Me.tpTolerance.ResumeLayout(False)
        Me.tpTolerance.PerformLayout()
        Me.pnlTolerance.ResumeLayout(False)
        CType(Me.picTolerance, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpAttFormat.ResumeLayout(False)
        Me.tpAttFormat.PerformLayout()
        Me.pnlAttributes.ResumeLayout(False)
        Me.pnlAttributes.PerformLayout()
        CType(Me.picAttrFormat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAttributes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpFirmware.ResumeLayout(False)
        Me.tpFirmware.PerformLayout()
        Me.pnlFirmware.ResumeLayout(False)
        Me.pnlFirmware.PerformLayout()
        CType(Me.picSwap, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFirmware, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpDatabase.ResumeLayout(False)
        Me.tpDatabase.PerformLayout()
        Me.tabSettings.ResumeLayout(False)
        Me.tpLooknfeel.ResumeLayout(False)
        Me.tpLooknfeel.PerformLayout()
        CType(Me.picWindow, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpUpdate.ResumeLayout(False)
        CType(Me.picUpdate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpMonitoring.ResumeLayout(False)
        Me.tpMonitoring.PerformLayout()
        CType(Me.picMonitoring, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpWarning.ResumeLayout(False)
        Me.tpWarning.PerformLayout()
        CType(Me.picWarning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpShare.ResumeLayout(False)
        Me.tpShare.PerformLayout()
        CType(Me.picXml, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picShare, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpRating.ResumeLayout(False)
        Me.tpRating.PerformLayout()
        Me.tlpTuneUp.ResumeLayout(False)
        Me.tlpTuneUp.PerformLayout()
        CType(Me.numErrors, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numCurPend, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numOfflUnc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRating, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tlpStatusBar.ResumeLayout(False)
        Me.pnlUpdate.ResumeLayout(False)
        Me.pnlUpdate.PerformLayout()
        Me.tabAbout.ResumeLayout(False)
        Me.tpContributors.ResumeLayout(False)
        Me.tpContributors.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ttMain As System.Windows.Forms.ToolTip
    Friend WithEvents imlAttr As System.Windows.Forms.ImageList
    Friend WithEvents mnuTrayIcon As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuRestore As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents niTrayIcon As System.Windows.Forms.NotifyIcon
    Friend WithEvents mnuRefresh As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tmrRefresh As System.Windows.Forms.Timer
    Friend WithEvents tabAdvanced As System.Windows.Forms.TabControl
    Friend WithEvents tpAttributes As System.Windows.Forms.TabPage
    Friend WithEvents lvwSmart As System.Windows.Forms.ListView
    Friend WithEvents chType As System.Windows.Forms.ColumnHeader
    Friend WithEvents chID As System.Windows.Forms.ColumnHeader
    Friend WithEvents chAttribute As System.Windows.Forms.ColumnHeader
    Friend WithEvents chCurrent As System.Windows.Forms.ColumnHeader
    Friend WithEvents chWorst As System.Windows.Forms.ColumnHeader
    Friend WithEvents chThreshold As System.Windows.Forms.ColumnHeader
    Friend WithEvents chWhenFailed As System.Windows.Forms.ColumnHeader
    Friend WithEvents chRawValue As System.Windows.Forms.ColumnHeader
    Friend WithEvents tpCapabilities As System.Windows.Forms.TabPage
    Friend WithEvents tpErrors As System.Windows.Forms.TabPage
    Friend WithEvents tpSelfTests As System.Windows.Forms.TabPage
    Friend WithEvents lvwSelective As System.Windows.Forms.ListView
    Friend WithEvents chSpan As System.Windows.Forms.ColumnHeader
    Friend WithEvents chLbaMin As System.Windows.Forms.ColumnHeader
    Friend WithEvents chLbaMax As System.Windows.Forms.ColumnHeader
    Friend WithEvents chCurTestStatus As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvwSelfTest As System.Windows.Forms.ListView
    Friend WithEvents chNum As System.Windows.Forms.ColumnHeader
    Friend WithEvents chTestType As System.Windows.Forms.ColumnHeader
    Friend WithEvents chTestStatus As System.Windows.Forms.ColumnHeader
    Friend WithEvents chRemaining As System.Windows.Forms.ColumnHeader
    Friend WithEvents chAge As System.Windows.Forms.ColumnHeader
    Friend WithEvents chFirstError As System.Windows.Forms.ColumnHeader
    Friend WithEvents tmrFlushMem As System.Windows.Forms.Timer
    Friend WithEvents mnuDevices As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuUpdateAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuRemoveVirtual As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUpdate As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAddVirtual As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblSelective As System.Windows.Forms.Label
    Friend WithEvents lblSelfTest As System.Windows.Forms.Label
    Friend WithEvents tmrTest As System.Windows.Forms.Timer
    Friend WithEvents mnuGuide As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lvwDevices As System.Windows.Forms.ListView
    Friend WithEvents chDevice As System.Windows.Forms.ColumnHeader
    Friend WithEvents chTemp As System.Windows.Forms.ColumnHeader
    Friend WithEvents picDeviceImage As System.Windows.Forms.PictureBox
    Friend WithEvents devPanel As hdd_guardian.DevicePanel
    Friend WithEvents imlDevice As System.Windows.Forms.ImageList
    Friend WithEvents FlagsPanel1 As hdd_guardian.FlagsPanel
    Friend WithEvents ValuesPanel1 As hdd_guardian.ValuesPanel
    Friend WithEvents flwFeatures As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents lblSmart As System.Windows.Forms.Label
    Friend WithEvents lblOfflineTest As System.Windows.Forms.Label
    Friend WithEvents lblAttrAutosave As System.Windows.Forms.Label
    Friend WithEvents lblDevTrayIcon As System.Windows.Forms.Label
    Friend WithEvents lblShare As System.Windows.Forms.Label
    Friend WithEvents lblDevFeatures As System.Windows.Forms.Label
    Friend WithEvents lblMonFeatures As System.Windows.Forms.Label
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnRunTest As System.Windows.Forms.Button
    Friend WithEvents btnDetails As System.Windows.Forms.Button
    Friend WithEvents gbAbout As hdd_guardian.GraphicalButton
    Friend WithEvents gbSmartctl As hdd_guardian.GraphicalButton
    Friend WithEvents gbAdvanced As hdd_guardian.GraphicalButton
    Friend WithEvents gbMain As hdd_guardian.GraphicalButton
    Friend WithEvents tabMain As System.Windows.Forms.TabControl
    Friend WithEvents tpSummary As System.Windows.Forms.TabPage
    Friend WithEvents tpInfo As System.Windows.Forms.TabPage
    Friend WithEvents dipInfo As hdd_guardian.DeviceInfoPanel
    Friend WithEvents tpFeatures As System.Windows.Forms.TabPage
    Friend WithEvents tpLog As System.Windows.Forms.TabPage
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnToday As System.Windows.Forms.Button
    Friend WithEvents btnPrev As System.Windows.Forms.Button
    Friend WithEvents btnReload As System.Windows.Forms.Button
    Friend WithEvents lvwLog As System.Windows.Forms.ListView
    Friend WithEvents chDeviceLog As System.Windows.Forms.ColumnHeader
    Friend WithEvents chTime As System.Windows.Forms.ColumnHeader
    Friend WithEvents chAttrLog As System.Windows.Forms.ColumnHeader
    Friend WithEvents chFrom As System.Windows.Forms.ColumnHeader
    Friend WithEvents chTo As System.Windows.Forms.ColumnHeader
    Friend WithEvents chVariation As System.Windows.Forms.ColumnHeader
    Friend WithEvents dteLog As System.Windows.Forms.DateTimePicker
    Friend WithEvents tpRunTest As System.Windows.Forms.TabPage
    Friend WithEvents btnRun As System.Windows.Forms.Button
    Friend WithEvents cboTest As System.Windows.Forms.ComboBox
    Friend WithEvents gbSettings As hdd_guardian.GraphicalButton
    Friend WithEvents lnkShowInfo As System.Windows.Forms.LinkLabel
    Friend WithEvents lblDataStructure As System.Windows.Forms.Label
    Friend WithEvents tabSmartctl As System.Windows.Forms.TabControl
    Friend WithEvents tpDatabase As System.Windows.Forms.TabPage
    Friend WithEvents tpOutput As System.Windows.Forms.TabPage
    Friend WithEvents lblModel As System.Windows.Forms.Label
    Friend WithEvents lblFirmware As System.Windows.Forms.Label
    Friend WithEvents lblFamily As System.Windows.Forms.Label
    Friend WithEvents lblAttrOptions As System.Windows.Forms.Label
    Friend WithEvents lblWarnings As System.Windows.Forms.Label
    Friend WithEvents lblModelValue As System.Windows.Forms.Label
    Friend WithEvents lblFirmwareValue As System.Windows.Forms.Label
    Friend WithEvents lblFamilyValue As System.Windows.Forms.Label
    Friend WithEvents lblAttrOptionsValue As System.Windows.Forms.Label
    Friend WithEvents lblWarningsValue As System.Windows.Forms.Label
    Friend WithEvents cboDatabase As System.Windows.Forms.ComboBox
    Friend WithEvents lblDatabase As System.Windows.Forms.Label
    Friend WithEvents btnSaveOutput As System.Windows.Forms.Button
    Friend WithEvents txtReport As System.Windows.Forms.TextBox
    Friend WithEvents tpTolerance As System.Windows.Forms.TabPage
    Friend WithEvents cboTolerance As System.Windows.Forms.ComboBox
    Friend WithEvents chkTolerance As System.Windows.Forms.CheckBox
    Friend WithEvents clCapabilities As hdd_guardian.CapabilitesList
    Friend WithEvents flwErrorLog As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents lblErrorLog As System.Windows.Forms.Label
    Friend WithEvents optError1 As System.Windows.Forms.RadioButton
    Friend WithEvents optError2 As System.Windows.Forms.RadioButton
    Friend WithEvents optError3 As System.Windows.Forms.RadioButton
    Friend WithEvents optError4 As System.Windows.Forms.RadioButton
    Friend WithEvents optError5 As System.Windows.Forms.RadioButton
    Friend WithEvents lblPowerOn As System.Windows.Forms.Label
    Friend WithEvents lblDeviceStatus As System.Windows.Forms.Label
    Friend WithEvents lblRegisters As System.Windows.Forms.Label
    Friend WithEvents lblCommands As System.Windows.Forms.Label
    Friend WithEvents CommandsPanel1 As hdd_guardian.CommandsPanel
    Friend WithEvents flwError As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents RegistersPanel1 As hdd_guardian.RegistersPanel
    Friend WithEvents tabSettings As System.Windows.Forms.TabControl
    Friend WithEvents tpLooknfeel As System.Windows.Forms.TabPage
    Friend WithEvents chkCloseOnTray As System.Windows.Forms.CheckBox
    Friend WithEvents chkStartupLink As System.Windows.Forms.CheckBox
    Friend WithEvents chkRunMinimized As System.Windows.Forms.CheckBox
    Friend WithEvents chkMinimizeInTray As System.Windows.Forms.CheckBox
    Friend WithEvents chkConfirmExit As System.Windows.Forms.CheckBox
    Friend WithEvents picWindow As System.Windows.Forms.PictureBox
    Friend WithEvents chkAlwaysShowTray As System.Windows.Forms.CheckBox
    Friend WithEvents tpUpdate As System.Windows.Forms.TabPage
    Friend WithEvents numUpdate As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblMinutes As System.Windows.Forms.Label
    Friend WithEvents lblOtherOptValue As System.Windows.Forms.Label
    Friend WithEvents lblOtherOpt As System.Windows.Forms.Label
    Friend WithEvents btnDelLog As System.Windows.Forms.Button
    Friend WithEvents btnDelAllLogs As System.Windows.Forms.Button
    Friend WithEvents flwTest As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents lblSelectTest As System.Windows.Forms.Label
    Friend WithEvents lblDuration As System.Windows.Forms.Label
    Friend WithEvents pnlTest As System.Windows.Forms.Panel
    Friend WithEvents lblProgress As System.Windows.Forms.Label
    Friend WithEvents btnStop As System.Windows.Forms.Button
    Friend WithEvents prbTestProgress As System.Windows.Forms.ProgressBar
    Friend WithEvents lblTestInfo As System.Windows.Forms.Label
    Friend WithEvents picTestInfo As System.Windows.Forms.PictureBox
    Friend WithEvents tpWarning As System.Windows.Forms.TabPage
    Friend WithEvents lblUpdate As System.Windows.Forms.Label
    Friend WithEvents picUpdate As System.Windows.Forms.PictureBox
    Friend WithEvents lblWarning As System.Windows.Forms.Label
    Friend WithEvents chkFailure As System.Windows.Forms.CheckBox
    Friend WithEvents chkTempThresh As System.Windows.Forms.CheckBox
    Friend WithEvents picWarning As System.Windows.Forms.PictureBox
    Friend WithEvents chkParamChng As System.Windows.Forms.CheckBox
    Friend WithEvents tpShare As System.Windows.Forms.TabPage
    Friend WithEvents btnBrwsFolder As System.Windows.Forms.Button
    Friend WithEvents lblFolder As System.Windows.Forms.Label
    Friend WithEvents lblSelFolder As System.Windows.Forms.Label
    Friend WithEvents picShare As System.Windows.Forms.PictureBox
    Friend WithEvents tpAttFormat As System.Windows.Forms.TabPage
    Friend WithEvents tpFirmware As System.Windows.Forms.TabPage
    Friend WithEvents pnlAttributes As System.Windows.Forms.Panel
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lvwAttrFormat As System.Windows.Forms.ListView
    Friend WithEvents chAttrID As System.Windows.Forms.ColumnHeader
    Friend WithEvents chAttrFormat As System.Windows.Forms.ColumnHeader
    Friend WithEvents chAttrName As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents cboFormat As System.Windows.Forms.ComboBox
    Friend WithEvents lblFormat As System.Windows.Forms.Label
    Friend WithEvents cboID As System.Windows.Forms.ComboBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents cboAttributes As System.Windows.Forms.ComboBox
    Friend WithEvents chkAttributes As System.Windows.Forms.CheckBox
    Friend WithEvents pnlFirmware As System.Windows.Forms.Panel
    Friend WithEvents chkFixSwap As System.Windows.Forms.CheckBox
    Friend WithEvents cboFirmware As System.Windows.Forms.ComboBox
    Friend WithEvents chkFirmware As System.Windows.Forms.CheckBox
    Friend WithEvents pnlTolerance As System.Windows.Forms.Panel
    Friend WithEvents picTolerance As System.Windows.Forms.PictureBox
    Friend WithEvents picAttrFormat As System.Windows.Forms.PictureBox
    Friend WithEvents picAttributes As System.Windows.Forms.PictureBox
    Friend WithEvents picSwap As System.Windows.Forms.PictureBox
    Friend WithEvents picFirmware As System.Windows.Forms.PictureBox
    Friend WithEvents hpSummary As hdd_guardian.HealthPanel
    Friend WithEvents apAttributes As hdd_guardian.AttributeInfoPanel
    'Friend WithEvents tipTest As hddguardian.TipPanel
    'Friend WithEvents tipTolerance As hddguardian.TipPanel
    'Friend WithEvents tipAttributes As hddguardian.TipPanel
    'Friend WithEvents tipFirmware As hddguardian.TipPanel
    Friend WithEvents picPower As System.Windows.Forms.PictureBox
    Friend WithEvents pnlProgress As System.Windows.Forms.Panel
    Friend WithEvents imlLog As System.Windows.Forms.ImageList
    Friend WithEvents lblNoLog As System.Windows.Forms.Label
    Friend WithEvents flwLog As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents tlpFeatures As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents picSmart As System.Windows.Forms.PictureBox
    Friend WithEvents picOfflineTest As System.Windows.Forms.PictureBox
    Friend WithEvents picAttrAutosave As System.Windows.Forms.PictureBox
    Friend WithEvents tlpMonitoring As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents picTrayIcon As System.Windows.Forms.PictureBox
    Friend WithEvents picShareOutput As System.Windows.Forms.PictureBox
    Friend WithEvents lblEnableSmart As System.Windows.Forms.Label
    Friend WithEvents lblEnableOffline As System.Windows.Forms.Label
    Friend WithEvents lblEnableAutosave As System.Windows.Forms.Label
    Friend WithEvents lblEnableTray As System.Windows.Forms.Label
    Friend WithEvents lblEnableShare As System.Windows.Forms.Label
    Friend WithEvents lnkSetFolder As System.Windows.Forms.LinkLabel
    Friend WithEvents tlpStatusBar As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents picManufacturer As System.Windows.Forms.PictureBox
    Friend WithEvents picOsIcon As System.Windows.Forms.PictureBox
    Friend WithEvents picUsb As System.Windows.Forms.PictureBox
    Friend WithEvents picAdmin As System.Windows.Forms.PictureBox
    Friend WithEvents lblExtimatedEnd As System.Windows.Forms.Label
    Friend WithEvents dlgFolder As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents tabAbout As System.Windows.Forms.TabControl
    Friend WithEvents lnkBrandsOfTheWorld As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkKamiyamane As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkFamFamFam As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkSmartMonTools As System.Windows.Forms.LinkLabel
    Friend WithEvents lblLicense As System.Windows.Forms.Label
    Friend WithEvents lnkCcBy As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkGpl As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkWesternDigital As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkPremiumPixels As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkHddGuardian As System.Windows.Forms.LinkLabel
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents lblCopyright As System.Windows.Forms.Label
    Friend WithEvents picAdminSelective As System.Windows.Forms.PictureBox
    Friend WithEvents picAdminSelfTest As System.Windows.Forms.PictureBox
    Friend WithEvents picAdminSmart As System.Windows.Forms.PictureBox
    Friend WithEvents picAdminOffline As System.Windows.Forms.PictureBox
    Friend WithEvents picAdminAutosave As System.Windows.Forms.PictureBox
    Friend WithEvents lblErrLogVer As System.Windows.Forms.Label
    Friend WithEvents picAdminError As System.Windows.Forms.PictureBox
    Friend WithEvents lblFramework As System.Windows.Forms.Label
    Friend WithEvents lnkGnomeGit As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkGnome As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkGplGnome As System.Windows.Forms.LinkLabel
    Friend WithEvents picLanguageFlag As System.Windows.Forms.PictureBox
    Friend WithEvents tpContributors As System.Windows.Forms.TabPage
    Friend WithEvents picVersion As System.Windows.Forms.PictureBox
    Friend WithEvents picHome As System.Windows.Forms.PictureBox
    Friend WithEvents lnkEmail As System.Windows.Forms.LinkLabel
    Friend WithEvents picEmail As System.Windows.Forms.PictureBox
    Friend WithEvents picGroup As System.Windows.Forms.PictureBox
    Friend WithEvents lnkGroup As System.Windows.Forms.LinkLabel
    Friend WithEvents pnlUpdate As System.Windows.Forms.Panel
    Friend WithEvents lnkUpdate As System.Windows.Forms.LinkLabel
    Friend WithEvents tipTolerance As hdd_guardian.TipPanel
    Friend WithEvents tipAttributes As hdd_guardian.TipPanel
    Friend WithEvents tipFirmware As hdd_guardian.TipPanel
    Friend WithEvents tipTest As hdd_guardian.TipPanel
    Friend WithEvents lnkCoolerMaster As System.Windows.Forms.LinkLabel
    Friend WithEvents picPlus As System.Windows.Forms.PictureBox
    Friend WithEvents lnkPlus As System.Windows.Forms.LinkLabel
    Friend WithEvents tlpUpdate As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lblExternal As System.Windows.Forms.Label
    Friend WithEvents numUpdateExt As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblMinutesExt As System.Windows.Forms.Label
    Friend WithEvents lblInternal As System.Windows.Forms.Label
    Friend WithEvents tmrRefreshExt As System.Windows.Forms.Timer
    Friend WithEvents lblVirtual As System.Windows.Forms.Label
    Friend WithEvents numUpdateVirtual As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblMinutesVirt As System.Windows.Forms.Label
    Friend WithEvents tmrRefreshVirtual As System.Windows.Forms.Timer
    Friend WithEvents tpMonitoring As System.Windows.Forms.TabPage
    Friend WithEvents lblMonitoring As System.Windows.Forms.Label
    Friend WithEvents picMonitoring As System.Windows.Forms.PictureBox
    Friend WithEvents chkIndilinx As System.Windows.Forms.CheckBox
    Friend WithEvents lnkInvertSelSSD As System.Windows.Forms.LinkLabel
    Friend WithEvents chkSandForce As System.Windows.Forms.CheckBox
    Friend WithEvents chkIntel As System.Windows.Forms.CheckBox
    Friend WithEvents chkSamsung As System.Windows.Forms.CheckBox
    Friend WithEvents chkMicron As System.Windows.Forms.CheckBox
    Friend WithEvents chkReallSectCt As System.Windows.Forms.CheckBox
    Friend WithEvents chkSpinRetryCt As System.Windows.Forms.CheckBox
    Friend WithEvents chkTemp As System.Windows.Forms.CheckBox
    Friend WithEvents chkReallEvCt As System.Windows.Forms.CheckBox
    Friend WithEvents chkCurPenSect As System.Windows.Forms.CheckBox
    Friend WithEvents chkOfflUnc As System.Windows.Forms.CheckBox
    Friend WithEvents chkSoftReadErr As System.Windows.Forms.CheckBox
    Friend WithEvents lnkInvertSel As System.Windows.Forms.LinkLabel
    Friend WithEvents chkDiskShift As System.Windows.Forms.CheckBox
    Friend WithEvents lblGeneric As System.Windows.Forms.Label
    Friend WithEvents lblSSD As System.Windows.Forms.Label
    Friend WithEvents tpGeometryPartitions As System.Windows.Forms.TabPage
    Friend WithEvents lvwGeometry As System.Windows.Forms.ListView
    Friend WithEvents chOne As System.Windows.Forms.ColumnHeader
    Friend WithEvents chTwo As System.Windows.Forms.ColumnHeader
    Friend WithEvents chThree As System.Windows.Forms.ColumnHeader
    Friend WithEvents lblGathering As System.Windows.Forms.Label
    Friend WithEvents chkXml As System.Windows.Forms.CheckBox
    Friend WithEvents btnXml As System.Windows.Forms.Button
    Friend WithEvents lblXmlPath As System.Windows.Forms.Label
    Friend WithEvents lblXml As System.Windows.Forms.Label
    Friend WithEvents picXml As System.Windows.Forms.PictureBox
    Friend WithEvents mnuRescanExternal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tpRating As System.Windows.Forms.TabPage
    Friend WithEvents chkTuneUp As System.Windows.Forms.CheckBox
    Friend WithEvents tlpTuneUp As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lnkResetCurPend As System.Windows.Forms.LinkLabel
    Friend WithEvents lblCurPendTune As System.Windows.Forms.Label
    Friend WithEvents lnkResetErrors As System.Windows.Forms.LinkLabel
    Friend WithEvents lblErrorsTune As System.Windows.Forms.Label
    Friend WithEvents lblOfflUncTune As System.Windows.Forms.Label
    Friend WithEvents lnkResetOfflUnc As System.Windows.Forms.LinkLabel
    Friend WithEvents numErrors As System.Windows.Forms.NumericUpDown
    Friend WithEvents numCurPend As System.Windows.Forms.NumericUpDown
    Friend WithEvents numOfflUnc As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkRating As System.Windows.Forms.CheckBox
    Friend WithEvents picRating As System.Windows.Forms.PictureBox
    Friend WithEvents picStars As System.Windows.Forms.PictureBox
    Friend WithEvents picHelp As System.Windows.Forms.PictureBox
    Friend WithEvents mnuRescanRemovable As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tpReliability As System.Windows.Forms.TabPage
    Friend WithEvents lblErrors As System.Windows.Forms.Label
    Friend WithEvents lblReallSect As System.Windows.Forms.Label
    Friend WithEvents lblCurPending As System.Windows.Forms.Label
    Friend WithEvents lblOfflUnc As System.Windows.Forms.Label
    Friend WithEvents lblIndilinx As System.Windows.Forms.Label
    Friend WithEvents lblIntel As System.Windows.Forms.Label
    Friend WithEvents lblMicron As System.Windows.Forms.Label
    Friend WithEvents lblSamsung As System.Windows.Forms.Label
    Friend WithEvents lblSandForce As System.Windows.Forms.Label
    Friend WithEvents picErrors As System.Windows.Forms.PictureBox
    Friend WithEvents picReallSect As System.Windows.Forms.PictureBox
    Friend WithEvents picCurPending As System.Windows.Forms.PictureBox
    Friend WithEvents picOfflUnc As System.Windows.Forms.PictureBox
    Friend WithEvents picIndilinx As System.Windows.Forms.PictureBox
    Friend WithEvents picIntel As System.Windows.Forms.PictureBox
    Friend WithEvents picMicron As System.Windows.Forms.PictureBox
    Friend WithEvents picSamsung As System.Windows.Forms.PictureBox
    Friend WithEvents picSandForce As System.Windows.Forms.PictureBox
    Friend WithEvents lblErrValue As System.Windows.Forms.Label
    Friend WithEvents lblReallSectValue As System.Windows.Forms.Label
    Friend WithEvents lblCurPendingValue As System.Windows.Forms.Label
    Friend WithEvents lblOfflUncValue As System.Windows.Forms.Label
    Friend WithEvents lblIndilinxValue As System.Windows.Forms.Label
    Friend WithEvents lblIntelValue As System.Windows.Forms.Label
    Friend WithEvents lblMicronValue As System.Windows.Forms.Label
    Friend WithEvents lblSamsungValue As System.Windows.Forms.Label
    Friend WithEvents lblSandForceValue As System.Windows.Forms.Label

End Class
