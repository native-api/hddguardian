﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GraphicalButton
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GraphicalButton))
        Me.tlpGrid = New System.Windows.Forms.TableLayoutPanel()
        Me.pbRight = New System.Windows.Forms.PictureBox()
        Me.pbLeft = New System.Windows.Forms.PictureBox()
        Me.imlBackground = New System.Windows.Forms.ImageList(Me.components)
        Me.lblText = New System.Windows.Forms.Label()
        Me.tlpGrid.SuspendLayout()
        CType(Me.pbRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tlpGrid
        '
        Me.tlpGrid.AutoSize = True
        Me.tlpGrid.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpGrid.BackColor = System.Drawing.Color.Transparent
        Me.tlpGrid.ColumnCount = 3
        Me.tlpGrid.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpGrid.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpGrid.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpGrid.Controls.Add(Me.lblText, 1, 0)
        Me.tlpGrid.Controls.Add(Me.pbRight, 2, 0)
        Me.tlpGrid.Controls.Add(Me.pbLeft, 0, 0)
        Me.tlpGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpGrid.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize
        Me.tlpGrid.Location = New System.Drawing.Point(0, 0)
        Me.tlpGrid.Margin = New System.Windows.Forms.Padding(0)
        Me.tlpGrid.Name = "tlpGrid"
        Me.tlpGrid.RowCount = 1
        Me.tlpGrid.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpGrid.Size = New System.Drawing.Size(269, 24)
        Me.tlpGrid.TabIndex = 0
        '
        'pbRight
        '
        Me.pbRight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbRight.Location = New System.Drawing.Point(268, 0)
        Me.pbRight.Margin = New System.Windows.Forms.Padding(0)
        Me.pbRight.Name = "pbRight"
        Me.pbRight.Size = New System.Drawing.Size(1, 24)
        Me.pbRight.TabIndex = 2
        Me.pbRight.TabStop = False
        '
        'pbLeft
        '
        Me.pbLeft.BackgroundImage = CType(resources.GetObject("pbLeft.BackgroundImage"), System.Drawing.Image)
        Me.pbLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbLeft.Location = New System.Drawing.Point(0, 0)
        Me.pbLeft.Margin = New System.Windows.Forms.Padding(0)
        Me.pbLeft.Name = "pbLeft"
        Me.pbLeft.Size = New System.Drawing.Size(1, 24)
        Me.pbLeft.TabIndex = 1
        Me.pbLeft.TabStop = False
        '
        'imlBackground
        '
        Me.imlBackground.ImageStream = CType(resources.GetObject("imlBackground.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlBackground.TransparentColor = System.Drawing.Color.Transparent
        Me.imlBackground.Images.SetKeyName(0, "old_selected")
        Me.imlBackground.Images.SetKeyName(1, "old_unselect")
        Me.imlBackground.Images.SetKeyName(2, "deselected_left")
        Me.imlBackground.Images.SetKeyName(3, "deselected")
        Me.imlBackground.Images.SetKeyName(4, "selected")
        '
        'lblText
        '
        Me.lblText.AutoSize = True
        Me.lblText.BackColor = System.Drawing.Color.Transparent
        Me.lblText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblText.ForeColor = System.Drawing.Color.White
        Me.lblText.Location = New System.Drawing.Point(4, 0)
        Me.lblText.MinimumSize = New System.Drawing.Size(0, 24)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(261, 24)
        Me.lblText.TabIndex = 0
        Me.lblText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GraphicalButton
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.hdd_guardian.My.Resources.Resources.deselected
        Me.Controls.Add(Me.tlpGrid)
        Me.Margin = New System.Windows.Forms.Padding(0)
        Me.MaximumSize = New System.Drawing.Size(0, 24)
        Me.MinimumSize = New System.Drawing.Size(24, 24)
        Me.Name = "GraphicalButton"
        Me.Size = New System.Drawing.Size(269, 24)
        Me.tlpGrid.ResumeLayout(False)
        Me.tlpGrid.PerformLayout()
        CType(Me.pbRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbLeft, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Protected WithEvents tlpGrid As System.Windows.Forms.TableLayoutPanel
    Protected WithEvents pbRight As System.Windows.Forms.PictureBox
    Protected WithEvents pbLeft As System.Windows.Forms.PictureBox
    Protected WithEvents imlBackground As System.Windows.Forms.ImageList
    Protected WithEvents lblText As System.Windows.Forms.Label

End Class
