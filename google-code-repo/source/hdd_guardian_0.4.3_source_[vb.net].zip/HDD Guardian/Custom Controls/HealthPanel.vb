﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Drawing

Public Class HealthPanel
    Dim iconsfolder As String
    Dim colorOk As Color = Color.Blue
    Dim colorWarning As Color = Color.DarkOrange
    Dim colorAlarm As Color = Color.Red
    Dim imgOK As Image
    Dim imgWarning As Image
    Dim imgAlarm As Image
    Dim imgStop As Image
    Dim tempOK As Image
    Dim tempHigh As Image
    Dim tempExcessive As Image
    Dim na As Image

    Public Enum WarningLevel
        Ok = 0
        Warning = 1
        Alarm = 2
        Halt = 3
        NA = 4
    End Enum

    Public Sub SetIconsFolder(ByVal path As String)
        iconsfolder = path
        imgOK = Image.FromFile(iconsfolder & "status-information.png")
        imgWarning = Image.FromFile(iconsfolder & "status-exclamation.png")
        imgAlarm = Image.FromFile(iconsfolder & "status-exclamation red.png")
        imgStop = Image.FromFile(iconsfolder & "status-stop.png")
        tempOK = Image.FromFile(iconsfolder & "temperature-low.png")
        tempHigh = Image.FromFile(iconsfolder & "temperature.png")
        tempExcessive = Image.FromFile(iconsfolder & "temperature-high.png")
        na = Image.FromFile(iconsfolder & "na.png")
    End Sub

    Public Sub SetCaptions(ByVal temperature As String, ByVal lasttest As String, _
                           ByVal overallhealth As String, ByVal lastupdate As String, _
                            ByVal warning As String)
        lblTemperature.Text = temperature & ":"
        lblLastTest.Text = lasttest & ":"
        lblOverallHealth.Text = overallhealth & ":"
        lblLastUpdate.Text = lastupdate & ":"
        lblWarning.Text = warning & ":"
    End Sub

    Public Sub Temperature(ByVal value As String, ByVal fahrenheit As Boolean)
        With lblTempValue
            If IsNumeric(value) Then
                Dim temp As String
                If fahrenheit = False Then
                    temp = value & "°C"
                Else
                    temp = Math.Round(value * 1.8 + 32) & "°F"
                End If
                Select Case value
                    Case 0 To 49
                        pbTemp.BackgroundImage = tempOK
                        .ForeColor = colorOk
                        .Text = temp
                    Case 50 To 54
                        pbTemp.BackgroundImage = tempHigh
                        .ForeColor = colorWarning
                        .Text = temp
                    Case Is >= 55
                        pbTemp.BackgroundImage = tempExcessive
                        .ForeColor = colorAlarm
                        .Text = temp
                End Select
                .Font = New Font(.Font, System.Drawing.FontStyle.Bold)
            Else
                pbTemp.BackgroundImage = na
                .Text = "N/A"
                .ForeColor = Color.FromKnownColor(KnownColor.GrayText)
                .Font = New Font(.Font, System.Drawing.FontStyle.Regular)
            End If
        End With
    End Sub

    Public Sub BadSectors(ByVal caption As String, ByVal badsectors As Integer)
        With lblBadSectorsValue
            Select Case badsectors
                Case 0
                    .ForeColor = colorOk
                Case 1 To 50
                    .ForeColor = colorWarning
                Case Is > 50
                    .ForeColor = colorAlarm
            End Select
            .Text = caption
            If pbOverallHealth.BackgroundImage Is na Then
                .Visible = False
            Else
                .Visible = True
            End If
        End With
    End Sub

    Public Sub Errors(ByVal caption As String, ByVal errorcount As Integer)
        With lblErrors
            Select Case errorcount
                Case 0
                    .ForeColor = colorOk
                Case 1 To 10
                    .ForeColor = colorWarning
                Case Is > 10
                    .ForeColor = colorAlarm
            End Select
            .Text = caption
            If pbOverallHealth.BackgroundImage Is na Then
                .Visible = False
            Else
                .Visible = True
            End If
        End With
    End Sub

    Public Sub LastUpdate(ByVal caption As String)
        lblLastUpdateValue.Text = caption
    End Sub

    Public Sub LastTest(ByVal caption As String, ByVal isfailed As WarningLevel)
        With lblLastTestValue
            Select Case isfailed
                Case WarningLevel.Warning
                    pbLastTest.BackgroundImage = imgWarning
                    .ForeColor = colorWarning
                    .Font = New Font(.Font, FontStyle.Bold)
                Case WarningLevel.Ok
                    pbLastTest.BackgroundImage = imgOK
                    .ForeColor = colorOk
                    .Font = New Font(.Font, FontStyle.Regular)
                Case WarningLevel.NA
                    pbLastTest.BackgroundImage = na
                    .ForeColor = Color.FromKnownColor(KnownColor.GrayText)
                    .Font = New Font(.Font, FontStyle.Regular)
                    caption = "N/A"
            End Select
            .Text = caption
        End With
    End Sub

    Public Sub OverallHealth(ByVal caption As String, ByVal isfailed As WarningLevel)
        With lblOverallHealthValue
            Select Case isfailed
                Case WarningLevel.Alarm
                    pbOverallHealth.BackgroundImage = imgAlarm
                    .ForeColor = colorAlarm
                    .Font = New Font(.Font, FontStyle.Bold)
                Case WarningLevel.Ok
                    pbOverallHealth.BackgroundImage = imgOK
                    .ForeColor = colorOk
                    .Font = New Font(.Font, FontStyle.Regular)
                Case WarningLevel.NA
                    pbOverallHealth.BackgroundImage = na
                    .ForeColor = Color.FromKnownColor(KnownColor.GrayText)
                    .Font = New Font(.Font, FontStyle.Regular)
                    caption = "N/A"
            End Select
            .Text = caption
        End With
    End Sub

    Public Sub Warning(ByVal warning As WarningLevel, ByVal caption As String, _
                       ByVal havelink As Boolean, Optional ByVal link1 As String = "", _
                        Optional ByVal link2 As String = "", Optional ByVal link3 As String = "")
        With lblWarningValue
            Select Case warning
                Case WarningLevel.Warning
                    pbWarning.BackgroundImage = imgWarning
                    .ForeColor = colorWarning
                    .Font = New Font(.Font, FontStyle.Bold)
                Case WarningLevel.Ok
                    pbWarning.BackgroundImage = imgOK
                    .ForeColor = colorOk
                    .Font = New Font(.Font, FontStyle.Regular)
                Case WarningLevel.Halt
                    pbWarning.BackgroundImage = imgStop
                    .ForeColor = colorAlarm
                    .Font = New Font(.Font, FontStyle.Regular)
            End Select
            .Text = caption
            If link1.Contains("Please see") Then .Text += " Please see:"
            lnkWeb1.Text = link1.Replace("Please see", "").Replace(" and", "").Replace(vbCr, "").Replace(vbLf, "").Trim
            lnkWeb2.Text = link2.Replace(vbCr, "").Replace(vbLf, "").Trim
            lnkWeb3.Text = link3.Replace(vbCr, "").Replace(vbLf, "").Trim
            Select Case havelink
                Case True
                    lnkWeb1.AutoSize = True
                    lnkWeb2.AutoSize = True
                    lnkWeb3.AutoSize = True
                Case False
                    lnkWeb1.AutoSize = False
                    lnkWeb1.Size = New Size(0, 0)
                    lnkWeb2.AutoSize = False
                    lnkWeb2.Size = New Size(0, 0)
                    lnkWeb3.AutoSize = False
                    lnkWeb3.Size = New Size(0, 0)
            End Select

        End With
    End Sub

    Public Sub New()

        ' Chiamata richiesta dalla finestra di progettazione.
        InitializeComponent()

        ' Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent().
        For Each Label In tlpMain.Controls
            Label.Text = ""
        Next
    End Sub

    Private Sub WebLinks(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkWeb1.Click, lnkWeb2.Click, lnkWeb3.Click
        Try
            System.Diagnostics.Process.Start(sender.Text)
        Catch
        End Try
    End Sub
End Class
