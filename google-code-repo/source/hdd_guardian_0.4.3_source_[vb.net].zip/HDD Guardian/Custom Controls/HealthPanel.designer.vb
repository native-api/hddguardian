﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HealthPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim flwWarnings As System.Windows.Forms.FlowLayoutPanel
        Me.lblWarningValue = New System.Windows.Forms.Label()
        Me.lnkWeb1 = New System.Windows.Forms.LinkLabel()
        Me.lnkWeb2 = New System.Windows.Forms.LinkLabel()
        Me.lnkWeb3 = New System.Windows.Forms.LinkLabel()
        Me.pbTemp = New System.Windows.Forms.PictureBox()
        Me.lblTempValue = New System.Windows.Forms.Label()
        Me.pbWarning = New System.Windows.Forms.PictureBox()
        Me.lblLastUpdateValue = New System.Windows.Forms.Label()
        Me.tlpMain = New System.Windows.Forms.TableLayoutPanel()
        Me.pbOverallHealth = New System.Windows.Forms.PictureBox()
        Me.lblTemperature = New System.Windows.Forms.Label()
        Me.lblLastTest = New System.Windows.Forms.Label()
        Me.lblOverallHealth = New System.Windows.Forms.Label()
        Me.lblLastUpdate = New System.Windows.Forms.Label()
        Me.lblWarning = New System.Windows.Forms.Label()
        Me.pbLastTest = New System.Windows.Forms.PictureBox()
        Me.flwOverallHealth = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblOverallHealthValue = New System.Windows.Forms.Label()
        Me.lblBadSectorsValue = New System.Windows.Forms.Label()
        Me.lblErrors = New System.Windows.Forms.Label()
        Me.lblLastTestValue = New System.Windows.Forms.Label()
        flwWarnings = New System.Windows.Forms.FlowLayoutPanel()
        flwWarnings.SuspendLayout()
        CType(Me.pbTemp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbWarning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tlpMain.SuspendLayout()
        CType(Me.pbOverallHealth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbLastTest, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.flwOverallHealth.SuspendLayout()
        Me.SuspendLayout()
        '
        'flwWarnings
        '
        flwWarnings.AutoSize = True
        flwWarnings.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        flwWarnings.Controls.Add(Me.lblWarningValue)
        flwWarnings.Controls.Add(Me.lnkWeb1)
        flwWarnings.Controls.Add(Me.lnkWeb2)
        flwWarnings.Controls.Add(Me.lnkWeb3)
        flwWarnings.Dock = System.Windows.Forms.DockStyle.Fill
        flwWarnings.Location = New System.Drawing.Point(108, 124)
        flwWarnings.Margin = New System.Windows.Forms.Padding(0)
        flwWarnings.Name = "flwWarnings"
        flwWarnings.Size = New System.Drawing.Size(304, 64)
        flwWarnings.TabIndex = 37
        '
        'lblWarningValue
        '
        Me.lblWarningValue.AutoSize = True
        flwWarnings.SetFlowBreak(Me.lblWarningValue, True)
        Me.lblWarningValue.Location = New System.Drawing.Point(3, 0)
        Me.lblWarningValue.Name = "lblWarningValue"
        Me.lblWarningValue.Padding = New System.Windows.Forms.Padding(0, 3, 0, 3)
        Me.lblWarningValue.Size = New System.Drawing.Size(83, 19)
        Me.lblWarningValue.TabIndex = 14
        Me.lblWarningValue.Text = "lblWarningValue"
        '
        'lnkWeb1
        '
        Me.lnkWeb1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkWeb1.AutoSize = True
        flwWarnings.SetFlowBreak(Me.lnkWeb1, True)
        Me.lnkWeb1.Location = New System.Drawing.Point(3, 19)
        Me.lnkWeb1.Name = "lnkWeb1"
        Me.lnkWeb1.Padding = New System.Windows.Forms.Padding(0, 0, 0, 3)
        Me.lnkWeb1.Size = New System.Drawing.Size(48, 16)
        Me.lnkWeb1.TabIndex = 15
        Me.lnkWeb1.TabStop = True
        Me.lnkWeb1.Text = "lnkWeb1"
        '
        'lnkWeb2
        '
        Me.lnkWeb2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkWeb2.AutoSize = True
        flwWarnings.SetFlowBreak(Me.lnkWeb2, True)
        Me.lnkWeb2.Location = New System.Drawing.Point(3, 35)
        Me.lnkWeb2.Name = "lnkWeb2"
        Me.lnkWeb2.Padding = New System.Windows.Forms.Padding(0, 0, 0, 3)
        Me.lnkWeb2.Size = New System.Drawing.Size(48, 16)
        Me.lnkWeb2.TabIndex = 16
        Me.lnkWeb2.TabStop = True
        Me.lnkWeb2.Text = "lnkWeb2"
        '
        'lnkWeb3
        '
        Me.lnkWeb3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lnkWeb3.AutoSize = True
        flwWarnings.SetFlowBreak(Me.lnkWeb3, True)
        Me.lnkWeb3.Location = New System.Drawing.Point(3, 51)
        Me.lnkWeb3.Name = "lnkWeb3"
        Me.lnkWeb3.Size = New System.Drawing.Size(48, 13)
        Me.lnkWeb3.TabIndex = 17
        Me.lnkWeb3.TabStop = True
        Me.lnkWeb3.Text = "lnkWeb3"
        '
        'pbTemp
        '
        Me.pbTemp.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pbTemp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pbTemp.Location = New System.Drawing.Point(90, 2)
        Me.pbTemp.Margin = New System.Windows.Forms.Padding(2)
        Me.pbTemp.Name = "pbTemp"
        Me.pbTemp.Size = New System.Drawing.Size(16, 16)
        Me.pbTemp.TabIndex = 2
        Me.pbTemp.TabStop = False
        '
        'lblTempValue
        '
        Me.lblTempValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblTempValue.AutoSize = True
        Me.lblTempValue.Location = New System.Drawing.Point(111, 3)
        Me.lblTempValue.Name = "lblTempValue"
        Me.lblTempValue.Size = New System.Drawing.Size(69, 13)
        Me.lblTempValue.TabIndex = 1
        Me.lblTempValue.Text = "lblTempValue"
        '
        'pbWarning
        '
        Me.pbWarning.Location = New System.Drawing.Point(90, 126)
        Me.pbWarning.Margin = New System.Windows.Forms.Padding(2)
        Me.pbWarning.Name = "pbWarning"
        Me.pbWarning.Size = New System.Drawing.Size(16, 16)
        Me.pbWarning.TabIndex = 13
        Me.pbWarning.TabStop = False
        '
        'lblLastUpdateValue
        '
        Me.lblLastUpdateValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblLastUpdateValue.AutoSize = True
        Me.lblLastUpdateValue.Location = New System.Drawing.Point(111, 98)
        Me.lblLastUpdateValue.Name = "lblLastUpdateValue"
        Me.lblLastUpdateValue.Padding = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.lblLastUpdateValue.Size = New System.Drawing.Size(98, 16)
        Me.lblLastUpdateValue.TabIndex = 0
        Me.lblLastUpdateValue.Text = "lblLastUpdateValue"
        Me.lblLastUpdateValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tlpMain
        '
        Me.tlpMain.AutoSize = True
        Me.tlpMain.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpMain.ColumnCount = 3
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpMain.Controls.Add(Me.pbWarning, 1, 6)
        Me.tlpMain.Controls.Add(Me.pbOverallHealth, 1, 2)
        Me.tlpMain.Controls.Add(flwWarnings, 2, 6)
        Me.tlpMain.Controls.Add(Me.lblTemperature, 0, 0)
        Me.tlpMain.Controls.Add(Me.lblTempValue, 2, 0)
        Me.tlpMain.Controls.Add(Me.lblLastTest, 0, 1)
        Me.tlpMain.Controls.Add(Me.lblOverallHealth, 0, 2)
        Me.tlpMain.Controls.Add(Me.lblLastUpdate, 0, 4)
        Me.tlpMain.Controls.Add(Me.lblWarning, 0, 6)
        Me.tlpMain.Controls.Add(Me.pbTemp, 1, 0)
        Me.tlpMain.Controls.Add(Me.pbLastTest, 1, 1)
        Me.tlpMain.Controls.Add(Me.flwOverallHealth, 2, 2)
        Me.tlpMain.Controls.Add(Me.lblLastTestValue, 2, 1)
        Me.tlpMain.Controls.Add(Me.lblLastUpdateValue, 2, 4)
        Me.tlpMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpMain.Location = New System.Drawing.Point(0, 0)
        Me.tlpMain.Margin = New System.Windows.Forms.Padding(0)
        Me.tlpMain.Name = "tlpMain"
        Me.tlpMain.RowCount = 8
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpMain.Size = New System.Drawing.Size(412, 227)
        Me.tlpMain.TabIndex = 0
        '
        'pbOverallHealth
        '
        Me.pbOverallHealth.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pbOverallHealth.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pbOverallHealth.Location = New System.Drawing.Point(90, 42)
        Me.pbOverallHealth.Margin = New System.Windows.Forms.Padding(2)
        Me.pbOverallHealth.Name = "pbOverallHealth"
        Me.pbOverallHealth.Size = New System.Drawing.Size(16, 16)
        Me.pbOverallHealth.TabIndex = 10
        Me.pbOverallHealth.TabStop = False
        '
        'lblTemperature
        '
        Me.lblTemperature.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblTemperature.AutoSize = True
        Me.lblTemperature.Location = New System.Drawing.Point(6, 3)
        Me.lblTemperature.Name = "lblTemperature"
        Me.lblTemperature.Size = New System.Drawing.Size(79, 13)
        Me.lblTemperature.TabIndex = 0
        Me.lblTemperature.Text = "lblTemperature"
        '
        'lblLastTest
        '
        Me.lblLastTest.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblLastTest.AutoSize = True
        Me.lblLastTest.Location = New System.Drawing.Point(27, 23)
        Me.lblLastTest.Name = "lblLastTest"
        Me.lblLastTest.Size = New System.Drawing.Size(58, 13)
        Me.lblLastTest.TabIndex = 6
        Me.lblLastTest.Text = "lblLastTest"
        '
        'lblOverallHealth
        '
        Me.lblOverallHealth.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblOverallHealth.AutoSize = True
        Me.lblOverallHealth.Location = New System.Drawing.Point(3, 43)
        Me.lblOverallHealth.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblOverallHealth.Name = "lblOverallHealth"
        Me.lblOverallHealth.Size = New System.Drawing.Size(82, 13)
        Me.lblOverallHealth.TabIndex = 9
        Me.lblOverallHealth.Text = "lblOverallHealth"
        '
        'lblLastUpdate
        '
        Me.lblLastUpdate.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblLastUpdate.AutoSize = True
        Me.lblLastUpdate.Location = New System.Drawing.Point(13, 98)
        Me.lblLastUpdate.Name = "lblLastUpdate"
        Me.lblLastUpdate.Padding = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.lblLastUpdate.Size = New System.Drawing.Size(72, 16)
        Me.lblLastUpdate.TabIndex = 30
        Me.lblLastUpdate.Text = "lblLastUpdate"
        Me.lblLastUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWarning
        '
        Me.lblWarning.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblWarning.AutoSize = True
        Me.lblWarning.Location = New System.Drawing.Point(28, 124)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.Padding = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.lblWarning.Size = New System.Drawing.Size(57, 16)
        Me.lblWarning.TabIndex = 12
        Me.lblWarning.Text = "lblWarning"
        '
        'pbLastTest
        '
        Me.pbLastTest.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pbLastTest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pbLastTest.Location = New System.Drawing.Point(90, 22)
        Me.pbLastTest.Margin = New System.Windows.Forms.Padding(2)
        Me.pbLastTest.Name = "pbLastTest"
        Me.pbLastTest.Size = New System.Drawing.Size(16, 16)
        Me.pbLastTest.TabIndex = 7
        Me.pbLastTest.TabStop = False
        '
        'flwOverallHealth
        '
        Me.flwOverallHealth.AutoSize = True
        Me.flwOverallHealth.Controls.Add(Me.lblOverallHealthValue)
        Me.flwOverallHealth.Controls.Add(Me.lblBadSectorsValue)
        Me.flwOverallHealth.Controls.Add(Me.lblErrors)
        Me.flwOverallHealth.Dock = System.Windows.Forms.DockStyle.Fill
        Me.flwOverallHealth.Location = New System.Drawing.Point(108, 40)
        Me.flwOverallHealth.Margin = New System.Windows.Forms.Padding(0)
        Me.flwOverallHealth.Name = "flwOverallHealth"
        Me.flwOverallHealth.Size = New System.Drawing.Size(304, 48)
        Me.flwOverallHealth.TabIndex = 36
        '
        'lblOverallHealthValue
        '
        Me.lblOverallHealthValue.AutoSize = True
        Me.flwOverallHealth.SetFlowBreak(Me.lblOverallHealthValue, True)
        Me.lblOverallHealthValue.Location = New System.Drawing.Point(3, 3)
        Me.lblOverallHealthValue.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblOverallHealthValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblOverallHealthValue.Name = "lblOverallHealthValue"
        Me.lblOverallHealthValue.Size = New System.Drawing.Size(108, 16)
        Me.lblOverallHealthValue.TabIndex = 11
        Me.lblOverallHealthValue.Text = "lblOverallHealthValue"
        '
        'lblBadSectorsValue
        '
        Me.lblBadSectorsValue.AutoSize = True
        Me.flwOverallHealth.SetFlowBreak(Me.lblBadSectorsValue, True)
        Me.lblBadSectorsValue.Location = New System.Drawing.Point(3, 19)
        Me.lblBadSectorsValue.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblBadSectorsValue.Name = "lblBadSectorsValue"
        Me.lblBadSectorsValue.Size = New System.Drawing.Size(97, 16)
        Me.lblBadSectorsValue.TabIndex = 5
        Me.lblBadSectorsValue.Text = "lblBadSectorsValue"
        '
        'lblErrors
        '
        Me.lblErrors.AutoSize = True
        Me.lblErrors.Location = New System.Drawing.Point(3, 35)
        Me.lblErrors.Name = "lblErrors"
        Me.lblErrors.Size = New System.Drawing.Size(46, 13)
        Me.lblErrors.TabIndex = 12
        Me.lblErrors.Text = "lblErrors"
        '
        'lblLastTestValue
        '
        Me.lblLastTestValue.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblLastTestValue.AutoSize = True
        Me.lblLastTestValue.Location = New System.Drawing.Point(111, 23)
        Me.lblLastTestValue.Name = "lblLastTestValue"
        Me.lblLastTestValue.Size = New System.Drawing.Size(84, 13)
        Me.lblLastTestValue.TabIndex = 8
        Me.lblLastTestValue.Text = "lblLastTestValue"
        '
        'HealthPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Controls.Add(Me.tlpMain)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MinimumSize = New System.Drawing.Size(300, 0)
        Me.Name = "HealthPanel"
        Me.Size = New System.Drawing.Size(412, 227)
        flwWarnings.ResumeLayout(False)
        flwWarnings.PerformLayout()
        CType(Me.pbTemp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbWarning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tlpMain.ResumeLayout(False)
        Me.tlpMain.PerformLayout()
        CType(Me.pbOverallHealth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbLastTest, System.ComponentModel.ISupportInitialize).EndInit()
        Me.flwOverallHealth.ResumeLayout(False)
        Me.flwOverallHealth.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Protected WithEvents lblTemperature As System.Windows.Forms.Label
    Protected WithEvents lblTempValue As System.Windows.Forms.Label
    Protected WithEvents pbTemp As System.Windows.Forms.PictureBox
    Protected WithEvents lblBadSectorsValue As System.Windows.Forms.Label
    Protected WithEvents lblLastTest As System.Windows.Forms.Label
    Protected WithEvents pbLastTest As System.Windows.Forms.PictureBox
    Protected WithEvents lblOverallHealth As System.Windows.Forms.Label
    Protected WithEvents pbOverallHealth As System.Windows.Forms.PictureBox
    Protected WithEvents lblOverallHealthValue As System.Windows.Forms.Label
    Protected WithEvents lblLastTestValue As System.Windows.Forms.Label
    Protected WithEvents lblWarning As System.Windows.Forms.Label
    Protected WithEvents pbWarning As System.Windows.Forms.PictureBox
    Private WithEvents tlpMain As System.Windows.Forms.TableLayoutPanel
    Protected WithEvents lblLastUpdate As System.Windows.Forms.Label
    Protected WithEvents lblLastUpdateValue As System.Windows.Forms.Label
    Protected WithEvents flwOverallHealth As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents lblErrors As System.Windows.Forms.Label
    Protected WithEvents lblWarningValue As System.Windows.Forms.Label
    Protected WithEvents lnkWeb1 As System.Windows.Forms.LinkLabel
    Protected WithEvents lnkWeb2 As System.Windows.Forms.LinkLabel
    Protected WithEvents lnkWeb3 As System.Windows.Forms.LinkLabel

End Class
