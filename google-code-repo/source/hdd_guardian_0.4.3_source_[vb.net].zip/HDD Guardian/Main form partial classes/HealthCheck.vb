﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main

    Dim err, tempthresh, chkhealth As String

    Private Sub VitalsCheck()
        err = ""
        If My.Settings.VitalParameters = False Then Exit Sub

        Dim logfilename As String = Now.Year & String.Format("{0:D2}", Now.Month) & _
            String.Format("{0:D2}", Now.Day) & ".log"
        If Not IO.Directory.Exists(healthlogpath) Then IO.Directory.CreateDirectory(healthlogpath)
        Dim logfullpath As String = healthlogpath & logfilename

        For i As Short = 0 To devicelist.Count - 1
            Dim dev As Device = devicelist(i)
            Dim v As Vitals = dev.VitalParametersVariation
            Dim o As Vitals = dev.OldVitalParameters
            Dim n As Vitals = dev.NewVitalParameters
            Dim havechanges As Boolean = False
            Dim model As String = dev.Model
            Dim d As Short = 0
            Dim txt As String = ""
            Dim errors As String = ""

            'now, compare vital parameters for each type of vital checked
            With My.Settings
                If .ReallocatedSector Then 'ID #5: Reallocated sector count
                    Dim idname As String = "Reallocated sector count"
                    txt = ""
                    If IsNumeric(v.ReallSect) Then
                        d = Convert.ToSingle(v.ReallSect)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.ReallSect & _
                                    " " & m_to & " " & n.ReallSect & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.ReallSect & _
                                    " " & m_to & " " & n.ReallSect & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.ReallSect & vbTab & n.ReallSect & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .SpinRetry Then 'ID #10: Spin retry count
                    Dim idname As String = "Spin retry count"
                    txt = ""
                    If IsNumeric(v.SpinRetry) Then
                        d = Convert.ToSingle(v.SpinRetry)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.SpinRetry & _
                                    " " & m_to & " " & n.SpinRetry & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.SpinRetry & _
                                    " " & m_to & " " & n.SpinRetry & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.SpinRetry & vbTab & n.SpinRetry & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .ReallocatedEvent Then 'ID #196: Rellocated event count
                    Dim idname As String = "Rellocated event count"
                    txt = ""
                    If IsNumeric(v.ReallEvent) Then
                        d = Convert.ToSingle(v.ReallEvent)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.ReallEvent & _
                                    " " & m_to & " " & n.ReallEvent & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.ReallEvent & _
                                    " " & m_to & " " & n.ReallEvent & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.ReallEvent & vbTab & n.ReallEvent & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .CurrentPendingSector Then 'ID #197: Current pending sector
                    Dim idname As String = "Current pending sector"
                    txt = ""
                    If IsNumeric(v.CurPending) Then
                        d = Convert.ToSingle(v.CurPending)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.CurPending & _
                                    " " & m_to & " " & n.CurPending & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.CurPending & _
                                    " " & m_to & " " & n.CurPending & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.CurPending & vbTab & n.CurPending & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .OfflineUncorrectable Then 'ID #198: Offline uncorrectable
                    Dim idname As String = "Offline uncorrectable"
                    txt = ""
                    If IsNumeric(v.OfflineUnc) Then
                        d = Convert.ToSingle(v.OfflineUnc)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.OfflineUnc & _
                                    " " & m_to & " " & n.OfflineUnc & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.OfflineUnc & _
                                    " " & m_to & " " & n.OfflineUnc & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.OfflineUnc & vbTab & n.OfflineUnc & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .SoftReadErrorRate Then 'ID #201: Soft read error rate
                    Dim idname As String = "Soft read error rate"
                    txt = ""
                    If IsNumeric(v.SoftRead) Then
                        d = Convert.ToSingle(v.SoftRead)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.SoftRead & _
                                    " " & m_to & " " & n.SoftRead & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.SoftRead & _
                                    " " & m_to & " " & n.SoftRead & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.SoftRead & vbTab & n.SoftRead & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .DiskShift Then 'ID #220: Disk shift
                    Dim idname As String = "Disk shift"
                    txt = ""
                    If IsNumeric(v.DiskShift) Then
                        d = Convert.ToSingle(v.DiskShift)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.DiskShift & _
                                    " " & m_to & " " & n.DiskShift & " [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.DiskShift & _
                                    " " & m_to & " " & n.DiskShift & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.DiskShift & vbTab & n.DiskShift & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .Temperature Then 'ID #194: Temperature
                    Dim idname As String = "Temperature"
                    txt = ""
                    If IsNumeric(v.Temperature) Then
                        d = Convert.ToSingle(v.Temperature)
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Temperature & "°C" & _
                                    " " & m_to & " " & n.Temperature & "°C [" & m_degradation & "]"
                            Case Is < 0
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Temperature & "°C" & _
                                    " " & m_to & " " & n.Temperature & "°C [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.Temperature & "°C" & vbTab & n.Temperature & "°C" & vbTab & d & "°C" & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .Indilinx Then 'ID #209: Remaining Life (%)
                    Dim idname As String = "Remaining Life (%)"
                    txt = ""
                    If IsNumeric(v.Indilinx) Then
                        d = Convert.ToSingle(v.Indilinx)
                        'value start to 100 and go to 0
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is < 0 'sample: 99 - 100 = -1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Indilinx & _
                                    " " & m_to & " " & n.Indilinx & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 100 - 99 = 1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Indilinx & _
                                    " " & m_to & " " & n.Indilinx & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.Indilinx & vbTab & n.Indilinx & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .Intel Then 'ID #233: Media Wearout Indicator
                    Dim idname As String = "Media Wearout Indicator"
                    txt = ""
                    If IsNumeric(v.Intel) Then
                        d = Convert.ToSingle(v.Intel)
                        'value start to 100 and go to 1
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is < 0 'sample: 99 - 100 = -1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Intel & _
                                    " " & m_to & " " & n.Intel & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 100 - 99 = 1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Intel & _
                                    " " & m_to & " " & n.Intel & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.Intel & vbTab & n.Intel & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .Micron Then 'ID #202: Percentage Lifetime Used
                    Dim idname As String = "Percentage Lifetime Used"
                    txt = ""
                    If IsNumeric(v.Micron) Then
                        d = Convert.ToSingle(v.Micron)
                        'value start to 0 and go to 100
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is > 0 'sample: 100 - 99 = 1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Micron & _
                                    " " & m_to & " " & n.Micron & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 99 - 100 = -1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Micron & _
                                    " " & m_to & " " & n.Micron & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.Micron & vbTab & n.Micron & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .Samsung Then 'ID #177: Wear Leveling Count
                    Dim idname As String = "Wear Leveling Count"
                    txt = ""
                    If IsNumeric(v.Samsung) Then
                        d = Convert.ToSingle(v.Samsung)
                        'value start to 100 and go to 1
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is < 0 'sample: 99 - 100 = -1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Samsung & _
                                    " " & m_to & " " & n.Samsung & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 100 - 99 = 1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.Samsung & _
                                    " " & m_to & " " & n.Samsung & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.Samsung & vbTab & n.Samsung & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                If .SandForce Then 'ID #231: SSD Life Left
                    Dim idname As String = "SSD Life Left"
                    txt = ""
                    If IsNumeric(v.SandForce) Then
                        d = Convert.ToSingle(v.SandForce)
                        'value start to 100 and go to 1
                        Select Case d
                            Case Is = 0
                                txt = ""
                            Case Is < 0 'sample: 99 - 100 = -1, is a degradation...
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.SandForce & _
                                    " " & m_to & " " & n.SandForce & " [" & m_degradation & "]"
                            Case Is > 0 'sample: 100 - 99 = 1, is a recovery
                                txt = vbCrLf & "   " & idname & " - " & m_from & " " & o.SandForce & _
                                    " " & m_to & " " & n.SandForce & " [" & m_recovery & "]"
                        End Select
                        If txt <> "" And installdevice = StoringDevice.Fixed Then
                            Dim logitem As String = Now.ToLongTimeString & vbTab & _
                                dev.Model & vbTab & idname & vbTab & _
                                o.SandForce & vbTab & n.SandForce & vbTab & d & vbCrLf
                            IO.File.AppendAllText(logfullpath, logitem)
                            havechanges = True
                        End If
                    End If
                    errors += txt
                End If

                'track total amount of errors
                Dim idstr As String = "Errors"
                txt = ""
                If IsNumeric(v.Errors) Then
                    d = Convert.ToSingle(v.Errors)
                    Select Case d
                        Case Is = 0
                            txt = ""
                        Case Is > 0
                            txt = vbCrLf & "   " & idstr & " - " & m_from & " " & o.Errors & _
                                " " & m_to & " " & n.Errors & " [" & m_degradation & "]"
                        Case Is < 0 'normally errors can't decrease...
                            txt = vbCrLf & "   " & idstr & " - " & m_from & " " & o.Errors & _
                                " " & m_to & " " & n.Errors & " [" & m_recovery & "]"
                    End Select
                    If txt <> "" And installdevice = StoringDevice.Fixed Then
                        Dim logitem As String = Now.ToLongTimeString & vbTab & _
                            dev.Model & vbTab & idstr & vbTab & _
                            o.Errors & vbTab & n.Errors & vbTab & d & vbCrLf
                        IO.File.AppendAllText(logfullpath, logitem)
                        havechanges = True
                    End If
                    errors += txt
                End If

                If havechanges Then
                    err = err & model & errors & vbCrLf
                End If
            End With
        Next

        If err.Length > 0 Then 'And err.LastIndexOf(vbCrLf) = err.Length - 1 Then
            Dim last As Short = err.LastIndexOf("]")
            'err = err.Substring(0, err.Length - 2)
            err = err.Substring(0, last + 1)
        End If
    End Sub

    Private Sub TemperatureCheck()
        tempthresh = ""
        If My.Settings.TemperatureThreshold = False Then Exit Sub

        For Each Device In devicelist
            If IsNumeric(Device.Temperature) Then
                If Convert.ToSingle(Device.Temperature) > 49 Then
                    tempthresh = tempthresh & Device.Model & ": " & Device.Temperature & "°C" & vbCrLf
                End If
            End If
        Next

        If tempthresh.Length > 0 And tempthresh.LastIndexOf(vbCrLf) = tempthresh.Length - 1 Then
            tempthresh = tempthresh.Substring(0, tempthresh.Length - 2)
        End If
    End Sub

    Private Sub OverallHealthCheck()
        chkhealth = ""

        Dim failure As Boolean = False
        For Each Device In devicelist
            If Device.Health = Status.Failed Then
                chkhealth += Device.Model & vbCrLf
                failure = True
            End If
        Next

        'HDD Guardian tray icon type change between combinations of devices failure and program updates...
        If failure Then
            Dim healthicon As Bitmap
            If pnlUpdate.Visible Then healthicon = My.Resources.update_ko Else healthicon = My.Resources.some_problems
            Dim geticon As IntPtr = healthicon.Clone(New Rectangle(0, 0, 16, 16), healthicon.PixelFormat).GetHicon
            niTrayIcon.Icon = Icon.FromHandle(geticon)
        Else
            Dim healthicon As Bitmap
            If pnlUpdate.Visible Then healthicon = My.Resources.update_ok Else healthicon = My.Resources.all_ok
            Dim geticon As IntPtr = healthicon.Clone(New Rectangle(0, 0, 16, 16), healthicon.PixelFormat).GetHicon
            niTrayIcon.Icon = Icon.FromHandle(geticon)
        End If

        If chkhealth.Length > 0 And chkhealth.LastIndexOf(vbCrLf) = chkhealth.Length - 1 Then
            chkhealth = chkhealth.Substring(0, chkhealth.Length - 2)
        End If

        If My.Settings.ImminentFailure = False Then chkhealth = ""
    End Sub

#Region "Display warnings"

    Dim WithEvents tmrDelay As New Timer
    Dim Warning As Integer

    Public Sub ShowWarnings()
        VitalsCheck()
        TemperatureCheck()
        OverallHealthCheck()
        tmrDelay.Interval = 3000
        tmrDelay.Start()
        Warning = 0
    End Sub

    Private Sub DelayWarnings() Handles tmrDelay.Tick
        ShowWarningsBaloons(Warning)
        If Warning = 2 Then tmrDelay.Stop()
        Warning += 1
    End Sub

    Enum BaloonMsgs
        Failure = 0
        Temperature
        Health
    End Enum

    Private Sub ShowWarningsBaloons(ByVal Baloon As BaloonMsgs)
        With niTrayIcon
            Select Case Baloon
                Case BaloonMsgs.Failure
                    'device failure message
                    If chkhealth.Length > 0 And niTrayIcon.Visible = True Then
                        With niTrayIcon
                            .BalloonTipIcon = ToolTipIcon.Error
                            .BalloonTipTitle = m_failuretitle
                            .BalloonTipText = m_failuretxt.Replace("%", chkhealth)
                            .ShowBalloonTip(3000)
                        End With
                    End If
                Case BaloonMsgs.Temperature
                    'device temperature message
                    If tempthresh.Length > 0 And niTrayIcon.Visible = True Then
                        With niTrayIcon
                            .BalloonTipIcon = ToolTipIcon.Warning
                            .BalloonTipTitle = m_temperaturealarm
                            .BalloonTipText = tempthresh
                            .ShowBalloonTip(3000)
                        End With
                    End If
                Case BaloonMsgs.Health
                    'raw values variation message
                    If err.Length > 0 And niTrayIcon.Visible = True Then
                        With niTrayIcon
                            .BalloonTipIcon = ToolTipIcon.Warning
                            .BalloonTipTitle = m_alarmdevstatus
                            .BalloonTipText = err
                            .ShowBalloonTip(3000)
                        End With
                    End If
            End Select
        End With
    End Sub

#End Region

End Class
