﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


'this partial class is here for a future (?) compatibility, but from version 0.3.0
'device's database is no more available...

Imports System.Xml

Partial Class Main

    Private Structure DBEntry
        Dim Model, Firmware, Family, Attributes, Warnings, Other As String
    End Structure

    Private Class DBList
        Inherits List(Of DBEntry)
    End Class

    Dim smartctlDB As New DBList

    Private Function GetIndexOf(ByVal arr As Array, ByVal strtosearch As String, ByVal start As Short) As Short
        For i As Short = start To arr.Length - 1
            If arr(i).contains(strtosearch) Then Return i
        Next
        Return -1
    End Function

    Private Sub LoadXmlDB()
        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        m_xmldoc.LoadXml(My.Resources.database)

        m_nodelist = m_xmldoc.SelectNodes("/entries/item")
        With smartctlDB
            .Clear()
            For Each m_node In m_nodelist
                Dim newentry As New DBEntry
                With newentry
                    .Model = m_node.ChildNodes.Item(0).InnerText
                    .Firmware = m_node.ChildNodes.Item(1).InnerText
                    .Family = m_node.ChildNodes.Item(2).InnerText
                    .Attributes = m_node.ChildNodes.Item(3).InnerText
                    .Other = m_node.ChildNodes.Item(4).InnerText
                    .Warnings = m_node.ChildNodes.Item(5).InnerText
                End With
                .Add(newentry)
            Next
        End With
    End Sub

    
End Class