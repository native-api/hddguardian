﻿Partial Class Main

    Public Sub PrintDebug(ByVal msg As String)
        If debug Then

            Dim strtoprint As String = String.Format("{0:D2}", Now.Hour) & ":" & _
                            String.Format("{0:D2}", Now.Minute & ":" & _
                            String.Format("{0:D2}", Now.Second) & "." & _
                            String.Format("{0:D3}", Now.Millisecond) & " - " & _
                            msg & vbCrLf)

            DebugWindow.txtDebug.AppendText(strtoprint)

            If savedebug Then
                Dim folder As String = My.Computer.FileSystem.SpecialDirectories.Desktop
                IO.File.AppendAllText(folder & "\hddguardian_debug.txt", strtoprint)
            End If
        End If
    End Sub

End Class
