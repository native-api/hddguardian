﻿'HDD Guardian is a GUI for smartcl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Management
Imports System.ComponentModel

Partial Class Main
    Public devices() As String
    Public usbdevices() As String
    Public csmidevices() As String
    Public scsidevices() As String
    Public lsidevices() As String
    Public intelrstdevices() As String
    Public devicelist As New DeviceCollection

    Private Enum ScsiController
        IntelQM77 = 0 'Intel(R) Mobile Express Chipset SATA RAID Controller
        LsiFalcon = 1 'LSI Adapter, SAS2 2008 Falcon
    End Enum

    Private Function CheckScsiController(ByVal controller As scsicontroller) As Boolean
        Dim win32_scsicontroller As New ManagementObjectSearcher("root/CIMV2", "SELECT * FROM Win32_SCSIController")
        Dim stringtoget As String = ""

        Select Case controller
            Case scsicontroller.IntelQM77
                stringtoget = "Intel(R) Mobile Express Chipset SATA RAID Controller"
            Case scsicontroller.LsiFalcon
                stringtoget = "LSI Adapter, SAS2 2008 Falcon"
        End Select

        For Each scsi As ManagementObject In win32_scsicontroller.Get()
            If scsi("Name").ToString.Trim.Contains(stringtoget) Then
                Return True
                Exit For
            End If
        Next

        Return False
    End Function

    Private Sub Search()
        Dim smartctl As New Console

        PrintDebug("Collect devices using '--scan -d csmi'")

        'collect devices under Intel Matrix using command "--scan -d csmi"
        Dim csmiscan() As String = smartctl.SendCmd("--scan -d csmi")
        For i As Integer = 0 To csmiscan.Count - 2 'the last item is an empty line
            If InStr(csmiscan(i), "/dev/csmi") < InStr(csmiscan(i), "#") And InStr(csmiscan(i), "/dev/csmi") >= 0 Then
                ReDim Preserve csmidevices(i)
                Dim matrix As String() = csmiscan(i).Split("#")
                csmidevices(i) = matrix(0).Replace("-d ata", "").Trim
            End If
        Next

        If Not IsNothing(csmidevices) Then PrintDebug("Devices found: " & csmidevices.Count) Else PrintDebug("No CSMI devices found")
        PrintDebug("Collect devices using '--scan -d ata'")

        'search devices: now, the local devices are searched by smartctl with "--scan -d ata" option
        'the "-d ata" option at the end collect only fixed (non removable, like usb) devices
        Dim scan() As String = smartctl.SendCmd("--scan -d ata")
        For i As Integer = 0 To scan.Count - 2 'the last item is an empty line
            If InStr(scan(i), "/dev/sd") < InStr(scan(i), "#") And InStr(scan(i), "/dev/sd") >= 0 Then
                ReDim Preserve devices(i)
                Dim dev As String() = scan(i).Split("#")
                devices(i) = dev(0).Replace("-d ata", "").Trim
            End If
        Next

        If Not IsNothing(devices) Then PrintDebug("Devices found: " & devices.Count) Else PrintDebug("No ATA devices found")
        PrintDebug("Collect devices using '--scan -d usb'")

        'collect usb devices: smartctl with "--scan -d usb" option is able to find devices under known interfaces
        'the "-d usb" option at the end collect only removable, like usb, devices
        Dim usbscan() As String = smartctl.SendCmd("--scan -d usb")
        For i As Integer = 0 To usbscan.Count - 2 'the last item is an empty line
            If InStr(usbscan(i), "/dev/sd") < InStr(usbscan(i), "#") And InStr(usbscan(i), "/dev/sd") >= 0 Then
                ReDim Preserve usbdevices(i)
                Dim usbdev As String() = usbscan(i).Split("#")
                usbdevices(i) = usbdev(0).Replace("-d ata", "").Trim
            End If
        Next

        If Not IsNothing(usbdevices) Then PrintDebug("Devices found: " & usbdevices.Count) Else PrintDebug("No USB devices found")

        '*********************************************** This section if for devices under SCSI controllers ******************************************
        'Some ATA devices are connected under a SCSI controller and listed ad SCSI devices but date aren't available using the "-d scsi" option with
        'smartctl: in some cases is needed to change the "-d scsi" with "-d ata" and in some other with "-d sat" option.

        If CheckScsiController(scsicontroller.IntelQM77) Then
            Dim intelscan() As String = smartctl.SendCmd("--scan -d scsi")
            For i As Integer = 0 To intelscan.Count - 2 'the last item is an empty line
                If InStr(intelscan(i), "/dev/sd") < InStr(intelscan(i), "#") And InStr(intelscan(i), "/dev/sd") >= 0 Then
                    ReDim Preserve intelrstdevices(i)
                    Dim intel As String() = intelscan(i).Split("#")
                    intelrstdevices(i) = intel(0).Replace("-d scsi", "-d ata").Trim
                End If
            Next
        End If

        If CheckScsiController(scsicontroller.LsiFalcon) Then
            Dim lsiscan() As String = smartctl.SendCmd("--scan -d scsi")
            For i As Integer = 0 To lsiscan.Count - 2 'the last item is an empty line
                If InStr(lsiscan(i), "/dev/sd") < InStr(lsiscan(i), "#") And InStr(lsiscan(i), "/dev/sd") >= 0 Then
                    ReDim Preserve lsidevices(i)
                    Dim lsi As String() = lsiscan(i).Split("#")
                    lsidevices(i) = lsi(0).Replace("-d scsi", "-d sat").Trim
                End If
            Next
        End If
        '*********************************************************************************************************************************************

        'if no devices are founded on system, display a message and then exits from application...
        If IsNothing(devices) And IsNothing(csmidevices) And IsNothing(intelrstdevices) Then
            MsgBox(m_nodevices, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, m_error)
            End
        End If

    End Sub

    Private Sub CollectDevices()

        PrintDebug("Adding devices to side list")

        'first, add local devices...
        'first of all the devices under Intel Matrix system...
        If Not IsNothing(csmidevices) Then
            PrintDebug("*** Adding Matrix devices ***")
            For d As Integer = 0 To csmidevices.Count - 1
                Dim matrixdevice As New Device(csmidevices(d), DeviceType.Internal)
                If Not matrixdevice.IsOptical Then
                    devicelist.Add(matrixdevice)
                    PrintDebug("Loading device settings")
                    LoadDeviceSettings(devicelist(devicelist.Count - 1))
                    PrintDebug("Loading device monitoring settings")
                    LoadMonitoringSettings(devicelist(devicelist.Count - 1))
                    'LoadValues(devicelist(devicelist.Count - 1))
                    PrintDebug("Updating device output")
                    devicelist(devicelist.Count - 1).Update()
                End If
            Next
        End If

        'then devices under Intel RST system...
        If Not IsNothing(intelrstdevices) Then
            PrintDebug("*** Adding Intel RST devices ***")
            For d As Integer = 0 To intelrstdevices.Count - 1
                Dim rstdevice As New Device(intelrstdevices(d), DeviceType.Internal)
                If Not rstdevice.IsOptical Then
                    devicelist.Add(rstdevice)
                    PrintDebug("Loading device settings")
                    LoadDeviceSettings(devicelist(devicelist.Count - 1))
                    PrintDebug("Loading device monitoring settings")
                    LoadMonitoringSettings(devicelist(devicelist.Count - 1))
                    'LoadValues(devicelist(devicelist.Count - 1))
                    PrintDebug("Updating device output")
                    devicelist(devicelist.Count - 1).Update()
                End If
            Next
        End If

        'then, the normal ATA devices: it check also if a device is already listed with the Intel Matrix system
        If Not IsNothing(devices) Then
            PrintDebug("*** Adding ATA devices ***")
            For d As Integer = 0 To devices.Count - 1
                PrintDebug("Adding " & devices(d))
                Dim devtoadd As New Device(devices(d), DeviceType.Internal)
                Dim isduplicate As Boolean = False
                If devtoadd.IsDetected Then
                    For i As Integer = 0 To devicelist.Count - 1
                        'check if the serial number or the device model are already in list:
                        'you can have the same model but not the same serial number or
                        'the same serial number but a different model...
                        If devtoadd.SerialNumber = devicelist(i).SerialNumber And _
                            devtoadd.Model = devicelist(i).Model Then
                            isduplicate = True
                        End If
                    Next

                    If Not isduplicate Then
                        devicelist.Add(devtoadd)
                        PrintDebug("Loading device settings")
                        LoadDeviceSettings(devicelist(devicelist.Count - 1))
                        PrintDebug("Loading device monitoring settings")
                        LoadMonitoringSettings(devicelist(devicelist.Count - 1))
                        'LoadValues(devicelist(devicelist.Count - 1))
                        PrintDebug("Updating device output")
                        devicelist(devicelist.Count - 1).Update()
                    End If
                End If
            Next
        End If

        'then devices inder a LSI controller...
        If Not IsNothing(lsidevices) Then
            PrintDebug("*** Adding LSI devices ***")
            For d As Integer = 0 To lsidevices.Count - 1
                Dim lsidevice As New Device(lsidevices(d), DeviceType.Internal)
                If Not lsidevice.IsOptical Then
                    devicelist.Add(lsidevice)
                    PrintDebug("Loading device settings")
                    LoadDeviceSettings(devicelist(devicelist.Count - 1))
                    PrintDebug("Loading device monitoring settings")
                    LoadMonitoringSettings(devicelist(devicelist.Count - 1))
                    'LoadValues(devicelist(devicelist.Count - 1))
                    PrintDebug("Updating device output")
                    devicelist(devicelist.Count - 1).Update()
                End If
            Next
        End If

        'then add usb devices...
        If Not IsNothing(usbdevices) Then
            PrintDebug("*** Adding USB devices ***")
            For d As Integer = 0 To usbdevices.Count - 1
                PrintDebug("Adding " & usbdevices(d))
                devicelist.Add(New Device(usbdevices(d), DeviceType.Removable))
                PrintDebug("Loading device settings")
                LoadDeviceSettings(devicelist(devicelist.Count - 1))
                PrintDebug("Loading device monitoring settings")
                LoadMonitoringSettings(devicelist(devicelist.Count - 1))
                'LoadValues(devicelist(devicelist.Count - 1))
                PrintDebug("Updating device output")
                devicelist(devicelist.Count - 1).Update()
            Next
        End If
        'then, finally, add virtual devices (files)
        Dim virtualfolder As String = My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData _
                                      .Substring(0, My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData.LastIndexOf("\")) _
                                      & "\Virtual devices\"

        If IO.Directory.Exists(virtualfolder) And installdevice = StoringDevice.Fixed Then
            PrintDebug("*** Adding virtual devices ***")
            If IO.Directory.EnumerateFiles(virtualfolder, "*.vd").Count = 0 Then Exit Sub
            For Each file As String In IO.Directory.GetFiles(virtualfolder, "*.vd")
                Dim content() As String = IO.File.ReadAllLines(file)
                devicelist.Add(New Device(content(0), DeviceType.Virtual))
                Dim vd As Device = devicelist(devicelist.Count - 1)
                Dim vdi As VirtualDeviceInfo
                With vdi
                    .Description = content(1)
                    .Model = content(2)
                    .UserSize = content(3)
                    .SerialNumber = content(4)
                    .Firmware = content(5)
                End With
                vd.VirtualDeviceInfo = vdi
            Next
        End If
        PrintDebug("Done")
    End Sub

    Private Sub PopulateDeviceList()
        'listview item scheme
        '
        'ColHead    |Model      |Temp       |
        '           -------------------------
        'Item       |Icon+model |temperature|
        'the listview follow the same indexing of "DeviceList" array
        'each string is colored differently: model string color is related to device health,
        'temperature string color is related to three different temperature ranges

        With lvwDevices
            For Each dev As Device In devicelist
                If dev.Type = DeviceType.Internal Then
                    Dim lvi As New ListViewItem(dev.Model, 1, .Groups(0))
                    .Items.Add(lvi)
                ElseIf dev.Type = DeviceType.Virtual Then
                    Dim lvi As New ListViewItem(dev.Model, 1, .Groups(2))
                    .Items.Add(lvi)
                Else 'device is sure a removable one...
                    Dim lvi As New ListViewItem(dev.Model, 1, .Groups(1))
                    .Items.Add(lvi)
                End If

                Dim i As Integer = .Items.Count - 1
                .Items(i).UseItemStyleForSubItems = False

                Select Case dev.Health
                    Case Status.Unkonwn
                        .Items(i).ForeColor = Color.DarkGray
                    Case Status.Failed
                        .Items(i).ForeColor = Color.Red
                        .Items(i).ImageIndex = 0
                    Case Status.Passed
                        .Items(i).ForeColor = Color.Blue
                End Select

                If IsNumeric(dev.Temperature) Then
                    If My.Settings.TempFahrenheit = True Then
                        .Items(i).SubItems.Add(Math.Round(dev.Temperature * 1.8 + 32) & "°F")
                    Else
                        .Items(i).SubItems.Add(dev.Temperature & "°C")
                    End If
                    Select Case Val(dev.Temperature)
                        Case 0 To 49
                            .Items(i).SubItems(1).ForeColor = Color.Blue
                        Case 50 To 54
                            .Items(i).SubItems(1).ForeColor = Color.DarkOrange
                        Case Is >= 55
                            .Items(i).SubItems(1).ForeColor = Color.Red
                    End Select
                Else
                    .Items(i).SubItems.Add(dev.Temperature)
                    .Items(i).SubItems(1).ForeColor = Color.DarkGray
                End If
            Next
            .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
            .Columns(0).Width = .ClientSize.Width - .Columns(1).Width
            .Items(0).Selected = True

            .Groups(0).Header = .Groups(0).Tag & " - " & .Groups(0).Items.Count
            .Groups(1).Header = .Groups(1).Tag & " - " & .Groups(1).Items.Count
            .Groups(2).Header = .Groups(2).Tag & " - " & .Groups(2).Items.Count

            SetWindowTheme(.Handle, "explorer", Nothing)
        End With
        cboTest.SelectedIndex = 0

    End Sub

    Private Sub PopulateTopPanel()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        Dim size, model, path, firmware, serial As String

        If (dev.Type = DeviceType.Internal Or dev.Type = DeviceType.Removable) _
            Or (dev.Type = DeviceType.Virtual And IO.File.Exists(dev.Location)) Then
            If Not dev.Type = DeviceType.Virtual Then
                Dim loc() As String = dev.Location.ToString.Split(" ")
                path = loc(0)
            Else
                path = dev.VirtualDeviceInfo.Description
            End If
            model = dev.Model
            size = dev.UserCapacity
            firmware = dev.FirmwareVersion
            serial = dev.SerialNumber
        Else
            With dev.VirtualDeviceInfo
                path = .Description
                model = .Model
                Dim s() As String = .UserSize.Split("bytes")
                size = ""
                For i As Integer = 0 To s(0).Length - 1
                    If IsNumeric(s(0).Chars(i)) Then size = size & s(0).Chars(i)
                Next
                Dim iec As String
                If Val(size / 1024 ^ 3) > 1000 Then
                    iec = Format(Val(size / 1024 ^ 4), "#.#") & " TiB"
                Else
                    iec = Format(Val(size / 1024 ^ 3), "#,###") & " GiB"
                End If
                Dim si As String '= Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                If Val(size / 1000 ^ 3) > 1000 Then
                    si = Format(Val(size / 1000 ^ 4), "#.#") & " TB"
                Else
                    si = Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                End If
                size = iec & " / " & si
                firmware = .Firmware
                serial = .SerialNumber
            End With
        End If

        With devPanel
            .Visible = False
            If IsNumeric(size) Then
                'Dim iec As String = Format(Val(size / 1024 ^ 3), "#,###") & " GiB"
                'Dim si As String = Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                Dim iec As String
                If Val(size / 1024 ^ 3) > 1000 Then
                    iec = Format(Val(size / 1024 ^ 4), "#.0") & " TiB"
                Else
                    iec = Format(Val(size / 1024 ^ 3), "#,###") & " GiB"
                End If
                Dim si As String '= Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                If Val(size / 1000 ^ 3) > 1000 Then
                    si = Format(Val(size / 1000 ^ 4), "#.0") & " TB"
                Else
                    si = Format(Val(size / 1000 ^ 3), "#,###") & " GB"
                End If
                .TotalSize = iec & " / " & si
            Else
                .TotalSize = size
            End If
            .Model = model
            .Path = path
            .Firmware = d_firmware & firmware
            .Serial = d_serial & serial
            .Web = ""
            .Visible = True
        End With
    End Sub

    Private Sub SetHealthPanel()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        'this is Main->Summary panel
        With hpSummary
            .Visible = False
            'temperature
            .Temperature(dev.Temperature, My.Settings.TempFahrenheit)
            'last test results
            Dim res As String = dev.LastTestResults.Status
            If Not IsNothing(res) Then
                For i As Short = 0 To m_testresults.Count - 1
                    res = res.Replace(m_testresults(i).Original, m_testresults(i).Change)
                Next
            End If
            Select Case dev.LastTestResults.IsPassed
                Case Status.Failed
                    Dim remaining As Short = 100 - Val(dev.LastTestResults.Remaining)
                    .LastTest(res & " " & remaining & "%", _
                          HealthPanel.WarningLevel.Warning)
                Case Status.Passed
                    .LastTest(res, HealthPanel.WarningLevel.Ok)
                Case Status.Unkonwn
                    .LastTest(res, HealthPanel.WarningLevel.NA)
            End Select
            'overall health test
            Select Case dev.Health
                Case Status.Failed
                    .OverallHealth(h_overallfailed, HealthPanel.WarningLevel.Alarm)
                Case Status.Passed
                    .OverallHealth(h_overallpassed, HealthPanel.WarningLevel.Ok)
                Case Status.Unkonwn
                    .OverallHealth("N/A", HealthPanel.WarningLevel.NA)
            End Select
            'bad sectors
            Select Case dev.BadSectorsCount
                Case 0
                    .BadSectors(badsect_no, dev.BadSectorsCount)
                Case 1
                    .BadSectors(badsect_one.Replace("%", dev.BadSectorsCount), dev.BadSectorsCount)
                Case 2 To 50
                    .BadSectors(badsect_few.Replace("%", dev.BadSectorsCount), dev.BadSectorsCount)
                Case Is > 50
                    .BadSectors(badsect_several.Replace("%", dev.BadSectorsCount), dev.BadSectorsCount)
            End Select
            'error count
            Select Case Val(dev.TotalErrors)
                Case 0
                    .Errors(error_no, dev.TotalErrors)
                Case 1
                    .Errors(error_one.Replace("%", dev.TotalErrors), dev.TotalErrors)
                Case 2 To 10
                    .Errors(error_few.Replace("%", dev.TotalErrors), dev.TotalErrors)
                Case Is > 10
                    .Errors(error_several.Replace("%", dev.TotalErrors), dev.TotalErrors)
            End Select
            'last update
            .LastUpdate(dev.LastCheck)
            'warnings
            If dev.Warning.Warning <> "" Then
                .Warning(HealthPanel.WarningLevel.Warning, _
                         dev.Warning.Warning, True, _
                         dev.Warning.Link1, dev.Warning.Link2, dev.Warning.Link3)
            Else
                If dev.SmartSupport = Support.Available Then
                    If dev.SmartEnabled = Support.Enabled Then
                        .Warning(HealthPanel.WarningLevel.Ok, w_no, False)
                    Else
                        .Warning(HealthPanel.WarningLevel.Warning, w_smartdisabled, False)
                    End If
                Else
                    .Warning(HealthPanel.WarningLevel.Halt, w_smartunavailble, False)
                End If
                If dev.Type = DeviceType.Virtual Then
                    If Not IO.File.Exists(dev.Location) Then
                        .Warning(HealthPanel.WarningLevel.Alarm, w_repunavailabe, False)
                    End If
                End If
            End If
            .Visible = True
        End With
    End Sub

    Private Sub SetSwitches()

        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        isloading_features = True

        Select Case dev.SmartEnabled
            Case Support.Enabled
                chkEnableSmart.Checked = True

                If dev.Type <> DeviceType.Virtual Then
                    chkEnableSmart.Enabled = True
                Else
                    chkEnableSmart.Enabled = False
                End If

                'the offline collection is available only if SMART is enabled
                If dev.OfflineCollectionStatus = Support.Enabled Then
                    chkEnableOffline.Checked = True
                    If dev.Type <> DeviceType.Virtual Then
                        chkEnableOffline.Enabled = True
                    Else
                        chkEnableOffline.Enabled = False
                    End If
                Else
                    chkEnableOffline.Checked = False
                    If dev.Type <> DeviceType.Virtual Then
                        chkEnableOffline.Enabled = True
                    Else
                        chkEnableOffline.Enabled = False
                    End If
                End If

                'also, the autosave of attributes is available only if SMART is enabled
                If Not IsNothing(dev.Options) Then
                    If dev.Options.Contains("-S on") Then
                        chkEnableAutosave.Checked = True
                        If dev.Type <> DeviceType.Virtual Then
                            chkEnableAutosave.Enabled = True
                        Else
                            chkEnableAutosave.Enabled = False
                        End If
                    Else
                        chkEnableAutosave.Checked = False
                        If dev.Type <> DeviceType.Virtual Then
                            chkEnableAutosave.Enabled = True
                        Else
                            chkEnableAutosave.Enabled = False
                        End If
                    End If
                Else
                    chkEnableAutosave.Checked = False
                End If
            Case Support.Disabled
                chkEnableSmart.Checked = False
                chkEnableOffline.Checked = False
                chkEnableAutosave.Checked = False

                If dev.Type <> DeviceType.Virtual Then
                    chkEnableSmart.Enabled = True
                Else
                    chkEnableSmart.Enabled = False
                End If
            Case Support.Unknown
                chkEnableSmart.Checked = False
                chkEnableOffline.Checked = False
                chkEnableAutosave.Checked = False
                chkEnableSmart.Enabled = False
                chkEnableOffline.Enabled = False
                chkEnableAutosave.Enabled = False
        End Select

        'the attribute autosave is setted when smartctl option are parsed
        chkEnableTray.Checked = dev.ShowTrayIcon

        chkEnableShare.Checked = dev.IsShared
        If IO.Directory.Exists(My.Settings.SharingFolder) Then
            chkEnableShare.Enabled = True
        Else
            chkEnableShare.Enabled = False
        End If

        If (dev.Type = DeviceType.Internal Or dev.Type = DeviceType.Removable) And installdevice = StoringDevice.Fixed Then
            'selected device is a physical one and hddguardian is installed into a fixed device:
            'monitoring features are available
            lblMonFeatures.Visible = True
            tlpMonitoring.Visible = True
        Else
            lblMonFeatures.Visible = False
            tlpMonitoring.Visible = False
            chkEnableAutosave.Enabled = False
        End If

        isloading_features = False
    End Sub

    Private Sub PopulateSmartctlPanels()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        'put complete output into the Smartctl->Output section
        txtReport.Text = dev.Output
        'populate (if necessary) the section under Smartctl->Tolerance, Smartctl->Attributes remap
        'and Smartctl->Firmware debug
        ParseOptions(dev.Options)
    End Sub

    Private Sub PopulateSmartAttributes()
        'listview item scheme
        '
        'ColHead    |Type |ID    |Attribute |Current |Worst  |Thresh     |When Failed |Raw       |
        '           ------------------------------------------------------------------------------
        'Item       |icon |.ID   |.Name     |.Value  |.Worst |.Threshold |.WhenFailed |.RawValue |
        'tag        |     |.Flag |          |        |       |           |            |          |
        'the "type" column show only an icon
        'Try

        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        With lvwSmart
            .Items.Clear()
            'set the first column to sort the listview, but it have no values to sort...
            .ListViewItemSorter = New ListViewComparer(0, SortOrder.None)
            For Each attr As Attribute In dev.Attributes

                If attr.Type = AttributeType.PreFail Then
                    .Items.Add("", 0)
                Else
                    .Items.Add("", 1)
                End If

                Dim i As Integer = .Items.Count - 1
                .Items(i).SubItems.Add(attr.ID)
                .Items(i).SubItems(0).Tag = attr.Flag
                .Items(i).SubItems.Add(attr.Name)
                .Items(i).SubItems.Add(attr.Value)
                .Items(i).SubItems.Add(attr.Worst)
                .Items(i).SubItems.Add(attr.Threshold)
                .Items(i).SubItems.Add(attr.WhenFailed)
                .Items(i).SubItems.Add(attr.RawValue)
            Next
            'set the second column (ID) to sort the listview...
            .ListViewItemSorter = New ListViewComparer(1, SortOrder.Ascending)

            For Item As Short = 0 To lvwSmart.Items.Count - 1
                'alternate backgroung color
                If Item Mod 2 <> 0 Then
                    .Items(Item).BackColor = Color.FromArgb(243, 245, 247)
                End If

                'check ID name and then, if raw value is a number and if it's >0
                'change background color of row
                Dim idname As String = .Items(Item).SubItems(2).Text
                If idname = "Reallocated Sector Ct" Or _
                        idname = "Spin Retry Count" Or _
                        idname = "Reallocated Event Count" Or _
                        idname = "Current Pending Sector" Or _
                        idname = "Offline Uncorrectable" Or _
                        idname = "Soft Read Error Rate" Or _
                        idname = "Disk Shift" Then
                    If IsNumeric(.Items(Item).SubItems(7).Text) Then
                        If Convert.ToSingle(.Items(Item).SubItems(7).Text) > 0 Then
                            .Items(Item).ForeColor = Color.DeepPink
                        End If
                    End If
                End If

                'evaluate if value is failing now or are failed in the past...
                Dim WhenFailed As String = .Items(Item).SubItems(6).Text
                Select Case WhenFailed
                    Case "FAILING NOW"
                        .Items.Item(Item).ForeColor = Color.Firebrick
                    Case "In the past"
                        .Items.Item(Item).ForeColor = Color.DarkOrange
                End Select
            Next

            For ColumnIndex = 0 To lvwSmart.Columns.Count - 1
                .Columns(ColumnIndex).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
            Next ColumnIndex

        End With

        lblDataStructure.Text = lblDataStructure.Tag & dev.DataStructuresRev.AttributesTable
        'Catch 'ex As Exception

        'End Try

    End Sub

    Private Sub PopulateDeviceInfo()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        lblFamilyInfoValue.Text = dev.Family
        lblModelInfoValue.Text = dev.Model
        lblSerialValue.Text = dev.SerialNumber
        lblWwnValue.Text = dev.WorldWideName
        lblFirmwareInfoValue.Text = dev.FirmwareVersion
        If IsNumeric(dev.UserCapacity) Then
            lblTotalSizeValue.Text = Format(Val(dev.UserCapacity), "#,###") & " bytes"
        Else
            lblTotalSizeValue.Text = "N/A"
        End If
        lblSectorSizeValue.Text = dev.SectorSize
        If dev.InDatabase Then
            lblInDatabaseValue.Text = m_yes
        Else
            lblInDatabaseValue.Text = m_no
        End If
        lblAtaVersionValue.Text = dev.AtaVersion

        Select Case dev.SmartSupport
            Case Support.Available
                Select Case dev.SmartEnabled
                    Case Support.Enabled
                        lblSmartStatusValue.Text = m_available & " " & m_enabled
                    Case Support.Disabled
                        lblSmartStatusValue.Text = m_available & " " & m_disabled
                    Case Else
                        lblSmartStatusValue.Text = m_available
                End Select
            Case Support.Unavailable
                lblSmartStatusValue.Text = m_unavailable
            Case Support.Ambiguous
                Select Case dev.SmartEnabled
                    Case Support.Enabled
                        lblSmartStatusValue.Text = m_ambiguous & " " & m_enabled
                    Case Support.Disabled
                        lblSmartStatusValue.Text = m_ambiguous & " " & m_disabled
                    Case Else
                        lblSmartStatusValue.Text = m_ambiguous
                End Select
            Case Support.Unknown
                lblSmartStatusValue.Text = m_unknown
        End Select
        lblRotationValue.Text = dev.RotationRate
        lblSataVersionValue.Text = dev.SataVersion

    End Sub

    Private Sub PopulateCapabilities()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        With clCapabilities
            .Clear()
            For i As Short = 0 To dev.Capabilities.Count - 1
                .Add(dev.Capabilities(i).Name, _
                     dev.Capabilities(i).Value, _
                     dev.Capabilities(i).Meaning)
            Next
        End With
    End Sub

    Private Sub PopulateATAErrors()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        Dim err As Short = dev.TotalErrors
        optError1.Visible = False
        optError1.Checked = False
        optError2.Visible = False
        optError2.Checked = False
        optError3.Visible = False
        optError3.Checked = False
        optError4.Visible = False
        optError4.Checked = False
        optError5.Visible = False
        optError5.Checked = False
        lblErrLogVer.Text = lblErrLogVer.Tag & dev.DataStructuresRev.ErrorLog

        If dev.IsSupportedErrorLogging Then
            lblErrLogVer.Visible = True
            If err = 0 Then
                flwError.Visible = False
                lblErrorLog.Text = e_noerror
                Exit Sub
            Else
                lblErrorLog.Text = e_select
            End If

            optError1.Checked = True

            For i As Short = 0 To 4 'only the last 5 errors are stored into the log
                If err - i < 1 Then Exit For
                Select Case i
                    Case 0
                        optError1.Text = err - i
                        optError1.Visible = True
                    Case 1
                        optError2.Text = err - i
                        optError2.Visible = True
                    Case 2
                        optError3.Text = err - i
                        optError3.Visible = True
                    Case 3
                        optError4.Text = err - i
                        optError4.Visible = True
                    Case 4
                        optError5.Text = err - i
                        optError5.Visible = True
                End Select
            Next
        Else
            lblErrorLog.Text = e_noerrorlogging
            lblErrLogVer.Visible = False
            flwError.Visible = False
        End If
    End Sub

    Private Sub DisplayATAError(ByVal e As Integer)
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        If dev.Errors.Count > 0 Then
            Dim err As SmartError = dev.Errors(e - 1)
            Dim reg As Register = err.Registers

            flwError.Visible = True
            lblPowerOn.Text = lblPowerOn.Tag.ToString.Replace("%", err.Number) & err.Lifetime
            Dim errstatus As String = err.Status
            For i As Short = 0 To m_devicestatus.Count - 1
                errstatus = errstatus.Replace(m_devicestatus(i).Original, m_devicestatus(i).Change)
            Next
            lblDeviceStatus.Text = lblDeviceStatus.Tag & " " & errstatus ' err.Status

            RegistersPanel1.SetRegisters(reg.ER, reg.ST, reg.SC, reg.SN, reg.CL, reg.CH, reg.DH, reg.ErrorText)

            CommandsPanel1.HideRows(5 - err.Commands.Count)
            If err.Commands(0).PowerUp.Contains(":") Then
                CommandsPanel1.SetPowerUpTooltip(t_poweron, t_powerontxt)
            Else
                CommandsPanel1.SetPowerUpTooltip(t_timestamp, t_timestamptxt)
            End If
            For i As Short = 0 To err.Commands.Count - 1
                CommandsPanel1.AddCommand(err.Commands(i).CR, err.Commands(i).FR, err.Commands(i).SC, _
                                               err.Commands(i).SN, err.Commands(i).CL, err.Commands(i).CH, _
                                               err.Commands(i).DH, err.Commands(i).DC, err.Commands(i).PowerUp, _
                                               err.Commands(i).Feature)
            Next
        End If
    End Sub

    Private Sub PopulateSelfTestLog()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        If dev.IsSupportedSeftTest Then
            lblSelfTest.Text = lblSelfTest.Tag.ToString.Replace("%", dev.DataStructuresRev.SelfTestLog)
            With lvwSelfTest
                lblNoSelfTests.Visible = False
                .Visible = True
                .Enabled = True
                .Items.Clear()
                If dev.SelfTests.Count > 0 Then
                    For i As Short = 0 To dev.SelfTests.Count - 1
                        Dim st As SelfTest = dev.SelfTests(i)
                        .Items.Add(st.Num)
                        .Items(.Items.Count - 1).SubItems.Add(st.Description)
                        .Items(.Items.Count - 1).SubItems.Add(st.Status)
                        .Items(.Items.Count - 1).SubItems.Add(st.Remaining)
                        .Items(.Items.Count - 1).SubItems.Add(st.LifeTime)
                        .Items(.Items.Count - 1).SubItems.Add(st.FirstError)
                        If i Mod 2 <> 0 Then .Items(.Items.Count - 1).BackColor = Color.FromArgb(243, 245, 247)
                    Next
                    .HeaderStyle = ColumnHeaderStyle.Nonclickable
                    .Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    .Columns(2).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    .Columns(3).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(4).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(5).Width = .ClientSize.Width - .Columns(0).Width - .Columns(1).Width - .Columns(2).Width - _
                        .Columns(3).Width - .Columns(4).Width
                Else
                    .Visible = False
                    lblNoSelfTests.Visible = True
                    '.HeaderStyle = ColumnHeaderStyle.None
                    '.Items.Add(l_noselftestlog)
                    '.Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    'For i As Short = 1 To 5
                    '.Columns(i).Width = 0
                    'Next
                    '.Enabled = False
                End If
            End With
        Else
            lblSelfTest.Text = l_noselftest
            lvwSelfTest.Visible = False
        End If
    End Sub

    Private Sub PopulateSelectiveSelfTestLog()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        If dev.IsSupportedSelective Then
            lblSelective.Text = lblSelective.Tag.ToString.Replace("%", dev.DataStructuresRev.SelectiveSelfTestLog)
            With lvwSelective
                lblNoSelective.Visible = False
                .Visible = True
                .Enabled = True
                .Items.Clear()
                If dev.SelectiveSelfTest.Count > 0 Then
                    For i As Short = 0 To dev.SelectiveSelfTest.Count - 1
                        Dim sel As Selectives = dev.SelectiveSelfTest(i)
                        .Items.Add(sel.Span)
                        .Items(.Items.Count - 1).SubItems.Add(sel.MinLba)
                        .Items(.Items.Count - 1).SubItems.Add(sel.MaxLba)
                        .Items(.Items.Count - 1).SubItems.Add(sel.Status)
                        If i Mod 2 <> 0 Then .Items(.Items.Count - 1).BackColor = Color.FromArgb(243, 245, 247)
                    Next
                    .Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(2).AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize)
                    .Columns(3).Width = .ClientSize.Width - .Columns(0).Width - .Columns(1).Width - .Columns(2).Width
                Else
                    .Visible = False
                    lblNoSelective.Visible = True
                    '.HeaderStyle = ColumnHeaderStyle.None
                    '.Items.Add(l_noselectivelog)
                    '.Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                    'For i As Short = 1 To 3
                    '.Columns(i).Width = 0
                    'Next
                    '.Enabled = False
                End If
            End With
        Else
            lblSelective.Text = l_noselective
            lvwSelective.Visible = False
        End If
    End Sub

    Private Sub UpdateTestTiming()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        'update label containig selected test timing
        btnRun.Visible = True
        If Not (My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator)) _
            Or dev.Type = DeviceType.Virtual Then
            pnlTest.Visible = False
        Else
            pnlTest.Visible = True
        End If

        Select Case cboTest.SelectedIndex
            Case 0
                lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.OfflineData
            Case 1
                lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ShortTest
            Case 2
                lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ExtendedTest
            Case 3
                lblDuration.Text = lblDuration.Tag & dev.TestsPollingTime.ConveyanceTest
        End Select
        If lblDuration.Text.Contains("N/A") Or dev.Type = DeviceType.Virtual Then btnRun.Visible = False
    End Sub

    Private Sub DisableFunctions()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)
        'disable some functions not available for virtual devices
        If dev.Type = DeviceType.Virtual Then
            chkTolerance.Checked = False
            chkTolerance.Enabled = False
            chkAttributes.Checked = False
            chkAttributes.Enabled = False
            chkFirmware.Checked = False
            chkFirmware.Enabled = False
        End If
    End Sub

    Private Sub PopulateAll()
        PopulateTopPanel()
        'Main panel
        PopulateDeviceInfo()
        SetHealthPanel()
        SetSwitches()
        'Performance panel
        PopulatePerformace()
        'Advanced panel
        PopulateSmartAttributes()
        PopulateCapabilities()
        PopulateATAErrors()
        PopulateSelfTestLog()
        PopulateSelectiveSelfTestLog()
        UpdateTestTiming()
        'Smartctl panel
        PopulateSmartctlPanels()
        'set os and manufacturer pictures 
        SetManufacturerPicture()
        SetOsPicture()
        'reliability
        SetRating()
        SetReliabilityDetails()
        'Analyze(lvwDevices.SelectedItems(0).Text)
        DisableFunctions()
    End Sub

    'the following sub is public because is called when a virtual device is added
    'from the dialog box
    Public Sub UpdateAll(ByVal type As DeviceType)
        Dim updateview As Boolean = False

        With lvwDevices
            'update devices smartctl output
            For Each dev As Device In devicelist
                If dev.Type = type Then
                    dev.Update()
                    'this boolean variable checks if they're some
                    'devices of selected type
                    updateview = True
                End If
            Next

            If updateview = True Then
                For i As Short = 0 To .Items.Count - 1
                    If devicelist(i).Type = type Then
                        'update color of device name and displayed icon
                        Select Case devicelist(i).Health
                            Case Status.Unkonwn
                                .Items(i).ForeColor = Color.DarkGray
                                .Items(i).ImageIndex = 1
                            Case Status.Failed
                                .Items(i).ForeColor = Color.Red
                                .Items(i).ImageIndex = 0
                            Case Status.Passed
                                .Items(i).ForeColor = Color.Blue
                                .Items(i).ImageIndex = 1
                        End Select
                        'update device temperatures and colors
                        If IsNumeric(devicelist(i).Temperature) Then
                            If My.Settings.TempFahrenheit = True Then
                                .Items(i).SubItems(1).Text = (Math.Round(devicelist(i).Temperature * 1.8 + 32) & "°F")
                            Else
                                .Items(i).SubItems(1).Text = (devicelist(i).Temperature & "°C")
                            End If
                            Select Case Val(devicelist(i).Temperature)
                                Case 0 To 49
                                    .Items(i).SubItems(1).ForeColor = Color.Blue
                                Case 50 To 54
                                    .Items(i).SubItems(1).ForeColor = Color.DarkOrange
                                Case Is >= 55
                                    .Items(i).SubItems(1).ForeColor = Color.Red
                            End Select
                        Else
                            .Items(i).SubItems(1).Text = devicelist(i).Temperature
                            .Items(i).SubItems(1).ForeColor = Color.DarkGray
                        End If
                    End If
                Next
                .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                .Columns(0).Width = .ClientSize.Width - .Columns(1).Width

                'check if the currently displayed device is of the type
                'that are currently updated
                If devicelist(.SelectedItems(0).Index).Type = type Then
                    PopulateAll()
                    UpdateTrayIcons()
                    ShowWarnings()
                    ShareOutput()
                End If
                'update also the log of today...
                With Now
                    LoadLog(.Year, .Month, .Day)
                End With

                'and now, from 0.4.0.0, export a Xml report!
                If My.Settings.ExportToXml And IO.Directory.Exists(My.Settings.XmlFolder) Then
                    ExportToXml()
                End If
            End If
        End With
    End Sub

    Private Sub UpdateCurrent()
        With lvwDevices
            Dim i As Short = .SelectedItems(0).Index

            devicelist(i).Update()

            'update color of device name
            Select Case devicelist(i).Health
                Case status.Unkonwn
                    .Items(i).ForeColor = Color.DarkGray
                Case status.Failed
                    .Items(i).ForeColor = Color.Red
                    .Items(i).ImageIndex = 0
                Case status.Passed
                    .Items(i).ForeColor = Color.Blue
            End Select
            'update device temperatures and colors
            If IsNumeric(devicelist(i).Temperature) Then
                .Items(i).SubItems(1).Text = devicelist(i).Temperature & "°C"
                Select Case Val(devicelist(i).Temperature)
                    Case 0 To 49
                        .Items(i).SubItems(1).ForeColor = Color.Blue
                    Case 50 To 54
                        .Items(i).SubItems(1).ForeColor = Color.DarkOrange
                    Case Is >= 55
                        .Items(i).SubItems(1).ForeColor = Color.Red
                End Select
            Else
                .Items(i).SubItems(1).Text = devicelist(i).Temperature
                .Items(i).SubItems(1).ForeColor = Color.DarkGray
            End If
            .Columns(1).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
            .Columns(0).Width = .ClientSize.Width - .Columns(1).Width

            PopulateAll()
            UpdateTrayIcons()
            ShowWarnings()
            ShareOutput()
        End With
    End Sub

    Private Sub ShareOutput()
        PrintDebug("Start sharing output")

        Dim outputfolder = My.Settings.SharingFolder

        If IO.Directory.Exists(outputfolder) Then
            For i As Short = 0 To devicelist.Count - 1
                Dim dev As Device = devicelist(i)
                If dev.Type = DeviceType.Internal And dev.IsShared = True Then
                    PrintDebug("Generating report: " & dev.Model & " (" & dev.SerialNumber & ")")

                    IO.File.WriteAllText(outputfolder & "\" & dev.Model & "_" & dev.SerialNumber & ".txt", dev.Output)
                End If
            Next
        End If

        PrintDebug("End sharing output")
    End Sub

    Dim isloading_performace As Boolean
    Private Sub PopulatePerformace()
        Dim dev As Device = devicelist(lvwDevices.SelectedItems(0).Index)

        pnlApply.Visible = False

        'AAM
        trkAam.Enabled = False
        lnkSetAam.Visible = False
        lnkSetRecommended.Visible = False
        lblAamRecommended.Visible = False
        Select Case dev.AamStatus
            Case Feature.Disable
                trkAam.Value = 0
                lblAamValue.Text = lblAamValue.Tag & ": " & trkAam.Value
                If dev.Type <> DeviceType.Virtual Then trkAam.Enabled = True
                lblAamValue.ForeColor = Color.FromKnownColor(KnownColor.ControlText)
            Case Feature.Enable
                trkAam.Value = dev.AamValue
                lblAamValue.Text = lblAamValue.Tag & ": " & trkAam.Value
                If dev.Type <> DeviceType.Virtual Then trkAam.Enabled = True
                lblAamValue.ForeColor = Color.FromKnownColor(KnownColor.ControlText)
                lnkSetAam.Visible = True
                If Not IsNothing(dev.RecommendedAAM) Then
                    lnkSetRecommended.Visible = True
                    lblAamRecommended.Text = lblAamRecommended.Tag & ": " & dev.RecommendedAAM
                    lblAamRecommended.Visible = True
                End If
            Case Feature.Unavailable
                trkAam.Value = 0
                lnkSetAam.Visible = False
                lblAamValue.Text = m_notavailable
                lblAamValue.ForeColor = Color.Red
            Case Feature.Unknown
                trkAam.Value = 0
                lnkSetAam.Visible = False
                lblAamValue.Text = m_unabletodetermine
                lblAamValue.ForeColor = Color.Red
        End Select
        lnkUndoAam.Visible = False

        'APM
        lnkSetApm.Visible = False
        trkApm.Enabled = False
        Select Case dev.ApmStatus
            Case Feature.Disable
                trkApm.Value = 0
                lblApmValue.Text = lblApmValue.Tag & ": " & trkApm.Value
                If dev.Type <> DeviceType.Virtual Then trkApm.Enabled = True
                lblApmValue.ForeColor = Color.FromKnownColor(KnownColor.ControlText)
            Case Feature.Enable
                trkApm.Value = dev.ApmValue
                lblApmValue.Text = lblApmValue.Tag & ": " & trkApm.Value
                If dev.Type <> DeviceType.Virtual Then trkApm.Enabled = True
                lblApmValue.ForeColor = Color.FromKnownColor(KnownColor.ControlText)
                lnkSetApm.Visible = True
            Case Feature.Unavailable
                trkApm.Value = 0
                lnkSetApm.Visible = False
                lblApmValue.Text = m_notavailable
                lblApmValue.ForeColor = Color.Red
            Case Feature.Unknown
                trkApm.Value = 0
                lnkSetApm.Visible = False
                lblApmValue.Text = m_unabletodetermine
                lblApmValue.ForeColor = Color.Red
        End Select
        lnkUndoApm.Visible = False

        'Standby
        trkStandby.Value = 0
        lblStandbyValue.Text = lblStandbyValue.Tag & ": 0 (off)"
        trkStandby.Enabled = True
        If dev.Type = DeviceType.Virtual Then
            trkStandby.Enabled = False
            lnkSetStandby.Visible = False
            lblStandbyValue.Text = m_unabletodetermine
            lblStandbyValue.ForeColor = Color.Red
        Else
            lblStandbyValue.ForeColor = Color.FromKnownColor(KnownColor.ControlText)
            trkStandby.Value = dev.Standby
            lnkSetStandby.Visible = True
        End If
        lnkUndoStandby.Visible = False

        'Other performance features
        isloading_performace = True
        'Cache
        chkCache.Enabled = True
        'If dev.Type = DeviceType.Virtual Then chkCache.Enabled = False
        Select Case dev.Cache
            Case Feature.Disable
                chkCache.Checked = False
            Case Feature.Enable
                chkCache.Checked = True
            Case Else
                chkCache.Enabled = False
                chkCache.Checked = False
        End Select
        'Look-ahead
        chkLookAhead.Enabled = True
        'If dev.Type = DeviceType.Virtual Then chkLookAhead.Enabled = False
        Select Case dev.LookAhead
            Case Feature.Disable
                chkLookAhead.Checked = False
            Case Feature.Enable
                chkLookAhead.Checked = True
            Case Else
                chkLookAhead.Enabled = False
                chkLookAhead.Checked = False
        End Select
        isloading_performace = False
    End Sub
End Class
