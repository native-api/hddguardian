﻿'HDD Guardian is a simple GUI for smartcl utility, part of smartmontools
'
'Copyright (C) 2010-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

'I've found this routine on AddressOf.com site, and if executed,
'it removes the unused memory of application, setting the used
'memory around a size of 600k!

Public Class Memory

    Private Declare Function SetProcessWorkingSetSize Lib "kernel32.dll" ( _
      ByVal process As IntPtr, _
      ByVal minimumWorkingSetSize As Integer, _
      ByVal maximumWorkingSetSize As Integer) As Integer

    Public Shared Sub FlushMemory()
        GC.Collect()
        GC.WaitForPendingFinalizers()
        If (Environment.OSVersion.Platform = PlatformID.Win32NT) Then
            SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, -1, -1)
        End If
    End Sub

End Class
