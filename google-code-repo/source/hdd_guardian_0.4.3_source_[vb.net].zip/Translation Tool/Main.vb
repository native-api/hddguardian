﻿'Translation Tool is the HDD Guardian translation utility
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2011-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Xml

Public Class Main
    Structure CultureCodes
        Dim Code, Description As String
    End Structure

    Class CultureCollection
        Inherits List(Of CultureCodes)
    End Class

    Dim cultures As New CultureCollection
    Dim isloading As Boolean = False

    Private Sub Main_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
            MsgBox("HDD Guardian Translation Tool require administration rights.", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error")
            End
        End If

        Dim c() As String = My.Resources.cultures.Split(vbCrLf)
        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        m_xmldoc.LoadXml(My.Resources.cultures)
        m_nodelist = m_xmldoc.SelectNodes("/cultures/item")

        For Each m_node In m_nodelist
            Dim cult As String = m_node.Attributes.GetNamedItem("culture").Value
            Dim zone As String = m_node.Attributes.GetNamedItem("zone").Value
            cboCulture.Items.Add(cult)
            Dim item As New CultureCodes
            item.Code = cult
            item.Description = zone
            cultures.Add(item)
        Next

        'cboCulture.Sorted = True
        cboCulture.SelectedIndex = 0
        lblSelLanguage.Text = cultures(cboCulture.SelectedIndex).Description
        txtLanguage.Enabled = False
        txtLanguage.ResetText()
        txtTranslator.Enabled = False
        txtTranslator.ResetText()
        numVersion.Enabled = False
        numVersion.ResetText()

        
        LoadDefaultTranslation()

        LoadDefaultAttributes()
    End Sub

    Private Sub lvwTranslation_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvwTranslation.ItemSelectionChanged
        If e.IsSelected _
            Then txtDefault.Text = lvwTranslation.SelectedItems(0).Text.Replace("\", vbCrLf)

        If e.Item.SubItems(1).Text.Length > 0 Then
            txtNew.Text = e.Item.SubItems(1).Text.Replace("\", vbCrLf)
        Else
            txtNew.Text = ""
        End If
    End Sub

    Private Sub txtNew_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtNew.KeyPress
        If e.KeyChar = """" Then e.KeyChar = "'"
    End Sub

    Private Sub txtNew_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNew.TextChanged
        Try
            Dim i As Short = lvwTranslation.SelectedItems(0).Index

            lvwTranslation.Items(i).SubItems(1).Text = txtNew.Text.Replace(vbCrLf, "\")

            If txtNew.Text.Length > 0 Then
                lvwTranslation.Items(i).ForeColor = Color.FromKnownColor(KnownColor.WindowText)
            Else
                lvwTranslation.Items(i).ForeColor = Color.Red
            End If

        Catch
        End Try
    End Sub

    Private Sub lvwAttributes_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvwAttributes.ItemSelectionChanged
        If e.IsSelected Then txtDefaultAttr.Text = e.Item.SubItems(1).Text

        If e.Item.SubItems(2).Text.Length > 0 Then
            txtNewAttr.Text = e.Item.SubItems(2).Text
            lblPreview.Text = e.Item.SubItems(2).Text
        Else
            txtNewAttr.Text = ""
            lblPreview.Text = ""
        End If
    End Sub

    Private Sub txtNewAttr_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNewAttr.TextChanged
        Try
            Dim i As Short = lvwAttributes.SelectedItems(0).Index

            lvwAttributes.Items(i).SubItems(2).Text = txtNewAttr.Text.Replace(vbCrLf, " ")
            lblPreview.Text = txtNewAttr.Text.Replace(vbCrLf, " ")

            If txtNewAttr.Text.Length > 0 Then
                lvwAttributes.Items(i).ForeColor = Color.FromKnownColor(KnownColor.WindowText)
            Else
                lvwAttributes.Items(i).ForeColor = Color.Red
            End If

        Catch
        End Try
    End Sub

    Private Sub lvwTranslation_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwTranslation.SelectedIndexChanged
        If Not isloading Then SaveTranslation()

        InterfaceTranslationProgress()
    End Sub

    Private Sub cboCulture_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCulture.SelectedIndexChanged
        lblSelLanguage.Text = cultures(cboCulture.SelectedIndex).Description

        Dim folder As String = My.Application.Info.DirectoryPath & "\" & cboCulture.SelectedItem.ToString & "\"
        isloading = True

        If IO.Directory.Exists(folder) Then

            If IO.File.Exists(folder & "interface.xml") Then
                LoadTranslation()
            Else
                SaveEmptyTranslation()
            End If


            If IO.File.Exists(folder & "attributes.xml") Then
                LoadAttributes()
            Else
                SaveEmptyAttributes()
            End If

            On Error Resume Next
            lvwTranslation.Items(0).Selected = True
            lvwAttributes.Items(0).Selected = True
            txtNew.Text = lvwTranslation.Items(0).SubItems(1).Text
            txtNewAttr.Text = lvwAttributes.Items(0).SubItems(2).Text
            txtLanguage.Enabled = True
            txtTranslator.Enabled = True
            numVersion.Enabled = True

            btnCreate.Enabled = False
            btnSave.Enabled = True
            btnFolder.Enabled = True
            tabTranslation.Enabled = True
        Else
            txtLanguage.Enabled = False
            txtLanguage.ResetText()
            txtTranslator.Enabled = False
            txtTranslator.ResetText()
            numVersion.Enabled = False
            numVersion.Value = 0

            For i As Short = 0 To lvwAttributes.Items.Count - 1
                lvwAttributes.Items(i).SubItems(2).Text = ""
                lvwAttributes.Items(i).ForeColor = Color.Red
            Next

            For i As Short = 0 To lvwTranslation.Items.Count - 1
                lvwTranslation.Items(i).SubItems(1).Text = ""
                lvwTranslation.Items(i).ForeColor = Color.Red
            Next

            btnCreate.Enabled = True
            btnSave.Enabled = False
            btnFolder.Enabled = False
            tabTranslation.Enabled = False
        End If

        InterfaceTranslationProgress()
        AttributesTranslationProgress()

        isloading = False
    End Sub

    Private Sub btnCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreate.Click
        Dim folder As String = My.Application.Info.DirectoryPath & "\" & cboCulture.SelectedItem.ToString & "\"

        If Not IO.Directory.Exists(folder) Then
            IO.Directory.CreateDirectory(folder)

            Dim output As XmlWriterSettings = New XmlWriterSettings()
            output.Indent = True

            If Not IO.Directory.Exists(folder) Then Exit Sub

            SaveEmptyTranslation()

            SaveEmptyAttributes()

            tabTranslation.Enabled = True
            btnSave.Enabled = True
            btnFolder.Enabled = True
            btnCreate.Enabled = False

            txtLanguage.Enabled = True
            txtTranslator.Enabled = True
            numVersion.Enabled = True
        End If
    End Sub

    Private Sub txtLanguage_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLanguage.TextChanged
        If txtLanguage.Text.Length = 0 Or txtTranslator.Text.Length = 0 Then
            btnCreate.Enabled = False
        Else
            btnCreate.Enabled = True
        End If
    End Sub

    Private Sub txtTranslator_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtTranslator.TextChanged
        If txtLanguage.Text.Length = 0 Or txtTranslator.Text.Length = 0 Then
            btnCreate.Enabled = False
        Else
            btnCreate.Enabled = True
        End If
    End Sub

    Private Sub lvwAttributes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwAttributes.SelectedIndexChanged
        If Not isloading Then SaveAttributes()

        AttributesTranslationProgress()
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        With lvwTranslation
            Dim i As Short = .SelectedItems(0).Index + 1
            If i > .Items.Count - 1 Then i = 0
            .Items(i).Selected = True
            .Items(i).EnsureVisible()
        End With
    End Sub

    Private Sub btnNextAttr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextAttr.Click
        With lvwAttributes
            Dim i As Short = .SelectedItems(0).Index + 1
            If i > .Items.Count - 1 Then i = 0
            .Items(i).Selected = True
            .Items(i).EnsureVisible()
        End With
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        SaveTranslation()

        SaveAttributes()
    End Sub

    Private Sub btnFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFolder.Click
        Process.Start("explorer.exe", My.Application.Info.DirectoryPath & "\" & cboCulture.SelectedItem.ToString & "\")
    End Sub

#Region "Custom subs"
    Private Sub InterfaceTranslationProgress()
        Dim tot As Short = lvwTranslation.Items.Count
        Dim completed As Short = 0

        Try
            For Each item As ListViewItem In lvwTranslation.Items
                If item.SubItems(1).Text.Length > 0 Then
                    completed += 1
                End If
            Next
        Catch
        End Try

        lblTranlsationInteface.Text = lblTranlsationInteface.Tag & " " & completed & "/" & tot
    End Sub

    Private Sub AttributesTranslationProgress()
        Dim tot As Short = lvwAttributes.Items.Count
        Dim completed As Short = 0

        Try
            For Each item As ListViewItem In lvwAttributes.Items
                If item.SubItems(2).Text.Length > 0 Then
                    completed += 1
                End If
            Next
        Catch
        End Try

        lblTranslationAttributes.Text = lblTranslationAttributes.Tag & " " & completed & "/" & tot
    End Sub
#End Region
End Class
