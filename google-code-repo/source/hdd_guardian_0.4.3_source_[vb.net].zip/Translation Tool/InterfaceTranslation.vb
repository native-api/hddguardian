﻿'Translation Tool is the HDD Guardian translation utility
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2011-2013  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Xml

Module InterfaceTranslation

    Public Sub LoadDefaultTranslation()
        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        m_xmldoc.LoadXml(My.Resources.default_interface)
        m_nodelist = m_xmldoc.SelectNodes("/interface/string")

        For Each m_node In m_nodelist
            Dim id As String = m_node.Attributes.GetNamedItem("id").Value
            Dim text As String = m_node.Attributes.GetNamedItem("text").Value
            With Main.lvwTranslation
                .Items.Add(text)
                .Items(.Items.Count - 1).Tag = id
                .Items(.Items.Count - 1).SubItems.Add("")
            End With
        Next
        Main.chDefaultCulture.Width = Main.lvwTranslation.ClientRectangle.Width / 2
        Main.chNewCulture.Width = Main.lvwTranslation.ClientRectangle.Width / 2
        Main.lvwTranslation.Items(0).Selected = True
    End Sub

    Public Sub SaveTranslation()
        Dim output As XmlWriterSettings = New XmlWriterSettings()
        output.Indent = True

        Dim folder As String = My.Application.Info.DirectoryPath & "\" & Main.cboCulture.SelectedItem.ToString & "\"
        If Not IO.Directory.Exists(folder) Then Exit Sub


        Using write As XmlWriter = XmlWriter.Create(folder & "interface.xml", output)
            ' Begin writing.
            write.WriteStartDocument()
            write.WriteStartElement("interface") 'root element
            write.WriteStartElement("info") 'the info element
            write.WriteAttributeString("language", Main.txtLanguage.Text)
            write.WriteAttributeString("translator", Main.txtTranslator.Text)
            write.WriteAttributeString("version", Main.numVersion.Value)
            write.WriteEndElement()
            'the translation strings
            For i As Short = 0 To Main.lvwTranslation.Items.Count - 1
                write.WriteStartElement("string")
                write.WriteAttributeString("id", Main.lvwTranslation.Items(i).Tag)
                write.WriteAttributeString("text", Main.lvwTranslation.Items(i).SubItems(1).Text)
                write.WriteEndElement()
            Next
            'end of root element & write the document
            write.WriteEndElement()
            write.WriteEndDocument()
        End Using
    End Sub

    Public Sub SaveEmptyTranslation()
        Dim folder As String = My.Application.Info.DirectoryPath & "\" & Main.cboCulture.SelectedItem.ToString & "\"

        If Not IO.Directory.Exists(folder) Then
            IO.Directory.CreateDirectory(folder)

            Dim output As XmlWriterSettings = New XmlWriterSettings()
            output.Indent = True

            If Not IO.Directory.Exists(folder) Then Exit Sub

            Using write As XmlWriter = XmlWriter.Create(folder & "interface.xml", output)
                ' Begin writing.
                write.WriteStartDocument()
                write.WriteStartElement("interface") 'root element
                write.WriteStartElement("info") 'the info element
                write.WriteAttributeString("language", Main.txtLanguage.Text)
                write.WriteAttributeString("translator", Main.txtTranslator.Text)
                write.WriteAttributeString("version", Main.numVersion.Value)
                write.WriteEndElement()
                write.WriteStartElement("string") 'one empty translation string
                write.WriteAttributeString("id", "")
                write.WriteAttributeString("text", "")
                write.WriteEndElement()
                'end of root element & write the document
                write.WriteEndElement()
                write.WriteEndDocument()
            End Using
        End If
    End Sub

    Public Sub LoadTranslation()
        Dim folder As String = My.Application.Info.DirectoryPath & "\" & Main.cboCulture.SelectedItem.ToString & "\"

        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode


        m_xmldoc.Load(folder & "interface.xml")

        m_nodelist = m_xmldoc.SelectNodes("/interface/info")
        For Each m_node In m_nodelist
            Main.txtLanguage.Text = m_node.Attributes.GetNamedItem("language").Value
            Main.txtTranslator.Text = m_node.Attributes.GetNamedItem("translator").Value
            Main.numVersion.Value = m_node.Attributes.GetNamedItem("version").Value
        Next

        With Main.lvwTranslation
            For i As Short = 0 To .Items.Count - 1
                .Items(i).SubItems(1).Text = ""
                .Items(i).ForeColor = Color.Red
            Next
        End With

        m_nodelist = m_xmldoc.SelectNodes("/interface/string")

        For Each m_node In m_nodelist
            Dim id As String = m_node.Attributes.GetNamedItem("id").Value
            Dim text As String = m_node.Attributes.GetNamedItem("text").Value

            With Main.lvwTranslation
                For i As Short = 0 To .Items.Count - 1
                    If .Items(i).Tag = id Then
                        .Items(i).SubItems(1).Text = text
                        If text.Trim.Length > 0 Then .Items(i).ForeColor = Color.FromKnownColor(KnownColor.WindowText)
                    End If
                Next
            End With
        Next
    End Sub

End Module
