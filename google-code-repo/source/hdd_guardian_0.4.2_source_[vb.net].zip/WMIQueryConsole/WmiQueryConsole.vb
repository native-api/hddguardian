﻿'WMI Automatic Query is the HDD Guardian automatic WMI query utility,
'that gets the raw data displayed in "Geometry and partitions" section
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2011-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


Imports System
Imports System.Management
Imports System.ComponentModel

Public Class WmiQueryConsole

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim savedialog As New SaveFileDialog
        Dim res As DialogResult

        savedialog.DefaultExt = "txt"
        savedialog.AddExtension = True
        savedialog.Filter = "*.txt|*.txt"
        savedialog.FileName = "wmiquery"
        res = savedialog.ShowDialog(Me)
        If res = DialogResult.OK Then
            IO.File.WriteAllText(savedialog.FileName, txtConsole.Text)
        End If
    End Sub

    Private Sub WmiQueryConsole_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        btnSave.Enabled = False

        With txtConsole

            On Error Resume Next

            '╚╝═╔╗║

            .AppendText("╔══════════════════════════════╗" & vbCrLf)
            .AppendText("║        Win32_DiskDrive       ║" & vbCrLf)
            .AppendText("╚══════════════════════════════╝" & vbCrLf)

            Dim searcher As New ManagementObjectSearcher( _
                "root\CIMV2", _
                "SELECT * FROM Win32_DiskDrive")

            For Each queryObj As ManagementObject In searcher.Get()
                .AppendText("Caption            : " & queryObj("Caption") & vbCrLf)
                .AppendText("Model              : " & queryObj("Model") & vbCrLf)
                .AppendText("Index              : " & queryObj("Index") & vbCrLf)
                .AppendText("Size               : " & queryObj("Size") & vbCrLf)
                .AppendText("Partitions         : " & queryObj("Partitions") & vbCrLf)
                .AppendText("Cylinders          : " & queryObj("TotalCylinders") & vbCrLf)
                .AppendText("Heads              : " & queryObj("TotalHeads") & vbCrLf)
                .AppendText("Sectors            : " & queryObj("TotalSectors") & vbCrLf)
                .AppendText("Tracks             : " & queryObj("TotalTracks") & vbCrLf)
                .AppendText("Bytes per sector   : " & queryObj("BytesPerSector") & vbCrLf)
                .AppendText("Sectors per track  : " & queryObj("SectorsPerTrack") & vbCrLf)
                .AppendText("Tracks per cylinder: " & queryObj("TracksPerCylinder") & vbCrLf)
                .AppendText("Media type         : " & queryObj("MediaType") & vbCrLf)
                .AppendText("--" & vbCrLf)
            Next


            .AppendText("╔══════════════════════════════╗" & vbCrLf)
            .AppendText("║      Win32_DiskPartition     ║" & vbCrLf)
            .AppendText("╚══════════════════════════════╝" & vbCrLf)

            Dim partitioninfos As New ManagementObjectSearcher( _
                "root\CIMV2", _
                "SELECT * FROM Win32_DiskPartition")

            For Each queryPartition As ManagementObject In partitioninfos.Get
                .AppendText("Disk index         : " & queryPartition("DiskIndex") & vbCrLf)
                .AppendText("DeviceID           : " & queryPartition("DeviceID") & vbCrLf)
                .AppendText("Bootable           : " & queryPartition("Bootable") & vbCrLf)
                .AppendText("Boot partition     : " & queryPartition("BootPartition") & vbCrLf)
                .AppendText("Description        : " & queryPartition("Description") & vbCrLf)
                .AppendText("Number of blocks   : " & queryPartition("NumberOfBlocks") & vbCrLf)
                .AppendText("Block size         : " & queryPartition("BlockSize") & vbCrLf)
                .AppendText("Primary Partition  : " & queryPartition("PrimaryPartition") & vbCrLf)
                .AppendText("--" & vbCrLf)
            Next


            .AppendText("╔══════════════════════════════╗" & vbCrLf)
            .AppendText("║ Win32_LogicalDiskToPartition ║" & vbCrLf)
            .AppendText("╚══════════════════════════════╝" & vbCrLf)

            Dim volumes As New ManagementObjectSearcher( _
                "root\CIMV2", _
                "SELECT * FROM Win32_LogicalDiskToPartition")

            For Each queryVolume As ManagementObject In volumes.Get
                .AppendText("Antecedent         : " & queryVolume("Antecedent") & vbCrLf)
                .AppendText("Dependent          : " & queryVolume("Dependent") & vbCrLf)
                .AppendText("--" & vbCrLf)
            Next


            .AppendText("╔══════════════════════════════╗" & vbCrLf)
            .AppendText("║       Win32_LogicalDisk      ║" & vbCrLf)
            .AppendText("╚══════════════════════════════╝" & vbCrLf)

            Dim volume As New ManagementObjectSearcher( _
                                "root\CIMV2", _
                                "SELECT * FROM Win32_LogicalDisk")

            For Each queryDetails As ManagementObject In volume.Get
                .AppendText("Volume letter      : " & queryDetails("Caption") & vbCrLf)
                .AppendText("Volume name        : " & queryDetails("VolumeName") & vbCrLf)
                .AppendText("Serial number      : " & queryDetails("VolumeSerialNumber") & vbCrLf)
                .AppendText("File system        : " & queryDetails("FileSystem") & vbCrLf)
                .AppendText("Total size         : " & queryDetails("Size") & vbCrLf)
                .AppendText("Free space         : " & queryDetails("FreeSpace") & vbCrLf)
                .AppendText("--" & vbCrLf)
            Next
        End With

        btnSave.Enabled = True
    End Sub

End Class
