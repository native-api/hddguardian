HDD Guardian		<http://code.google.com/p/hddguardian/>
---------------------------------------------------------------------------
Copyright (C) 2010-2012 Parise Samuele

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2, or (at your option) any later
version.

You should have received a copy of the GNU General Public License;
if not, write to the Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA.

<http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>

This software are developed using Microsoft Visual Basic 2010 Express
Edition under Windows 7, and require the .NET Framework 4.0.
---------------------------------------------------------------------------


Smart Monitoring Tools	<http://smartmontools.sourceforge.net/>
---------------------------------------------------------------------------
	Copyright (C) 2002-11 by Bruce Allen
	This utilities are licensed under the GNU GPL 2.0
	<http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
---------------------------------------------------------------------------


Fugue			<http://p.yusukekamiyamane.com/>
---------------------------------------------------------------------------
	Copyright (C) 2010 Yusuke Kamiyamane. All rights reserved.
	The icons set are licensed under a Creative Commons Attribution
	3.0 license.
	<http://creativecommons.org/licenses/by/3.0/>
---------------------------------------------------------------------------


Flags			<http://www.famfamfam.com/lab/icons/flags/>
---------------------------------------------------------------------------
	Mark James
	This icon set are licensed under Public Domain License.
---------------------------------------------------------------------------


Logos
---------------------------------------------------------------------------
	Mostly from Brands Of The World	<http://www.brandsoftheworld.com/>