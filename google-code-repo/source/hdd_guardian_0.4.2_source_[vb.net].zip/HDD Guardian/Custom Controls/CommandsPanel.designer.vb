﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CommandsPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tlpCommands = New System.Windows.Forms.TableLayoutPanel()
        Me.lblSN2 = New System.Windows.Forms.Label()
        Me.lblCR1 = New System.Windows.Forms.Label()
        Me.lblCR2 = New System.Windows.Forms.Label()
        Me.lblCR3 = New System.Windows.Forms.Label()
        Me.lblCR4 = New System.Windows.Forms.Label()
        Me.lblCR5 = New System.Windows.Forms.Label()
        Me.lblFR1 = New System.Windows.Forms.Label()
        Me.lblFR2 = New System.Windows.Forms.Label()
        Me.lblFR3 = New System.Windows.Forms.Label()
        Me.lblFR4 = New System.Windows.Forms.Label()
        Me.lblFR5 = New System.Windows.Forms.Label()
        Me.lblSC1 = New System.Windows.Forms.Label()
        Me.lblSC2 = New System.Windows.Forms.Label()
        Me.lblSC3 = New System.Windows.Forms.Label()
        Me.lblSC4 = New System.Windows.Forms.Label()
        Me.lblSC5 = New System.Windows.Forms.Label()
        Me.lblSN1 = New System.Windows.Forms.Label()
        Me.lblSN3 = New System.Windows.Forms.Label()
        Me.lblSN4 = New System.Windows.Forms.Label()
        Me.lblSN5 = New System.Windows.Forms.Label()
        Me.lblCL1 = New System.Windows.Forms.Label()
        Me.lblCL2 = New System.Windows.Forms.Label()
        Me.lblCL3 = New System.Windows.Forms.Label()
        Me.lblCL4 = New System.Windows.Forms.Label()
        Me.lblCL5 = New System.Windows.Forms.Label()
        Me.lblCH1 = New System.Windows.Forms.Label()
        Me.lblCH2 = New System.Windows.Forms.Label()
        Me.lblCH3 = New System.Windows.Forms.Label()
        Me.lblCH4 = New System.Windows.Forms.Label()
        Me.lblCH5 = New System.Windows.Forms.Label()
        Me.lblDH1 = New System.Windows.Forms.Label()
        Me.lblDH2 = New System.Windows.Forms.Label()
        Me.lblDH3 = New System.Windows.Forms.Label()
        Me.lblDH4 = New System.Windows.Forms.Label()
        Me.lblDH5 = New System.Windows.Forms.Label()
        Me.lblDC1 = New System.Windows.Forms.Label()
        Me.lblDC2 = New System.Windows.Forms.Label()
        Me.lblDC3 = New System.Windows.Forms.Label()
        Me.lblDC4 = New System.Windows.Forms.Label()
        Me.lblDC5 = New System.Windows.Forms.Label()
        Me.lblPowerUp1 = New System.Windows.Forms.Label()
        Me.lblPowerUp2 = New System.Windows.Forms.Label()
        Me.lblPowerUp3 = New System.Windows.Forms.Label()
        Me.lblPowerUp4 = New System.Windows.Forms.Label()
        Me.lblPowerUp5 = New System.Windows.Forms.Label()
        Me.lblCmd1 = New System.Windows.Forms.Label()
        Me.lblCmd2 = New System.Windows.Forms.Label()
        Me.lblCmd3 = New System.Windows.Forms.Label()
        Me.lblCmd4 = New System.Windows.Forms.Label()
        Me.lblCmd5 = New System.Windows.Forms.Label()
        Me.ttCommands = New System.Windows.Forms.ToolTip(Me.components)
        Me.ttPowerUp = New System.Windows.Forms.ToolTip(Me.components)
        Me.tlpCommands.SuspendLayout()
        Me.SuspendLayout()
        '
        'tlpCommands
        '
        Me.tlpCommands.AutoSize = True
        Me.tlpCommands.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpCommands.ColumnCount = 10
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100.0!))
        Me.tlpCommands.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpCommands.Controls.Add(Me.lblSN2, 3, 1)
        Me.tlpCommands.Controls.Add(Me.lblCR1, 0, 0)
        Me.tlpCommands.Controls.Add(Me.lblCR2, 0, 1)
        Me.tlpCommands.Controls.Add(Me.lblCR3, 0, 2)
        Me.tlpCommands.Controls.Add(Me.lblCR4, 0, 3)
        Me.tlpCommands.Controls.Add(Me.lblCR5, 0, 4)
        Me.tlpCommands.Controls.Add(Me.lblFR1, 1, 0)
        Me.tlpCommands.Controls.Add(Me.lblFR2, 1, 1)
        Me.tlpCommands.Controls.Add(Me.lblFR3, 1, 2)
        Me.tlpCommands.Controls.Add(Me.lblFR4, 1, 3)
        Me.tlpCommands.Controls.Add(Me.lblFR5, 1, 4)
        Me.tlpCommands.Controls.Add(Me.lblSC1, 2, 0)
        Me.tlpCommands.Controls.Add(Me.lblSC2, 2, 1)
        Me.tlpCommands.Controls.Add(Me.lblSC3, 2, 2)
        Me.tlpCommands.Controls.Add(Me.lblSC4, 2, 3)
        Me.tlpCommands.Controls.Add(Me.lblSC5, 2, 4)
        Me.tlpCommands.Controls.Add(Me.lblSN1, 3, 0)
        Me.tlpCommands.Controls.Add(Me.lblSN3, 3, 2)
        Me.tlpCommands.Controls.Add(Me.lblSN4, 3, 3)
        Me.tlpCommands.Controls.Add(Me.lblSN5, 3, 4)
        Me.tlpCommands.Controls.Add(Me.lblCL1, 4, 0)
        Me.tlpCommands.Controls.Add(Me.lblCL2, 4, 1)
        Me.tlpCommands.Controls.Add(Me.lblCL3, 4, 2)
        Me.tlpCommands.Controls.Add(Me.lblCL4, 4, 3)
        Me.tlpCommands.Controls.Add(Me.lblCL5, 4, 4)
        Me.tlpCommands.Controls.Add(Me.lblCH1, 5, 0)
        Me.tlpCommands.Controls.Add(Me.lblCH2, 5, 1)
        Me.tlpCommands.Controls.Add(Me.lblCH3, 5, 2)
        Me.tlpCommands.Controls.Add(Me.lblCH4, 5, 3)
        Me.tlpCommands.Controls.Add(Me.lblCH5, 5, 4)
        Me.tlpCommands.Controls.Add(Me.lblDH1, 6, 0)
        Me.tlpCommands.Controls.Add(Me.lblDH2, 6, 1)
        Me.tlpCommands.Controls.Add(Me.lblDH3, 6, 2)
        Me.tlpCommands.Controls.Add(Me.lblDH4, 6, 3)
        Me.tlpCommands.Controls.Add(Me.lblDH5, 6, 4)
        Me.tlpCommands.Controls.Add(Me.lblDC1, 7, 0)
        Me.tlpCommands.Controls.Add(Me.lblDC2, 7, 1)
        Me.tlpCommands.Controls.Add(Me.lblDC3, 7, 2)
        Me.tlpCommands.Controls.Add(Me.lblDC4, 7, 3)
        Me.tlpCommands.Controls.Add(Me.lblDC5, 7, 4)
        Me.tlpCommands.Controls.Add(Me.lblPowerUp1, 8, 0)
        Me.tlpCommands.Controls.Add(Me.lblPowerUp2, 8, 1)
        Me.tlpCommands.Controls.Add(Me.lblPowerUp3, 8, 2)
        Me.tlpCommands.Controls.Add(Me.lblPowerUp4, 8, 3)
        Me.tlpCommands.Controls.Add(Me.lblPowerUp5, 8, 4)
        Me.tlpCommands.Controls.Add(Me.lblCmd1, 9, 0)
        Me.tlpCommands.Controls.Add(Me.lblCmd2, 9, 1)
        Me.tlpCommands.Controls.Add(Me.lblCmd3, 9, 2)
        Me.tlpCommands.Controls.Add(Me.lblCmd4, 9, 3)
        Me.tlpCommands.Controls.Add(Me.lblCmd5, 9, 4)
        Me.tlpCommands.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpCommands.Location = New System.Drawing.Point(0, 0)
        Me.tlpCommands.Name = "tlpCommands"
        Me.tlpCommands.RowCount = 5
        Me.tlpCommands.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCommands.Size = New System.Drawing.Size(496, 182)
        Me.tlpCommands.TabIndex = 0
        '
        'lblSN2
        '
        Me.lblSN2.AutoSize = True
        Me.lblSN2.BackColor = System.Drawing.Color.White
        Me.lblSN2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSN2.ForeColor = System.Drawing.Color.DarkKhaki
        Me.lblSN2.Location = New System.Drawing.Point(60, 20)
        Me.lblSN2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSN2.Name = "lblSN2"
        Me.lblSN2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSN2.Size = New System.Drawing.Size(20, 20)
        Me.lblSN2.TabIndex = 25
        Me.lblSN2.Text = "lblSN"
        Me.lblSN2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCR1
        '
        Me.lblCR1.AutoSize = True
        Me.lblCR1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCR1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCR1.ForeColor = System.Drawing.Color.Silver
        Me.lblCR1.Location = New System.Drawing.Point(0, 0)
        Me.lblCR1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCR1.Name = "lblCR1"
        Me.lblCR1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCR1.Size = New System.Drawing.Size(20, 20)
        Me.lblCR1.TabIndex = 9
        Me.lblCR1.Text = "lblCR"
        Me.lblCR1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCR2
        '
        Me.lblCR2.AutoSize = True
        Me.lblCR2.BackColor = System.Drawing.Color.White
        Me.lblCR2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCR2.ForeColor = System.Drawing.Color.Silver
        Me.lblCR2.Location = New System.Drawing.Point(0, 20)
        Me.lblCR2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCR2.Name = "lblCR2"
        Me.lblCR2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCR2.Size = New System.Drawing.Size(20, 20)
        Me.lblCR2.TabIndex = 10
        Me.lblCR2.Text = "lblCR"
        Me.lblCR2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCR3
        '
        Me.lblCR3.AutoSize = True
        Me.lblCR3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCR3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCR3.ForeColor = System.Drawing.Color.Silver
        Me.lblCR3.Location = New System.Drawing.Point(0, 40)
        Me.lblCR3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCR3.Name = "lblCR3"
        Me.lblCR3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCR3.Size = New System.Drawing.Size(20, 20)
        Me.lblCR3.TabIndex = 11
        Me.lblCR3.Text = "lblCR"
        Me.lblCR3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCR4
        '
        Me.lblCR4.AutoSize = True
        Me.lblCR4.BackColor = System.Drawing.Color.White
        Me.lblCR4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCR4.ForeColor = System.Drawing.Color.Silver
        Me.lblCR4.Location = New System.Drawing.Point(0, 60)
        Me.lblCR4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCR4.Name = "lblCR4"
        Me.lblCR4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCR4.Size = New System.Drawing.Size(20, 20)
        Me.lblCR4.TabIndex = 12
        Me.lblCR4.Text = "lblCR"
        Me.lblCR4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCR5
        '
        Me.lblCR5.AutoSize = True
        Me.lblCR5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCR5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCR5.ForeColor = System.Drawing.Color.Silver
        Me.lblCR5.Location = New System.Drawing.Point(0, 80)
        Me.lblCR5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCR5.Name = "lblCR5"
        Me.lblCR5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCR5.Size = New System.Drawing.Size(20, 102)
        Me.lblCR5.TabIndex = 13
        Me.lblCR5.Text = "lblCR"
        Me.lblCR5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblFR1
        '
        Me.lblFR1.AutoSize = True
        Me.lblFR1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblFR1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFR1.ForeColor = System.Drawing.Color.Red
        Me.lblFR1.Location = New System.Drawing.Point(20, 0)
        Me.lblFR1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblFR1.Name = "lblFR1"
        Me.lblFR1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblFR1.Size = New System.Drawing.Size(20, 20)
        Me.lblFR1.TabIndex = 14
        Me.lblFR1.Text = "lblFR"
        Me.lblFR1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblFR2
        '
        Me.lblFR2.AutoSize = True
        Me.lblFR2.BackColor = System.Drawing.Color.White
        Me.lblFR2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFR2.ForeColor = System.Drawing.Color.Red
        Me.lblFR2.Location = New System.Drawing.Point(20, 20)
        Me.lblFR2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblFR2.Name = "lblFR2"
        Me.lblFR2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblFR2.Size = New System.Drawing.Size(20, 20)
        Me.lblFR2.TabIndex = 15
        Me.lblFR2.Text = "lblFR"
        Me.lblFR2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblFR3
        '
        Me.lblFR3.AutoSize = True
        Me.lblFR3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblFR3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFR3.ForeColor = System.Drawing.Color.Red
        Me.lblFR3.Location = New System.Drawing.Point(20, 40)
        Me.lblFR3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblFR3.Name = "lblFR3"
        Me.lblFR3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblFR3.Size = New System.Drawing.Size(20, 20)
        Me.lblFR3.TabIndex = 16
        Me.lblFR3.Text = "lblFR"
        Me.lblFR3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblFR4
        '
        Me.lblFR4.AutoSize = True
        Me.lblFR4.BackColor = System.Drawing.Color.White
        Me.lblFR4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFR4.ForeColor = System.Drawing.Color.Red
        Me.lblFR4.Location = New System.Drawing.Point(20, 60)
        Me.lblFR4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblFR4.Name = "lblFR4"
        Me.lblFR4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblFR4.Size = New System.Drawing.Size(20, 20)
        Me.lblFR4.TabIndex = 17
        Me.lblFR4.Text = "lblFR"
        Me.lblFR4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblFR5
        '
        Me.lblFR5.AutoSize = True
        Me.lblFR5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblFR5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblFR5.ForeColor = System.Drawing.Color.Red
        Me.lblFR5.Location = New System.Drawing.Point(20, 80)
        Me.lblFR5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblFR5.Name = "lblFR5"
        Me.lblFR5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblFR5.Size = New System.Drawing.Size(20, 102)
        Me.lblFR5.TabIndex = 18
        Me.lblFR5.Text = "lblFR"
        Me.lblFR5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSC1
        '
        Me.lblSC1.AutoSize = True
        Me.lblSC1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblSC1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSC1.ForeColor = System.Drawing.Color.DarkOrange
        Me.lblSC1.Location = New System.Drawing.Point(40, 0)
        Me.lblSC1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSC1.Name = "lblSC1"
        Me.lblSC1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSC1.Size = New System.Drawing.Size(20, 20)
        Me.lblSC1.TabIndex = 19
        Me.lblSC1.Text = "lblSC"
        Me.lblSC1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSC2
        '
        Me.lblSC2.AutoSize = True
        Me.lblSC2.BackColor = System.Drawing.Color.White
        Me.lblSC2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSC2.ForeColor = System.Drawing.Color.DarkOrange
        Me.lblSC2.Location = New System.Drawing.Point(40, 20)
        Me.lblSC2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSC2.Name = "lblSC2"
        Me.lblSC2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSC2.Size = New System.Drawing.Size(20, 20)
        Me.lblSC2.TabIndex = 20
        Me.lblSC2.Text = "lblSC"
        Me.lblSC2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSC3
        '
        Me.lblSC3.AutoSize = True
        Me.lblSC3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblSC3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSC3.ForeColor = System.Drawing.Color.DarkOrange
        Me.lblSC3.Location = New System.Drawing.Point(40, 40)
        Me.lblSC3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSC3.Name = "lblSC3"
        Me.lblSC3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSC3.Size = New System.Drawing.Size(20, 20)
        Me.lblSC3.TabIndex = 21
        Me.lblSC3.Text = "lblSC"
        Me.lblSC3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSC4
        '
        Me.lblSC4.AutoSize = True
        Me.lblSC4.BackColor = System.Drawing.Color.White
        Me.lblSC4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSC4.ForeColor = System.Drawing.Color.DarkOrange
        Me.lblSC4.Location = New System.Drawing.Point(40, 60)
        Me.lblSC4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSC4.Name = "lblSC4"
        Me.lblSC4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSC4.Size = New System.Drawing.Size(20, 20)
        Me.lblSC4.TabIndex = 22
        Me.lblSC4.Text = "lblSC"
        Me.lblSC4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSC5
        '
        Me.lblSC5.AutoSize = True
        Me.lblSC5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblSC5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSC5.ForeColor = System.Drawing.Color.DarkOrange
        Me.lblSC5.Location = New System.Drawing.Point(40, 80)
        Me.lblSC5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSC5.Name = "lblSC5"
        Me.lblSC5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSC5.Size = New System.Drawing.Size(20, 102)
        Me.lblSC5.TabIndex = 23
        Me.lblSC5.Text = "lblSC"
        Me.lblSC5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSN1
        '
        Me.lblSN1.AutoSize = True
        Me.lblSN1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblSN1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSN1.ForeColor = System.Drawing.Color.DarkKhaki
        Me.lblSN1.Location = New System.Drawing.Point(60, 0)
        Me.lblSN1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSN1.Name = "lblSN1"
        Me.lblSN1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSN1.Size = New System.Drawing.Size(20, 20)
        Me.lblSN1.TabIndex = 24
        Me.lblSN1.Text = "lblSN"
        Me.lblSN1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSN3
        '
        Me.lblSN3.AutoSize = True
        Me.lblSN3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblSN3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSN3.ForeColor = System.Drawing.Color.DarkKhaki
        Me.lblSN3.Location = New System.Drawing.Point(60, 40)
        Me.lblSN3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSN3.Name = "lblSN3"
        Me.lblSN3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSN3.Size = New System.Drawing.Size(20, 20)
        Me.lblSN3.TabIndex = 26
        Me.lblSN3.Text = "lblSN"
        Me.lblSN3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSN4
        '
        Me.lblSN4.AutoSize = True
        Me.lblSN4.BackColor = System.Drawing.Color.White
        Me.lblSN4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSN4.ForeColor = System.Drawing.Color.DarkKhaki
        Me.lblSN4.Location = New System.Drawing.Point(60, 60)
        Me.lblSN4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSN4.Name = "lblSN4"
        Me.lblSN4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSN4.Size = New System.Drawing.Size(20, 20)
        Me.lblSN4.TabIndex = 27
        Me.lblSN4.Text = "lblSN"
        Me.lblSN4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSN5
        '
        Me.lblSN5.AutoSize = True
        Me.lblSN5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblSN5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSN5.ForeColor = System.Drawing.Color.DarkKhaki
        Me.lblSN5.Location = New System.Drawing.Point(60, 80)
        Me.lblSN5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSN5.Name = "lblSN5"
        Me.lblSN5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblSN5.Size = New System.Drawing.Size(20, 102)
        Me.lblSN5.TabIndex = 28
        Me.lblSN5.Text = "lblSN"
        Me.lblSN5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCL1
        '
        Me.lblCL1.AutoSize = True
        Me.lblCL1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCL1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCL1.ForeColor = System.Drawing.Color.MediumSeaGreen
        Me.lblCL1.Location = New System.Drawing.Point(80, 0)
        Me.lblCL1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCL1.Name = "lblCL1"
        Me.lblCL1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCL1.Size = New System.Drawing.Size(20, 20)
        Me.lblCL1.TabIndex = 29
        Me.lblCL1.Text = "lblCL"
        Me.lblCL1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCL2
        '
        Me.lblCL2.AutoSize = True
        Me.lblCL2.BackColor = System.Drawing.Color.White
        Me.lblCL2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCL2.ForeColor = System.Drawing.Color.MediumSeaGreen
        Me.lblCL2.Location = New System.Drawing.Point(80, 20)
        Me.lblCL2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCL2.Name = "lblCL2"
        Me.lblCL2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCL2.Size = New System.Drawing.Size(20, 20)
        Me.lblCL2.TabIndex = 30
        Me.lblCL2.Text = "lblCL"
        Me.lblCL2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCL3
        '
        Me.lblCL3.AutoSize = True
        Me.lblCL3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCL3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCL3.ForeColor = System.Drawing.Color.MediumSeaGreen
        Me.lblCL3.Location = New System.Drawing.Point(80, 40)
        Me.lblCL3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCL3.Name = "lblCL3"
        Me.lblCL3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCL3.Size = New System.Drawing.Size(20, 20)
        Me.lblCL3.TabIndex = 31
        Me.lblCL3.Text = "lblCL"
        Me.lblCL3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCL4
        '
        Me.lblCL4.AutoSize = True
        Me.lblCL4.BackColor = System.Drawing.Color.White
        Me.lblCL4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCL4.ForeColor = System.Drawing.Color.MediumSeaGreen
        Me.lblCL4.Location = New System.Drawing.Point(80, 60)
        Me.lblCL4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCL4.Name = "lblCL4"
        Me.lblCL4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCL4.Size = New System.Drawing.Size(20, 20)
        Me.lblCL4.TabIndex = 32
        Me.lblCL4.Text = "lblCL"
        Me.lblCL4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCL5
        '
        Me.lblCL5.AutoSize = True
        Me.lblCL5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCL5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCL5.ForeColor = System.Drawing.Color.MediumSeaGreen
        Me.lblCL5.Location = New System.Drawing.Point(80, 80)
        Me.lblCL5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCL5.Name = "lblCL5"
        Me.lblCL5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCL5.Size = New System.Drawing.Size(20, 102)
        Me.lblCL5.TabIndex = 33
        Me.lblCL5.Text = "lblCL"
        Me.lblCL5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCH1
        '
        Me.lblCH1.AutoSize = True
        Me.lblCH1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCH1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCH1.ForeColor = System.Drawing.Color.MediumTurquoise
        Me.lblCH1.Location = New System.Drawing.Point(100, 0)
        Me.lblCH1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCH1.Name = "lblCH1"
        Me.lblCH1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCH1.Size = New System.Drawing.Size(20, 20)
        Me.lblCH1.TabIndex = 34
        Me.lblCH1.Text = "lblCH"
        Me.lblCH1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCH2
        '
        Me.lblCH2.AutoSize = True
        Me.lblCH2.BackColor = System.Drawing.Color.White
        Me.lblCH2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCH2.ForeColor = System.Drawing.Color.MediumTurquoise
        Me.lblCH2.Location = New System.Drawing.Point(100, 20)
        Me.lblCH2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCH2.Name = "lblCH2"
        Me.lblCH2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCH2.Size = New System.Drawing.Size(20, 20)
        Me.lblCH2.TabIndex = 35
        Me.lblCH2.Text = "lblCH"
        Me.lblCH2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCH3
        '
        Me.lblCH3.AutoSize = True
        Me.lblCH3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCH3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCH3.ForeColor = System.Drawing.Color.MediumTurquoise
        Me.lblCH3.Location = New System.Drawing.Point(100, 40)
        Me.lblCH3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCH3.Name = "lblCH3"
        Me.lblCH3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCH3.Size = New System.Drawing.Size(20, 20)
        Me.lblCH3.TabIndex = 36
        Me.lblCH3.Text = "lblCH"
        Me.lblCH3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCH4
        '
        Me.lblCH4.AutoSize = True
        Me.lblCH4.BackColor = System.Drawing.Color.White
        Me.lblCH4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCH4.ForeColor = System.Drawing.Color.MediumTurquoise
        Me.lblCH4.Location = New System.Drawing.Point(100, 60)
        Me.lblCH4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCH4.Name = "lblCH4"
        Me.lblCH4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCH4.Size = New System.Drawing.Size(20, 20)
        Me.lblCH4.TabIndex = 37
        Me.lblCH4.Text = "lblCH"
        Me.lblCH4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCH5
        '
        Me.lblCH5.AutoSize = True
        Me.lblCH5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCH5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCH5.ForeColor = System.Drawing.Color.MediumTurquoise
        Me.lblCH5.Location = New System.Drawing.Point(100, 80)
        Me.lblCH5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCH5.Name = "lblCH5"
        Me.lblCH5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCH5.Size = New System.Drawing.Size(20, 102)
        Me.lblCH5.TabIndex = 38
        Me.lblCH5.Text = "lblCH"
        Me.lblCH5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDH1
        '
        Me.lblDH1.AutoSize = True
        Me.lblDH1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblDH1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDH1.ForeColor = System.Drawing.Color.Blue
        Me.lblDH1.Location = New System.Drawing.Point(120, 0)
        Me.lblDH1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDH1.Name = "lblDH1"
        Me.lblDH1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDH1.Size = New System.Drawing.Size(20, 20)
        Me.lblDH1.TabIndex = 39
        Me.lblDH1.Text = "lblDH"
        Me.lblDH1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDH2
        '
        Me.lblDH2.AutoSize = True
        Me.lblDH2.BackColor = System.Drawing.Color.White
        Me.lblDH2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDH2.ForeColor = System.Drawing.Color.Blue
        Me.lblDH2.Location = New System.Drawing.Point(120, 20)
        Me.lblDH2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDH2.Name = "lblDH2"
        Me.lblDH2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDH2.Size = New System.Drawing.Size(20, 20)
        Me.lblDH2.TabIndex = 40
        Me.lblDH2.Text = "lblDH"
        Me.lblDH2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDH3
        '
        Me.lblDH3.AutoSize = True
        Me.lblDH3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblDH3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDH3.ForeColor = System.Drawing.Color.Blue
        Me.lblDH3.Location = New System.Drawing.Point(120, 40)
        Me.lblDH3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDH3.Name = "lblDH3"
        Me.lblDH3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDH3.Size = New System.Drawing.Size(20, 20)
        Me.lblDH3.TabIndex = 41
        Me.lblDH3.Text = "lblDH"
        Me.lblDH3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDH4
        '
        Me.lblDH4.AutoSize = True
        Me.lblDH4.BackColor = System.Drawing.Color.White
        Me.lblDH4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDH4.ForeColor = System.Drawing.Color.Blue
        Me.lblDH4.Location = New System.Drawing.Point(120, 60)
        Me.lblDH4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDH4.Name = "lblDH4"
        Me.lblDH4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDH4.Size = New System.Drawing.Size(20, 20)
        Me.lblDH4.TabIndex = 42
        Me.lblDH4.Text = "lblDH"
        Me.lblDH4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDH5
        '
        Me.lblDH5.AutoSize = True
        Me.lblDH5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblDH5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDH5.ForeColor = System.Drawing.Color.Blue
        Me.lblDH5.Location = New System.Drawing.Point(120, 80)
        Me.lblDH5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDH5.Name = "lblDH5"
        Me.lblDH5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDH5.Size = New System.Drawing.Size(20, 102)
        Me.lblDH5.TabIndex = 43
        Me.lblDH5.Text = "lblDH"
        Me.lblDH5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDC1
        '
        Me.lblDC1.AutoSize = True
        Me.lblDC1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblDC1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDC1.ForeColor = System.Drawing.Color.MediumOrchid
        Me.lblDC1.Location = New System.Drawing.Point(140, 0)
        Me.lblDC1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDC1.Name = "lblDC1"
        Me.lblDC1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDC1.Size = New System.Drawing.Size(20, 20)
        Me.lblDC1.TabIndex = 44
        Me.lblDC1.Text = "lblDC"
        Me.lblDC1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDC2
        '
        Me.lblDC2.AutoSize = True
        Me.lblDC2.BackColor = System.Drawing.Color.White
        Me.lblDC2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDC2.ForeColor = System.Drawing.Color.MediumOrchid
        Me.lblDC2.Location = New System.Drawing.Point(140, 20)
        Me.lblDC2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDC2.Name = "lblDC2"
        Me.lblDC2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDC2.Size = New System.Drawing.Size(20, 20)
        Me.lblDC2.TabIndex = 45
        Me.lblDC2.Text = "lblDC"
        Me.lblDC2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDC3
        '
        Me.lblDC3.AutoSize = True
        Me.lblDC3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblDC3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDC3.ForeColor = System.Drawing.Color.MediumOrchid
        Me.lblDC3.Location = New System.Drawing.Point(140, 40)
        Me.lblDC3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDC3.Name = "lblDC3"
        Me.lblDC3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDC3.Size = New System.Drawing.Size(20, 20)
        Me.lblDC3.TabIndex = 46
        Me.lblDC3.Text = "lblDC"
        Me.lblDC3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDC4
        '
        Me.lblDC4.AutoSize = True
        Me.lblDC4.BackColor = System.Drawing.Color.White
        Me.lblDC4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDC4.ForeColor = System.Drawing.Color.MediumOrchid
        Me.lblDC4.Location = New System.Drawing.Point(140, 60)
        Me.lblDC4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDC4.Name = "lblDC4"
        Me.lblDC4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDC4.Size = New System.Drawing.Size(20, 20)
        Me.lblDC4.TabIndex = 47
        Me.lblDC4.Text = "lblDC"
        Me.lblDC4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDC5
        '
        Me.lblDC5.AutoSize = True
        Me.lblDC5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblDC5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblDC5.ForeColor = System.Drawing.Color.MediumOrchid
        Me.lblDC5.Location = New System.Drawing.Point(140, 80)
        Me.lblDC5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblDC5.Name = "lblDC5"
        Me.lblDC5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblDC5.Size = New System.Drawing.Size(20, 102)
        Me.lblDC5.TabIndex = 48
        Me.lblDC5.Text = "lblDC"
        Me.lblDC5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblPowerUp1
        '
        Me.lblPowerUp1.AutoSize = True
        Me.lblPowerUp1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblPowerUp1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblPowerUp1.Location = New System.Drawing.Point(160, 0)
        Me.lblPowerUp1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblPowerUp1.Name = "lblPowerUp1"
        Me.lblPowerUp1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblPowerUp1.Size = New System.Drawing.Size(100, 20)
        Me.lblPowerUp1.TabIndex = 49
        Me.lblPowerUp1.Text = "lblPowerUp"
        Me.lblPowerUp1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblPowerUp2
        '
        Me.lblPowerUp2.AutoSize = True
        Me.lblPowerUp2.BackColor = System.Drawing.Color.White
        Me.lblPowerUp2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblPowerUp2.Location = New System.Drawing.Point(160, 20)
        Me.lblPowerUp2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblPowerUp2.Name = "lblPowerUp2"
        Me.lblPowerUp2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblPowerUp2.Size = New System.Drawing.Size(100, 20)
        Me.lblPowerUp2.TabIndex = 50
        Me.lblPowerUp2.Text = "lblPowerUp"
        Me.lblPowerUp2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblPowerUp3
        '
        Me.lblPowerUp3.AutoSize = True
        Me.lblPowerUp3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblPowerUp3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblPowerUp3.Location = New System.Drawing.Point(160, 40)
        Me.lblPowerUp3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblPowerUp3.Name = "lblPowerUp3"
        Me.lblPowerUp3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblPowerUp3.Size = New System.Drawing.Size(100, 20)
        Me.lblPowerUp3.TabIndex = 51
        Me.lblPowerUp3.Text = "lblPowerUp"
        Me.lblPowerUp3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblPowerUp4
        '
        Me.lblPowerUp4.AutoSize = True
        Me.lblPowerUp4.BackColor = System.Drawing.Color.White
        Me.lblPowerUp4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblPowerUp4.Location = New System.Drawing.Point(160, 60)
        Me.lblPowerUp4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblPowerUp4.Name = "lblPowerUp4"
        Me.lblPowerUp4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblPowerUp4.Size = New System.Drawing.Size(100, 20)
        Me.lblPowerUp4.TabIndex = 52
        Me.lblPowerUp4.Text = "lblPowerUp"
        Me.lblPowerUp4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblPowerUp5
        '
        Me.lblPowerUp5.AutoSize = True
        Me.lblPowerUp5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblPowerUp5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblPowerUp5.Location = New System.Drawing.Point(160, 80)
        Me.lblPowerUp5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblPowerUp5.Name = "lblPowerUp5"
        Me.lblPowerUp5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblPowerUp5.Size = New System.Drawing.Size(100, 102)
        Me.lblPowerUp5.TabIndex = 53
        Me.lblPowerUp5.Text = "lblPowerUp"
        Me.lblPowerUp5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCmd1
        '
        Me.lblCmd1.AutoSize = True
        Me.lblCmd1.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCmd1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCmd1.Location = New System.Drawing.Point(260, 0)
        Me.lblCmd1.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCmd1.Name = "lblCmd1"
        Me.lblCmd1.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCmd1.Size = New System.Drawing.Size(236, 20)
        Me.lblCmd1.TabIndex = 54
        Me.lblCmd1.Text = "lblCmd"
        '
        'lblCmd2
        '
        Me.lblCmd2.AutoSize = True
        Me.lblCmd2.BackColor = System.Drawing.Color.White
        Me.lblCmd2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCmd2.Location = New System.Drawing.Point(260, 20)
        Me.lblCmd2.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCmd2.Name = "lblCmd2"
        Me.lblCmd2.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCmd2.Size = New System.Drawing.Size(236, 20)
        Me.lblCmd2.TabIndex = 55
        Me.lblCmd2.Text = "lblCmd"
        '
        'lblCmd3
        '
        Me.lblCmd3.AutoSize = True
        Me.lblCmd3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCmd3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCmd3.Location = New System.Drawing.Point(260, 40)
        Me.lblCmd3.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCmd3.Name = "lblCmd3"
        Me.lblCmd3.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCmd3.Size = New System.Drawing.Size(236, 20)
        Me.lblCmd3.TabIndex = 56
        Me.lblCmd3.Text = "lblCmd"
        '
        'lblCmd4
        '
        Me.lblCmd4.AutoSize = True
        Me.lblCmd4.BackColor = System.Drawing.Color.White
        Me.lblCmd4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCmd4.Location = New System.Drawing.Point(260, 60)
        Me.lblCmd4.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCmd4.Name = "lblCmd4"
        Me.lblCmd4.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCmd4.Size = New System.Drawing.Size(236, 20)
        Me.lblCmd4.TabIndex = 57
        Me.lblCmd4.Text = "lblCmd"
        '
        'lblCmd5
        '
        Me.lblCmd5.AutoSize = True
        Me.lblCmd5.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.lblCmd5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblCmd5.Location = New System.Drawing.Point(260, 80)
        Me.lblCmd5.Margin = New System.Windows.Forms.Padding(0)
        Me.lblCmd5.Name = "lblCmd5"
        Me.lblCmd5.Padding = New System.Windows.Forms.Padding(0, 2, 0, 1)
        Me.lblCmd5.Size = New System.Drawing.Size(236, 102)
        Me.lblCmd5.TabIndex = 58
        Me.lblCmd5.Text = "lblCmd"
        '
        'CommandsPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.tlpCommands)
        Me.Name = "CommandsPanel"
        Me.Size = New System.Drawing.Size(496, 182)
        Me.tlpCommands.ResumeLayout(False)
        Me.tlpCommands.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ttCommands As System.Windows.Forms.ToolTip
    Private WithEvents tlpCommands As System.Windows.Forms.TableLayoutPanel
    Private WithEvents lblSN2 As System.Windows.Forms.Label
    Private WithEvents lblCR1 As System.Windows.Forms.Label
    Private WithEvents lblCR2 As System.Windows.Forms.Label
    Private WithEvents lblCR3 As System.Windows.Forms.Label
    Private WithEvents lblCR4 As System.Windows.Forms.Label
    Private WithEvents lblCR5 As System.Windows.Forms.Label
    Private WithEvents lblFR1 As System.Windows.Forms.Label
    Private WithEvents lblFR2 As System.Windows.Forms.Label
    Private WithEvents lblFR3 As System.Windows.Forms.Label
    Private WithEvents lblFR4 As System.Windows.Forms.Label
    Private WithEvents lblFR5 As System.Windows.Forms.Label
    Private WithEvents lblSC1 As System.Windows.Forms.Label
    Private WithEvents lblSC2 As System.Windows.Forms.Label
    Private WithEvents lblSC3 As System.Windows.Forms.Label
    Private WithEvents lblSC4 As System.Windows.Forms.Label
    Private WithEvents lblSC5 As System.Windows.Forms.Label
    Private WithEvents lblSN1 As System.Windows.Forms.Label
    Private WithEvents lblSN3 As System.Windows.Forms.Label
    Private WithEvents lblSN4 As System.Windows.Forms.Label
    Private WithEvents lblSN5 As System.Windows.Forms.Label
    Private WithEvents lblCL1 As System.Windows.Forms.Label
    Private WithEvents lblCL2 As System.Windows.Forms.Label
    Private WithEvents lblCL3 As System.Windows.Forms.Label
    Private WithEvents lblCL4 As System.Windows.Forms.Label
    Private WithEvents lblCL5 As System.Windows.Forms.Label
    Private WithEvents lblCH1 As System.Windows.Forms.Label
    Private WithEvents lblCH2 As System.Windows.Forms.Label
    Private WithEvents lblCH3 As System.Windows.Forms.Label
    Private WithEvents lblCH4 As System.Windows.Forms.Label
    Private WithEvents lblCH5 As System.Windows.Forms.Label
    Private WithEvents lblDH1 As System.Windows.Forms.Label
    Private WithEvents lblDH2 As System.Windows.Forms.Label
    Private WithEvents lblDH3 As System.Windows.Forms.Label
    Private WithEvents lblDH4 As System.Windows.Forms.Label
    Private WithEvents lblDH5 As System.Windows.Forms.Label
    Private WithEvents lblDC1 As System.Windows.Forms.Label
    Private WithEvents lblDC2 As System.Windows.Forms.Label
    Private WithEvents lblDC3 As System.Windows.Forms.Label
    Private WithEvents lblDC4 As System.Windows.Forms.Label
    Private WithEvents lblDC5 As System.Windows.Forms.Label
    Private WithEvents lblPowerUp1 As System.Windows.Forms.Label
    Private WithEvents lblPowerUp2 As System.Windows.Forms.Label
    Private WithEvents lblPowerUp3 As System.Windows.Forms.Label
    Private WithEvents lblPowerUp4 As System.Windows.Forms.Label
    Private WithEvents lblPowerUp5 As System.Windows.Forms.Label
    Private WithEvents lblCmd1 As System.Windows.Forms.Label
    Private WithEvents lblCmd2 As System.Windows.Forms.Label
    Private WithEvents lblCmd3 As System.Windows.Forms.Label
    Private WithEvents lblCmd4 As System.Windows.Forms.Label
    Private WithEvents lblCmd5 As System.Windows.Forms.Label
    Friend WithEvents ttPowerUp As System.Windows.Forms.ToolTip

End Class
