﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AttributeInfoPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMeaning = New System.Windows.Forms.Label()
        Me.tlpContents = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblType = New System.Windows.Forms.Label()
        Me.lblUpdated = New System.Windows.Forms.Label()
        Me.tlpContents.SuspendLayout()
        Me.pnlTitle.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblMeaning
        '
        Me.lblMeaning.AutoSize = True
        Me.lblMeaning.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMeaning.ForeColor = System.Drawing.Color.DimGray
        Me.lblMeaning.Location = New System.Drawing.Point(3, 19)
        Me.lblMeaning.Margin = New System.Windows.Forms.Padding(3)
        Me.lblMeaning.MaximumSize = New System.Drawing.Size(194, 164)
        Me.lblMeaning.MinimumSize = New System.Drawing.Size(194, 164)
        Me.lblMeaning.Name = "lblMeaning"
        Me.lblMeaning.Size = New System.Drawing.Size(194, 164)
        Me.lblMeaning.TabIndex = 6
        Me.lblMeaning.Text = "lblMeaning"
        '
        'tlpContents
        '
        Me.tlpContents.AutoSize = True
        Me.tlpContents.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.tlpContents.BackColor = System.Drawing.Color.Transparent
        Me.tlpContents.ColumnCount = 1
        Me.tlpContents.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpContents.Controls.Add(Me.lblMeaning, 0, 1)
        Me.tlpContents.Controls.Add(Me.pnlTitle, 0, 0)
        Me.tlpContents.Controls.Add(Me.lblType, 0, 2)
        Me.tlpContents.Controls.Add(Me.lblUpdated, 0, 3)
        Me.tlpContents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpContents.Location = New System.Drawing.Point(0, 0)
        Me.tlpContents.Name = "tlpContents"
        Me.tlpContents.RowCount = 4
        Me.tlpContents.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.tlpContents.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 168.0!))
        Me.tlpContents.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpContents.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpContents.Size = New System.Drawing.Size(200, 224)
        Me.tlpContents.TabIndex = 7
        '
        'pnlTitle
        '
        Me.pnlTitle.Controls.Add(Me.lblTitle)
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlTitle.Location = New System.Drawing.Point(0, 0)
        Me.pnlTitle.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(200, 16)
        Me.pnlTitle.TabIndex = 7
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.DimGray
        Me.lblTitle.Location = New System.Drawing.Point(3, 0)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblTitle.MinimumSize = New System.Drawing.Size(0, 16)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(45, 16)
        Me.lblTitle.TabIndex = 6
        Me.lblTitle.Text = "lblTitle"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblType
        '
        Me.lblType.AutoSize = True
        Me.lblType.ForeColor = System.Drawing.Color.DimGray
        Me.lblType.Location = New System.Drawing.Point(3, 187)
        Me.lblType.Margin = New System.Windows.Forms.Padding(3)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(41, 13)
        Me.lblType.TabIndex = 8
        Me.lblType.Text = "lblType"
        '
        'lblUpdated
        '
        Me.lblUpdated.AutoSize = True
        Me.lblUpdated.ForeColor = System.Drawing.Color.DimGray
        Me.lblUpdated.Location = New System.Drawing.Point(3, 207)
        Me.lblUpdated.Margin = New System.Windows.Forms.Padding(3)
        Me.lblUpdated.Name = "lblUpdated"
        Me.lblUpdated.Size = New System.Drawing.Size(58, 13)
        Me.lblUpdated.TabIndex = 9
        Me.lblUpdated.Text = "lblUpdated"
        '
        'AttributeInfoPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.tlpContents)
        Me.Name = "AttributeInfoPanel"
        Me.Size = New System.Drawing.Size(200, 224)
        Me.tlpContents.ResumeLayout(False)
        Me.tlpContents.PerformLayout()
        Me.pnlTitle.ResumeLayout(False)
        Me.pnlTitle.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents lblType As System.Windows.Forms.Label
    Private WithEvents lblUpdated As System.Windows.Forms.Label
    Private WithEvents pnlTitle As System.Windows.Forms.Panel
    Private WithEvents tlpContents As System.Windows.Forms.TableLayoutPanel
    Private WithEvents lblMeaning As System.Windows.Forms.Label
    Private WithEvents lblTitle As System.Windows.Forms.Label

End Class
