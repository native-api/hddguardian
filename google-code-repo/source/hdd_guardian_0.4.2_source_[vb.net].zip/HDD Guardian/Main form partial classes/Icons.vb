﻿Imports System.IO

'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main
    Dim pic_admin, pic_noadmin, pic_hourglass, pic_info As Image

    Private Sub LoadIcons()
        Dim iconsfolder As String = My.Application.Info.DirectoryPath & "\graphics\icons\"
        Dim picinfo As Image = Image.FromFile(iconsfolder & "status-information.png")
        pic_hourglass = Image.FromFile(iconsfolder & "hourglass.png")
        pic_info = picinfo
        pic_admin = Image.FromFile(iconsfolder & "admin.png")
        pic_noadmin = Image.FromFile(iconsfolder & "noadmin.png")
        Dim picquestion As Image = Image.FromFile(iconsfolder & "question.png")

        picHelp.Image = Image.FromFile(iconsfolder & "help.png")

        'main panel
        picVersion.Image = Image.FromFile(iconsfolder & "new.png")
        hpSummary.SetIconsFolder(iconsfolder)
        picAdminSmart.Image = pic_admin
        picAdminOffline.Image = pic_admin
        picAdminAutosave.Image = pic_admin

        'determine where HDD Guardian is stored and then show an usb key
        'if the device is removable or a tower if the device is a fixed disc
        If devtype.DriveType <> DriveType.Fixed Then
            picUsb.Image = Image.FromFile(iconsfolder & "usb.png")
        Else
            picUsb.Image = Image.FromFile(iconsfolder & "fixed.png")
        End If

        'determine if current user is an administrator and then set the admin (a fingerprint) icon
        If My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
            picAdmin.Image = pic_admin
        Else
            picAdmin.Image = pic_noadmin
        End If

        btnPrev.Image = Image.FromFile(iconsfolder & "calendar-previous.png")
        btnNext.Image = Image.FromFile(iconsfolder & "calendar-next.png")
        btnToday.Image = Image.FromFile(iconsfolder & "calendar-today.png")
        btnReload.Image = Image.FromFile(iconsfolder & "update.png")
        btnDelLog.Image = Image.FromFile(iconsfolder & "delete.png")
        btnDelAllLogs.Image = Image.FromFile(iconsfolder & "delete_all.png")
        'performance panel
        tipAam.SetIcons(Image.FromFile(iconsfolder & "aam.png"))
        tipApm.SetIcons(Image.FromFile(iconsfolder & "apm.png"))
        tipStandby.SetIcons(Image.FromFile(iconsfolder & "standby.png"))
        picCache.Image = Image.FromFile(iconsfolder & "cache.png")
        picLookAhead.Image = Image.FromFile(iconsfolder & "look-ahead.png")
        picApply.Image = Image.FromFile(iconsfolder & "status-information.png")
        'advanced panel
        With imlAttr.Images
            .Clear()
            .Add("pre-fail", Image.FromFile(iconsfolder & "attr-pre-fail.png"))
            .Add("old age", Image.FromFile(iconsfolder & "attr-old age.png"))
        End With
        picAdminError.Image = pic_admin
        picAdminSelective.Image = pic_admin
        picAdminSelfTest.Image = pic_admin
        tipTest.SetIcons(picinfo, pic_admin)
        picTestInfo.Image = picinfo
        'smartctl panel
        tipTolerance.SetIcons(picinfo, pic_admin)
        picTolerance.Image = picquestion
        tipAttributes.SetIcons(picinfo, pic_admin)
        picAttributes.Image = picquestion
        picAttrFormat.Image = picquestion
        tipFirmware.SetIcons(picinfo, pic_admin)
        picFirmware.Image = picquestion
        picSwap.Image = picquestion
        picNoLogDir.Image = picquestion
        picXErrorLba.Image = picquestion
        'settings panel
        picWindow.Image = Image.FromFile(iconsfolder & "settings-appearance.png")
        picUpdate.Image = Image.FromFile(iconsfolder & "update.png")
        picWarning.Image = Image.FromFile(iconsfolder & "settings-bell.png")
        picShare.Image = Image.FromFile(iconsfolder & "settings-share.png")
        picMonitoring.Image = Image.FromFile(iconsfolder & "monitoring.png")
        picXml.Image = Image.FromFile(iconsfolder & "xml.png")
        picRating.Image = Image.FromFile(iconsfolder & "star.png")
        'device list images
        imlDevice.Images.Clear()
        imlDevice.Images.Add("error", My.Resources.drive_error)
        imlDevice.Images.Add("ok", My.Resources.drive_ok)
        imlDevice.Images.Add("pie", My.Resources.pie)
        'imlDevice.Images.Add("folder", Image.FromFile(iconsfolder & "folder.png"))
        imlDevice.Images.Add("foder", My.Resources.drive_folder)
        imlDevice.Images.Add("windrive", My.Resources.drive_win)
        imlDevice.Images.Add("pc", Image.FromFile(iconsfolder & "monitor.png"))
        'contacts into about page
        picHome.Image = Image.FromFile(iconsfolder & "home.png")
        picGroup.Image = Image.FromFile(iconsfolder & "group.png")
        picEmail.Image = Image.FromFile(iconsfolder & "mail.png")
        picPlus.Image = Image.FromFile(iconsfolder & "plus.png")
    End Sub

End Class
