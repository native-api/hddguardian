﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Public Class Console
    Private WithEvents Cmd As Process

    Public Function SendCmd(ByVal command As String) As String()
        Dim output() As String
        Dim lines() As String

        Cmd = New Process

        'setup for hidden command window
        Cmd.StartInfo.RedirectStandardInput = True
        Cmd.StartInfo.RedirectStandardOutput = True
        Cmd.StartInfo.UseShellExecute = False 'required to redirect
        Cmd.StartInfo.CreateNoWindow = True 'this command avoid the creation of window
        Cmd.StartInfo.FileName = "cmd" 'the command window interpreter
        Cmd.StartInfo.WorkingDirectory = My.Application.Info.DirectoryPath 'set working folder

        Cmd.Start() 'start hidden command window from current folder
        Cmd.StandardInput.WriteLine("smartctl " & command) 'write command to cmd window
        'for a general purpose use remove '"smartctl " &' from the previous row
        Cmd.StandardInput.WriteLine("exit") 'exit from cmd window
        lines = Cmd.StandardOutput.ReadToEnd.Split(vbCrLf) 'load output into an array

        Cmd.Close() 'release the resources

        'copy the "lines" array into the "output" array, excluding the first 4 lines of
        'standard output (OS info and the command sent by this function) and the last
        'line (where is sent the DOS command "exit")
        ReDim output(lines.Length - 7) 'expand the output array
        Array.ConstrainedCopy(lines, 4, output, 0, lines.Length - 7)

        Return output 'return the "output" array

        Cmd.Kill()
    End Function
End Class
