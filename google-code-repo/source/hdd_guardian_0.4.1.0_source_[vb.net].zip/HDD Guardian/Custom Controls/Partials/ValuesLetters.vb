﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Drawing

Partial Class FlagsPanel

    'letters B, H, J, K, Q, X, Y, Z are not used

    Private Sub A(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "A" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y)
            .DrawLine(letter, x, y - 2, x + 4, y - 2)
        End With
    End Sub

    Private Sub C(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "C" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
        End With
    End Sub

    Private Sub D(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "D" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 3, y - 4)
            .DrawLine(letter, x, y, x + 3, y)
            .DrawLine(letter, x + 4, y - 1, x + 4, y - 3)
        End With
    End Sub

    Private Sub E(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "E" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
            .DrawLine(letter, x, y - 2, x + 2, y - 2)
        End With
    End Sub

    Private Sub F(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "F" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x, y - 2, x + 2, y - 2)
        End With
    End Sub

    Private Sub G(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "G" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
            .DrawLine(letter, x + 4, y, x + 4, y - 2)
            .DrawLine(letter, x + 4, y - 2, x + 2, y - 2)
        End With
    End Sub

    Private Sub I(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "I" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
        End With
    End Sub

    Private Sub L(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "L" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
        End With
    End Sub

    Private Sub M(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "M" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y)
            .DrawLine(letter, x + 2, y - 4, x + 2, y)
        End With
    End Sub

    Private Sub N(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "N" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y)
        End With
    End Sub

    Private Sub O(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "O" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y)
            .DrawLine(letter, x, y, x + 4, y)
        End With
    End Sub

    Private Sub P(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "P" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y - 2)
            .DrawLine(letter, x + 4, y - 2, x, y - 2)
        End With
    End Sub

    Private Sub R(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "R" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 4, y - 4, x + 4, y - 2)
            .DrawLine(letter, x + 4, y - 2, x, y - 2)
            .DrawLine(letter, x + 2, y - 2, x + 4, y)
        End With
    End Sub

    Private Sub S(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "S" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x, y - 4, x, y - 2)
            .DrawLine(letter, x, y - 2, x + 4, y - 2)
            .DrawLine(letter, x + 4, y - 2, x + 4, y)
            .DrawLine(letter, x + 4, y, x, y)
        End With
    End Sub

    Private Sub T(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "T" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y - 4, x + 4, y - 4)
            .DrawLine(letter, x + 2, y, x + 2, y - 4)
        End With
    End Sub

    Private Sub U(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "U" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
            .DrawLine(letter, x + 4, y, x + 4, y - 4)
        End With
    End Sub

    Private Sub V(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "V" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y - 4, x, y - 2)
            .DrawLine(letter, x, y - 2, x + 2, y)
            .DrawLine(letter, x + 2, y, x + 4, y - 2)
            .DrawLine(letter, x + 4, y - 2, x + 4, y - 4)
        End With
    End Sub

    Private Sub W(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw letter "W" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x, y - 4)
            .DrawLine(letter, x, y, x + 4, y)
            .DrawLine(letter, x + 4, y, x + 4, y - 4)
            .DrawLine(letter, x + 2, y, x + 2, y - 4)
        End With
    End Sub

    Private Sub Slash(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw symbol "/" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y, x + 4, y - 4)
        End With
    End Sub

    Private Sub Line(ByVal color As Color, ByVal x As Integer, ByVal y As Integer)
        Dim letter As New Pen(color, 1)
        Dim g As Graphics = Me.CreateGraphics

        'draw symbol "-" from x,y source at bottom left
        With g
            .DrawLine(letter, x, y - 2, x + 4, y - 2)
        End With
    End Sub
End Class
