﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.ComponentModel

Public Class GraphicalButton
    Dim txt As String = ""
    Dim chk As Boolean = False
    Dim collapse As Boolean = False

    Private Sub lblText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblText.Click
        InvokeOnClick(Me, e)
    End Sub

    Private Sub lblText_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblText.MouseEnter
        lblText.Font = New Font(lblText.Font, FontStyle.Underline)
    End Sub

    Private Sub lblText_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblText.MouseLeave
        lblText.Font = New Font(lblText.Font, FontStyle.Regular)
    End Sub

    Public Sub New()

        ' Chiamata richiesta dalla finestra di progettazione.
        InitializeComponent()

        ' Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent().
        chk = False
        tlpGrid.BackgroundImage = imlBackground.Images("deselected")
        If txt = "" Then lblText.Text = Me.Name
    End Sub

    Public Property Caption As String
        Get
            Return lblText.Text
        End Get
        Set(ByVal value As String)
            txt = value
            lblText.Text = value
        End Set
    End Property

    <DefaultValue(False)> _
    Public Property Checked As Boolean
        Get
            Return chk
        End Get
        Set(ByVal value As Boolean)
            chk = value

            DeselectAll()

            With tlpGrid
                If chk = False Then
                    .BackgroundImage = imlBackground.Images("deselected")
                Else
                    .BackgroundImage = imlBackground.Images("selected")

                End If
            End With
        End Set
    End Property

    Private Sub DeselectAll()
        For Each Control In Parent.Controls
            If Control.GetType.Name = Me.GetType.Name Then
                Control.BackgroundImage = imlBackground.Images("deselected")
            End If
        Next
    End Sub

    <DefaultValue(False)> _
    Public Property Collapsed As Boolean
        Get
            Return collapse
        End Get
        Set(ByVal value As Boolean)
            collapse = value

            With Me
                If value = False Then
                    .AutoSize = True
                Else
                    .AutoSize = False
                    .Width = 0
                End If
            End With

        End Set
    End Property

    Private Sub GraphicalButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        DeselectAll()

        Me.Checked = True
        lblText.Font = New Font(lblText.Font, FontStyle.Regular)
        Me.Focus()
    End Sub

    Private Sub GraphicalButton_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.GotFocus
        lblText.Font = New Font(lblText.Font, FontStyle.Underline)
    End Sub

    Private Sub GraphicalButton_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If e.KeyChar = " " Then
            DeselectAll()

            Me.Checked = True
            lblText.Font = New Font(lblText.Font, FontStyle.Regular)
            Me.Focus()
            Me.InvokeOnClick(Me, Nothing)
        End If
    End Sub

    Private Sub GraphicalButton_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LostFocus
        lblText.Font = New Font(lblText.Font, FontStyle.Regular)
    End Sub

    <System.ComponentModel.Browsable(False)> _
    Public Overloads Property BackgroundImage() As System.Drawing.Image
        Get
            Return tlpGrid.BackgroundImage
        End Get
        Set(ByVal value As System.Drawing.Image)
            tlpGrid.BackgroundImage = value
        End Set
    End Property

    <System.ComponentModel.Browsable(False)> _
    Public Overloads Property BackColor() As Color
        Set(ByVal value As Color)
            MyBase.BackColor = value
        End Set
        Get
            Return MyBase.BackColor
        End Get
    End Property

    <System.ComponentModel.Browsable(False)> _
    Public Overloads ReadOnly Property BackgroundImageLayout() As Boolean
        Get
            Return Nothing
        End Get
    End Property

    <System.ComponentModel.Browsable(False)> _
    Public Overloads ReadOnly Property BorderStyle() As Boolean
        Get
            Return Nothing
        End Get
    End Property
End Class
