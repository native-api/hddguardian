﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

'This if the partial class of main form that perform the interface translation.
'Interface translation is based upon the culture code installed for the current user;
'it check if the current culture have a translation searching their folder, otherwise
'load the default english translation.
'By example, if the current culture is the spanish used in Argentina, it check if the
'folder "es-AR" exist; if this folder doesn't exist, if go for the generic spanish folder
'named "es"; again, if this folder doesn't exist, it uses the built-in basic english translation.

Imports System.Xml

Partial Class Main

    'Dim language() As String
    Dim language As New Hashtable
    Dim external_language As New Hashtable
    Dim d_firmware, d_serial As String
    Dim m_temperature, m_overallhealth As String
    Dim h_overallpassed, h_overallfailed, h_unknown As String
    Dim badsect_no, badsect_few, badsect_several, badsect_one As String
    Dim w_no, w_repunavailabe, w_smartdisabled, w_smartunavailble As String
    Dim e_noerror, e_select, e_noerrorlogging As String
    Dim t_timestamp, t_timestamptxt, t_poweron, t_powerontxt As String
    Dim l_noselftest, l_noselective, l_noselftestlog, l_noselectivelog As String
    Dim m_tests As New TestsList
    Dim m_prefail, m_oldage, m_always, m_offline As String
    Dim m_attributes, m_formats, m_tolerance, m_firmware As New Collection
    Dim m_yes, m_no, m_available, m_unavailable, m_ambiguous, m_enabled, m_disabled, m_unknown As String
    Dim m_message, m_question As String
    Dim m_smartenabled, m_smartdisabled, m_smartnotsupported, m_smartambiguous, m_qdisablesmart As String
    Dim m_offldataenabled, m_offldatanotsupported, m_offldatadisabled, m_qdisableoffldata, m_unabletodisable As String
    Dim m_alarmdevstatus, m_degradation, m_recovery, m_from, m_to As String
    Dim m_temperaturealarm As String
    Dim m_failuretitle, m_failuretxt As String
    Dim m_exit, m_exitmsg As String
    Dim m_error, m_nodevices, m_nosmartctl As String
    Dim m_aborttitle, m_abortmsg As String
    Dim m_adminrights As String
    Dim m_tip, m_tiptext As String
    Dim m_updateavailable As String
    Public m_dataerror, m_nogooddata As String
    Dim m_testresults As New ResultsList
    Dim m_devicestatus As New DevStatusList
    Dim m_diskgeometry, m_deviceindex, m_partitions, m_totalsize, m_availablesize, m_cylinders, m_heads As String
    Dim m_sectors, m_tracks, m_bytespersector, m_sectorspertrack, m_trackspercylinder, m_partitiondetails, m_serialnumber As String
    Dim m_filesystem, m_numofblocks, m_blocksize, m_type, m_bootable, m_bootpartition, m_primarypartition As String
    Dim m_gathering, m_notforvirtual As String
    Dim error_no, error_few, error_several, error_one As String
    Dim m_notavailable, m_unabletodetermine As String
    Dim m_reserved, m_vendortime As String

    Private Class TestsList
        Inherits List(Of Tests)
    End Class

    Private Structure Tests
        Dim Test As String
        Dim Info As String
    End Structure

    Private Class ResultsList
        Inherits List(Of Results)
    End Class

    Private Structure Results
        Dim Original, Change As String
        Sub New(ByVal orig As String, ByVal chng As String)
            Original = orig
            Change = chng
        End Sub
    End Structure

    Private Class DevStatusList
        Inherits List(Of DevStatus)
    End Class

    Private Structure DevStatus
        Dim Original, Change As String
        Sub New(ByVal orig As String, ByVal chng As String)
            Original = orig
            Change = chng
        End Sub
    End Structure

    Private Sub LoadInternalLanguage()
        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        m_xmldoc.LoadXml(My.Resources.default_interface)

        ttMain.SetToolTip(picLanguageFlag, "Default translation" & vbNewLine & _
                          "Current culture: " & My.Computer.Info.InstalledUICulture.Name)

        m_nodelist = m_xmldoc.SelectNodes("/interface/string")
        With language
            .Clear()
            For Each m_node In m_nodelist
                .Add(m_node.Attributes.GetNamedItem("id").Value, _
                     m_node.Attributes.GetNamedItem("text").Value)
            Next
        End With
    End Sub

    Private Sub LoadExternalLanguage(ByRef culture As String)
        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        If IO.File.Exists(culture & "\interface.xml") Then
            Try
                m_xmldoc.Load(culture & "\interface.xml")

                m_nodelist = m_xmldoc.SelectNodes("/interface/info")
                For Each m_node In m_nodelist
                    Dim language As String = m_node.Attributes.GetNamedItem("language").Value
                    Dim author As String = m_node.Attributes.GetNamedItem("translator").Value
                    Dim version As String = m_node.Attributes.GetNamedItem("version").Value
                    If FileIO.FileSystem.FileExists(culture & "\flag.png") Then
                        picLanguageFlag.Image = Image.FromFile(culture & "\flag.png")
                        ttMain.SetToolTip(picLanguageFlag, language & " by " & author & vbCrLf & _
                                          "Version: " & version.Replace(",", ".") & vbCrLf & _
                                          "Current culture: " & My.Computer.Info.InstalledUICulture.Name)
                    End If
                Next

                m_nodelist = m_xmldoc.SelectNodes("/interface/string")
                With external_language
                    .Clear()
                    For Each m_node In m_nodelist
                        .Add(m_node.Attributes.GetNamedItem("id").Value, _
                             m_node.Attributes.GetNamedItem("text").Value)
                    Next
                End With
            Catch
            End Try
        End If
    End Sub

    Private Sub LoadLanguage()
        Dim curculture As String = My.Computer.Info.InstalledUICulture.Name 'it gets, by example, "es-AR"
        Dim languagesfolder As String = My.Application.Info.DirectoryPath & "\languages\"
        Dim cult() As String = curculture.Split("-")
        Dim curculturefolder0 As String = languagesfolder & curculture
        Dim curculturefolder1 As String = languagesfolder & cult(0)
        'Dim english As String = languagesfolder & "en"

        'load internal (english) interface translation
        LoadInternalLanguage()

        If FileIO.FileSystem.DirectoryExists(curculturefolder0) Then 'check if subfolder named "es-AR" exists
            LoadExternalLanguage(curculturefolder0)
        ElseIf FileIO.FileSystem.DirectoryExists(curculturefolder1) Then 'check if subfolder named "es" exists
            LoadExternalLanguage(curculturefolder1)
        End If

        'replace translation strings that exists into the external translation:
        'if external translation is incomplete, are used the strings into the internal translation
        If external_language.Count > 0 Then
            For Each de As DictionaryEntry In external_language
                If de.Value.ToString.Length > 0 Then
                    language(de.Key) = de.Value
                End If
            Next
        End If
    End Sub

    Private Function GetString(ByVal value As Short) As String
        Dim val As String = String.Format("{0:D4}", value)
        Return language(val).ToString.Replace("\", vbCrLf)
    End Function

    Private Sub InterfaceTranslation()
        LoadLanguage()

        'top panel
        d_firmware = GetString(22) & ": "
        d_serial = GetString(21) & ": "
        m_updateavailable = GetString(7) 'new version available

        'devicelist groups
        lvwDevices.Groups(0).Tag = GetString(19) 'internal
        lvwDevices.Groups(2).Tag = GetString(20) 'virtual
        lvwDevices.Groups(1).Tag = GetString(18) 'external

        'tray icon menu
        mnuRefresh.Text = GetString(2)
        mnuRestore.Text = GetString(5)
        mnuExit.Text = GetString(6)
        mnuRescanRemovable.Text = GetString(8)

        'power button
        ttMain.SetToolTip(picPower, GetString(6))

        'devices context menu
        mnuUpdate.Text = GetString(1)
        mnuUpdateAll.Text = GetString(2)
        mnuRescanExternal.Text = GetString(8)
        mnuAddVirtual.Text = GetString(3)
        mnuRemoveVirtual.Text = GetString(4)

        'navigation buttons
        gbMain.Caption = GetString(1000)
        gbAdvanced.Caption = GetString(2000)
        gbSmartctl.Caption = GetString(3000)
        gbSettings.Caption = GetString(4000)
        gbAbout.Caption = GetString(5000)
        gbPerformance.Caption = GetString(6900)

        'main panel
        'summary
        tpSummary.Text = GetString(1100)
        m_temperature = GetString(1101)
        m_overallhealth = GetString(1103)
        hpSummary.SetCaptions(m_temperature, GetString(1102), m_overallhealth, GetString(1104), GetString(1105))
        h_overallpassed = GetString(1106)
        h_overallfailed = GetString(1107)
        h_unknown = GetString(1120)
        badsect_no = GetString(1108)
        badsect_few = GetString(1123)
        badsect_several = GetString(1110)
        badsect_one = GetString(1109)
        error_no = GetString(1118)
        error_few = GetString(1122)
        error_several = GetString(1121)
        error_one = GetString(1119)
        w_no = GetString(1111)
        w_repunavailabe = GetString(1112)
        w_smartdisabled = GetString(1113)
        w_smartunavailble = GetString(1114)
        btnUpdate.Text = GetString(1115)
        btnDetails.Text = GetString(1116)
        btnRunTest.Text = GetString(1117)
        'device test results: here are loaded the text that change the default smartctl english output
        With m_testresults
            .Add(New Results("Completed without error", GetString(1130)))
            .Add(New Results("Aborted by host", GetString(1131)))
            .Add(New Results("Interrupted (host reset)", GetString(1132)))
            .Add(New Results("Fatal or unknown error", GetString(1133)))
            .Add(New Results("Completed: unknown failure", GetString(1134)))
            .Add(New Results("Completed: electrical failure", GetString(1135)))
            .Add(New Results("Completed: servo/seek failure", GetString(1136)))
            .Add(New Results("Completed: read failure", GetString(1137)))
            .Add(New Results("Completed: handling damage", GetString(1138)))
            .Add(New Results("Self-test routine in progress", GetString(1139)))
            .Add(New Results("Unknown status", GetString(1140)))
        End With

        'device info
        tpInfo.Text = GetString(1200)
        dipInfo.SetCaptions(GetString(1201), GetString(1202), GetString(1203), GetString(1204), _
                            GetString(1205), GetString(1206), GetString(1207), GetString(1208), _
                            GetString(1209), GetString(1210), GetString(1211), GetString(1212), GetString(1213))
        m_yes = GetString(1220)
        m_no = GetString(1221)
        m_available = GetString(1222)
        m_unavailable = GetString(1223)
        m_ambiguous = GetString(1224)
        m_enabled = GetString(1225)
        m_disabled = GetString(1226)
        m_unknown = GetString(1227)

        'device features
        tpFeatures.Text = GetString(1300)

        lblDevFeatures.Text = GetString(1310)
        lblEnableSmart.Text = GetString(1311)
        lblSmart.Text = GetString(1312)
        lblEnableOffline.Text = GetString(1313)
        lblOfflineTest.Text = GetString(1314)
        lblEnableAutosave.Text = GetString(1315)
        lblAttrAutosave.Text = GetString(1316)

        lblMonFeatures.Text = GetString(1320)
        lblEnableTray.Text = GetString(1321)
        lblDevTrayIcon.Text = GetString(1322)
        lblEnableShare.Text = GetString(1323)
        lblShare.Text = GetString(1324)
        lnkSetFolder.Text = GetString(1325)

        m_message = GetString(1330)
        m_question = GetString(1331)

        m_smartenabled = GetString(1340)
        m_smartambiguous = GetString(1341)
        m_smartnotsupported = GetString(1342)
        m_qdisablesmart = GetString(1343)
        m_smartdisabled = GetString(1344)
        m_offldataenabled = GetString(1345)
        m_offldatanotsupported = GetString(1346)
        m_qdisableoffldata = GetString(1347)
        m_offldatadisabled = GetString(1348)
        m_unabletodisable = GetString(1349)

        'log events
        tpLog.Text = GetString(1400)
        chTime.Text = GetString(1401)
        chDeviceLog.Text = GetString(1402)
        chAttrLog.Text = GetString(1403)
        chFrom.Text = GetString(1404)
        chTo.Text = GetString(1405)
        chVariation.Text = GetString(1406)
        ttMain.SetToolTip(btnDelLog, GetString(1407))
        ttMain.SetToolTip(btnDelAllLogs, GetString(1408))
        lblNoLog.Text = GetString(1409)
        ttMain.SetToolTip(btnPrev, GetString(1410))
        ttMain.SetToolTip(btnToday, GetString(1411))
        ttMain.SetToolTip(btnNext, GetString(1412))
        ttMain.SetToolTip(btnReload, GetString(1413))

        'geometry and partitions
        tpGeometryPartitions.Text = GetString(1500)
        m_diskgeometry = GetString(1501)
        m_deviceindex = GetString(1502)
        m_partitions = GetString(1503)
        m_totalsize = GetString(1504)
        m_availablesize = GetString(1505)
        m_cylinders = GetString(1506)
        m_heads = GetString(1507)
        m_sectors = GetString(1508)
        m_tracks = GetString(1509)
        m_bytespersector = GetString(1510)
        m_sectorspertrack = GetString(1511)
        m_trackspercylinder = GetString(1512)
        m_partitiondetails = GetString(1513)
        m_serialnumber = GetString(1514)
        m_filesystem = GetString(1515)
        m_numofblocks = GetString(1516)
        m_blocksize = GetString(1517)
        m_type = GetString(1518)
        m_bootable = GetString(1519)
        m_bootpartition = GetString(1520)
        m_primarypartition = GetString(1521)
        m_gathering = GetString(1522)
        m_notforvirtual = GetString(1523)

        'performance panel
        'aam
        tpAAM.Text = GetString(6100)
        tipAam.Tip = GetString(6101)
        lblQuiet.Text = GetString(6102)
        lblLoudest.Text = GetString(6103)
        lblAamValue.Tag = GetString(6111)
        lnkSetAam.Text = GetString(6112)
        lnkSetRecommended.Text = GetString(6104)
        lblAamRecommended.Tag = GetString(6105)
        lnkUndoAam.Text = GetString(6115)
        'apm
        tpAPM.Text = GetString(6200)
        tipApm.Tip = GetString(6201)
        lblApmValue.Tag = GetString(6111)
        lnkSetApm.Text = GetString(6112)
        lnkUndoApm.Text = GetString(6115)
        'standby
        tpStandby.Text = GetString(6300)
        tipStandby.Tip = GetString(6301)
        lblStandbyValue.Tag = GetString(6111)
        lnkSetStandby.Text = GetString(6112)
        m_reserved = GetString(6302)
        m_vendortime = GetString(6303)
        lnkUndoStandby.Text = GetString(6115)
        'other features
        tpOtherFeatures.Text = GetString(6400)
        chkCache.Text = GetString(6401)
        lblCacheInfo.Text = GetString(6402)
        chkLookAhead.Text = GetString(6403)
        lblLookAheadInfo.Text = GetString(6404)
        'common strings
        m_notavailable = GetString(6110)
        m_unabletodetermine = GetString(6113)
        lblApply.Text = GetString(6114)

        'advanced panel
        'smart attributes
        tpAttributes.Text = GetString(2100)
        lblDataStructure.Tag = GetString(2101) & ": "
        lnkShowInfo.Text = GetString(2102)
        chType.Text = GetString(2110)
        chID.Text = GetString(2111)
        chAttribute.Text = GetString(2112)
        chCurrent.Text = GetString(2113)
        chWorst.Text = GetString(2114)
        chThreshold.Text = GetString(2115)
        chWhenFailed.Text = GetString(2116)
        chRawValue.Text = GetString(2117)
        apAttributes.SetCaptions(GetString(2120), GetString(2121))
        m_prefail = GetString(2122)
        m_oldage = GetString(2123)
        m_always = GetString(2124)
        m_offline = GetString(2125)
        m_tip = GetString(2126)
        m_tiptext = GetString(2127)
        apAttributes.SetInfo(m_tip, m_tiptext, "", "")
        'capabilities
        tpCapabilities.Text = GetString(2200)

        'error log
        tpErrors.Text = GetString(2300)
        e_noerror = GetString(2301)
        e_select = GetString(2302)
        e_noerrorlogging = GetString(2304)
        lblErrLogVer.Tag = GetString(2303) & ": "
        lblPowerOn.Tag = GetString(2310) & ": " 'text is putted into the tag because we have to show the error #
        lblDeviceStatus.Tag = GetString(2311)
        lblRegisters.Text = GetString(2312) & ":"
        lblCommands.Text = GetString(2313) & ":"
        t_timestamp = GetString(2320)
        t_timestamptxt = GetString(2321)
        t_poweron = GetString(2330)
        t_powerontxt = GetString(2331)
        'device status: here are loaded the text that change the default smartctl english output
        With m_devicestatus
            .Add(New DevStatus("in an unknown state", GetString(2340)))
            .Add(New DevStatus("sleeping", GetString(2341)))
            .Add(New DevStatus("in standby mode", GetString(2342)))
            .Add(New DevStatus("active or idle", GetString(2343)))
            .Add(New DevStatus("doing SMART Offline or Self-test", GetString(2344)))
            .Add(New DevStatus("in a reserved state", GetString(2345)))
            .Add(New DevStatus("in a vendor specific state", GetString(2346)))
        End With

        'self tests logs
        tpSelfTests.Text = GetString(2400)
        l_noselftest = GetString(2401)
        l_noselective = GetString(2402)
        l_noselftestlog = GetString(2403)
        l_noselectivelog = GetString(2404)

        lblSelfTest.Tag = GetString(2410) 'text is putted into the tag because we have to show the log revision #
        chNum.Text = GetString(2411)
        chTestType.Text = GetString(2412)
        chTestStatus.Text = GetString(2413)
        chRemaining.Text = GetString(2414)
        chAge.Text = GetString(2415)
        chFirstError.Text = GetString(2416)

        lblSelective.Tag = GetString(2420) 'text is putted into the tag because we have to show the log revision #
        chSpan.Text = GetString(2421)
        chLbaMin.Text = GetString(2422)
        chLbaMax.Text = GetString(2423)
        chCurTestStatus.Text = GetString(2424)

        'reliability details
        tpReliability.Text = GetString(2600)
        'HDD
        lblErrors.Text = GetString(4604)
        lblCurPending.Text = GetString(4314)
        lblOfflUnc.Text = GetString(4315)
        lblReallSect.Text = GetString(4310)
        'SSD
        lblIndilinx.Text = GetString(4320)
        lblIntel.Text = GetString(4321)
        lblMicron.Text = GetString(4322)
        lblSamsung.Text = GetString(4323)
        lblSandForce.Text = GetString(4324)

        'run tests
        tpRunTest.Text = GetString(2500)
        tipTest.Tip = GetString(2513)
        'lblTestGeneralInfo.Text = GetString(2512)
        lblSelectTest.Text = GetString(2508) & ":"
        lblDuration.Tag = GetString(2507) & ": "
        With m_tests
            Dim test As New Tests
            .Clear()
            'offline test
            test.Test = GetString(2501)
            test.Info = GetString(2514)
            .Add(test)
            'short self test
            test.Test = GetString(2502)
            test.Info = GetString(2510)
            .Add(test)
            'extended self test
            test.Test = GetString(2503)
            test.Info = GetString(2511)
            .Add(test)
            'conveyance self test
            test.Test = GetString(2504)
            test.Info = GetString(2512)
            .Add(test)
        End With
        With cboTest
            For i As Integer = 0 To m_tests.Count - 1
                cboTest.Items.Add(m_tests(i).Test)
            Next
        End With
        btnRun.Text = GetString(2505)
        btnStop.Text = GetString(2506)
        lblExtimatedEnd.Tag = GetString(2515) & ": "
        m_aborttitle = GetString(2520)
        m_abortmsg = GetString(2521)

        'smartctl tab
        'database
        'no more available from version 0.3.0.0
        'tpDatabase.Text = GetString(3100)
        'lblDatabase.Tag = GetString(3101)
        'lblModel.Text = GetString(3102) & ":"
        'lblFirmware.Text = GetString(3103) & ":"
        'lblFamily.Text = GetString(3104) & ":"
        'lblAttrOptions.Text = GetString(3105) & ":"
        'lblOtherOpt.Text = GetString(3106) & ":"
        'lblWarnings.Text = GetString(3107) & ":"

        'output
        tpOutput.Text = GetString(3200)
        btnSaveOutput.Text = GetString(3201)

        'tolerance
        tpTolerance.Text = GetString(3300)
        chkTolerance.Text = GetString(3301)
        For i As Short = 0 To 2
            m_tolerance.Add(GetString(3320 + i))
        Next
        With cboTolerance
            With .Items
                .Add(GetString(3302))
                .Add(GetString(3303))
                .Add(GetString(3304))
            End With
            .SelectedIndex = 0
        End With
        tipTolerance.Tip = GetString(3310)

        'firmware
        tpFirmware.Text = GetString(3500)
        chkFirmware.Text = GetString(3501)
        For i As Short = 0 To 3
            m_firmware.Add(GetString(3520 + i))
        Next
        With cboFirmware
            With .Items
                .Add(GetString(3502))
                .Add("Samsung")
                .Add("Samsung2")
                .Add("Samsung3")
            End With
            .SelectedIndex = 0
        End With
        chkFixSwap.Text = GetString(3503)
        ttMain.SetToolTip(picSwap, GetString(3524))
        tipFirmware.Tip = GetString(3510)

        'vendor specific attributes
        tpAttFormat.Text = GetString(3400)
        chkAttributes.Text = GetString(3401)
        lblID.Text = GetString(3403) & ":"
        lblFormat.Text = GetString(3404) & ":"
        lblName.Text = GetString(3405) & ":"
        btnAdd.Text = GetString(3406)
        chAttrID.Text = GetString(3407)
        chAttrFormat.Text = GetString(3408)
        chAttrName.Text = GetString(3409)
        btnRemove.Text = GetString(3410)
        tipAttributes.Tip = GetString(3420)
        'populate Formats, ID and attributes comboboxes
        For i As Short = 0 To 13
            m_formats.Add(GetString(3450 + i))
        Next
        With cboFormat
            With .Items
                .Clear()
                .Add("") '0
                .Add("raw8") '1
                .Add("raw16") '2
                .Add("raw16(avg16)") '3
                .Add("raw16(raw16)") '4
                .Add("raw24/raw24") '5
                .Add("raw48") '6
                .Add("raw64") '7
                .Add("hex48") '8
                .Add("hex64") '9
                .Add("min2hour") '10
                .Add("sec2hour") '11
                .Add("halfmin2hour") '12
                .Add("tempminmax") '13
                .Add("temp10x") '14
            End With
            .SelectedIndex = 0
        End With

        With cboID
            With .Items
                .Clear()
                .Add("")
                .Add("N")
                For i As Short = 1 To 255
                    .Add(i)
                Next
            End With
            .SelectedIndex = 0
        End With
        For i As Short = 0 To 13
            m_attributes.Add(GetString(3430 + i))
        Next
        With cboAttributes
            With .Items()
                .Add(GetString(3402)) '0
                .Add("9: Power-On (minutes)")
                .Add("9: Power-On (seconds)")
                .Add("9: Power-On (halfminutes)")
                .Add("9: Temperature")
                .Add("192: Emergency Retract Cycle Count (Fujitsu)")
                .Add("193: Load/Unload Cycle Count")
                .Add("194: Temperature x 10")
                .Add("194: Unknown")
                .Add("197: Total Pending Sectors")
                .Add("198: Total Offline Uncorrectable")
                .Add("198: Off-Line Scan Uncorrectable Sector Count (Fujitsu)")
                .Add("200: Write Error Count")
                .Add("201: Detected TA Count")
                .Add("220: Temperature") '14
            End With
            .SelectedIndex = 0
        End With
        'settings tab
        'look n' feel
        tpLooknfeel.Text = GetString(4100)
        chkStartupLink.Text = GetString(4101)
        chkRunMinimized.Text = GetString(4102)
        chkMinimizeInTray.Text = GetString(4103)
        chkCloseOnTray.Text = GetString(4104)
        chkAlwaysShowTray.Text = GetString(4105)
        chkConfirmExit.Text = GetString(4106)
        'update
        tpUpdate.Text = GetString(4200)
        lblUpdate.Text = GetString(4201)
        lblInternal.Text = GetString(19) & ":"
        lblExternal.Text = GetString(18) & ":"
        lblVirtual.Text = GetString(20) & ":"
        lblMinutes.Text = GetString(4202)
        lblMinutesExt.Text = GetString(4202)
        lblMinutesVirt.Text = GetString(4202)

        'monitoring
        tpMonitoring.Text = GetString(4500)
        lblMonitoring.Text = GetString(4501)
        lblGeneric.Text = GetString(4502) & ":"
        lblSSD.Text = GetString(4503) & ":"
        lnkInvertSel.Text = GetString(4318)
        lnkInvertSelSSD.Text = GetString(4318)
        'generic
        chkReallSectCt.Text = GetString(4310)
        chkSpinRetryCt.Text = GetString(4311)
        chkTemp.Text = GetString(4312)
        chkReallEvCt.Text = GetString(4313)
        chkCurPenSect.Text = GetString(4314)
        chkOfflUnc.Text = GetString(4315)
        chkSoftReadErr.Text = GetString(4316)
        chkDiskShift.Text = GetString(4317)
        'SSD
        chkIndilinx.Text = GetString(4320) & " (Indilinx)"
        chkIntel.Text = GetString(4321) & " (Intel)"
        chkMicron.Text = GetString(4322) & " (Micron)"
        chkSamsung.Text = GetString(4323) & " (Samsung)"
        chkSandForce.Text = GetString(4324) & " (SandForce)"

        'warning
        tpWarning.Text = GetString(4300)
        lblWarning.Text = GetString(4301)
        chkParamChng.Text = GetString(4302) '& ":"
        chkFailure.Text = GetString(4303)
        chkTempThresh.Text = GetString(4304) & " (50°C)"

        'share
        tpShare.Text = GetString(4400)
        lblSelFolder.Text = GetString(4401)
        btnBrwsFolder.Text = GetString(4402)
        lblFolder.Tag = GetString(4403)
        lblXml.Text = GetString(4410)
        chkXml.Text = GetString(4411)
        btnXml.Text = GetString(4402)
        lblXmlPath.Tag = GetString(4403)

        'rating
        tpRating.Text = GetString(4600)
        chkRating.Text = GetString(4601)
        chkTuneUp.Text = GetString(4602)
        Dim reset As String = GetString(4603)
        lnkResetCurPend.Text = reset
        lnkResetErrors.Text = reset
        lnkResetOfflUnc.Text = reset
        lblErrorsTune.Text = GetString(4604) & ":"
        lblCurPendTune.Text = GetString(4606) & ":"
        lblOfflUncTune.Text = GetString(4607) & ":"

        'warnings and failure tooltip
        m_alarmdevstatus = GetString(6000)
        m_from = GetString(6001)
        m_to = GetString(6002)
        m_degradation = GetString(6003)
        m_recovery = GetString(6004)
        m_temperaturealarm = GetString(6005)
        m_failuretitle = GetString(6006)
        m_failuretxt = GetString(6007)

        'exit message
        m_exit = GetString(5100)
        m_exitmsg = GetString(5101)

        'no devices found message error
        m_error = GetString(8000)
        m_nodevices = GetString(8001)
        m_nosmartctl = GetString(8002)

        'add virtual device dialog box
        With AddVirtual
            .Text = GetString(7000)
            .lblDescription.Text = GetString(7001)
            .lblLocation.Text = GetString(7002)
            .btnAdd.Text = GetString(7003)
            .btnCancel.Text = GetString(7004)
        End With
        m_dataerror = GetString(7010)
        m_nogooddata = GetString(7011)

        'admin rights
        m_adminrights = GetString(9000)
        ttMain.SetToolTip(picAdminAutosave, m_adminrights)
        ttMain.SetToolTip(picAdminOffline, m_adminrights)
        ttMain.SetToolTip(picAdminSelective, m_adminrights)
        ttMain.SetToolTip(picAdminSelfTest, m_adminrights)
        ttMain.SetToolTip(picAdminSmart, m_adminrights)
        ttMain.SetToolTip(picAdminError, m_adminrights)
    End Sub

End Class