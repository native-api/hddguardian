﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Imports System.Xml
Imports System.Text.RegularExpressions

Partial Class Main

    Structure OsItem
        Dim RegExp As String
        Dim Logo As Image
    End Structure

    Structure Manufacturer
        Dim RegExp, Web As String
        Dim Banner As Image
        Dim Internal As Image
        Dim External As Image
    End Structure

    Class OS
        Inherits List(Of OsItem)
    End Class

    Class Manufacturers
        Inherits List(Of Manufacturer)
    End Class

    Dim manufacturersList As New Manufacturers
    Dim osList As New OS

    Private Sub LoadManufacturers()
        Dim man_folder As String = My.Application.Info.DirectoryPath & "\graphics\manufacturers\"

        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        m_xmldoc.Load(man_folder & "manufacturers.xml")
        m_nodelist = m_xmldoc.SelectNodes("/manufacturers/manufacturer")

        manufacturersList.Clear()
        For Each m_node In m_nodelist
            Dim vendor As New Manufacturer
            With vendor
                .RegExp = m_node.ChildNodes.Item(0).InnerText
                .Banner = Image.FromFile(man_folder & m_node.ChildNodes.Item(1).InnerText)
                .Internal = Image.FromFile(man_folder & "internal\" & m_node.ChildNodes.Item(1).InnerText)
                If IO.File.Exists(man_folder & "external\" & m_node.ChildNodes.Item(1).InnerText) Then
                    .External = Image.FromFile(man_folder & "external\" & m_node.ChildNodes.Item(1).InnerText)
                Else
                    .External = My.Resources.XCraft
                End If
                .Web = m_node.ChildNodes.Item(2).InnerText
            End With
            manufacturersList.Add(vendor)
        Next
    End Sub

    Private Sub SetManufacturerPicture()
        Dim dev As Device = DeviceList(lvwDevices.SelectedItems(0).Index)
        'Dim pctsetted As Boolean = False

        picManufacturer.Image = Nothing
        picDeviceImage.BackgroundImage = Nothing
        'picDeviceImage.Image = My.Resources.Raptor_X

        'try to detect manufacturer from device family
        For i As Short = 0 To manufacturersList.Count - 1
            If Not IsNothing(dev.Family) Then
                Dim re As New Regex(manufacturersList(i).RegExp, RegexOptions.IgnoreCase)
                If re.Match(dev.Family).Success Then
                    picManufacturer.Image = manufacturersList(i).Banner
                    If dev.Type = DeviceType.Removable Then
                        picDeviceImage.BackgroundImage = manufacturersList(i).External
                    Else
                        picDeviceImage.BackgroundImage = manufacturersList(i).Internal
                    End If
                    devPanel.Web = manufacturersList(i).Web
                    'pctsetted = True
                    Exit Sub
                End If
                'If dev.Family.ToLower.StartsWith(manufacturersList(i).RegExp.ToLower) Then
                'picManufacturer.Image = manufacturersList(i).Banner
                'If dev.Type = DeviceType.Removable Then
                'picDeviceImage.Image = manufacturersList(i).External
                'Else
                'picDeviceImage.Image = manufacturersList(i).Internal
                'End If
                'devPanel.Web = manufacturersList(i).Web
                'pctsetted = True
                'Exit Sub
                'End If
            End If
        Next

        'try to detect manufacturer from device model if the previous block have failed
        If IsNothing(picDeviceImage.BackgroundImage) Then 'pctsetted = False Then
            For i As Short = 0 To manufacturersList.Count - 1
                If Not IsNothing(dev.Model) Then
                    Dim re As New Regex(manufacturersList(i).RegExp, RegexOptions.IgnoreCase)
                    If re.Match(dev.Model).Success Then
                        picManufacturer.Image = manufacturersList(i).Banner
                        If dev.Type = DeviceType.Removable Then
                            picDeviceImage.BackgroundImage = manufacturersList(i).External
                        Else
                            picDeviceImage.BackgroundImage = manufacturersList(i).Internal
                        End If
                        devPanel.Web = manufacturersList(i).Web
                        'pctsetted = True
                        Exit Sub
                    End If
                    'If dev.Model.ToLower.StartsWith(manufacturersList(i).RegExp.ToLower) Then
                    'picManufacturer.Image = manufacturersList(i).Banner
                    'If dev.Type = DeviceType.Removable Then
                    'picDeviceImage.Image = manufacturersList(i).External
                    'Else
                    'picDeviceImage.Image = manufacturersList(i).Internal
                    'End If
                    'devPanel.Web = manufacturersList(i).Web
                    'pctsetted = True
                    'Exit Sub
                    'End If
                End If
            Next
        End If

        If IsNothing(picDeviceImage.BackgroundImage) Then
            If dev.Type = DeviceType.Removable Then
                picDeviceImage.BackgroundImage = My.Resources.XCraft
            Else
                picDeviceImage.BackgroundImage = My.Resources.Raptor_X
            End If
        End If
    End Sub

    Private Sub LoadOs()
        Dim os_folder As String = My.Application.Info.DirectoryPath & "\graphics\os\"

        Dim m_xmldoc As New XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode

        m_xmldoc.Load(os_folder & "os.xml")
        m_nodelist = m_xmldoc.SelectNodes("/os_list/os")

        osList.Clear()
        For Each m_node In m_nodelist
            Dim new_os As New OsItem
            With new_os
                .RegExp = m_node.ChildNodes.Item(0).InnerText
                .Logo = Image.FromFile(os_folder & m_node.ChildNodes.Item(1).InnerText)
            End With
            osList.Add(new_os)
        Next
    End Sub

    Private Sub SetOsPicture()
        Dim dev As Device = DeviceList(lvwDevices.SelectedItems(0).Index)

        picOsIcon.Image = Nothing

        For i As Short = 0 To osList.Count - 1
            If Not IsNothing(dev.OS) Then
                If dev.OS.ToLower.Contains(osList(i).RegExp.ToLower) Then
                    picOsIcon.Image = osList(i).Logo
                    Exit For
                End If
            End If
        Next
    End Sub
End Class
