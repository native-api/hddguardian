﻿'HDD Guardian is a GUI for smartctl utility, part of smartmontools
'
'home page is http://code.google.com/p/hddguardian/
'
'Copyright (C) 2010-2012  Samuele Parise
'
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License
'as published by the Free Software Foundation; either version 2
'of the License, or (at your option) any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program; if not, write to the Free Software
'Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Partial Class Main

    Dim healthlogpath As String = My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData. _
        Substring(0, My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData.LastIndexOf("\")) & "\logs\"

    Private Sub LoadLog(ByVal year As Integer, ByVal month As Integer, ByVal day As Integer)
        Dim logfilename As String = year & String.Format("{0:D2}", month) & _
            String.Format("{0:D2}", day) & ".log"
        Dim logfullpath As String = healthlogpath & logfilename

        With lvwLog
            .Items.Clear()
            .SmallImageList = imlLog

            If IO.File.Exists(logfullpath) Then
                .Visible = True
                flwLog.Visible = True
                lblNoLog.Visible = False

                Dim logcontent() As String = IO.File.ReadAllLines(logfullpath)

                For i As Integer = 0 To logcontent.Length - 1
                    If logcontent(i).Length = 0 Then Exit For
                    Dim Line() As String = logcontent(i).Split(vbTab, 6, StringSplitOptions.RemoveEmptyEntries)
                    If Line.Length <> 0 Then
                        .Items.Add(Line(1))
                        .Items(.Items.Count - 1).SubItems.Add(Line(0))
                        .Items(.Items.Count - 1).SubItems.Add(Line(2))
                        .Items(.Items.Count - 1).SubItems.Add(Line(3))
                        .Items(.Items.Count - 1).SubItems.Add(Line(4))
                        .Items(.Items.Count - 1).SubItems.Add(Line(5))

                        If Line(2) = "Remaining Life (%)" Or Line(2) = "Media Wearout Indicator" Or _
                                      Line(2) = "Wear Leveling Count" Or Line(2) = "SSD Life Left" Then
                            If Convert.ToSingle(Val(Line(5))) < 0 Then
                                .Items(.Items.Count - 1).ForeColor = Color.Red
                                .Items(.Items.Count - 1).ImageKey = "warning"
                            Else
                                .Items(.Items.Count - 1).ForeColor = Color.Blue
                                .Items(.Items.Count - 1).ImageKey = "ok"
                            End If
                        Else
                            If Convert.ToSingle(Val(Line(5))) > 0 Then
                                .Items(.Items.Count - 1).ForeColor = Color.Red
                                .Items(.Items.Count - 1).ImageKey = "warning"
                            Else
                                .Items(.Items.Count - 1).ForeColor = Color.Blue
                                .Items(.Items.Count - 1).ImageKey = "ok"
                            End If
                        End If
                    End If
                Next

                For ch As Integer = 3 To .Columns.Count - 1
                    .Columns(ch).Width = 60
                Next
                For ch As Integer = 0 To .Columns.Count - 5
                    .Columns(ch).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
                Next
                .Columns(2).Width = .ClientSize.Width - .Columns(0).Width - .Columns(1).Width - 180

                .HeaderStyle = ColumnHeaderStyle.Nonclickable
                .Enabled = True
            Else
                .Visible = False
                flwLog.Visible = False
                lblNoLog.Visible = True
            End If

        End With
    End Sub

    Private Sub DelCurrentLog(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelLog.Click
        With dteLog.Value
            Dim logfilename As String = .Year & .Month & .Day & ".log"
            IO.File.Delete(healthlogpath & logfilename)
        End With
    End Sub

    Private Sub DelAllLogs(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelAllLogs.Click
        If IO.Directory.GetFiles(healthlogpath).Length > 0 Then
            For Each file As String In IO.Directory.GetFiles(healthlogpath)
                If IsNumeric(IO.Path.GetFileNameWithoutExtension(file)) Then IO.File.Delete(file)
            Next
        End If
    End Sub

    Private Sub btnReload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReload.Click
        With dteLog.Value
            LoadLog(.Year, .Month, .Day)
        End With
    End Sub

    Private Sub btnToday_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnToday.Click
        dteLog.Value = Today
    End Sub

    Private Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click
        dteLog.Value = dteLog.Value.AddDays(-1)
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        dteLog.Value = dteLog.Value.AddDays(1)
    End Sub

    Private Sub dteLog_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dteLog.ValueChanged
        With dteLog.Value
            LoadLog(.Year, .Month, .Day)
        End With
    End Sub
End Class
